/*
Navicat MySQL Data Transfer

Source Server         : 59.56.69.152
Source Server Version : 50163
Source Host           : 59.56.69.152:3306
Source Database       : cps3

Target Server Type    : MYSQL
Target Server Version : 50163
File Encoding         : 65001

Date: 2017-08-11 00:27:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cps_access
-- ----------------------------
DROP TABLE IF EXISTS `cps_access`;
CREATE TABLE `cps_access` (
  `role_id` int(5) unsigned NOT NULL COMMENT '角色id',
  `node_id` int(5) unsigned NOT NULL COMMENT '节点id',
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1070 DEFAULT CHARSET=utf8 COMMENT='5.2.4权限表';

-- ----------------------------
-- Records of cps_access
-- ----------------------------
INSERT INTO `cps_access` VALUES ('4', '292', '1032');
INSERT INTO `cps_access` VALUES ('3', '291', '1039');
INSERT INTO `cps_access` VALUES ('1', '291', '1022');
INSERT INTO `cps_access` VALUES ('1', '290', '1021');
INSERT INTO `cps_access` VALUES ('1', '294', '1020');
INSERT INTO `cps_access` VALUES ('1', '281', '1019');
INSERT INTO `cps_access` VALUES ('1', '278', '1018');
INSERT INTO `cps_access` VALUES ('1', '195', '1017');
INSERT INTO `cps_access` VALUES ('1', '102', '1016');
INSERT INTO `cps_access` VALUES ('1', '287', '1015');
INSERT INTO `cps_access` VALUES ('2', '195', '895');
INSERT INTO `cps_access` VALUES ('2', '116', '894');
INSERT INTO `cps_access` VALUES ('2', '102', '893');
INSERT INTO `cps_access` VALUES ('7', '116', '817');
INSERT INTO `cps_access` VALUES ('4', '291', '1031');
INSERT INTO `cps_access` VALUES ('3', '290', '1038');
INSERT INTO `cps_access` VALUES ('1', '13', '1014');
INSERT INTO `cps_access` VALUES ('6', '292', '977');
INSERT INTO `cps_access` VALUES ('5', '292', '972');
INSERT INTO `cps_access` VALUES ('5', '291', '971');
INSERT INTO `cps_access` VALUES ('5', '278', '970');
INSERT INTO `cps_access` VALUES ('4', '290', '1030');
INSERT INTO `cps_access` VALUES ('4', '289', '1029');
INSERT INTO `cps_access` VALUES ('4', '294', '1028');
INSERT INTO `cps_access` VALUES ('4', '281', '1027');
INSERT INTO `cps_access` VALUES ('4', '278', '1026');
INSERT INTO `cps_access` VALUES ('4', '102', '1025');
INSERT INTO `cps_access` VALUES ('4', '287', '1024');
INSERT INTO `cps_access` VALUES ('1', '7', '1013');
INSERT INTO `cps_access` VALUES ('4', '13', '1023');
INSERT INTO `cps_access` VALUES ('5', '102', '969');
INSERT INTO `cps_access` VALUES ('5', '287', '968');
INSERT INTO `cps_access` VALUES ('5', '13', '967');
INSERT INTO `cps_access` VALUES ('6', '278', '976');
INSERT INTO `cps_access` VALUES ('6', '116', '975');
INSERT INTO `cps_access` VALUES ('6', '102', '974');
INSERT INTO `cps_access` VALUES ('6', '287', '973');
INSERT INTO `cps_access` VALUES ('3', '294', '1037');
INSERT INTO `cps_access` VALUES ('3', '281', '1036');
INSERT INTO `cps_access` VALUES ('3', '278', '1035');
INSERT INTO `cps_access` VALUES ('3', '102', '1034');
INSERT INTO `cps_access` VALUES ('3', '287', '1033');
INSERT INTO `cps_access` VALUES ('7', '107', '816');
INSERT INTO `cps_access` VALUES ('7', '102', '815');
INSERT INTO `cps_access` VALUES ('7', '51', '814');
INSERT INTO `cps_access` VALUES ('7', '14', '813');
INSERT INTO `cps_access` VALUES ('7', '13', '812');
INSERT INTO `cps_access` VALUES ('7', '8', '811');
INSERT INTO `cps_access` VALUES ('7', '7', '810');
INSERT INTO `cps_access` VALUES ('7', '118', '818');
INSERT INTO `cps_access` VALUES ('7', '134', '819');

-- ----------------------------
-- Table structure for cps_activity
-- ----------------------------
DROP TABLE IF EXISTS `cps_activity`;
CREATE TABLE `cps_activity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `abst` varchar(255) NOT NULL,
  `info` mediumtext NOT NULL,
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) NOT NULL,
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  `name` varchar(66) DEFAULT '' COMMENT '主题名称',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机',
  `username` varchar(32) DEFAULT '' COMMENT '姓名',
  `vehicle` varchar(11) DEFAULT NULL COMMENT '适合车辆',
  `circuit` varchar(255) DEFAULT NULL COMMENT '自驾线路',
  `notice` varchar(11) DEFAULT NULL COMMENT '注意事项',
  `price` text COMMENT '价格政策',
  `instructions` text COMMENT '活动目的',
  `place` varchar(255) DEFAULT NULL COMMENT '活动地点',
  `total` int(11) DEFAULT NULL COMMENT '活动人数',
  `uid` int(1) DEFAULT NULL COMMENT '状态（1、启用，0、关闭）',
  `data_state` char(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `cnt_show` int(11) unsigned DEFAULT '0' COMMENT '收藏数展示',
  `left_show` int(11) DEFAULT '0' COMMENT '余量展示',
  `cnt_reply` int(11) DEFAULT '0' COMMENT '余量展示',
  `date_begin` datetime DEFAULT NULL COMMENT '开始时间',
  `date_end` datetime DEFAULT NULL COMMENT '结束时间',
  `plan` text COMMENT '活动安排',
  `fee` varchar(255) DEFAULT NULL COMMENT '费用',
  `stick` varchar(255) DEFAULT NULL COMMENT '置顶',
  `region_name` varchar(256) DEFAULT NULL COMMENT '区域',
  `region_id` int(11) unsigned DEFAULT NULL COMMENT '区域id',
  `remark` varchar(255) DEFAULT NULL,
  `pv` int(11) unsigned DEFAULT '0',
  `update_time` datetime NOT NULL COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL,
  `update_username` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_best` (`is_best`),
  KEY `add_time` (`add_time`),
  KEY `cate_id` (`cate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_activity
-- ----------------------------
INSERT INTO `cps_activity` VALUES ('1', '1', '关于我们', '', '', '', '', '  <w:worddocument>   <w:view>Normal</w:view>   <w:zoom>0</w:zoom>   <w:trackmoves />   <w:trackformatting />   <w:punctuationkerning />   <w:drawinggridverticalspacing>7.8 磅</w:drawinggridverticalspacing>   <w:displayhorizontaldrawinggridevery>0</w:displayhorizontaldrawinggridevery>   <w:displayverticaldrawinggridevery>2</w:displayverticaldrawinggridevery>   <w:validateagainstschemas />   <w:saveifxmlinvalid>false</w:saveifxmlinvalid>   <w:ignoremixedcontent>false</w:ignoremixedcontent>   <w:alwaysshowplaceholdertext>false</w:alwaysshowplaceholdertext>   <w:donotpromoteqf />   <w:lidthemeother>EN-US</w:lidthemeother>   <w:lidthemeasian>ZH-CN</w:lidthemeasian>   <w:lidthemecomplexscript>X-NONE</w:lidthemecomplexscript>   <w:compatibility>    <w:spaceforul />    <w:balancesinglebytedoublebytewidth />    <w:donotleavebackslashalone />    <w:ultrailspace />    <w:donotexpandshiftreturn />    <w:adjustlineheightintable />    <w:breakwrappedtables />    <w:snaptogridincell />    <w:wraptextwithpunct />    <w:useasianbreakrules />    <w:dontgrowautofit />    <w:splitpgbreakandparamark />    <w:dontvertaligncellwithsp />    <w:dontbreakconstrainedforcedtables />    <w:dontvertalignintxbx />    <w:word11kerningpairs />    <w:cachedcolbalance />    <w:usefelayout />   </w:compatibility>   <w:browserlevel>MicrosoftInternetExplorer4</w:browserlevel>   <m:mathpr>    <m:mathfont m:val=\"Cambria Math\" />    <m:brkbin m:val=\"before\" />    <m:brkbinsub m:val=\"--\" />    <m:smallfrac m:val=\"off\" />    <m:dispdef />    <m:lmargin m:val=\"0\" />    <m:rmargin m:val=\"0\" />    <m:defjc m:val=\"centerGroup\" />    <m:wrapindent m:val=\"1440\" />    <m:intlim m:val=\"subSup\" />    <m:narylim m:val=\"undOvr\" />   </m:mathpr></w:worddocument> </xml><![endif]--><!--[if gte mso 9]><xml>  <w:latentstyles deflockedstate=\"false\" defunhidewhenused=\"true\" defsemihidden=\"true\" defqformat=\"false\" defpriority=\"99\" latentstylecount=\"267\">   <w:lsdexception locked=\"false\" priority=\"0\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Normal\" />   <w:lsdexception locked=\"false\" priority=\"9\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"heading 1\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 2\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 3\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 4\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 5\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 6\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 7\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 8\" />   <w:lsdexception locked=\"false\" priority=\"9\" qformat=\"true\" name=\"heading 9\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 1\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 2\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 3\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 4\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 5\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 6\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 7\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 8\" />   <w:lsdexception locked=\"false\" priority=\"39\" name=\"toc 9\" />   <w:lsdexception locked=\"false\" priority=\"35\" qformat=\"true\" name=\"caption\" />   <w:lsdexception locked=\"false\" priority=\"10\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Title\" />   <w:lsdexception locked=\"false\" priority=\"1\" name=\"Default Paragraph Font\" />   <w:lsdexception locked=\"false\" priority=\"11\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Subtitle\" />   <w:lsdexception locked=\"false\" priority=\"22\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Strong\" />   <w:lsdexception locked=\"false\" priority=\"20\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Emphasis\" />   <w:lsdexception locked=\"false\" priority=\"59\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Table Grid\" />   <w:lsdexception locked=\"false\" unhidewhenused=\"false\" name=\"Placeholder Text\" />   <w:lsdexception locked=\"false\" priority=\"1\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"No Spacing\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 1\" />   <w:lsdexception locked=\"false\" unhidewhenused=\"false\" name=\"Revision\" />   <w:lsdexception locked=\"false\" priority=\"34\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"List Paragraph\" />   <w:lsdexception locked=\"false\" priority=\"29\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Quote\" />   <w:lsdexception locked=\"false\" priority=\"30\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Intense Quote\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 1\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 2\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 3\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 4\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 5\" />   <w:lsdexception locked=\"false\" priority=\"60\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Shading Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"61\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light List Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"62\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Light Grid Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"63\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 1 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"64\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Shading 2 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"65\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 1 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"66\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium List 2 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"67\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 1 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"68\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 2 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"69\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Medium Grid 3 Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"70\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Dark List Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"71\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Shading Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"72\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful List Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"73\" semihidden=\"false\" unhidewhenused=\"false\" name=\"Colorful Grid Accent 6\" />   <w:lsdexception locked=\"false\" priority=\"19\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Subtle Emphasis\" />   <w:lsdexception locked=\"false\" priority=\"21\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Intense Emphasis\" />   <w:lsdexception locked=\"false\" priority=\"31\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Subtle Reference\" />   <w:lsdexception locked=\"false\" priority=\"32\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Intense Reference\" />   <w:lsdexception locked=\"false\" priority=\"33\" semihidden=\"false\" unhidewhenused=\"false\" qformat=\"true\" name=\"Book Title\" />   <w:lsdexception locked=\"false\" priority=\"37\" name=\"Bibliography\" />   <w:lsdexception locked=\"false\" priority=\"39\" qformat=\"true\" name=\"TOC Heading\" />  </w:latentstyles> </xml><![endif]--><!--[if gte mso 10]>\r\n<style>\r\n /* Style Definitions */\r\n table.MsoNormalTable\r\n	{mso-style-name:普通表格;\r\n	mso-tstyle-rowband-size:0;\r\n	mso-tstyle-colband-size:0;\r\n	mso-style-noshow:yes;\r\n	mso-style-priority:99;\r\n	mso-style-qformat:yes;\r\n	mso-style-parent:\"\";\r\n	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;\r\n	mso-para-margin:0cm;\r\n	mso-para-margin-bottom:.0001pt;\r\n	mso-pagination:widow-orphan;\r\n	font-size:10.5pt;\r\n	mso-bidi-font-size:11.0pt;\r\n	font-family:\"Calibri\",\"sans-serif\";\r\n	mso-ascii-font-family:Calibri;\r\n	mso-ascii-theme-font:minor-latin;\r\n	mso-hansi-font-family:Calibri;\r\n	mso-hansi-theme-font:minor-latin;\r\n	mso-bidi-font-family:\"Times New Roman\";\r\n	mso-bidi-theme-font:minor-bidi;\r\n	mso-font-kerning:1.0pt;}\r\n</style>\r\n<![endif]--><p class=\"MsoNormal\"><span style=\"font-family:宋体;mso-ascii-font-family:Calibri;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:宋体;mso-fareast-theme-font:minor-fareast;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;\">wegou是国内时尚返利购物社区，致力于为用户提供最好时尚购物体验，用最好的互联网技术为用户解决“如何网购更省钱”的问题。</span></p>', '2012-03-17 11:30:14', '0', '1', '1', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('13', '1', '赚取积分', '', '', '', '赚取积分', '<p><b><span style=\"color:#666666;\">1 什么是积分？</span></b></p>\r\n<p><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 积分是就是根据您在我们网站上的活跃情况，给与您的奖励，是一笔虚拟财富！</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">2 积分的用处？</span></b></p>\r\n<p><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 积分可以用于兑换我们提供的精美礼品！</span></p>\r\n<p><span style=\"color:#999999;font-size:12px;\"><br />\r\n</span></p>\r\n<p></p>\r\n<p><b><span style=\"color:#666666;\">3 赚取积分的方法</span></b>？</p>\r\n<p><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 赚取积分，可以按以下要点操作：</span></p>\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 1、每天登录网站，积分加+21</span><span style=\"color:#999999;font-size:12px;\">；</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 2、每分享一个商品，积分+21；</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 3、新用户注册，赠送51积分；</span><br />\r\n<p><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 4、网站活动获奖奖励积分</span></p>', '2012-08-04 18:57:34', '0', '1', '0', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('3', '1', '联系我们', '', '', '', '', '<p>联系电话：010-66668888</p>\r\n<p>&nbsp;</p>\r\n<p>官方网站：htt</p>\r\n<br />\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', '2012-03-17 11:32:08', '0', '0', '0', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('21', '11', '测试标题sssss', 'fasdfasdf', '58d389eae1dc4.jpg', 'ddddddddddddd', 'fadsfasdf', '<span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span><span>adfasdfas发生大幅度的的顶顶顶顶顶顶顶顶顶顶的顶顶顶顶顶顶顶顶顶顶的方法反反复复凤飞飞凤飞飞</span>', '2017-03-23 16:40:10', '0', '1', '1', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('22', '9', '测试添加成功跳转ssss', '', '58d38ade353b7.jpg', '', '测试添加成功跳转测试添加成功跳转', '<h1 class=\"QuestionHeader-title\" style=\"font-weight:400;font-size:24px;font-family:\" color:#1e1e1e;background-color:#ffffff;\"=\"\">\r\n	后台管理员操作日志怎么记录？（ PHP MYSQL）\r\n	</h1>\r\n<div class=\"QuestionHeader-detail\" style=\"color:#262626;font-family:\" font-size:15px;background-color:#ffffff;\"=\"\">\r\n	<div class=\"QuestionRichText QuestionRichText--expandable\">\r\n		<span class=\"RichText\">一个电商网站后台 然后要记录每个管理人员的操作明细， 修改了那些内容 添加了那些内容，比如：添加了什么商品，属性都是什么，订单修改状态之类的。 后台超管还可查看管理人员都改了哪些东西</span> \r\n	</div>\r\n		</div>', '2017-03-23 16:44:14', '1', '1', '1', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '2017-03-23 17:23:42', '1', 'admin');
INSERT INTO `cps_activity` VALUES ('7', '9', '国际品牌包包免费试用 ', '', '4f640f80f14d9.jpg', '?a=index&m=cate&cid=3', '国际品牌包包免费试用 ', '', '2012-03-17 12:13:53', '0', '1', '1', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('8', '9', '美丽清爽夏装免费试穿', '', '4f640fe112c89.jpg', '?a=index&m=cate&cid=1', '美丽清爽夏装免费试穿', '', '2012-03-17 12:15:29', '0', '1', '1', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('9', '9', '清凉夏季凉鞋免费试穿 ', '', '', '?a=index&m=cate&cid=2', '清凉夏季凉鞋免费试穿', '', '2012-03-17 12:15:49', '0', '1', '1', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('10', '9', '知名品牌化妆品免费试用', '', '', '?a=index&m=cate&cid=5', '知名品牌化妆品免费试用', '', '2012-03-17 12:16:01', '3', '1', '1', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('11', '9', '七夕到 鹊桥会 好礼送', '', '502e0eec7af0a.jpg', '?a=index&m=cate&cid=4', '七夕好礼，千万配饰商品等你来拿！\r\n', '', '2012-03-17 12:16:33', '2', '1', '1', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('12', '10', '不错的内容哦', '', '', '', '不错的内容哦', '不错的内容哦不错的内容哦不错的内容哦不错的内容哦不错的内容哦111111111111111<br />', '2012-06-21 16:14:34', '1', '1', '0', '0', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('14', '1', '如何返利', '', '', '/index.php?a=index&m=article&id=17', '如何返利', '如何返利<br />', '2012-08-17 14:51:37', '0', '1', '0', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('17', '5', ' 返利常见问题', '', '', '', '', '<b><span style=\"color:#666666;\">1 什么是返利？</span></b><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n您通过本站去商家店铺购买商品，商家会通过购物网支付给本站一定的推广佣金，本站会将这笔佣金的大部分返还给您。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n假设您在淘宝网看中一个100元的宝贝，通过本站查询该宝贝现金返利金额为10元，通过查询结果中的购买进入淘宝网购物，在确认收货后，我们就会给予您10元的现金返利，您申请提现后我们会将这 笔钱提现到您指定的支付宝账户内。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp; 所以，通过本站去购物可以让您获得更多实惠。</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">2 返利的钱从哪里来的？是我多付了钱吗？</span></b> </p>\r\n<p>&nbsp;&nbsp; <span style=\"color:#999999;font-size:12px;\">您好，您并未多付钱，购物网商家为了加大商品的销售渠道，建立了一种付费推广机制，在收入中专门预留了一部分给合作推广渠道。而本站就是购物网推广渠道高级合作伙伴之一，本站会将通过推广 获得的佣金大部分返还给您，您可以将这部分钱直接转账到您的支付宝帐户里，让您购物更加省钱！</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">3 店家会不会是提高了宝贝价格所以才给返利的钱？</span></b></p>\r\n&nbsp;&nbsp; <span style=\"font-size:12px;color:#999999;\">当然不是！合理的推广费用是一个网店必要的成本开支，这笔费用与商品的售价无关，因此您完全不必担心是因为宝贝价格高，多付了钱财获得了返利。</span><br />\r\n<span style=\"font-size:12px;\"> </span><span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 举例，您去一个淘宝店铺买一个价值100元的宝贝，无论是否通过本站，您购买该宝贝都需要支付100元，但是通过本站过去购买，您就能额外获得一定比例的返利，这样不是更省钱吗？</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">4 一定要通过本站去购物才能获得返利吗？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">不一定哦！在本站不购物一样可以赚到返利哦！</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n推荐好友注册可获得推广奖励（永久）；可登录本站后在会员中心查看具体详情和推广链接。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">5 购物多久我才能得到现金返利？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">您好，您通过本站去购物网购物后，在购物网确认收货后的24小时内，我们会将返利加到您的本站会员帐户里。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">6 现金返利有什么用？我可以直接拿来购物吗？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，因为本站是个返利导航站，不出售任何商品，所以现金返利不能直接用来购物。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n当您的现金返利到账后，您可以在“会员中心-我的返利”处申请提现到您的支付宝。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">7 通过本站去购物还能享受店铺本来的优惠吗？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，完全可以！通过本站去购物网购物，丝毫不会影响到您在购物网的权益。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">8 我退换货了，返利怎么计算？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，退货商品无返利，如一单中有部分退货，则符合返利规则的未退货部分有返利；</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n换货的话，符合返利规则，换一样的商品有返利，换其他商品无返利。如有问题可联系本站在线客服。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">9 如何挑选宝贝才能获得返利啊？有特别的要求吗？</span></b></p>\r\n&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">您好，挑选宝贝没有任何特别的要求，可通过以下几种方式挑选宝贝：</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;\r\n1，通过本站页面顶部的搜索框，搜索您需要的宝贝或店铺挑选宝贝；</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;\r\n2，您也可以先在淘宝网、淘宝商城挑选好您需要的宝贝或店铺名称，然后复制宝贝名称，再通过本站顶部搜索框搜索。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">10 如何查询我挑选的宝贝的返利啊？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">本站为会员提供宝贝返利查询通道，在搜索框中输入您要查询的宝贝名称，点击“搜索返利”即可。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">11 如何购物才能获得返利？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，要获得返利，可在“返利”页面的搜索返利框，输入您要购买的宝贝名称，通过查询结果里的“购物按钮”去宝贝页面购买，才能获得返利。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n亦可通过店铺页面，选择您要购物的店铺直接去店铺购物，只要不跳转到其他店铺或使用页面上方的搜索框，也可获得返利。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">12 返利从何而来？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">各大购物网为了推广商品和店铺，推出了（网站联盟）计划。本站参加了网站联盟计划，因此本站通过引导用户购物，就可以从购物网获得一定比例的佣金。本站将所获得的绝大部分佣金都返利给会 员，这就是返利的来源。</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;&nbsp;\r\n您可以先前往淘宝网挑选好商品，然后通过本站的返利通道，查询返利并购买。同样的商品、同样的价格，不一样的是额外的返利，更加的省钱。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">13 购物为什么不是所有宝贝返利都有40%，甚至有的查询不到？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">每件商品的返利比例，是由购物网卖家来确定的，因此每个店铺的返利比例都会不同。一些商品，例如化妆品、服装类、食品类等，因为利润较高，所以返利比例较高；而电子产品一类，利润空间较 低，所以返利比例相应会低一些。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n还有少数的卖家没有参加网站联盟计划，如果用户购买这些卖家提供的商品，都是没有返利的。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n但是，也有一些商城的卖家虽然没有参加网站联盟推广，通过返利查询不到返利的，但最后还是能从本站拿到返利。这是因为：购物网将自己的收入拿出来进行推广（购物商城入驻都要按照销售额的 一定比例支付给购物网），本站收到这部分的佣金后，也会一样返利给用户的。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">14 返利什么时间可以到账？</span></b></p>\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp; &nbsp; 购物网支付佣金给联盟网站的时间周期，一般来讲都有1-2个月，而本站为了方便会员的返利及时到账，在没有收到购物网的佣金之前，就先行垫付给会员了。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n所以用户在购物网“确认收货”后24小时内，本站会根据购物网反馈的信息同时将返利与订单加到用户在本站的会员帐户里。(若确认收货后3天还未查看到订单请先确认是否严格按照淘宝返利流程操 作，如果是请尽快联系本站在线客服查询)</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">15 如何避免返利掉单？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">除了淘宝聚划算，都要通过返利通道一，或者返利通道二，查询返利后再购买。特别提醒：只有通过“购物拿返利”的按钮，才能保证获得返利。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n其次，购物网站一般都是通过用户浏览器的Cookie值来判断用户来源。如果用户经常访问一些来路不明的网站，那么建议用户在购物拿返利之前，最好能清除一下浏览器的Cookie值，以保证不会被购物网误认为是来源于其他网站而无法得到返利。当然，如果嫌麻烦，这个步骤是可以省略的，前提是不要随意访问来路不明的网站。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n最后，要确保自己的电脑没有中毒，经常杀毒并养成良好的上网习惯，不要访问来路不明的网站，或者随意下载软件。一些病毒就是通过劫持用户浏览器的方式，窃取用户购物返利，而这一切都是很多用户通常所无法察觉出来的。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">16 返利掉单后怎么办？</span></b></p>\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;&nbsp; 一旦发现自己按照本站的购物返利流程，还是发生购物掉单的问题，建议马上联系本站的在线客服，提交购物的凭证，以方便本站能够与购物网联系，并帮助用户找回返利。</span><br />\r\n<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;&nbsp;\r\n另外，要马上检查自己的电脑是否中毒，是否被安装了非法的浏览器插件，要进行严格的杀毒。目前发现的很多浏览器劫持插件，都不能被杀毒软件及时发现，这个时候就需要重装电脑系统，以确保您能获得应得的返利。</span><br />\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">17 为何实际拿到的返利与查询的不符？</span></b></p>\r\n&nbsp;<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您好，返利金额与购买时候查询到的返利金额不同一般是以下2种情况：</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 1，具体返利金额是根据您支付的金额按一定比例返利的。所以如果您实际的支付金额少于原价，那返利也会相应减少。</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; 比如：查询显示宝贝价格为 100元，返利为20元。（返利比例为 20%）&nbsp;&nbsp; 实际您在购买该宝贝的时候支付的金额为50元（如商家促销、优惠降价、还价等），那么实际最终获得的返利=实际支付金额*返利比例=50*20%=10元。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 2，返利是按最后支付时作为确认，若正好卖家在您支付之前正好在调整商品的返利佣金比例，也会导致最后获得的返利与查询到的返利不符。（返利查询是通过购物接口读取物品传输的数据，存在一定的延迟）</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 因受购物网平台的技术所限，暂无法做到100%保证用户查询时的返利与实际获得的返利相符（可能会多也可能会少），本站已经就这些用户遇到的实际问题积极向购物网反馈，争取给用户更好的返利体验。</span></p>\r\n<p>&nbsp;</p>\r\n<p><b><span style=\"color:#666666;\">18 购物是否能100%获得返利？</span></b></p>\r\n&nbsp;&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，因受购物网平台的技术所限，需用户确认收货后24小时内购物网才反馈给我们订单信息，故购物返利跟单存在一定风险性，因此本站目前无法100%保证您能够获得返利，就此问题本站已经积极向购物网反馈，争取给予用户更好的购物返利体验。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><p><span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 另下列已知操作方式，本站不保证可获得返利：</span></p>\r\n<span style=\"font-size:12px;color:#999999;\"> </span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n1，通过本站“购物返利”搜索商品进入购物网后，从搜索结果进入的所有商品都有返利，但进入商品页面后再使用“购物网”的搜索，二次搜索的结果里的商品不保证有返利；</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n2，通过“店铺”页面的任何链接进入购物网后，进入的第一个购物网店铺购物有返利，进入第一个店铺再跳转到其他店铺或通过购物网的搜索购物，不保证有返利；</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;&nbsp;\r\n强烈建议：每次去购物都从本站“购物返利”页面点击进入商品页（不论是通过搜索宝贝、查询返利还是通过“店铺”进入）</span><br />', '2012-09-12 14:23:21', '0', '1', '0', '0', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('18', '5', '返利订单问题', '', '', '', '', '<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 在您下单之前，请您先详细了解一下本站返利的相关操作流程，如果您确认自己的操作无误但是仍然无法生成订单，请联系我们本站在线客服。</span><br />', '2012-09-12 14:26:32', '0', '1', '0', '0', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('19', '5', '现金返利提现问题666', '', '', '', '', '<b><span style=\"color:#666666;\">1 什么是现金返利？</span></b><br />\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 通过本站去各大购物商城、淘宝店铺购物后获得的返利即为现金返利，只有现金返利可进行提现操作。</span>\r\n</p>\r\n<p>\r\n	<b><br />\r\n</b>\r\n</p>\r\n<p>\r\n	<b><span style=\"color:#666666;\">2 如何申请返利提现？</span></b>\r\n</p>\r\n<p>\r\n	&nbsp;<span style=\"color:#999999;font-size:12px;\">&nbsp; 您好，当您的帐户现金返利时即可申请提现，您可以点击“会员中心-我的返利”申请返利提现，返利提现需先进行“收款信息设置”按照要求设置完毕后才能申请。</span>\r\n</p>\r\n<p>\r\n	<b><br />\r\n</b>\r\n</p>\r\n<p>\r\n	<b><span style=\"color:#666666;\">3 为什么我申请不了提现？提现按钮是灰色的？</span></b>\r\n</p>\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您好，返利提现需满足2个条件才能申请提现。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 1，您的帐户返利有余额；</span><br />\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 2，您已经在“收款信息设置”里设置过收款帐户信息。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">4 我申请的返利提现多久能收到呢？</span></b><span style=\"color:#666666;\"> </span><br />\r\n<p>\r\n	&nbsp;<span style=\"font-size:12px;color:#999999;\">&nbsp; 您好，会员申请提现后，本站工作人员会在1~3个工作日内把钱支付到您在本站填写提交的收款帐户里，支付宝收款用户可实时到账。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">5 提现只能整数兑吗？</span></b><br />\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您好，本站对提现没有限制，只要您账户有余额均可以提现。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">6 我填错收款信息了，不想提现了怎么办啊？</span></b><br />\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您可以及时联系本站在线客服帮你驳回申请，并按照要求修改收款帐户信息后重新申请提现即可。对于已经成功提现的申请将无法取消。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">7 为什么我的提现被驳回了？</span></b><br />\r\n<p>\r\n	&nbsp;<span style=\"font-size:12px;color:#999999;\">&nbsp; 您好，提现申请被驳回可能是您的收款信息填写错误，具体您可以查看站内信里的具体驳回原因，如果还是不清楚可联系本站在线客服帮您解决。</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<b><span style=\"color:#666666;\">8 返利提现时需要手续费吗？</span></b>\r\n</p>\r\n<p>\r\n	<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp; 您好，如果您的收款帐户为支付宝帐户，提现时无需手续费（提现手续费由本站承担）。</span>\r\n</p>', '2012-09-12 14:27:23', '0', '1', '0', '0', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('20', '5', '用户常见问题3456', '', '', '', '', '<b><span style=\"color:#666666;\">1 为什么实际拿到的返利金额和当时购买东西时查询到的返利金额不一样呢？</span></b> <br />\r\n<span style=\"color:#999999;font-size:10px;\">&nbsp;&nbsp; <span style=\"font-size:12px;\">您好，返利金额与购买时候查询到的返利金额不同一般是以下2种情况：</span></span><br />\r\n<span style=\"font-size:12px;\"> </span><span style=\"font-size:12px;\"> </span><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 1，具体返利金额是根据您支付的金额按一定比例返利的。所以如果您实际的支付金额少于原价，那返利也会相应减少。</span><br />\r\n<p>\r\n	<span style=\"font-size:12px;\"> </span><span style=\"font-size:12px;\"> </span><span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp; 2，在您拍下商品到支付完成期间，正好卖家在调整商品的返利佣金比例，也会导致最后获得的返利与查询到的返利不符。（返利查询是通过购物接口读取物品传输的数据，存在一定的延迟）</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">2 为什么开始我要买的宝贝能查到返利，现在查不到了呢？</span></b><br />\r\n<p>\r\n	&nbsp;<span style=\"font-size:12px;\">&nbsp;</span><span style=\"color:#999999;font-size:12px;\">您好，返利是由该店铺卖家决定的，店铺卖家可随时更改调整店铺中各宝贝的返利比例，用户实际获得返利以支付时该宝贝的返利比例为准。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">3 我在下单了为什么看不到订单？</span></b><br />\r\n<p>\r\n	&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，返利与其他购物商城返利不同，购物后需在购物网“确认收货”后（24小时内）方可查看到相应的订单信息。若“确认收货”3天后还看不到订单信息请再详细查看下返利的相关步骤说明，确认所有 操作都没问题后，及时联系本站在线客服人员帮您查询处理。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">4 如何使用购物车购物获得返利？</span></b><br />\r\n<p>\r\n	&nbsp;<span style=\"font-size:12px;\">&nbsp;</span><span style=\"color:#999999;font-size:12px;\">您好，因目前订单跟踪方面存在一定技术问题，所以在购物车购物时必须注意“不同店铺卖家的商品建议不要使用购物车购买”，否则很可能会出现无法跟到订单从而无法获得返利。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">5 购物为什么同一批有的订单拿到返利了有的没拿到？我用的购物车购物的.</span></b><br />\r\n<p>\r\n	&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\">您好，购物车购物是根据购物车里的各子订单是否有效判定的。如果购物车中的子订单不符合返利规则要求（任何形式的退款，包括部分退款，退运费等），则该子订单会被判为无效。</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#999999;font-size:12px;\"><br />\r\n</span> \r\n</p>\r\n<b><span style=\"color:#666666;\">6 同样的商品我购买了多件，返利如何计算啊？</span></b><br />\r\n<p>\r\n	<span style=\"color:#999999;\">&nbsp;&nbsp;</span><span style=\"font-size:12px;color:#999999;\">您好，返利是按单件商品计算的，同样的商品购买多件，返利会按件数叠加累计。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b><span style=\"color:#666666;\">7 购物返利返的不都是现金吗,为什么会有返金币的？</span></b><br />\r\n&nbsp;&nbsp;<span style=\"color:#999999;font-size:12px;\"> 您好，购物返利大部分是返现金，只有个别商城如 当当网、麦网 等因商城不允许直接给用户</span><br />\r\n<p>\r\n	<span style=\"color:#999999;font-size:12px;\">&nbsp;&nbsp;\r\n返现金，所以我们将现金返利按同等比例以金币的形式返还给用户。（金币=现金）</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#999999;font-size:12px;\"><br />\r\n</span> \r\n</p>\r\n<b><span style=\"color:#666666;\">8 购物后的现金返利是返到哪里的啊?</span></b><br />\r\n<p>\r\n	&nbsp;&nbsp;<span style=\"font-size:12px;color:#999999;\">您好，购物后的现金返利和金币返利都是直接加到您在本站的会员帐户里，现金返利到本站账户即可提现到您的支付宝里，金币返利可用于玩本站的金币游戏或兑换礼品。</span> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<b> <span style=\"color:#666666;\">9 为什么明明我是通过本站去购物的，结果我没有拿到返利？</span></b><br />\r\n<span style=\"font-size:12px;color:#999999;\">&nbsp;&nbsp;\r\n您好，本站是根据购物商城（淘宝网、凡客诚品等）反馈的订单信息给予用户返利的，目前有2种情况会导致您明明是通过本站去购物的，但购物商城判定该订单不属于本站的，从而无法获得返利。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp; 1，您有访问过其他相关购物类的站点：一般购物商城会通过COOKIES记录您的访问来源，如果您在近期有访问过这类站点再访问本站，很可能会导致订单被判定不属于本站，从而无法获得返利。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp;&nbsp; 解决办法：删除浏览器的 COOKIES 记录。&nbsp; （点击查看如何删除各浏览器的COOKIES记录）</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp; 2，您的电脑被安装了拦截木马：有些购物类站点会有这类非法的推广链接拦截替换木马，对您的购物链接进行拦截，并在你购物的时候将链接替换成他们的推广链接。因这类木马只是拦截替换链接，修改特定参数且只针对个别商城（如淘宝网等），对电脑本身包括用户安全等无害，所以杀毒软件一般无法查杀这类恶意插件木马。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> &nbsp;&nbsp;&nbsp;&nbsp; 解决办法：重新安装系统，或换台机器，并且尽量不要去访问一些没有正规网络备案的非法站点和个人主页。</span><br />\r\n<span style=\"font-size:12px;color:#999999;\"> </span><br />\r\n<br />\r\n<br />', '2012-09-12 14:27:58', '0', '1', '0', '1', '', '', '', '', '', '', null, null, null, null, null, null, null, null, '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '0000-00-00 00:00:00', null, null);
INSERT INTO `cps_activity` VALUES ('23', '9', 'php后台操作日志怎么做，记录数据库操作', '', '', '', 'php后台操作日志怎么做，记录数据库操作\r\nberryblue | 浏览 2165 次\r\n发布于2016-01-18 11:49 最佳答案\r\n解决方案：\r\n插入数据库\r\n$db->先创建一个log表, \']，有id,$username;];update\'，登录后都有的吧\r\nif(in_array($action, action;$username就是当前操作人的名字了;;/, username;这里可以把时间和$query_string处理一下,\'，可添加\r\n$query_string = $_SERVE', '<div class=\"wgt-ask accuse-response line mod-shadow \" id=\"wgt-ask\" style=\"color:#333333;font-family:\" font-size:14px;background-color:#ffffff;\"=\"\">\r\n<h1 style=\"font-size:16px;\">\r\n	<span class=\"ask-title \" style=\"font-size:24px;line-height:34px;font-weight:400;\">php后台操作日志怎么做，记录数据库操作</span> \r\n</h1>\r\n<div class=\"line f-aid ask-info ff-arial\" id=\"ask-info\" style=\"font-size:12px;color:#9EADB6;\">\r\n	<span class=\"grid-r ask-time\"> \r\n	<div class=\"others-share\">\r\n		<a target=\"_blank\" class=\"others-share-item weixin iknow-qb_share_icons\"><span class=\"logo\" style=\"color:#BFCAD5;line-height:28px;\"></span></a><a href=\"http://v.t.sina.com.cn/share/share.php?url=http%3A%2F%2Fzhidao.baidu.com%2Fquestion%2F1947579271168463308%3Fsharesource%3Dweibo&title=php%E5%90%8E%E5%8F%B0%E6%93%8D%E4%BD%9C%E6%97%A5%E5%BF%97%E6%80%8E%E4%B9%88%E5%81%9A%EF%BC%8C%E8%AE%B0%E5%BD%95%E6%95%B0%E6%8D%AE%E5%BA%93%E6%93%8D%E4%BD%9C_%E7%99%BE%E5%BA%A6%E7%9F%A5%E9%81%93&pic=https%3A%2F%2Fgss0.bdstatic.com%2F70cFsjip0QIZ8tyhnq%2Fimg%2Fiknow%2Fzhidaologo.png\" target=\"_blank\" class=\"others-share-item weibo iknow-qb_share_icons\"><span class=\"logo\" style=\"color:#BFCAD5;line-height:28px;\"></span></a><a href=\"http://connect.qq.com/widget/shareqq/index.html?url=http%3A%2F%2Fzhidao.baidu.com%2Fquestion%2F1947579271168463308%3Fsharesource%3Dqq&title=php%E5%90%8E%E5%8F%B0%E6%93%8D%E4%BD%9C%E6%97%A5%E5%BF%97%E6%80%8E%E4%B9%88%E5%81%9A%EF%BC%8C%E8%AE%B0%E5%BD%95%E6%95%B0%E6%8D%AE%E5%BA%93%E6%93%8D%E4%BD%9C_%E7%99%BE%E5%BA%A6%E7%9F%A5%E9%81%93&pics=https%3A%2F%2Fgss0.bdstatic.com%2F70cFsjip0QIZ8tyhnq%2Fimg%2Fiknow%2Fzhidaologo.png\" target=\"_blank\" class=\"others-share-item qq iknow-qb_share_icons\"><span class=\"logo\" style=\"color:#BFCAD5;line-height:28px;\"></span></a><a href=\"http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=http%3A%2F%2Fzhidao.baidu.com%2Fquestion%2F1947579271168463308%3Fsharesource%3Dqzone&title=php%E5%90%8E%E5%8F%B0%E6%93%8D%E4%BD%9C%E6%97%A5%E5%BF%97%E6%80%8E%E4%B9%88%E5%81%9A%EF%BC%8C%E8%AE%B0%E5%BD%95%E6%95%B0%E6%8D%AE%E5%BA%93%E6%93%8D%E4%BD%9C_%E7%99%BE%E5%BA%A6%E7%9F%A5%E9%81%93&pics=https%3A%2F%2Fgss0.bdstatic.com%2F70cFsjip0QIZ8tyhnq%2Fimg%2Fiknow%2Fzhidaologo.png\" target=\"_blank\" class=\"others-share-item qzone iknow-qb_share_icons\"><span class=\"logo\" style=\"color:#BFCAD5;font-size:18px;line-height:28px;\"></span></a> \r\n	</div>\r\n</span><a class=\"\" href=\"http://zhidao.baidu.com/usercenter?uid=b0944069236f25705e79a618\" target=\"_blank\">berryblue</a>&nbsp;<span id=\"v-times\" class=\"f-pipe\" style=\"color:#E8ECEE;vertical-align:middle;background:#E8ECEE;\">|</span><span class=\"browse-times\">&nbsp;浏览 2165 次</span> \r\n</div>\r\n	</div>\r\n<div class=\"wgt-best mod-shadow  \" id=\"best-answer-2411180585\" style=\"font-family:\" padding:0px=\"\" 0px=\"\" 28px;color:#333333;font-size:14px;background:0px=\"\" #ffffff;\"=\"\">\r\n	<div class=\"hd line \" style=\"margin:0px;\">\r\n		<span class=\"grid-r f-aid pos-time answer-time f-pening\" style=\"font-size:12px;color:#A4B4BB;line-height:26px;\">发布于2016-01-18 11:49</span> \r\n		<div id=\"act-link-banner-wp\" class=\"grid-r\">\r\n		</div>\r\n<span class=\"iknow-qb_home_icons answer-type answer-best grid\" style=\"vertical-align:middle;color:#4ACA5D;font-size:28px;line-height:1;font-family:iknow-qb_home_icons !important;\"></span><span class=\"answer-title h2 grid\" style=\"font-size:22px;font-family:\" color:#35b558;\"=\"\">最佳答案</span> \r\n	</div>\r\n	<div class=\"bd answer\" id=\"answer-2411180585\" style=\"margin:0px;\">\r\n		<div class=\"line info f-aid\" style=\"font-size:12px;color:#9EADB6;\">\r\n		</div>\r\n		<div class=\"line content\">\r\n<pre id=\"best-content-2411180585\" class=\"best-text mb-10\">解决方案：\r\n插入数据库\r\n$db-&gt;先创建一个log表, \']，有id,$username;];update\'，登录后都有的吧\r\nif(<a href=\"https://www.baidu.com/s?wd=in_array&tn=44039180_cpr&fenlei=mv6quAkxTZn0IZRqIHckPjm4nH00T1Y3n199nhRkmWmvrjFBrHTz0ZwV5Hcvrjm3rH6sPfKWUMw85HfYnjn4nH6sgvPsT6KdThsqpZwYTjCEQLGCpyw9Uz4Bmy-bIi4WUvYETgN-TLwGUv3EnHbYP1RLrHcLnHDvrjfvn1nsr0\" target=\"_blank\" class=\"baidu-highlight\">in_array</a>($action, action;$username就是当前操作人的名字了;;/, username;这里可以把时间和$query_string处理一下,\'，可添加\r\n$query_string = $_SERVER[\', query;, time 等字段，可以自己定义;delete\',$username,$query_string);edit\'，如果需要记录更多。比如;)))\r\n{\r\naddlog($action;/QUERY_STRING\',这个最好处理一下\r\n$action = $_REQUEST[\'///查询(query)的字符串?action=add&amp;id=xx\r\n/,\'action\';操作类型, array(\'add\'/\r\n}\r\nfunction addlog($action,$query_string)\r\n{\r\n/query($sql);\r\n}</pre>\r\n		</div>\r\n	</div>\r\n</div>', '2017-03-23 17:26:03', '0', '1', '1', '1', '', '', '', '', '', 'admin', null, null, null, null, null, null, null, '1', '1', '0', '0', '0', '0', null, null, null, null, null, null, null, null, '0', '2017-03-23 17:29:37', '1', 'admin');

-- ----------------------------
-- Table structure for cps_ad
-- ----------------------------
DROP TABLE IF EXISTS `cps_ad`;
CREATE TABLE `cps_ad` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `board_id` smallint(5) NOT NULL,
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `code` text NOT NULL,
  `start_time` int(10) NOT NULL,
  `end_time` int(10) NOT NULL,
  `clicks` int(10) NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL,
  `ordid` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `board_id` (`board_id`,`start_time`,`end_time`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_ad
-- ----------------------------
INSERT INTO `cps_ad` VALUES ('6', '6', 'image', '59秒开放平台', 'http://www.59miao.com', '50165dc897fbe.jpg', '1333595088', '1365217491', '103', '1333681516', '1', '0');
INSERT INTO `cps_ad` VALUES ('7', '5', 'code', '凡客', '', '<a href=\"http://r.59miao.com/?e=103098&s=1064&a=\" target=\"_blank\"><img border=\"0\" src=\"http://www.duomai.com/Public/Uploads/d5755cdbca7ca21daccf62114f129dba.gif\" alt=\"格子衬衫 79元起\" /></a>', '1333683143', '1365219146', '11', '1333683151', '2', '0');

-- ----------------------------
-- Table structure for cps_adboard
-- ----------------------------
DROP TABLE IF EXISTS `cps_adboard`;
CREATE TABLE `cps_adboard` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `width` smallint(5) NOT NULL,
  `height` smallint(5) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_adboard
-- ----------------------------
INSERT INTO `cps_adboard` VALUES ('1', '首页焦点图', 'focus', '580', '280', '', '0');
INSERT INTO `cps_adboard` VALUES ('4', '详细页横幅', 'banner', '950', '100', '', '0');
INSERT INTO `cps_adboard` VALUES ('5', '详细页右侧', 'banner', '226', '226', '', '1');
INSERT INTO `cps_adboard` VALUES ('6', '首页下方横幅', 'banner', '960', '100', '', '0');

-- ----------------------------
-- Table structure for cps_admin
-- ----------------------------
DROP TABLE IF EXISTS `cps_admin`;
CREATE TABLE `cps_admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号，自增长',
  `user_name` varchar(50) NOT NULL DEFAULT '' COMMENT '账号（唯一客户经理编号）',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `add_time` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `last_time` int(10) DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态，1激活、0禁用',
  `role_id` int(10) NOT NULL DEFAULT '6' COMMENT '角色标识',
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `user_id` varchar(50) NOT NULL COMMENT '客户经理姓名',
  `mobile` varchar(13) DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) NOT NULL COMMENT '电子信箱',
  `ip` varchar(15) NOT NULL,
  `account` varchar(32) DEFAULT NULL COMMENT '收款账户信息（结算账户）',
  `data_state` tinyint(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `pid` int(10) unsigned DEFAULT NULL COMMENT '父id',
  `address` varchar(10) DEFAULT NULL COMMENT '家庭地址',
  PRIMARY KEY (`id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='5.2.1后台用户表';

-- ----------------------------
-- Records of cps_admin
-- ----------------------------
INSERT INTO `cps_admin` VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1502373188', null, '1', '1', null, 'cps平台', null, '', '', null, '1', null, null);
INSERT INTO `cps_admin` VALUES ('11', 'mingshengshangcheng', 'dc483e80a7a0bd9ef71d8cf973673924', '1502373629', '1502373629', '1', '3', null, '民生商城', '18999999999', 'aaa@qq.com', '', 'aaa123@qq.com', '1', '0', 'beijing');
INSERT INTO `cps_admin` VALUES ('12', 'beijingfenghang', 'dc483e80a7a0bd9ef71d8cf973673924', '1502373681', '1502373681', '1', '4', null, '北京分行', '18999999999', 'bj@qq.com', '', 'bj123@qq.com', '1', '0', 'beijing');
INSERT INTO `cps_admin` VALUES ('13', 'tianmaoshangcheng', 'dc483e80a7a0bd9ef71d8cf973673924', '1502375294', '1502375294', '1', '3', null, '天猫商城', '18999999999', 'tm@qq.com', '', 'tm@qq.com', '1', '0', '天猫');
INSERT INTO `cps_admin` VALUES ('14', 'fujianfenghang', 'dc483e80a7a0bd9ef71d8cf973673924', '1502375364', '1502375364', '1', '4', null, '福建分行', '18999999999', 'fj@qq.com', '', 'fj@qq.com', '1', '0', '福建');
INSERT INTO `cps_admin` VALUES ('15', 'zhangsan12', 'dc483e80a7a0bd9ef71d8cf973673924', '1502378001', '1502378001', '1', '5', '1502378001', '昌平支行', ' 18958222222', ' bank_sub_xm@qq.com', '110.87.6.217', ' bank_sub_xm@qq.com', '1', '12', '昌平支行');
INSERT INTO `cps_admin` VALUES ('16', 'chaoyang1', 'dc483e80a7a0bd9ef71d8cf973673924', '1502378001', '1502378001', '1', '5', '1502378001', '朝阳支行', ' 18999990000', ' bank_sub_xm@qq.com', '110.87.6.217', ' bank_sub_xm@qq.com', '1', '12', '朝阳支行');
INSERT INTO `cps_admin` VALUES ('17', 'xicheng1', 'dc483e80a7a0bd9ef71d8cf973673924', '1502378001', '1502378001', '1', '5', '1502378001', '西城支行', ' 18989898989', ' bank_sub_xm@qq.com', '110.87.6.217', ' bank_sub_xm@qq.com', '1', '12', '西城支行');
INSERT INTO `cps_admin` VALUES ('18', 'haidian1', 'dc483e80a7a0bd9ef71d8cf973673924', '1502378001', '1502378001', '1', '5', '1502378001', '海淀支行', ' 18989898989', ' bank_sub_xm@qq.com', '110.87.6.217', ' bank_sub_xm@qq.com', '1', '12', '海淀支行');
INSERT INTO `cps_admin` VALUES ('19', 'zhangsan', 'dc483e80a7a0bd9ef71d8cf973673924', '1502378168', '1502378168', '1', '6', '1502378168', '张三', ' 18958222222', ' bank_sub_xm@qq.com', '110.87.6.217', ' bank_sub_xm@qq.com', '1', '18', '海淀支行');
INSERT INTO `cps_admin` VALUES ('20', 'lisi', 'dc483e80a7a0bd9ef71d8cf973673924', '1502378168', '1502378168', '1', '6', '1502378168', '李四', ' 18999990000', ' bank_sub_xm@qq.com', '110.87.6.217', ' bank_sub_xm@qq.com', '1', '18', '海淀支行');

-- ----------------------------
-- Table structure for cps_album
-- ----------------------------
DROP TABLE IF EXISTS `cps_album`;
CREATE TABLE `cps_album` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '默认专辑',
  `img` varchar(255) DEFAULT NULL,
  `uid` int(10) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `cid` int(10) NOT NULL DEFAULT '0',
  `sort_order` int(10) DEFAULT '0',
  `recommend_count` int(10) NOT NULL,
  `recommend` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `add_time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recommend` (`recommend`),
  KEY `sort_order` (`sort_order`),
  KEY `uid` (`uid`),
  KEY `status` (`status`,`cid`,`sort_order`),
  KEY `recommend_count` (`recommend_count`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_album
-- ----------------------------
INSERT INTO `cps_album` VALUES ('1', '默认专辑', null, '4', null, '0', '0', '0', '0', '1', '1489544175');

-- ----------------------------
-- Table structure for cps_album_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_album_cate`;
CREATE TABLE `cps_album_cate` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '我的专辑',
  `add_time` int(10) NOT NULL DEFAULT '0',
  `album_num` int(10) NOT NULL DEFAULT '0',
  `sort_order` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sort_order` (`status`,`sort_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_album_cate
-- ----------------------------
INSERT INTO `cps_album_cate` VALUES ('1', '其他', '1338789120', '0', '5', '1');
INSERT INTO `cps_album_cate` VALUES ('2', '美容', '1338789120', '0', '4', '1');
INSERT INTO `cps_album_cate` VALUES ('3', '包包', '1338789120', '0', '3', '1');
INSERT INTO `cps_album_cate` VALUES ('4', '衣服', '1338789120', '0', '1', '1');
INSERT INTO `cps_album_cate` VALUES ('5', '鞋子', '1338789120', '0', '2', '1');

-- ----------------------------
-- Table structure for cps_album_items
-- ----------------------------
DROP TABLE IF EXISTS `cps_album_items`;
CREATE TABLE `cps_album_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `items_id` int(10) NOT NULL DEFAULT '0',
  `pid` int(10) NOT NULL DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `add_time` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_album_items
-- ----------------------------
INSERT INTO `cps_album_items` VALUES ('1', '1', '1', '', '1489544175');

-- ----------------------------
-- Table structure for cps_album_recommend
-- ----------------------------
DROP TABLE IF EXISTS `cps_album_recommend`;
CREATE TABLE `cps_album_recommend` (
  `album_id` int(10) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  KEY `album_id` (`album_id`,`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_album_recommend
-- ----------------------------

-- ----------------------------
-- Table structure for cps_article
-- ----------------------------
DROP TABLE IF EXISTS `cps_article`;
CREATE TABLE `cps_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `abst` varchar(255) NOT NULL,
  `info` mediumtext NOT NULL COMMENT '信息',
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) unsigned NOT NULL,
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` varchar(1024) NOT NULL,
  `platform_id` int(10) unsigned NOT NULL COMMENT '分销机构（发布的时候可指定全部或者具体分行、子机构的人员能看到） 0全部',
  `data_state` tinyint(1) unsigned DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `aid` varchar(255) NOT NULL COMMENT '附件id',
  PRIMARY KEY (`id`),
  KEY `is_best` (`is_best`),
  KEY `add_time` (`add_time`),
  KEY `cate_id` (`cate_id`),
  KEY `status` (`status`),
  KEY `data_state` (`data_state`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='5.2.10公告表';

-- ----------------------------
-- Records of cps_article
-- ----------------------------
INSERT INTO `cps_article` VALUES ('1', '0', '公告1', '', '', '', '', '<p>公告1</p><p>公告1</p><p>公告1</p><p>公告1</p><p>公告1</p><p><br></p>', '2017-08-10 23:17:45', '0', '0', '0', '1', '', '', '', '0', '1', '2017-08-10 23:17:45', '1', '');

-- ----------------------------
-- Table structure for cps_article_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_article_cate`;
CREATE TABLE `cps_article_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `pid` smallint(4) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `article_nums` int(10) unsigned NOT NULL,
  `sort_order` smallint(4) unsigned NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_article_cate
-- ----------------------------
INSERT INTO `cps_article_cate` VALUES ('1', '网站信息', 'sites', '11', '0', '4294967295', '4', '', '', '');
INSERT INTO `cps_article_cate` VALUES ('5', '新手入门', 'rumen', '11', '1', '4294967294', '2', '', '', '');
INSERT INTO `cps_article_cate` VALUES ('9', '热门活动', 'activity', '10', '0', '8', '5', '网站在线帮助说明', '', '');
INSERT INTO `cps_article_cate` VALUES ('10', '资讯活动', 'news', '0', '0', '3', '1', '网站资讯', '', '');
INSERT INTO `cps_article_cate` VALUES ('11', '网站帮助', 'sites', '0', '0', '4294967289', '0', '', '', '');

-- ----------------------------
-- Table structure for cps_attatch
-- ----------------------------
DROP TABLE IF EXISTS `cps_attatch`;
CREATE TABLE `cps_attatch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL COMMENT '文件路径',
  `info` mediumtext NOT NULL COMMENT '信息',
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) NOT NULL,
  `uptime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `filesize` varchar(32) NOT NULL DEFAULT '0' COMMENT 'w文件大小',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `filetype` varchar(32) NOT NULL COMMENT '文件类型',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `shop_id` int(10) unsigned DEFAULT '0' COMMENT '商户id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `origin_id` bigint(20) unsigned DEFAULT NULL COMMENT '商品原始id',
  `origin_name` varchar(32) DEFAULT NULL COMMENT '商品原始title',
  PRIMARY KEY (`id`),
  KEY `is_best` (`filesize`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='5.2.14文件图片管理表';

-- ----------------------------
-- Records of cps_attatch
-- ----------------------------

-- ----------------------------
-- Table structure for cps_auto_collect
-- ----------------------------
DROP TABLE IF EXISTS `cps_auto_collect`;
CREATE TABLE `cps_auto_collect` (
  `id` char(4) NOT NULL,
  `value` varchar(200) NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_auto_collect
-- ----------------------------
INSERT INTO `cps_auto_collect` VALUES ('i', '1');
INSERT INTO `cps_auto_collect` VALUES ('p', '1');

-- ----------------------------
-- Table structure for cps_auto_collect_date
-- ----------------------------
DROP TABLE IF EXISTS `cps_auto_collect_date`;
CREATE TABLE `cps_auto_collect_date` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `add_date` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_auto_collect_date
-- ----------------------------

-- ----------------------------
-- Table structure for cps_cash_back_log
-- ----------------------------
DROP TABLE IF EXISTS `cps_cash_back_log`;
CREATE TABLE `cps_cash_back_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `uname` varchar(40) NOT NULL,
  `before_money` decimal(10,2) DEFAULT NULL,
  `after_money` decimal(10,2) DEFAULT NULL,
  `in_money` decimal(10,2) DEFAULT NULL,
  `out_money` decimal(10,2) DEFAULT NULL,
  `time` varchar(20) NOT NULL,
  `type` int(1) NOT NULL COMMENT '1表示收入，2表示支出',
  `info` varchar(100) NOT NULL,
  `sign` char(40) NOT NULL,
  `before_jifenbao` decimal(10,0) DEFAULT NULL,
  `after_jifenbao` decimal(10,0) DEFAULT NULL,
  `in_jifenbao` decimal(10,0) DEFAULT NULL,
  `out_jifenbao` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_cash_back_log
-- ----------------------------

-- ----------------------------
-- Table structure for cps_collect_miao
-- ----------------------------
DROP TABLE IF EXISTS `cps_collect_miao`;
CREATE TABLE `cps_collect_miao` (
  `cate_id` smallint(4) NOT NULL,
  `collect_time` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `cate_id` (`cate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_collect_miao
-- ----------------------------

-- ----------------------------
-- Table structure for cps_collect_taobao
-- ----------------------------
DROP TABLE IF EXISTS `cps_collect_taobao`;
CREATE TABLE `cps_collect_taobao` (
  `cate_id` smallint(4) NOT NULL,
  `collect_time` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `cate_id` (`cate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_collect_taobao
-- ----------------------------
INSERT INTO `cps_collect_taobao` VALUES ('448', '1489541725');
INSERT INTO `cps_collect_taobao` VALUES ('449', '1489541728');

-- ----------------------------
-- Table structure for cps_commission
-- ----------------------------
DROP TABLE IF EXISTS `cps_commission`;
CREATE TABLE `cps_commission` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `con_id` varchar(255) DEFAULT '0' COMMENT '合同编号id,分行手动输入',
  `rate` varchar(255) DEFAULT NULL COMMENT '分销比例(佣金比例)',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `approver` varchar(1000) DEFAULT NULL COMMENT '审批人',
  `approver_id` smallint(4) NOT NULL DEFAULT '0' COMMENT '审批人_id',
  `approver_time` int(10) NOT NULL DEFAULT '0' COMMENT '审批时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `platform_id` int(10) unsigned DEFAULT '0' COMMENT '分销平台，指定到机构？对，必须对应机构。',
  `remark` varchar(50) DEFAULT NULL,
  `remark_status` tinyint(6) DEFAULT '1',
  `freight` decimal(10,2) DEFAULT '0.00' COMMENT '承担运费',
  `period` varchar(1000) DEFAULT NULL COMMENT '账期',
  `data_state` tinyint(1) unsigned DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `cate_id` bigint(255) unsigned DEFAULT NULL COMMENT '分类id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `shop_id` bigint(10) unsigned NOT NULL COMMENT '商户id',
  `commission` decimal(10,2) DEFAULT NULL COMMENT '佣金金额',
  `click` int(10) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `contract` varchar(255) DEFAULT NULL COMMENT '合同名称',
  `platform` varchar(255) DEFAULT NULL COMMENT '分销平台',
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  `role_id` bigint(10) unsigned NOT NULL DEFAULT '1' COMMENT '角色id,提供是否是分润使用，如果role_id为4',
  `img` varchar(255) DEFAULT '' COMMENT '商品图片URL',
  `url` varchar(1000) DEFAULT '' COMMENT '商品链接URL',
  PRIMARY KEY (`id`),
  KEY `cid` (`con_id`),
  KEY `title` (`rate`),
  KEY `index_sid` (`approver_id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='5.2.8商品佣金表';

-- ----------------------------
-- Records of cps_commission
-- ----------------------------
INSERT INTO `cps_commission` VALUES ('12', '3', '20', '1499.00', null, '0', '0', '1', '1502373843', '1', '1', null, '1', '0.00', null, '1', '1502373843', '0', '3439034', '11', '299.80', '0', 'FIIL Diva Pro 头戴式无线耳机 曜石黑 智能降噪 本地高清无损播放 语音交互', '民生商城合同', null, '数码', '1', 'https://img14.360buyimg.com/n5/s54x54_jfs/t2590/228/4101190783/80643/103dc60d/57a98a7aN8c8b3b8f.jpg', 'https://item.jd.com/3439034.html');
INSERT INTO `cps_commission` VALUES ('13', '3', '15', '1776.00', null, '0', '0', '1', '1502373843', '1', '1', null, '1', '0.00', null, '1', '1502373843', '0', 'sku10880611', '11', '266.40', '7', '52度新品五粮液（普五） [500ml*2瓶]', '民生商城合同', null, '酒水饮料', '1', 'http://img.minshengec.com/product/pics/2016/8/16/384855/384855-4-1469-1-400_400.jpg', 'http://item.minshengec.com/c-msdszy/spu-384855-sku10880611.jhtml');
INSERT INTO `cps_commission` VALUES ('14', '3', '20', '829.00', null, '0', '0', '1', '1502373843', '1', '1', null, '1', '0.00', null, '1', '1502373843', '0', '23', '11', '165.80', '0', '奈唯 足金转运珠手链 [圆圆满满]', '民生商城合同', null, '珠宝配饰', '1', 'http://wd2.jieqiangtec.com/attachment/images/5/2017/07/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg', 'http://shop.adjyc.com/app/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23');
INSERT INTO `cps_commission` VALUES ('15', '3', '20', '0.01', null, '0', '0', '1', '1502373843', '1', '1', null, '1', '0.00', null, '1', '1502373843', '0', '25', '11', '0.00', '0', '测试', '民生商城合同', null, '珠宝配饰', '1', 'http://shop.adjyc.com/attachment/images/5/2017/07/H0QAu1cWCWPhhQ00anhahW6hEHAZs6.jpg', 'http://shop.adjyc.com/app/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=25');
INSERT INTO `cps_commission` VALUES ('16', '4', '20', '1499.00', null, '0', '0', '1', '1502373955', '1', '12', null, '1', '0.00', null, '1', '1502373955', '0', '3439034', '11', '299.80', '0', 'FIIL Diva Pro 头戴式无线耳机 曜石黑 智能降噪 本地高清无损播放 语音交互', '北京分行合同', null, '数码', '1', 'https://img14.360buyimg.com/n5/s54x54_jfs/t2590/228/4101190783/80643/103dc60d/57a98a7aN8c8b3b8f.jpg', 'https://item.jd.com/3439034.html');
INSERT INTO `cps_commission` VALUES ('17', '4', '15', '1776.00', null, '0', '0', '1', '1502373955', '1', '12', null, '1', '0.00', null, '1', '1502373955', '0', 'sku10880611', '11', '266.40', '7', '52度新品五粮液（普五） [500ml*2瓶]', '北京分行合同', null, '酒水饮料', '1', 'http://img.minshengec.com/product/pics/2016/8/16/384855/384855-4-1469-1-400_400.jpg', 'http://item.minshengec.com/c-msdszy/spu-384855-sku10880611.jhtml');
INSERT INTO `cps_commission` VALUES ('18', '5', '20', '1499.00', null, '0', '0', '1', '1502377651', '1', '1', null, '1', '0.00', null, '1', '1502377651', '0', 'tm3439034', '13', '299.80', '0', '天猫本地高清无损播放 语音交互', '天猫商城', null, '数码', '1', 'https://img14.360buyimg.com/n5/s54x54_jfs/t2590/228/4101190783/80643/103dc60d/57a98a7aN8c8b3b8f.jpg', 'https://item.jd.com/3439034.html');
INSERT INTO `cps_commission` VALUES ('19', '5', '15', '1776.00', null, '0', '0', '1', '1502377651', '1', '1', null, '1', '0.00', null, '1', '1502377651', '0', 'sku10880611', '13', '266.40', '0', '天猫52度新品五粮液（普五） [500ml*2瓶]', '天猫商城', null, '酒水饮料', '1', 'http://img.minshengec.com/product/pics/2016/8/16/384855/384855-4-1469-1-400_400.jpg', 'http://item.minshengec.com/c-msdszy/spu-384855-sku10880611.jhtml');
INSERT INTO `cps_commission` VALUES ('20', '6', '20', '1499.00', null, '0', '0', '1', '1502377845', '1', '14', null, '1', '0.00', null, '1', '1502377845', '0', 'tm3439034', '13', '299.80', '0', '天猫本地高清无损播放 语音交互', '福建分行合同', null, '数码', '1', 'https://img14.360buyimg.com/n5/s54x54_jfs/t2590/228/4101190783/80643/103dc60d/57a98a7aN8c8b3b8f.jpg', 'https://item.jd.com/3439034.html');
INSERT INTO `cps_commission` VALUES ('21', '6', '15', '1776.00', null, '0', '0', '1', '1502377845', '1', '14', null, '1', '0.00', null, '1', '1502377845', '0', 'sku10880611', '11', '266.40', '7', '52度新品五粮液（普五） [500ml*2瓶]', '福建分行合同', null, '酒水饮料', '1', 'http://img.minshengec.com/product/pics/2016/8/16/384855/384855-4-1469-1-400_400.jpg', 'http://item.minshengec.com/c-msdszy/spu-384855-sku10880611.jhtml');
INSERT INTO `cps_commission` VALUES ('22', '', '10', '1776.00', null, '0', '0', '1', '1502378609', '12', '12', null, '1', '0.00', null, '1', '1502378609', '0', 'sku10880611', '11', '177.60', '7', '52度新品五粮液（普五） [500ml*2瓶]', '', null, '酒水饮料', '4', 'http://img.minshengec.com/product/pics/2016/8/16/384855/384855-4-1469-1-400_400.jpg', 'http://item.minshengec.com/c-msdszy/spu-384855-sku10880611.jhtml');
INSERT INTO `cps_commission` VALUES ('23', '', '16', '1499.00', null, '0', '0', '1', '1502378609', '12', '12', null, '1', '0.00', null, '1', '1502378609', '0', '3439034', '11', '239.84', '0', 'FIIL Diva Pro 头戴式无线耳机 曜石黑 智能降噪 本地高清无损播放 语音交互', '', null, '数码', '4', '', '');

-- ----------------------------
-- Table structure for cps_contract
-- ----------------------------
DROP TABLE IF EXISTS `cps_contract`;
CREATE TABLE `cps_contract` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `con_id` varchar(255) DEFAULT NULL COMMENT '合同编号id,分行手动输入',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `approver` varchar(1000) DEFAULT NULL COMMENT '审批人',
  `approver_id` smallint(4) NOT NULL DEFAULT '0' COMMENT '审批人_id',
  `approver_time` int(10) NOT NULL DEFAULT '0' COMMENT '审批时间',
  `period_account` varchar(32) NOT NULL DEFAULT '0' COMMENT '账期',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `platform_id` int(10) unsigned DEFAULT '0' COMMENT '分销平台，指定到机构？对，必须对应机构。',
  `seo_desc` text,
  `cash_back_rate` varchar(40) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `remark` varchar(50) DEFAULT NULL,
  `remark_status` tinyint(6) DEFAULT '1',
  `freight` decimal(10,2) DEFAULT '0.00' COMMENT '承担运费',
  `period` varchar(1000) DEFAULT NULL COMMENT '账期',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `con_type` varchar(1000) DEFAULT NULL COMMENT '合同类型,关联感觉',
  `shop_id` bigint(11) DEFAULT NULL COMMENT '商城id',
  `payee` varchar(1000) DEFAULT NULL COMMENT '收款方',
  `begin_time` bigint(12) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end_time` bigint(12) unsigned NOT NULL DEFAULT '0' COMMENT '结束时间',
  PRIMARY KEY (`id`),
  KEY `cid` (`con_id`),
  KEY `is_index` (`period_account`),
  KEY `title` (`title`),
  KEY `index_sid` (`approver_id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='5.2.7合同表';

-- ----------------------------
-- Records of cps_contract
-- ----------------------------
INSERT INTO `cps_contract` VALUES ('3', 'c1001', '民生商城合同', null, null, '0', '0', '30', '1', '1502373766', '1', '1', null, '', '', null, '1', '8.00', '1', null, '1502373766', '3', '11', null, '1502294400', '1533830400');
INSERT INTO `cps_contract` VALUES ('4', 'c1002', '北京分行合同', null, null, '0', '0', '30', '1', '1502373891', '1', '12', null, '', '', null, '1', '0.00', '1', null, '1502373891', '4', '1', null, '1502294400', '1533830400');
INSERT INTO `cps_contract` VALUES ('5', 'c1003', '天猫商城', null, null, '0', '0', '30', '1', '1502377507', '1', '1', null, '', '', null, '1', '0.00', '1', null, '1502377507', '1', '13', null, '1502294400', '1533830400');
INSERT INTO `cps_contract` VALUES ('6', 'c1004', '福建分行合同', null, null, '0', '0', '30', '1', '1502377734', '1', '14', null, '', '', null, '1', '0.00', '1', null, '1502377734', '4', '1', null, '1502294400', '1533830400');

-- ----------------------------
-- Table structure for cps_contract_log
-- ----------------------------
DROP TABLE IF EXISTS `cps_contract_log`;
CREATE TABLE `cps_contract_log` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(40) DEFAULT NULL,
  `op_time` datetime DEFAULT NULL,
  `op` varchar(66) DEFAULT NULL COMMENT '操作：增加、修改、删除、审核、回复',
  `op_object` varchar(256) DEFAULT NULL COMMENT '操作的表',
  `op_desc` text COMMENT '操作内容',
  `sql` varchar(1024) DEFAULT NULL COMMENT '执行的sql语句 add update insert delete',
  `product` int(11) unsigned DEFAULT '0' COMMENT '商品id',
  `data_state` char(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `uid` int(10) unsigned DEFAULT '0' COMMENT '用户',
  `app` int(11) DEFAULT NULL COMMENT '活动',
  `status` char(1) DEFAULT NULL COMMENT '数据状态：2成功，1审核中',
  `content` varchar(255) DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL COMMENT '审核时间',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作日志表';

-- ----------------------------
-- Records of cps_contract_log
-- ----------------------------

-- ----------------------------
-- Table structure for cps_exchange_goods
-- ----------------------------
DROP TABLE IF EXISTS `cps_exchange_goods`;
CREATE TABLE `cps_exchange_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `goods_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:虚拟卡 2:实体商品',
  `img` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `integral` int(11) NOT NULL DEFAULT '0',
  `stock` int(11) NOT NULL DEFAULT '0',
  `buy_count` int(11) NOT NULL DEFAULT '0',
  `user_id` smallint(5) NOT NULL DEFAULT '1',
  `user_num` int(8) NOT NULL COMMENT '每人限兑',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `begin_time` varchar(40) NOT NULL,
  `end_time` varchar(40) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(400) NOT NULL,
  `seo_keys` varchar(400) NOT NULL,
  `seo_desc` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `begin_end_time` (`begin_time`,`end_time`),
  KEY `status` (`status`),
  KEY `sort` (`sort`),
  KEY `is_best` (`is_best`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_exchange_goods
-- ----------------------------
INSERT INTO `cps_exchange_goods` VALUES ('2', '自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水', '1', './data/exchangegoods/503473aa672c6.jpg', '自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水', '5000', '10', '0', '1', '1', '0', '0', '1345478400', '1608566400', '100', '1', '自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水', '自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水', '自然堂CHCEDO 雪域精粹系列 四件套装 洗+水+乳+霜 (凝润型) 补水');
INSERT INTO `cps_exchange_goods` VALUES ('3', '沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）', '1', './data/exchangegoods/5034740bc7671.jpg', '沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）', '40000', '10', '0', '1', '1', '0', '0', '1345564800', '1666281600', '100', '1', '沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）', '沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）', '沙宣修护水养套装（洗发露750ml+润发乳400ml+发质重塑发膜150ml）');
INSERT INTO `cps_exchange_goods` VALUES ('4', 'IPHONE 4s 16G原价4999现在只需要50000积分，快快赚取积分吧', '1', './data/exchangegoods/5034749736066.jpg', 'IPHONE 4s 16G原价4999现在只需要50000积分', '50000', '1', '0', '1', '1', '0', '0', '1345478400', '1608566400', '100', '1', 'IPHONE 4s 16G原价4999现在只需要50000积分', 'IPHONE 4s 16G原价4999现在只需要50000积分', 'IPHONE 4s 16G原价4999现在只需要50000积分');
INSERT INTO `cps_exchange_goods` VALUES ('5', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '1', './data/exchangegoods/503474ff36995.jpg', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）<img src=\"/data/news/image/20170315/20170315114353_26081.jpg\" alt=\"\" />', '1', '1000', '4', '1', '100', '0', '0', '1345478400', '1769616000', '100', '1', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）');

-- ----------------------------
-- Table structure for cps_exchange_order
-- ----------------------------
DROP TABLE IF EXISTS `cps_exchange_order`;
CREATE TABLE `cps_exchange_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sn` varchar(255) NOT NULL,
  `data_name` varchar(255) NOT NULL DEFAULT '',
  `goods_status` tinyint(1) NOT NULL COMMENT '0:未发货;1:部分发货;2:全部发货;3:部分退货;4:全部退货'',',
  `data_num` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL COMMENT '订单状态\r\n0: 未确认\r\n1: 完成\r\n2: 作废',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `region_lv1` int(11) NOT NULL,
  `region_lv2` int(11) NOT NULL,
  `region_lv3` int(11) NOT NULL,
  `region_lv4` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `fax_phone` varchar(255) NOT NULL,
  `fix_phone` varchar(255) NOT NULL,
  `alim` varchar(255) NOT NULL,
  `msn` varchar(255) NOT NULL,
  `qq` varchar(255) NOT NULL,
  `consignee` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `user_name` varchar(60) NOT NULL DEFAULT '',
  `remark` varchar(255) NOT NULL,
  `adm_memo` varchar(255) NOT NULL,
  `order_score` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sn` (`sn`),
  KEY `uid` (`uid`),
  KEY `goods_status` (`goods_status`),
  KEY `status` (`status`),
  KEY `goods_id` (`goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_exchange_order
-- ----------------------------
INSERT INTO `cps_exchange_order` VALUES ('1', '20170315114601181', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '0', '1', '0', '1489549561', '1489549561', '366200', '0', '0', '0', '0', '福建省厦门市集美区', '18888888888@163.com', '18888888888', '05922222222', '', '', '', '1569501393', '街墙', '4', 'jieqiang', '', '', '1', '5');
INSERT INTO `cps_exchange_order` VALUES ('2', '20170315115024352', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '0', '1', '0', '1489549824', '1489549824', '366200', '0', '0', '0', '0', '福建省厦门市集美区', '18888888888@163.com', '18888888888', '05922222222', '', '', '', '1569501393', '街墙', '4', 'jieqiang', '', '', '1', '5');
INSERT INTO `cps_exchange_order` VALUES ('3', '20170315115028886', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '0', '1', '0', '1489549828', '1489549828', '366200', '0', '0', '0', '0', '福建省厦门市集美区', '18888888888@163.com', '18888888888', '05922222222', '', '', '', '1569501393', '街墙', '4', 'jieqiang', '', '', '1', '5');
INSERT INTO `cps_exchange_order` VALUES ('4', '20170315115313461', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '0', '1', '0', '1489549993', '1489549993', '366200', '0', '0', '0', '0', '福建省厦门市集美区', '18888888888@163.com', '18888888888', '05922222222', '', '', '', '1569501393', '街墙', '4', 'jieqiang', '', '', '1', '5');
INSERT INTO `cps_exchange_order` VALUES ('5', '20170315115558567', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '0', '1', '0', '1489550158', '1489550158', '366200', '0', '0', '0', '0', '福建省厦门市集美区', '18888888888@163.com', '18888888888', '05922222222', '', '', '', '1569501393', '街墙', '4', 'jieqiang', '', '', '1', '5');
INSERT INTO `cps_exchange_order` VALUES ('6', '20170315124723967', '佳能（Canon） Power Shot A4000 IS 数码相机 红色（1600万像素 3.0液晶屏 8倍光变 28mm广角）', '1', '1', '0', '1489553243', '1489553243', '366200', '0', '0', '0', '0', '福建省厦门市集美区', '18888888888@163.com', '18888888888', '05922222222', '', '', '', '1569501393', '街墙', '4', 'jieqiang', '阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发阿斯顿发沙发', '', '1', '5');

-- ----------------------------
-- Table structure for cps_file
-- ----------------------------
DROP TABLE IF EXISTS `cps_file`;
CREATE TABLE `cps_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL COMMENT '文件路径',
  `info` mediumtext NOT NULL COMMENT '信息',
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) NOT NULL,
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `platform_id` int(10) unsigned NOT NULL COMMENT '分销机构（发布的时候可指定全部或者具体分行、子机构的人员能看到）',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `shop_id` int(10) unsigned DEFAULT '0' COMMENT '商户id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `origin_id` bigint(20) unsigned DEFAULT NULL COMMENT '商品原始id',
  `origin_name` varchar(32) DEFAULT NULL COMMENT '商品原始title',
  `name` varchar(32) DEFAULT NULL COMMENT '图片原始名称',
  `extension` varchar(32) DEFAULT NULL COMMENT '图片后缀',
  `size` varchar(32) DEFAULT NULL COMMENT '图片大小',
  `bimg` varchar(255) NOT NULL COMMENT '原图',
  `simg` varchar(255) NOT NULL COMMENT '缩略图',
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  PRIMARY KEY (`id`),
  KEY `is_best` (`is_best`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='5.2.14文件图片管理表';

-- ----------------------------
-- Records of cps_file
-- ----------------------------
INSERT INTO `cps_file` VALUES ('114', '0', '', '', 'data/items/m_598c7d9893fb2.jpg', '', '', '', '2017-08-10 23:36:56', '0', '0', '0', '1', '0', '1', '2017-08-10 23:36:56', '1', '11', 'sku10880611', '6', '52度新品五粮液（普五） [500ml*2瓶]', 'm_59283266bb86f.jpg', 'jpg', '47490', 'data/items/598c7d9893fb2.jpg', 'data/items/s_598c7d9893fb2.jpg', '1');
INSERT INTO `cps_file` VALUES ('115', '0', '', '', 'data/items/m_598c7da5cfb13.jpg', '', '', '', '2017-08-10 23:37:10', '0', '0', '0', '1', '0', '1', '2017-08-10 23:37:10', '1', '11', 'sku10880611', '6', '52度新品五粮液（普五） [500ml*2瓶]', 'm_592832546e5e0.jpg', 'jpg', '42354', 'data/items/598c7da5cfb13.jpg', 'data/items/s_598c7da5cfb13.jpg', '1');

-- ----------------------------
-- Table structure for cps_find_password_log
-- ----------------------------
DROP TABLE IF EXISTS `cps_find_password_log`;
CREATE TABLE `cps_find_password_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `md5` char(32) NOT NULL,
  `create_time` varchar(20) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `status` int(1) NOT NULL COMMENT '0表示没有激活，1表示激活',
  `address` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` varchar(1024) NOT NULL,
  `result` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_find_password_log
-- ----------------------------
INSERT INTO `cps_find_password_log` VALUES ('1', 'c3fcd98a123da79c81a88f72a71680ee', '1496395404', '127.0.0.1', '2', '0', '', '', '', '');
INSERT INTO `cps_find_password_log` VALUES ('2', '636e6fca61078b2500d3407a7792418c', '1496395535', '127.0.0.1', '2', '0', '', '', '', '');
INSERT INTO `cps_find_password_log` VALUES ('3', '7fbb8abbd0d7a2228d5e8e1c48a6d3e4', '1496396247', '127.0.0.1', '2', '0', '', '', '', '');

-- ----------------------------
-- Table structure for cps_flink
-- ----------------------------
DROP TABLE IF EXISTS `cps_flink`;
CREATE TABLE `cps_flink` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` smallint(4) NOT NULL DEFAULT '1',
  `img` varchar(255) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `ordid` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_flink
-- ----------------------------
INSERT INTO `cps_flink` VALUES ('2', '1', '4f8ceab7e6f6c.jpg', '微购官网', 'http://www.wego360.com', '1', '1');
INSERT INTO `cps_flink` VALUES ('5', '2', null, '59秒开放平台', 'http://www.59miao.com', '1', '99');
INSERT INTO `cps_flink` VALUES ('6', '2', null, '精品网', 'http://jingpin.59miao.com', '1', '99');

-- ----------------------------
-- Table structure for cps_flink_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_flink_cate`;
CREATE TABLE `cps_flink_cate` (
  `id` smallint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_flink_cate
-- ----------------------------
INSERT INTO `cps_flink_cate` VALUES ('1', '友情链接');
INSERT INTO `cps_flink_cate` VALUES ('2', '合作伙伴');

-- ----------------------------
-- Table structure for cps_focus
-- ----------------------------
DROP TABLE IF EXISTS `cps_focus`;
CREATE TABLE `cps_focus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `abst` text NOT NULL,
  `clicks` int(10) NOT NULL DEFAULT '0',
  `ordid` smallint(4) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `ordid` (`ordid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_focus
-- ----------------------------
INSERT INTO `cps_focus` VALUES ('9', '1', 'NOP新秋新体验，8折购新品，限时一周。', '?a=index&m=cate&cid=3', './data/focus/5051891a9e924.jpg', '', '154', '0', '1');
INSERT INTO `cps_focus` VALUES ('10', '1', '格子控女生', '?a=index&m=cate&cid=5', './data/focus/5051892acdd67.jpg', '', '105', '0', '1');
INSERT INTO `cps_focus` VALUES ('7', '1', '悦己网时装周，2件6折，3件4折。', '?a=index&m=cate&cid=7', './data/focus/50518986355f9.jpg', '', '95', '0', '1');

-- ----------------------------
-- Table structure for cps_focus_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_focus_cate`;
CREATE TABLE `cps_focus_cate` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `width` smallint(6) NOT NULL DEFAULT '0',
  `height` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_focus_cate
-- ----------------------------
INSERT INTO `cps_focus_cate` VALUES ('1', '首页焦点', '580', '280');

-- ----------------------------
-- Table structure for cps_group
-- ----------------------------
DROP TABLE IF EXISTS `cps_group`;
CREATE TABLE `cps_group` (
  `id` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `title` varchar(50) NOT NULL,
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `sort` (`sort`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_group
-- ----------------------------
INSERT INTO `cps_group` VALUES ('4', 'article', '内容管理', '1222841259', '1222841259', '1', '3');
INSERT INTO `cps_group` VALUES ('1', 'system', '系统设置', '1222841259', '1222841259', '1', '6');
INSERT INTO `cps_group` VALUES ('6', 'goods', '商品管理', '1222841259', '0', '1', '2');
INSERT INTO `cps_group` VALUES ('8', 'member', '会员管理', '0', '0', '1', '4');
INSERT INTO `cps_group` VALUES ('9', 'home', '起始页', '0', '1341386748', '1', '0');
INSERT INTO `cps_group` VALUES ('27', 'seller', '商家管理', '1340586215', '0', '1', '1');
INSERT INTO `cps_group` VALUES ('28', 'cash_back', '返利管理', '1340615780', '0', '1', '2');
INSERT INTO `cps_group` VALUES ('29', 'other', '其他管理', '1345776358', '0', '1', '7');

-- ----------------------------
-- Table structure for cps_items
-- ----------------------------
DROP TABLE IF EXISTS `cps_items`;
CREATE TABLE `cps_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` smallint(4) DEFAULT NULL COMMENT '分类id',
  `item_key` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `img` varchar(255) DEFAULT '' COMMENT '商品图片URL',
  `simg` varchar(255) DEFAULT NULL,
  `bimg` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `url` varchar(1000) DEFAULT '' COMMENT '商品链接URL',
  `sid` smallint(4) NOT NULL DEFAULT '0',
  `hits` int(10) NOT NULL DEFAULT '0',
  `likes` int(10) NOT NULL DEFAULT '0' COMMENT '喜欢数',
  `browse_num` int(10) NOT NULL,
  `haves` int(10) NOT NULL DEFAULT '0' COMMENT '库存数',
  `comments` int(10) NOT NULL DEFAULT '0' COMMENT '评论数',
  `comments_last` text COMMENT '最近的N条评论',
  `is_index` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `uid` int(10) NOT NULL DEFAULT '0',
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_keys` varchar(255) DEFAULT NULL,
  `sort_order` int(10) DEFAULT '0',
  `seo_desc` text,
  `cash_back_rate` varchar(40) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `remark` varchar(50) DEFAULT NULL,
  `remark_status` tinyint(6) DEFAULT '1',
  `is_collect_comments` int(1) DEFAULT '0' COMMENT '是否采集了淘宝评论1表示已经采集了淘宝评论',
  `data_state` tinyint(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `item_id` varchar(32) NOT NULL COMMENT '对方商品库id',
  `shop_id` int(10) unsigned NOT NULL COMMENT '商城id',
  `qrcode` varchar(1000) DEFAULT NULL COMMENT '二维码图片URL',
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `is_index` (`is_index`),
  KEY `title` (`title`),
  KEY `index_sid` (`sid`),
  KEY `uid` (`uid`),
  KEY `item_key` (`item_key`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='5.2.6推广商品表';

-- ----------------------------
-- Records of cps_items
-- ----------------------------
INSERT INTO `cps_items` VALUES ('5', '0', null, 'FIIL Diva Pro 头戴式无线耳机 曜石黑 智能降噪 本地高清无损播放 语音交互', 'https://img14.360buyimg.com/n5/s54x54_jfs/t2590/228/4101190783/80643/103dc60d/57a98a7aN8c8b3b8f.jpg', null, null, '1499.00', 'https://item.jd.com/3439034.html', '0', '0', '0', '0', '0', '0', null, '0', '1', '1502373955', '1', null, null, '0', null, '', '', null, '1', '0', '1', '1502373955', '3439034', '11', null, '数码');
INSERT INTO `cps_items` VALUES ('6', '0', null, '52度新品五粮液（普五） [500ml*2瓶]', 'http://img.minshengec.com/product/pics/2016/8/16/384855/384855-4-1469-1-400_400.jpg', null, null, '1776.00', 'http://item.minshengec.com/c-msdszy/spu-384855-sku10880611.jhtml', '0', '0', '0', '0', '0', '0', null, '0', '1', '1502373955', '1', null, null, '0', null, '', '', null, '1', '0', '1', '1502373955', 'sku10880611', '11', './data/qrcode/poster___sku10880611_11_1502379430.jpg', '酒水饮料');
INSERT INTO `cps_items` VALUES ('7', '0', null, '奈唯 足金转运珠手链 [圆圆满满]', 'http://wd2.jieqiangtec.com/attachment/images/5/2017/07/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg', null, null, '829.00', 'http://shop.adjyc.com/app/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23', '0', '0', '0', '0', '0', '0', null, '0', '1', '1502373843', '1', null, null, '0', null, '', '', null, '1', '0', '1', '1502373843', '23', '11', null, '珠宝配饰');
INSERT INTO `cps_items` VALUES ('8', '0', null, '测试', 'http://shop.adjyc.com/attachment/images/5/2017/07/H0QAu1cWCWPhhQ00anhahW6hEHAZs6.jpg', null, null, '0.01', 'http://shop.adjyc.com/app/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=25', '0', '0', '0', '0', '0', '0', null, '0', '1', '1502373843', '1', null, null, '0', null, '', '', null, '1', '0', '1', '1502373843', '25', '11', null, '珠宝配饰');
INSERT INTO `cps_items` VALUES ('9', '0', null, '天猫本地高清无损播放 语音交互', 'https://img14.360buyimg.com/n5/s54x54_jfs/t2590/228/4101190783/80643/103dc60d/57a98a7aN8c8b3b8f.jpg', null, null, '1499.00', 'https://item.jd.com/3439034.html', '0', '0', '0', '0', '0', '0', null, '0', '1', '1502377845', '1', null, null, '0', null, '', '', null, '1', '0', '1', '1502377845', 'tm3439034', '13', null, '数码');
INSERT INTO `cps_items` VALUES ('10', '0', null, '天猫52度新品五粮液（普五） [500ml*2瓶]', 'http://img.minshengec.com/product/pics/2016/8/16/384855/384855-4-1469-1-400_400.jpg', null, null, '1776.00', 'http://item.minshengec.com/c-msdszy/spu-384855-sku10880611.jhtml', '0', '0', '0', '0', '0', '0', null, '0', '1', '1502377651', '1', null, null, '0', null, '', '', null, '1', '0', '1', '1502377651', 'sku10880611', '13', null, '酒水饮料');

-- ----------------------------
-- Table structure for cps_items_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_items_cate`;
CREATE TABLE `cps_items_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  `keywords` varchar(128) NOT NULL COMMENT '分类关键字',
  `img` varchar(255) DEFAULT NULL,
  `pid` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '父类id',
  `item_nums` int(10) NOT NULL DEFAULT '0',
  `item_likes` int(11) NOT NULL,
  `ordid` smallint(4) NOT NULL DEFAULT '0',
  `tags` varchar(50) NOT NULL COMMENT '标签',
  `is_hots` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `recommend` int(1) NOT NULL DEFAULT '0' COMMENT '0表示不推荐，1表示推荐',
  `import_status` int(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  `seo_desc` text NOT NULL,
  `matching_title` varchar(2000) DEFAULT NULL,
  `add_time` int(11) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL COMMENT '更新时间',
  `data_state` tinyint(1) unsigned DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  PRIMARY KEY (`id`),
  KEY `index_is_hots` (`is_hots`),
  KEY `ordid` (`ordid`),
  KEY `index_pid` (`pid`,`recommend`,`status`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='5.2.5推广商品分类表';

-- ----------------------------
-- Records of cps_items_cate
-- ----------------------------
INSERT INTO `cps_items_cate` VALUES ('2', '数码', '', 'https://img14.360buyimg.com/n5/s54x54_jfs/t2590/228/4101190783/80643/103dc60d/57a98a7aN8c8b3b8f.jpg', '0', '0', '0', '0', '', '0', '1', '0', '1', '', '', null, '', null, '1502373843', '1502373843', '1');
INSERT INTO `cps_items_cate` VALUES ('3', '酒水饮料', '', 'http://img.minshengec.com/product/pics/2016/8/16/384855/384855-4-1469-1-400_400.jpg', '0', '0', '0', '0', '', '0', '1', '0', '1', '', '', null, '', null, '1502373843', '1502373843', '1');
INSERT INTO `cps_items_cate` VALUES ('4', '珠宝配饰', '', 'http://wd2.jieqiangtec.com/attachment/images/5/2017/07/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg', '0', '0', '0', '0', '', '0', '1', '0', '1', '', '', null, '', null, '1502373843', '1502373843', '1');

-- ----------------------------
-- Table structure for cps_items_comments
-- ----------------------------
DROP TABLE IF EXISTS `cps_items_comments`;
CREATE TABLE `cps_items_comments` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL,
  `uname` varchar(50) DEFAULT NULL,
  `info` text NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_items_comments
-- ----------------------------

-- ----------------------------
-- Table structure for cps_items_site
-- ----------------------------
DROP TABLE IF EXISTS `cps_items_site`;
CREATE TABLE `cps_items_site` (
  `id` smallint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `site_domain` varchar(255) NOT NULL,
  `site_logo` varchar(255) NOT NULL,
  `collect_url` varchar(255) NOT NULL,
  `collect_time` int(10) NOT NULL DEFAULT '0',
  `item_nums` int(10) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_items_site
-- ----------------------------
INSERT INTO `cps_items_site` VALUES ('1', '淘宝', 'taobao', 'open.taobao.com', '4f62c63e7b59d.jpg', '', '0', '0', '1');
INSERT INTO `cps_items_site` VALUES ('2', '59秒', 'miao', 'www.59miao.com', '4fe7cefb6dde7.png', 'www.59miao.com', '0', '0', '1');
INSERT INTO `cps_items_site` VALUES ('3', '微购api', 'wego', 'api.wego360.com', 'asdf', ' ', '0', '0', '0');

-- ----------------------------
-- Table structure for cps_items_tags
-- ----------------------------
DROP TABLE IF EXISTS `cps_items_tags`;
CREATE TABLE `cps_items_tags` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `item_nums` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_items_tags
-- ----------------------------

-- ----------------------------
-- Table structure for cps_items_tags_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_items_tags_cate`;
CREATE TABLE `cps_items_tags_cate` (
  `cate_id` smallint(4) NOT NULL,
  `tag_id` int(10) NOT NULL,
  KEY `cate_id` (`cate_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_items_tags_cate
-- ----------------------------

-- ----------------------------
-- Table structure for cps_items_tags_item
-- ----------------------------
DROP TABLE IF EXISTS `cps_items_tags_item`;
CREATE TABLE `cps_items_tags_item` (
  `item_id` varchar(32) NOT NULL,
  `tag_id` int(10) NOT NULL,
  KEY `item_id` (`item_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_items_tags_item
-- ----------------------------

-- ----------------------------
-- Table structure for cps_items_user
-- ----------------------------
DROP TABLE IF EXISTS `cps_items_user`;
CREATE TABLE `cps_items_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iid` int(11) NOT NULL,
  `item_id` varchar(32) NOT NULL,
  `uid` int(11) NOT NULL,
  `add_time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`iid`),
  KEY `uid` (`uid`),
  KEY `item_id_2` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_items_user
-- ----------------------------

-- ----------------------------
-- Table structure for cps_like_list
-- ----------------------------
DROP TABLE IF EXISTS `cps_like_list`;
CREATE TABLE `cps_like_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `items_id` int(10) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL DEFAULT '0',
  `add_time` bigint(12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `add_time` (`add_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_like_list
-- ----------------------------
INSERT INTO `cps_like_list` VALUES ('1', '1', '4', '1489544165');

-- ----------------------------
-- Table structure for cps_miao_order
-- ----------------------------
DROP TABLE IF EXISTS `cps_miao_order`;
CREATE TABLE `cps_miao_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_time` varchar(20) DEFAULT NULL,
  `seller_name` varchar(20) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `order_code` varchar(50) DEFAULT NULL,
  `item_count` int(5) DEFAULT NULL,
  `item_price` varchar(10) DEFAULT NULL,
  `sales` varchar(20) DEFAULT NULL,
  `commission` varchar(10) DEFAULT NULL,
  `cash_back` varchar(10) DEFAULT NULL,
  `status` varchar(20) NOT NULL COMMENT '//订单状态',
  `is_update` int(1) NOT NULL DEFAULT '0' COMMENT '0表示未更新用户表，以及返现表，1表示已经更新，不需要再次更新',
  `jiesuan_data` datetime NOT NULL COMMENT '结算日期',
  `order_id` varchar(64) NOT NULL,
  `cash_back_jifenbao` varchar(10) DEFAULT NULL,
  `shop_id` bigint(10) unsigned NOT NULL COMMENT '商户id',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `order_code` (`order_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_miao_order
-- ----------------------------

-- ----------------------------
-- Table structure for cps_nav
-- ----------------------------
DROP TABLE IF EXISTS `cps_nav`;
CREATE TABLE `cps_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `sort_order` smallint(4) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1-系统 0-自定义',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '导航位置1-顶部 2-底部',
  `in_site` tinyint(1) NOT NULL COMMENT '1-本站内 0-站外',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` text NOT NULL,
  `seo_desc` text NOT NULL,
  `items_cate_id` int(11) DEFAULT NULL COMMENT '//分类id',
  PRIMARY KEY (`id`),
  KEY `is_show` (`is_show`),
  KEY `type` (`type`),
  KEY `sort_order` (`sort_order`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_nav
-- ----------------------------

-- ----------------------------
-- Table structure for cps_node
-- ----------------------------
DROP TABLE IF EXISTS `cps_node`;
CREATE TABLE `cps_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `module` varchar(255) NOT NULL COMMENT '模块',
  `module_name` varchar(50) NOT NULL COMMENT '模块名称',
  `action` varchar(255) NOT NULL COMMENT '操作',
  `action_name` varchar(50) DEFAULT NULL COMMENT '操作名称',
  `data` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0' COMMENT '状态',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `auth_type` tinyint(1) NOT NULL DEFAULT '0',
  `group_id` tinyint(3) unsigned DEFAULT '0',
  `often` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-不常用 1-常用',
  `is_show` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-不常用 1-常用',
  `add_time` int(11) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL COMMENT '更新时间',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `module` (`module`),
  KEY `auth_type` (`auth_type`),
  KEY `is_show` (`is_show`),
  KEY `group_id` (`group_id`),
  KEY `sort` (`sort`)
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=utf8 COMMENT='5.2.3节点表';

-- ----------------------------
-- Records of cps_node
-- ----------------------------
INSERT INTO `cps_node` VALUES ('1', 'node', '菜单管理', '', '', '', '0', '', '0', '0', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('2', 'node', '菜单管理', 'index', '菜单列表', '', '0', '', '0', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('3', 'node', '菜单管理', 'add', '添加菜单', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('4', 'node', '菜单管理', 'edit', '编辑菜单', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('5', 'node', '菜单管理', 'delete', '删除菜单', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('6', 'role', '角色管理', '', '', '', '1', '', '7', '0', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('7', 'role', '角色管理', 'index', '权限管理', '', '1', '角色管理', '7', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('8', 'role', '角色管理', 'add', '添加角色', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('9', 'role', '角色管理', 'edit', '编辑角色', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('10', 'role', '角色管理', 'delete', '删除角色', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('11', 'role', '角色管理', 'auth', '角色授权', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('12', 'admin', '管理员管理', '', '', '', '1', '', '97', '0', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('13', 'admin', '管理员管理', 'index', '用户管理', '', '1', '管理员列表', '98', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('14', 'admin', '管理员管理', 'add', '添加管理员', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('15', 'admin', '管理员管理', 'edit', '编辑管理员', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('16', 'admin', '管理员管理', 'delete', '删除管理员', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('50', 'setting', '网站设置', '', '', '', '0', '', '399', '0', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('51', 'setting', '网站设置', 'index', '网站设置', '', '0', '', '0', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('99', 'flink', '友情链接', '', '', '', '0', '', '98', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('100', 'flink', '友情链接', 'index', '友情链接列表', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('101', 'article', '公告管理', '', '', '', '1', '', '2', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('102', 'article', '公告管理', 'index', '公告管理', '', '1', '公告列表', '3', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('103', 'article', '公告管理', 'add', '添加公告', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('104', 'article_cate', '公告分类', '', '', '', '0', '', '99', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('105', 'article', '公告管理', 'edit', '编辑公告', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('106', 'article', '公告管理', 'delete', '删除公告', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('107', 'article_cate', '公告分类', 'index', '分类列表', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('108', 'article_cate', '公告分类', 'add', '添加公告', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('109', 'article_cate', '公告分类', 'edit', '编辑分类', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('110', 'article_cate', '公告分类', 'delete', '删除分类', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('115', 'items', '商品管理', '', '', '', '1', '', '2', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('116', 'items', '商品管理', 'index', '推广商品', '', '1', '商品列表', '2', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('117', 'items_cate', '商品分类', '', '', '', '0', '', '0', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('118', 'items_cate', '商品分类', 'index', '商品分类', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('134', 'items_tags', '标签管理', 'index', '标签列表', '', '0', '', '0', '1', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('121', 'nav', '导航管理', '', '', '', '0', '', '2', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('122', 'nav', '导航管理', 'index', '导航列表', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('123', 'nav', '导航管理', 'add', '添加导航', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('124', 'nav', '导航管理', 'edit', '编辑导航', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('125', 'nav', '导航管理', 'delete', '删除导航', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('133', 'items_tags', '标签管理', '', '', '', '0', '', '0', '0', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('132', 'items_cate', '商品管理', 'add', '添加分类', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('131', 'items', '商品管理', 'add', '添加商品', '5', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('135', 'items_collect', '商品采集', '', '', '', '0', '', '0', '0', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('136', 'items_collect', '商品采集', 'index', '商品采集', '', '0', '', '6', '1', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('139', 'adboard', '广告位置', '', '', '', '0', '', '90', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('140', 'adboard', '广告位置', 'index', '广告位置', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('141', 'ad', '广告管理', '', '', '', '0', '', '90', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('142', 'ad', '广告管理', 'index', '广告列表', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('143', 'template', '模板管理', '', '', '', '0', '', '0', '0', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('144', 'template', '模板管理', 'index', '模板管理', '', '0', '', '0', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('145', 'items', '商品管理', 'batch_add', '批量添加', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('148', 'flink', '友情链接', 'add', '添加友情链接', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('149', 'flink', '友情链接', 'edit', '编辑友情链接', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('150', 'flink', '友情链接', 'del', '删除友情链接', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('151', 'ad', '广告管理', 'add', '添加广告', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('152', 'ad', '广告管理', 'edit', '编辑广告', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('153', 'ad', '广告管理', 'delete', '删除广告', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('154', 'adboard', '广告位置', 'add', '添加广告位置', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('155', 'adboard', '广告位置', 'edit', '编辑广告位置', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('156', 'adboard', '广告位置', 'delete', '删除广告位置', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('157', 'focus', '焦点图管理', '', '', '', '0', '', '101', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('158', 'focus', '焦点图管理', 'edit', '编辑焦点图', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('159', 'focus', '焦点图管理', 'delete', '删除焦点图', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('160', 'items', '商品管理', 'edit', '编辑商品', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('161', 'items', '商品管理', 'delete', '删除商品', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('162', 'items_cate', '商品管理', 'edit', '编辑分类', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('163', 'items_cate', '商品管理', 'delete', '删除分类', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('164', 'items_tags', '标签管理', 'add', '添加标签', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('165', 'items_tags', '标签管理', 'edit', '编辑标签', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('166', 'items_tags', '标签管理', 'delete', '删除标签', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('167', 'items_tags_cate', '关联标签管理', ' ', '', '', '0', '', '0', '0', '6', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('168', 'items_tags_cate', '关联标签管理', 'index', '关联标签列表', '', '0', '', '0', '1', '6', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('169', 'items_tags_cate', '关联标签管理', 'add', '添加关联标签', '', '0', '', '0', '1', '6', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('181', 'items_tags', '标签管理', 'index', '标签列表', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('171', 'items_tags_cate', '关联标签管理', 'del', '删除关联标签', '', '0', '', '0', '2', '6', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('172', 'items_collect', '商品采集管理', 'edit', '编辑采集设置', '', '0', '', '0', '2', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('173', 'items_collect', '商品采集管理', 'collect', '采集详情列表', '', '0', '', '0', '2', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('174', 'items_collect', '商品采集管理', 'taobao_collect', '采集', '', '0', '', '0', '2', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('177', 'cache', '缓存管理', ' ', '', '', '0', '', '0', '0', '1', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('178', 'cache', '缓存管理', 'index', '缓存管理', '', '0', '', '0', '2', '1', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('179', 'items_collect', '商品采集管理', 'add', '添加来源', '', '0', '', '0', '1', '6', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('180', 'items_collect', '商品采集管理', 'delete', '删除来源', '', '0', '', '0', '1', '6', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('182', 'shop', '商城管理', '', '', '', '0', '', '399', '0', '7', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('183', 'shop', '商城管理', 'index', '商城列表', '', '0', '', '0', '1', '7', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('184', 'shop', '商城管理', 'add', '添加商城', '', '0', '', '0', '1', '7', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('185', 'shop', '商城管理', 'edit', '编辑商城', '', '0', '', '0', '1', '7', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('186', 'shop', '商城管理', 'delete', '删除商城', '', '0', '', '0', '1', '7', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('187', 'shop_cate', '商城类别', '', '', '', '0', '', '399', '0', '7', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('188', 'shop_cate', '商城类别', 'index', '类别列表', '', '0', '', '0', '1', '7', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('189', 'shop_cate', '商城类别', 'add', '添加类别', '', '0', '', '0', '1', '7', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('190', 'shop_cate', '商城类别', 'edit', '编辑类别', '', '0', '', '0', '1', '7', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('191', 'shop_cate', '商城类别', 'delete', '删除类别', '', '0', '', '0', '1', '7', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('192', 'user', '会员管理', '', '', '', '0', '', '399', '0', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('193', 'user', '会员管理', 'index', '会员列表', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('194', 'user', '会员管理', 'delete', '删除', '', '0', '', '0', '1', '8', '0', '1', '0', '0', null);
INSERT INTO `cps_node` VALUES ('195', 'items', '商品管理', 'poster', '海报管理', '', '1', '', '8', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('197', 'setting', '网站设置', 'index', '第三方登录', 'type=oauth', '0', '', '0', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('198', 'seo', 'SEO管理', 'rewrite', '伪静态设置', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('199', 'setting', '网站设置', 'index', '关注我们', 'type=guanzhu', '0', '', '0', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('200', 'album', '专辑管理', '', '', '', '0', '', '399', '0', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('201', 'album', '专辑管理', 'index', '专辑列表', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('202', 'album', '专辑管理', 'edit', '编辑专辑', '', '0', '', '0', '2', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('203', 'album', '专辑管理', 'delete', '删除专辑', '', '0', '', '0', '2', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('204', 'album_cate', '专辑分类管理', 'index', '分类列表', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('205', 'album_cate', '专辑分类管理', 'add', '添加分类', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('206', 'album_cate', '专辑分类管理', 'edit', '编辑分类', '', '0', '', '0', '2', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('207', 'album_cate', '专辑分类管理', 'delete', '删除分类', '', '0', '', '0', '2', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('208', 'database', '数据库管理', '', '', '', '0', '', '0', '0', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('209', 'database', '数据库管理', 'execute', '执行', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('210', 'group', '菜单分类管理', '', '', '', '0', '菜单分类管理', '10', '0', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('211', 'group', '菜单分类管理', 'index', '分类列表', '', '0', '', '0', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('212', 'public', '起始页', '', '', '', '0', '', '0', '0', '9', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('213', 'public', '起始页', 'main', '后台首页', '', '0', '', '0', '1', '9', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('214', 'exchange_goods', '积分商品管理', '', '', '', '0', '', '0', '0', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('215', 'exchange_goods', '积分商品管理', 'index', '商品列表', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('216', 'exchange_goods', '积分商品管理', 'add', '增加商品', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('217', 'word_cate', '屏蔽关键词', '', '', '', '0', '', '0', '0', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('218', 'word_cate', '屏蔽分类', 'index', '分类列表', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('219', 'items_collect', '商品采集', 'miaoapi', '59秒api设置', '', '0', '', '5', '1', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('220', 'miao_order', '订单管理', '', '', '', '0', '', '0', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('221', 'miao_order', '订单管理', 'getorder', '获取b2c订单', '', '0', '', '2', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('222', 'cash_back_log', '用户收支管理', '', '', '', '0', '', '0', '0', '28', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('223', 'cash_back_log', '用户收支管理', 'index', '收支记录列表', '', '0', '', '0', '1', '28', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('224', 'user_tixian', '提现管理', '', '', '', '0', '', '0', '0', '28', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('225', 'user_tixian', '提现管理', 'index', '提现列表', '', '0', '', '0', '1', '28', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('226', 'miao_order', '订单管理', 'index', '订单列表', '', '0', '', '1', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('227', 'word', '屏蔽关键词', '', '', '', '0', '', '0', '0', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('228', 'word', '屏蔽关键词', 'index', '关键词列表', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('233', 'seller_cate', '商家分类管理', 'index', '分类列表', '', '0', '', '0', '1', '27', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('232', 'seller_cate', '商家分类管理', '', '', '', '0', '', '0', '0', '27', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('231', 'user', '会员管理', 'setscore', '积分设置', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('234', 'seller_cate', '商家分类管理', 'delete', '删除分类', '', '0', '', '0', '2', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('235', 'seller_cate', '商家分类管理', 'edit', '编辑分类', '', '0', '', '0', '2', '27', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('236', 'seller_cate', '商家分类管理', 'add', '增加分类', '', '0', '', '0', '2', '27', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('237', 'seller_list', '商家管理', '', '', '', '0', '', '0', '0', '27', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('238', 'seller_list', '商家管理', 'index', '商家列表', '', '0', '', '0', '1', '27', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('239', 'seller_list', '商家管理', 'add', '增加商家', '', '0', '', '0', '2', '27', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('240', 'seller_list', '增加商家', 'delete', '删除商家', '', '0', '', '0', '2', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('241', 'group', '菜单分类管理', 'add', '增加分类', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('242', 'group', '菜单分类管理', 'edit', '编辑分类', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('243', 'group', '菜单分类管理', 'delete', '删除分类', '', '0', '', '0', '2', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('244', 'exchange_order', '积分订单管理', '', '', '', '0', '', '0', '0', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('245', 'exchange_order', '积分订单管理', 'index', '订单列表', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('246', 'setting', '网站设置', 'msg', '短信设置', '', '0', '', '0', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('247', 'message', '短信息管理', 'index', '短信息列表', '', '0', '', '0', '0', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('248', 'database', '数据库管理', 'backup', '数据库备份', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('249', 'database', '数据库管理', 'restore', '数据库恢复', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('250', 'items_cate', '商品分类', 'import', '导入分类', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('251', 'items', '商品管理', 'delete_search', '一键删除', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('252', 'banspider', '屏蔽蜘蛛管理', '', '', '', '0', '', '0', '0', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('253', 'banspider', '屏蔽蜘蛛管理', 'index', '屏蔽蜘蛛', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('254', 'banip', '屏蔽Ip管理', '', '', '', '0', '', '0', '0', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('255', 'banip', '屏蔽Ip管理', 'index', '屏蔽ip', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('266', 'miao_order', '订单管理', 'get_tao_order', '获取淘宝订单', '', '0', '', '3', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('257', 'seo', 'seo管理', 'index', 'SEO管理', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('259', 'seo', '网站地图', 'sitemap', '网站地图', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('260', 'seo', 'SEO管理', '', '', '', '0', '', '0', '0', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('261', 'focus', '焦点图管理', 'index', '焦点图列表', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('262', 'focus', '焦点图管理', 'add', '增加焦点图', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('263', 'ucenter', 'Ucenter设置', '', '', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('264', 'ucenter', 'Ucenter设置', 'setucenter', 'Ucenter设置', '', '0', '', '0', '1', '29', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('265', 'items_collect', '商品采集', 'taobaoapi', '淘宝Api设置', '', '0', '', '4', '1', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('267', 'items_collect', '商品采集', 'collect_comments', '评论采集', '', '0', '', '1', '0', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('268', 'cash_setting', '返利设置', '', '', '', '0', '', '0', '0', '28', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('269', 'cash_setting', '返利设置', 'index', '返利设置', '', '0', '', '0', '1', '28', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('270', 'items_cate', '商品分类', 'add_all', '批量添加', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('271', 'user', '会员管理', 'add_all', '批量添加', '', '0', '', '0', '1', '8', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('272', 'items_collect', '商品采集', 'set_collect_cate', '一键采集分类', '', '0', '', '2', '1', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('273', 'items_collect', '商品采集', 'wegoapi', '微购api设置', '', '0', '', '3', '1', '6', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('274', 'activity', '活动管理', 'index', '活动列表', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('275', 'activity', '活动管理', 'add', '添加活动', '', '0', '', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('276', 'activity', '活动管理', 'edit', '编辑活动', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('277', 'activity', '活动管理', 'delete', '删除活动', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('278', 'analyse', '数据分析', 'index', '数据分析', 'type=1', '1', '机构销售业绩 机构销售业绩', '13', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('279', 'analyse', '数据分析', '', '', '', '1', '', '13', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('280', 'contract', '合同管理', '', '', '', '1', '', '1', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('281', 'contract', '合同管理', 'index', '合同管理', '', '1', '合同列表', '0', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('282', 'contract', '合同管理', 'add', '添加合同', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('283', 'contract', '合同管理', 'delete', '删除合同', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('284', 'contract', '合同管理', 'edit', '编辑导航', '', '0', '', '0', '2', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('285', 'analyse', '数据分析', 'index', '机构销售佣金', 'type=2', '0', '机构销售佣金收益', '13', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('286', 'analyse', '数据分析', 'index', '热销商品', 'type=3', '0', '热销商品', '13', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('287', 'admin', '管理员管理', 'pwd', '账号管理', '', '1', '修改密码', '99', '1', '1', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('288', 'finance', '财务相关', '', '', '', '1', '', '9', '0', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('289', 'finance', '财务相关', 'commission', '佣金管理', '', '1', '', '12', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('290', 'finance', '财务相关', 'finance', '财务管理', '', '1', '', '9', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('291', 'finance', '财务相关', 'push', '推广管理', '', '1', '', '11', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('292', 'finance', '财务相关', 'settle', '结算管理', '', '1', '', '15', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('293', 'article', '公告管理', 'view', '联盟公告', null, '0', '公告列表', '3', '1', '4', '0', '0', '0', '0', null);
INSERT INTO `cps_node` VALUES ('294', 'contract', '合同管理', 'log', '日志管理', null, '1', '日志管理', '0', '1', '4', '0', '0', '0', '0', null);

-- ----------------------------
-- Table structure for cps_op_log
-- ----------------------------
DROP TABLE IF EXISTS `cps_op_log`;
CREATE TABLE `cps_op_log` (
  `log_id` bigint(40) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(40) DEFAULT NULL,
  `op_time` datetime DEFAULT NULL,
  `op` varchar(66) DEFAULT NULL COMMENT '操作：增加、修改、删除、审核、回复',
  `op_object` varchar(256) DEFAULT NULL COMMENT '操作对象',
  `op_desc` text COMMENT '操作内容',
  `sql` text COMMENT '执行的sql语句 add update insert delete',
  `product` int(11) unsigned DEFAULT '0' COMMENT '商品id',
  `data_state` char(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `user` int(10) unsigned DEFAULT '0' COMMENT '用户',
  `app` int(11) DEFAULT NULL COMMENT '活动',
  `status` char(1) DEFAULT '1' COMMENT '数据状态：2成功，1审核中',
  `remark` varchar(255) DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL COMMENT '审核时间',
  `ip` varchar(64) DEFAULT NULL COMMENT 'ip',
  `op_table` varchar(256) DEFAULT NULL COMMENT '操作的表',
  `uid` bigint(40) unsigned NOT NULL,
  `op_time2` int(11) DEFAULT NULL,
  `op_content` varchar(256) DEFAULT NULL COMMENT '操作对象',
  `user_id` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COMMENT='5.2.12合同日志表';

-- ----------------------------
-- Records of cps_op_log
-- ----------------------------
INSERT INTO `cps_op_log` VALUES ('28', 'admin', '2017-08-10 22:00:29', '添加', '用户_民生商城', '{\"user_name\":\"mingshengshangcheng\",\"user_id\":\"\\u6c11\\u751f\\u5546\\u57ce\",\"mobile\":\"18999999999\",\"address\":\"beijing\",\"email\":\"aaa@qq.com\",\"account\":\"aaa123@qq.com\",\"role_id\":\"3\",\"pid\":\"0\",\"status\":\"1\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\"}', 'INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`address`,`email`,`account`,`role_id`,`pid`,`status`,`password`,`add_time`,`last_time`) VALUES (\'mingshengshangcheng\',\'民生商城\',\'18999999999\',\'beijing\',\'aaa@qq.com\',\'aaa123@qq.com\',3,0,1,\'dc483e80a7a0bd9ef71d8cf973673924\',1502373629,1502373629)', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'admin', '1', null, '添加用户_民生商城', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('29', 'admin', '2017-08-10 22:01:21', '添加', '用户_北京分行', '{\"user_name\":\"beijingfenghang\",\"user_id\":\"\\u5317\\u4eac\\u5206\\u884c\",\"mobile\":\"18999999999\",\"address\":\"beijing\",\"email\":\"bj@qq.com\",\"account\":\"bj123@qq.com\",\"role_id\":\"4\",\"pid\":\"0\",\"status\":\"1\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\"}', 'INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`address`,`email`,`account`,`role_id`,`pid`,`status`,`password`,`add_time`,`last_time`) VALUES (\'beijingfenghang\',\'北京分行\',\'18999999999\',\'beijing\',\'bj@qq.com\',\'bj123@qq.com\',4,0,1,\'dc483e80a7a0bd9ef71d8cf973673924\',1502373681,1502373681)', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'admin', '1', null, '添加用户_北京分行', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('30', 'admin', '2017-08-10 22:02:46', '添加', '合同', '{\"id\":\"\",\"con_id\":\"c1001\",\"con_type\":\"3\",\"shop_id\":\"11\",\"period\":\"1\",\"platform_id\":\"1\",\"begin_time\":1502294400,\"end_time\":\"1533830400\",\"period_account\":\"30\",\"freight\":\"8\",\"title\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"dosubmit\":\"1\",\"uid\":\"1\",\"update_time\":1502373766,\"add_time\":1502373766}', 'INSERT INTO `cps_contract` (`id`,`con_id`,`con_type`,`shop_id`,`period`,`platform_id`,`begin_time`,`end_time`,`period_account`,`freight`,`title`,`uid`,`update_time`,`add_time`) VALUES (0,\'c1001\',\'3\',\'11\',\'1\',1,1502294400,\'1533830400\',\'30\',\'8\',\'民生商城合同\',1,1502373766,1502373766)', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'contract', '1', null, '添加合同', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('31', 'admin', '2017-08-10 22:04:03', '修改', '合同（导入商品佣金）', '{\"id\":\"3\",\"shop_id\":\"11\",\"contract\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"platform_id\":\"1\",\"dosubmit\":\"2\"}', '[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (14,\'\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\',1,3439034,20,299.8,\'\\u6570\\u7801\',\'\\u6570\\u7801\',1499,\'FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',\'https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\',\'https:\\/\\/item.jd.com\\/3439034.html\',\'3\',1,\'1\',1502373843,1502373843)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (12,\'\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\',1,\'sku10880611\',15,266.4,\'\\u9152\\u6c34\\u996e\\u6599\',\'\\u9152\\u6c34\\u996e\\u6599\',1776,\'52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',\'http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\',\'http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\',\'3\',1,\'1\',1502373843,1502373843)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\',1,23,20,165.8,\'\\u73e0\\u5b9d\\u914d\\u9970\',\'\\u73e0\\u5b9d\\u914d\\u9970\',829,\'\\u5948\\u552f \\u8db3\\u91d1\\u8f6c\\u8fd0\\u73e0\\u624b\\u94fe [\\u5706\\u5706\\u6ee1\\u6ee1]\',\'http:\\/\\/wd2.jieqiangtec.com\\/attachment\\/images\\/5\\/2017\\/07\\/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg\',\'http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23\',\'3\',1,\'1\',1502373843,1502373843)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\',1,25,20,0.002,\'\\u73e0\\u5b9d\\u914d\\u9970\',\'\\u73e0\\u5b9d\\u914d\\u9970\',0.01,\'\\u6d4b\\u8bd5\',\'http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/07\\/H0QAu1cWCWPhhQ00anhahW6hEHAZs6.jpg\',\'http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=25\',\'3\',1,\'1\',1502373843,1502373843)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '1', null, '修改合同（导入商品佣金）', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('32', 'admin', '2017-08-10 22:04:03', '修改', '合同（导入商品内容）', '[{\"shop_id\":14,\"contract\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"platform_id\":\"1\",\"dosubmit\":\"2\",\"item_id\":3439034,\"rate\":20,\"commission\":299.8,\"cate_name\":\"\\u6570\\u7801\",\"cate_id\":\"\\u6570\\u7801\",\"cid\":\"\\u6570\\u7801\",\"price\":1499,\"title\":\"FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\",\"img\":\"https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\",\"url\":\"https:\\/\\/item.jd.com\\/3439034.html\",\"con_id\":\"3\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502373843,\"add_time\":1502373843,\"name\":\"\\u6570\\u7801\"},{\"shop_id\":12,\"contract\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"platform_id\":\"1\",\"dosubmit\":\"2\",\"item_id\":\"sku10880611\",\"rate\":15,\"commission\":266.4,\"cate_name\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cate_id\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cid\":\"\\u9152\\u6c34\\u996e\\u6599\",\"price\":1776,\"title\":\"52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\",\"img\":\"http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\",\"url\":\"http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\",\"con_id\":\"3\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502373843,\"add_time\":1502373843,\"name\":\"\\u9152\\u6c34\\u996e\\u6599\"},{\"shop_id\":11,\"contract\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"platform_id\":\"1\",\"dosubmit\":\"2\",\"item_id\":23,\"rate\":20,\"commission\":165.8,\"cate_name\":\"\\u73e0\\u5b9d\\u914d\\u9970\",\"cate_id\":\"\\u73e0\\u5b9d\\u914d\\u9970\",\"cid\":\"\\u73e0\\u5b9d\\u914d\\u9970\",\"price\":829,\"title\":\"\\u5948\\u552f \\u8db3\\u91d1\\u8f6c\\u8fd0\\u73e0\\u624b\\u94fe [\\u5706\\u5706\\u6ee1\\u6ee1]\",\"img\":\"http:\\/\\/wd2.jieqiangtec.com\\/attachment\\/images\\/5\\/2017\\/07\\/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg\",\"url\":\"http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23\",\"con_id\":\"3\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502373843,\"add_time\":1502373843,\"name\":\"\\u73e0\\u5b9d\\u914d\\u9970\"},{\"shop_id\":11,\"contract\":\"\\u6c11\\u751f\\u5546\\u57ce\\u5408\\u540c\",\"platform_id\":\"1\",\"dosubmit\":\"2\",\"item_id\":25,\"rate\":20,\"commission\":0.002,\"cate_name\":\"\\u73e0\\u5b9d\\u914d\\u9970\",\"cate_id\":\"\\u73e0\\u5b9d\\u914d\\u9970\",\"cid\":\"\\u73e0\\u5b9d\\u914d\\u9970\",\"price\":0.01,\"title\":\"\\u6d4b\\u8bd5\",\"img\":\"http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/07\\/H0QAu1cWCWPhhQ00anhahW6hEHAZs6.jpg\",\"url\":\"http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=25\",\"con_id\":\"3\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502373843,\"add_time\":1502373843}]', '[\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (14,3439034,\'\\u6570\\u7801\',0,1499,\'FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',\'https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\',\'https:\\/\\/item.jd.com\\/3439034.html\',1,1502373843,1502373843)\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (12,\'sku10880611\',\'\\u9152\\u6c34\\u996e\\u6599\',0,1776,\'52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',\'http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\',\'http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\',1,1502373843,1502373843)\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (11,23,\'\\u73e0\\u5b9d\\u914d\\u9970\',0,829,\'\\u5948\\u552f \\u8db3\\u91d1\\u8f6c\\u8fd0\\u73e0\\u624b\\u94fe [\\u5706\\u5706\\u6ee1\\u6ee1]\',\'http:\\/\\/wd2.jieqiangtec.com\\/attachment\\/images\\/5\\/2017\\/07\\/k0FQlfuTs0rfsqtz707tuBHubyUtl0.jpg\',\'http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=23\',1,1502373843,1502373843)\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (11,25,\'\\u73e0\\u5b9d\\u914d\\u9970\',0,0.01,\'\\u6d4b\\u8bd5\',\'http:\\/\\/shop.adjyc.com\\/attachment\\/images\\/5\\/2017\\/07\\/H0QAu1cWCWPhhQ00anhahW6hEHAZs6.jpg\',\'http:\\/\\/shop.adjyc.com\\/app\\/index.php?i=5&c=entry&do=shop&m=ewei_shop&p=detail&id=25\',1,1502373843,1502373843)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '1', null, '修改合同（导入商品内容）', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('33', 'admin', '2017-08-10 22:04:51', '添加', '合同', '{\"id\":\"\",\"con_id\":\"c1002\",\"con_type\":\"4\",\"shop_id\":\"1\",\"period\":\"1\",\"platform_id\":\"12\",\"begin_time\":1502294400,\"end_time\":\"1533830400\",\"period_account\":\"30\",\"freight\":\"0\",\"title\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"dosubmit\":\"1\",\"uid\":\"1\",\"update_time\":1502373891,\"add_time\":1502373891}', 'INSERT INTO `cps_contract` (`id`,`con_id`,`con_type`,`shop_id`,`period`,`platform_id`,`begin_time`,`end_time`,`period_account`,`freight`,`title`,`uid`,`update_time`,`add_time`) VALUES (0,\'c1002\',\'4\',\'1\',\'1\',12,1502294400,\'1533830400\',\'30\',\'0\',\'北京分行合同\',1,1502373891,1502373891)', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'contract', '1', null, '添加合同', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('34', 'admin', '2017-08-10 22:05:55', '修改', '合同（导入商品佣金）', '{\"id\":\"4\",\"shop_id\":\"1\",\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\"}', '[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (14,\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',12,3439034,20,299.8,\'\\u6570\\u7801\',\'\\u6570\\u7801\',1499,\'FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',\'https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\',\'https:\\/\\/item.jd.com\\/3439034.html\',\'4\',1,\'1\',1502373955,1502373955)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (12,\'\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\',12,\'sku10880611\',15,266.4,\'\\u9152\\u6c34\\u996e\\u6599\',\'\\u9152\\u6c34\\u996e\\u6599\',1776,\'52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',\'http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\',\'http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\',\'4\',1,\'1\',1502373955,1502373955)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '1', null, '修改合同（导入商品佣金）', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('35', 'admin', '2017-08-10 22:05:55', '修改', '合同（导入商品内容）', '[{\"shop_id\":14,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":3439034,\"rate\":20,\"commission\":299.8,\"cate_name\":\"\\u6570\\u7801\",\"cate_id\":\"\\u6570\\u7801\",\"cid\":\"\\u6570\\u7801\",\"price\":1499,\"title\":\"FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\",\"img\":\"https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\",\"url\":\"https:\\/\\/item.jd.com\\/3439034.html\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502373955,\"add_time\":1502373955},{\"shop_id\":12,\"contract\":\"\\u5317\\u4eac\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":\"sku10880611\",\"rate\":15,\"commission\":266.4,\"cate_name\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cate_id\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cid\":\"\\u9152\\u6c34\\u996e\\u6599\",\"price\":1776,\"title\":\"52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\",\"img\":\"http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\",\"url\":\"http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\",\"con_id\":\"4\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502373955,\"add_time\":1502373955}]', '[\"UPDATE `cps_items` SET `shop_id`=14,`item_id`=3439034,`cate_name`=\'\\u6570\\u7801\',`cid`=0,`price`=1499,`title`=\'FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',`img`=\'https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\',`url`=\'https:\\/\\/item.jd.com\\/3439034.html\',`uid`=1,`update_time`=1502373955,`add_time`=1502373955 WHERE (   item_id=\'3439034\'  AND  shop_id=14  )\",\"UPDATE `cps_items` SET `shop_id`=12,`item_id`=\'sku10880611\',`cate_name`=\'\\u9152\\u6c34\\u996e\\u6599\',`cid`=0,`price`=1776,`title`=\'52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',`img`=\'http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\',`url`=\'http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\',`uid`=1,`update_time`=1502373955,`add_time`=1502373955 WHERE (   item_id=\'sku10880611\'  AND  shop_id=12  )\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '1', null, '修改合同（导入商品内容）', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('36', 'admin', '2017-08-10 22:28:14', '添加', '用户_天猫商城', '{\"user_name\":\"tianmaoshangcheng\",\"user_id\":\"\\u5929\\u732b\\u5546\\u57ce\",\"mobile\":\"18999999999\",\"address\":\"\\u5929\\u732b\",\"email\":\"tm@qq.com\",\"account\":\"tm@qq.com\",\"role_id\":\"3\",\"pid\":\"0\",\"status\":\"1\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\"}', 'INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`address`,`email`,`account`,`role_id`,`pid`,`status`,`password`,`add_time`,`last_time`) VALUES (\'tianmaoshangcheng\',\'天猫商城\',\'18999999999\',\'天猫\',\'tm@qq.com\',\'tm@qq.com\',3,0,1,\'dc483e80a7a0bd9ef71d8cf973673924\',1502375294,1502375294)', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'admin', '1', null, '添加用户_天猫商城', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('37', 'admin', '2017-08-10 22:29:24', '添加', '用户_福建分行', '{\"user_name\":\"fujianfenghang\",\"user_id\":\"\\u798f\\u5efa\\u5206\\u884c\",\"mobile\":\"18999999999\",\"address\":\"\\u798f\\u5efa\",\"email\":\"fj@qq.com\",\"account\":\"fj@qq.com\",\"role_id\":\"4\",\"pid\":\"0\",\"status\":\"1\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\"}', 'INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`address`,`email`,`account`,`role_id`,`pid`,`status`,`password`,`add_time`,`last_time`) VALUES (\'fujianfenghang\',\'福建分行\',\'18999999999\',\'福建\',\'fj@qq.com\',\'fj@qq.com\',4,0,1,\'dc483e80a7a0bd9ef71d8cf973673924\',1502375364,1502375364)', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'admin', '1', null, '添加用户_福建分行', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('38', 'admin', '2017-08-10 23:05:07', '添加', '合同', '{\"id\":\"\",\"con_id\":\"c1003\",\"con_type\":\"1\",\"shop_id\":\"13\",\"period\":\"1\",\"platform_id\":\"1\",\"begin_time\":1502294400,\"end_time\":\"1533830400\",\"period_account\":\"30\",\"freight\":\"0\",\"title\":\"\\u5929\\u732b\\u5546\\u57ce\",\"dosubmit\":\"1\",\"uid\":\"1\",\"update_time\":1502377507,\"add_time\":1502377507}', 'INSERT INTO `cps_contract` (`id`,`con_id`,`con_type`,`shop_id`,`period`,`platform_id`,`begin_time`,`end_time`,`period_account`,`freight`,`title`,`uid`,`update_time`,`add_time`) VALUES (0,\'c1003\',\'1\',\'13\',\'1\',1,1502294400,\'1533830400\',\'30\',\'0\',\'天猫商城\',1,1502377507,1502377507)', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'contract', '1', null, '添加合同', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('39', 'admin', '2017-08-10 23:07:31', '修改', '合同（导入商品佣金）', '{\"id\":\"5\",\"shop_id\":\"13\",\"contract\":\"\\u5929\\u732b\\u5546\\u57ce\",\"platform_id\":\"1\",\"dosubmit\":\"2\"}', '[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (13,\'\\u5929\\u732b\\u5546\\u57ce\',1,\'tm3439034\',20,299.8,\'\\u6570\\u7801\',\'\\u6570\\u7801\',1499,\'\\u5929\\u732b\\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',\'https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\',\'https:\\/\\/item.jd.com\\/3439034.html\',\'5\',1,\'1\',1502377651,1502377651)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (13,\'\\u5929\\u732b\\u5546\\u57ce\',1,\'sku10880611\',15,266.4,\'\\u9152\\u6c34\\u996e\\u6599\',\'\\u9152\\u6c34\\u996e\\u6599\',1776,\'\\u5929\\u732b52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',\'http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\',\'http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\',\'5\',1,\'1\',1502377651,1502377651)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '1', null, '修改合同（导入商品佣金）', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('40', 'admin', '2017-08-10 23:07:31', '修改', '合同（导入商品内容）', '[{\"shop_id\":13,\"contract\":\"\\u5929\\u732b\\u5546\\u57ce\",\"platform_id\":\"1\",\"dosubmit\":\"2\",\"item_id\":\"tm3439034\",\"rate\":20,\"commission\":299.8,\"cate_name\":\"\\u6570\\u7801\",\"cate_id\":\"\\u6570\\u7801\",\"cid\":\"\\u6570\\u7801\",\"price\":1499,\"title\":\"\\u5929\\u732b\\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\",\"img\":\"https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\",\"url\":\"https:\\/\\/item.jd.com\\/3439034.html\",\"con_id\":\"5\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502377651,\"add_time\":1502377651},{\"shop_id\":13,\"contract\":\"\\u5929\\u732b\\u5546\\u57ce\",\"platform_id\":\"1\",\"dosubmit\":\"2\",\"item_id\":\"sku10880611\",\"rate\":15,\"commission\":266.4,\"cate_name\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cate_id\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cid\":\"\\u9152\\u6c34\\u996e\\u6599\",\"price\":1776,\"title\":\"\\u5929\\u732b52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\",\"img\":\"http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\",\"url\":\"http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\",\"con_id\":\"5\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502377651,\"add_time\":1502377651}]', '[\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (13,\'tm3439034\',\'\\u6570\\u7801\',0,1499,\'\\u5929\\u732b\\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',\'https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\',\'https:\\/\\/item.jd.com\\/3439034.html\',1,1502377651,1502377651)\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (13,\'sku10880611\',\'\\u9152\\u6c34\\u996e\\u6599\',0,1776,\'\\u5929\\u732b52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',\'http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\',\'http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\',1,1502377651,1502377651)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '1', null, '修改合同（导入商品内容）', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('41', 'admin', '2017-08-10 23:08:54', '添加', '合同', '{\"id\":\"\",\"con_id\":\"c1004\",\"con_type\":\"4\",\"shop_id\":\"1\",\"period\":\"1\",\"platform_id\":\"14\",\"begin_time\":1502294400,\"end_time\":\"1533830400\",\"period_account\":\"30\",\"freight\":\"0\",\"title\":\"\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\",\"dosubmit\":\"1\",\"uid\":\"1\",\"update_time\":1502377734,\"add_time\":1502377734}', 'INSERT INTO `cps_contract` (`id`,`con_id`,`con_type`,`shop_id`,`period`,`platform_id`,`begin_time`,`end_time`,`period_account`,`freight`,`title`,`uid`,`update_time`,`add_time`) VALUES (0,\'c1004\',\'4\',\'1\',\'1\',14,1502294400,\'1533830400\',\'30\',\'0\',\'福建分行合同\',1,1502377734,1502377734)', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'contract', '1', null, '添加合同', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('42', 'admin', '2017-08-10 23:10:45', '修改', '合同（导入商品佣金）', '{\"id\":\"6\",\"shop_id\":\"1\",\"contract\":\"\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"14\",\"dosubmit\":\"2\"}', '[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (13,\'\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\',14,\'tm3439034\',20,299.8,\'\\u6570\\u7801\',\'\\u6570\\u7801\',1499,\'\\u5929\\u732b\\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',\'https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\',\'https:\\/\\/item.jd.com\\/3439034.html\',\'6\',1,\'1\',1502377845,1502377845)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`img`,`url`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\',14,\'sku10880611\',15,266.4,\'\\u9152\\u6c34\\u996e\\u6599\',\'\\u9152\\u6c34\\u996e\\u6599\',1776,\'52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',\'http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\',\'http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\',\'6\',1,\'1\',1502377845,1502377845)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '1', null, '修改合同（导入商品佣金）', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('43', 'admin', '2017-08-10 23:10:45', '修改', '合同（导入商品内容）', '[{\"shop_id\":13,\"contract\":\"\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"14\",\"dosubmit\":\"2\",\"item_id\":\"tm3439034\",\"rate\":20,\"commission\":299.8,\"cate_name\":\"\\u6570\\u7801\",\"cate_id\":\"\\u6570\\u7801\",\"cid\":\"\\u6570\\u7801\",\"price\":1499,\"title\":\"\\u5929\\u732b\\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\",\"img\":\"https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\",\"url\":\"https:\\/\\/item.jd.com\\/3439034.html\",\"con_id\":\"6\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502377845,\"add_time\":1502377845},{\"shop_id\":11,\"contract\":\"\\u798f\\u5efa\\u5206\\u884c\\u5408\\u540c\",\"platform_id\":\"14\",\"dosubmit\":\"2\",\"item_id\":\"sku10880611\",\"rate\":15,\"commission\":266.4,\"cate_name\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cate_id\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cid\":\"\\u9152\\u6c34\\u996e\\u6599\",\"price\":1776,\"title\":\"52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\",\"img\":\"http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\",\"url\":\"http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\",\"con_id\":\"6\",\"uid\":\"1\",\"role_id\":\"1\",\"update_time\":1502377845,\"add_time\":1502377845}]', '[\"UPDATE `cps_items` SET `shop_id`=13,`item_id`=\'tm3439034\',`cate_name`=\'\\u6570\\u7801\',`cid`=0,`price`=1499,`title`=\'\\u5929\\u732b\\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',`img`=\'https:\\/\\/img14.360buyimg.com\\/n5\\/s54x54_jfs\\/t2590\\/228\\/4101190783\\/80643\\/103dc60d\\/57a98a7aN8c8b3b8f.jpg\',`url`=\'https:\\/\\/item.jd.com\\/3439034.html\',`uid`=1,`update_time`=1502377845,`add_time`=1502377845 WHERE (   item_id=\'tm3439034\'  AND  shop_id=13  )\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`img`,`url`,`uid`,`update_time`,`add_time`) VALUES (11,\'sku10880611\',\'\\u9152\\u6c34\\u996e\\u6599\',0,1776,\'52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',\'http:\\/\\/img.minshengec.com\\/product\\/pics\\/2016\\/8\\/16\\/384855\\/384855-4-1469-1-400_400.jpg\',\'http:\\/\\/item.minshengec.com\\/c-msdszy\\/spu-384855-sku10880611.jhtml\',1,1502377845,1502377845)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '1', null, '修改合同（导入商品内容）', 'cps平台');
INSERT INTO `cps_op_log` VALUES ('44', 'beijingfenghang', '2017-08-10 23:13:21', '批量添加', '用户', '[{\"dosubmit\":\"2\",\"user_name\":\"zhangsan12\",\"user_id\":\"\\u660c\\u5e73\\u652f\\u884c\",\"mobile\":\" 18958222222\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u660c\\u5e73\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"110.87.6.217\",\"update_time\":1502378001,\"last_time\":1502378001,\"add_time\":1502378001},{\"dosubmit\":\"2\",\"user_name\":\"chaoyang1\",\"user_id\":\"\\u671d\\u9633\\u652f\\u884c\",\"mobile\":\" 18999990000\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u671d\\u9633\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"110.87.6.217\",\"update_time\":1502378001,\"last_time\":1502378001,\"add_time\":1502378001},{\"dosubmit\":\"2\",\"user_name\":\"xicheng1\",\"user_id\":\"\\u897f\\u57ce\\u652f\\u884c\",\"mobile\":\" 18989898989\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u897f\\u57ce\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"110.87.6.217\",\"update_time\":1502378001,\"last_time\":1502378001,\"add_time\":1502378001},{\"dosubmit\":\"2\",\"user_name\":\"haidian1\",\"user_id\":\"\\u6d77\\u6dc0\\u652f\\u884c\",\"mobile\":\" 18989898989\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u6d77\\u6dc0\\u652f\\u884c\",\"role_id\":5,\"pid\":\"12\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"110.87.6.217\",\"update_time\":1502378001,\"last_time\":1502378001,\"add_time\":1502378001}]', '[\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'zhangsan12\',\'\\u660c\\u5e73\\u652f\\u884c\',\' 18958222222\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u660c\\u5e73\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'110.87.6.217\',1502378001,1502378001,1502378001)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'chaoyang1\',\'\\u671d\\u9633\\u652f\\u884c\',\' 18999990000\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u671d\\u9633\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'110.87.6.217\',1502378001,1502378001,1502378001)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'xicheng1\',\'\\u897f\\u57ce\\u652f\\u884c\',\' 18989898989\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u897f\\u57ce\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'110.87.6.217\',1502378001,1502378001,1502378001)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'haidian1\',\'\\u6d77\\u6dc0\\u652f\\u884c\',\' 18989898989\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u6d77\\u6dc0\\u652f\\u884c\',5,12,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'110.87.6.217\',1502378001,1502378001,1502378001)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'admin', '12', null, '批量添加用户', '北京分行');
INSERT INTO `cps_op_log` VALUES ('45', 'haidian1', '2017-08-10 23:16:08', '批量添加', '用户', '[{\"dosubmit\":\"2\",\"user_name\":\"zhangsan\",\"user_id\":\"\\u5f20\\u4e09\",\"mobile\":\" 18958222222\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u6d77\\u6dc0\\u652f\\u884c\",\"role_id\":6,\"pid\":\"18\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"110.87.6.217\",\"update_time\":1502378168,\"last_time\":1502378168,\"add_time\":1502378168},{\"dosubmit\":\"2\",\"user_name\":\"lisi\",\"user_id\":\"\\u674e\\u56db\",\"mobile\":\" 18999990000\",\"email\":\" bank_sub_xm@qq.com\",\"account\":\" bank_sub_xm@qq.com\",\"address\":\"\\u6d77\\u6dc0\\u652f\\u884c\",\"role_id\":6,\"pid\":\"18\",\"password\":\"dc483e80a7a0bd9ef71d8cf973673924\",\"data_state\":1,\"status\":1,\"ip\":\"110.87.6.217\",\"update_time\":1502378168,\"last_time\":1502378168,\"add_time\":1502378168}]', '[\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'zhangsan\',\'\\u5f20\\u4e09\',\' 18958222222\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u6d77\\u6dc0\\u652f\\u884c\',6,18,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'110.87.6.217\',1502378168,1502378168,1502378168)\",\"INSERT INTO `cps_admin` (`user_name`,`user_id`,`mobile`,`email`,`account`,`address`,`role_id`,`pid`,`password`,`data_state`,`status`,`ip`,`update_time`,`last_time`,`add_time`) VALUES (\'lisi\',\'\\u674e\\u56db\',\' 18999990000\',\' bank_sub_xm@qq.com\',\' bank_sub_xm@qq.com\',\'\\u6d77\\u6dc0\\u652f\\u884c\',6,18,\'dc483e80a7a0bd9ef71d8cf973673924\',1,1,\'110.87.6.217\',1502378168,1502378168,1502378168)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', 'admin', '18', null, '批量添加用户', '海淀支行');
INSERT INTO `cps_op_log` VALUES ('46', 'beijingfenghang', '2017-08-10 23:23:29', '修改', '合同（导入商品佣金）', '{\"id\":\"\",\"shop_id\":\"\",\"contract\":\"\",\"platform_id\":\"\",\"dosubmit\":\"2\"}', '[\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\',12,\'sku10880611\',10,177.6,\'\\u9152\\u6c34\\u996e\\u6599\',\'\\u9152\\u6c34\\u996e\\u6599\',1776,\'52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',\'\',12,\'4\',1502378609,1502378609)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (11,\'\',12,3439034,16,239.84,\'\\u6570\\u7801\',\'\\u6570\\u7801\',1499,\'FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',\'\',12,\'4\',1502378609,1502378609)\",\"INSERT INTO `cps_commission` (`shop_id`,`contract`,`platform_id`,`item_id`,`rate`,`commission`,`cate_name`,`cate_id`,`price`,`title`,`con_id`,`uid`,`role_id`,`update_time`,`add_time`) VALUES (\'\',\'\',12,null,null,null,null,null,null,null,\'\',12,\'4\',1502378609,1502378609)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '12', null, '修改合同（导入商品佣金）', '北京分行');
INSERT INTO `cps_op_log` VALUES ('47', 'beijingfenghang', '2017-08-10 23:23:29', '修改', '合同（导入商品内容）', '[{\"shop_id\":11,\"contract\":\"\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":\"sku10880611\",\"rate\":10,\"commission\":177.6,\"cate_name\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cate_id\":\"\\u9152\\u6c34\\u996e\\u6599\",\"cid\":\"\\u9152\\u6c34\\u996e\\u6599\",\"price\":1776,\"title\":\"52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\",\"con_id\":\"\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1502378609,\"add_time\":1502378609},{\"shop_id\":11,\"contract\":\"\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":3439034,\"rate\":16,\"commission\":239.84,\"cate_name\":\"\\u6570\\u7801\",\"cate_id\":\"\\u6570\\u7801\",\"cid\":\"\\u6570\\u7801\",\"price\":1499,\"title\":\"FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\",\"con_id\":\"\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1502378609,\"add_time\":1502378609},{\"shop_id\":\"\",\"contract\":\"\",\"platform_id\":\"12\",\"dosubmit\":\"2\",\"item_id\":null,\"rate\":null,\"commission\":null,\"cate_name\":null,\"cate_id\":null,\"cid\":null,\"price\":null,\"title\":null,\"con_id\":\"\",\"uid\":\"12\",\"role_id\":\"4\",\"update_time\":1502378609,\"add_time\":1502378609,\"name\":null}]', '[\"UPDATE `cps_items` SET `shop_id`=11,`item_id`=\'sku10880611\',`cate_name`=\'\\u9152\\u6c34\\u996e\\u6599\',`cid`=0,`price`=1776,`title`=\'52\\u5ea6\\u65b0\\u54c1\\u4e94\\u7cae\\u6db2\\uff08\\u666e\\u4e94\\uff09 [500ml*2\\u74f6]\',`uid`=12,`update_time`=1502378609,`add_time`=1502378609 WHERE (   item_id=\'sku10880611\'  AND  shop_id=11  )\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`uid`,`update_time`,`add_time`) VALUES (11,3439034,\'\\u6570\\u7801\',0,1499,\'FIIL Diva Pro \\u5934\\u6234\\u5f0f\\u65e0\\u7ebf\\u8033\\u673a \\u66dc\\u77f3\\u9ed1 \\u667a\\u80fd\\u964d\\u566a \\u672c\\u5730\\u9ad8\\u6e05\\u65e0\\u635f\\u64ad\\u653e \\u8bed\\u97f3\\u4ea4\\u4e92\',12,1502378609,1502378609)\",\"INSERT INTO `cps_items` (`shop_id`,`item_id`,`cate_name`,`cid`,`price`,`title`,`uid`,`update_time`,`add_time`) VALUES (0,null,null,null,null,null,12,1502378609,1502378609)\"]', '0', null, '0', null, '0', '0', null, null, '110.87.6.217', '', '12', null, '修改合同（导入商品内容）', '北京分行');

-- ----------------------------
-- Table structure for cps_orderlist
-- ----------------------------
DROP TABLE IF EXISTS `cps_orderlist`;
CREATE TABLE `cps_orderlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_time` varchar(20) DEFAULT '1444444231' COMMENT '下单时间',
  `seller_name` varchar(20) DEFAULT NULL COMMENT '推广人',
  `username` varchar(50) DEFAULT NULL,
  `order_code` varchar(50) DEFAULT NULL,
  `item_count` int(5) DEFAULT NULL,
  `item_price` varchar(10) DEFAULT NULL,
  `sales` varchar(20) DEFAULT NULL,
  `commission` varchar(10) DEFAULT NULL,
  `cash_back` varchar(10) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT '1' COMMENT '//订单状态',
  `is_update` int(1) NOT NULL DEFAULT '0' COMMENT '0表示未更新用户表，以及返现表，1表示已经更新，不需要再次更新',
  `jiesuan_data` datetime NOT NULL COMMENT '结算日期',
  `order_id` varchar(64) NOT NULL COMMENT '对方订单号',
  `cash_back_jifenbao` varchar(10) DEFAULT NULL,
  `shop_id` bigint(10) unsigned NOT NULL COMMENT '商户id',
  `item_id` varchar(32) NOT NULL COMMENT '商品id',
  `sum_price` varchar(10) DEFAULT '0' COMMENT '商品总价',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `platform_id` int(10) unsigned DEFAULT '0' COMMENT '分销平台，指定到机构？对，必须对应机构。',
  `settle_time` varchar(20) DEFAULT '0' COMMENT '结算时间',
  `settle_price` varchar(10) DEFAULT '0' COMMENT '结算总价',
  `settle_status` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态',
  `settle_status1_stc` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态  商城对cps的结算',
  `settle_status2_cts` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态 cps对商城的结算',
  `settle_status3_ctb` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态 cps对分行的结算',
  `settle_status4_btc` tinyint(20) NOT NULL DEFAULT '0' COMMENT '//结算状态 分行对cps的结算',
  `sid` varchar(20) DEFAULT '1' COMMENT '推广员id',
  `bank_id` varchar(20) DEFAULT '1' COMMENT '分行id',
  `bank_subid` varchar(20) DEFAULT '1' COMMENT '支行id',
  `data_state` tinyint(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  `cate_id` bigint(10) unsigned NOT NULL DEFAULT '1' COMMENT '分类id',
  `cate_name` varchar(128) DEFAULT '1' COMMENT '分类名称',
  `commission2` varchar(10) DEFAULT NULL COMMENT '分润',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `order_code` (`order_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='5.2.11订单表';

-- ----------------------------
-- Records of cps_orderlist
-- ----------------------------

-- ----------------------------
-- Table structure for cps_parameters
-- ----------------------------
DROP TABLE IF EXISTS `cps_parameters`;
CREATE TABLE `cps_parameters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `parameter_name` varchar(256) NOT NULL COMMENT '参数名',
  `parameter_id` varchar(3) NOT NULL COMMENT '参数id',
  `parameter_value` varchar(256) NOT NULL,
  `parameter_desc` varchar(1024) NOT NULL COMMENT '参数描述',
  `APP_FLAG01` varchar(1024) DEFAULT NULL,
  `data_state` char(1) DEFAULT '1' COMMENT '数据状态：0删除，1正常',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_parameters
-- ----------------------------
INSERT INTO `cps_parameters` VALUES ('39', 'DONATE_STATUS', '3', '已申请', '捐赠状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('2', 'period', '1', '半月', '结算周期', '', '1');
INSERT INTO `cps_parameters` VALUES ('22', 'ORDER_TIME', '3', '11:00-12:00', '预约时间', null, '1');
INSERT INTO `cps_parameters` VALUES ('5', 'period', '2', '一月', '结算周期', null, '1');
INSERT INTO `cps_parameters` VALUES ('6', 'period', '3', '季度', '结算周期', null, '1');
INSERT INTO `cps_parameters` VALUES ('7', 'period', '4', '年度', '结算周期', null, '1');
INSERT INTO `cps_parameters` VALUES ('21', 'ORDER_TIME', '2', '10:00-11:00', '预约时间', null, '1');
INSERT INTO `cps_parameters` VALUES ('11', 'check_status', '1', '已通过', '审核状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('12', 'check_status', '2', '审核中', '审核状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('13', 'check_status', '3', '已打回', '审核状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('14', 'payee', '1', '民生银行信用卡中心1', '收款方', null, '1');
INSERT INTO `cps_parameters` VALUES ('15', 'payee', '2', '民生银行信用卡中心2', '收款方', null, '1');
INSERT INTO `cps_parameters` VALUES ('16', 'payee', '3', '民生银行信用卡中心3', '收款方', null, '1');
INSERT INTO `cps_parameters` VALUES ('17', 'payee', '4', '民生银行信用卡中心4', '收款方', null, '1');
INSERT INTO `cps_parameters` VALUES ('18', 'settle_status', '0', '未结算', '结算状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('19', 'settle_status', '1', '已结算', '结算状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('20', 'settle_status', '2', '待审批', '结算状态', null, '0');
INSERT INTO `cps_parameters` VALUES ('23', 'ORDER_TIME', '4', '14:30-15:30', '预约时间', null, '1');
INSERT INTO `cps_parameters` VALUES ('24', 'ORDER_TIME', '5', '15:30-16:30', '预约时间', null, '1');
INSERT INTO `cps_parameters` VALUES ('25', 'ORDER_TIME', '6', '16:30-17:30', '预约时间', null, '1');
INSERT INTO `cps_parameters` VALUES ('26', 'IDEA_STATUS', '0', '已处理', '金点子状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('27', 'IDEA_STATUS', '1', '待处理', '金点子状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('28', 'IDEA_STATUS', '2', '处理中', '金点子状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('34', 'CAMP_STATE', '1', '进行中', '活动状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('33', 'CAMP_STATE', '0', '已结束', '活动状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('40', 'OBJECT_TYPE', '1', '生活必需品', '置换类别', null, '1');
INSERT INTO `cps_parameters` VALUES ('41', 'OBJECT_TYPE', '2', '装饰物品', '置换类别', null, '1');
INSERT INTO `cps_parameters` VALUES ('42', 'OBJECT_TYPE', '3', '学习用品', '置换类别', null, '1');
INSERT INTO `cps_parameters` VALUES ('43', 'OBJECT_TYPE', '4', '办公用品', '置换类别', null, '1');
INSERT INTO `cps_parameters` VALUES ('44', 'SERVICE_TYPE', '1', '交通', '生活服务类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('45', 'SERVICE_TYPE', '2', '娱乐', '生活服务类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('46', 'SERVICE_TYPE', '3', '餐饮', '生活服务类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('47', 'SERVICE_TYPE', '4', '生活', '生活服务类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('48', 'SERVICE_TYPE', '5', '银行', '生活服务类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('49', 'SERVICE_TYPE', '6', '住宿', '生活服务类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('50', 'SERVICE_TYPE', '7', '购物', '生活服务类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('92', 'IDEA_TYPE', '1', '建议', '金点子类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('52', 'SERVICE_TYPE', '11', '公交站', '交通', null, '1');
INSERT INTO `cps_parameters` VALUES ('53', 'SERVICE_TYPE', '12', '加油站', '交通', null, '1');
INSERT INTO `cps_parameters` VALUES ('54', 'SERVICE_TYPE', '13', '停车场', '交通', null, '1');
INSERT INTO `cps_parameters` VALUES ('55', 'SERVICE_TYPE', '19', '其他', '交通', null, '1');
INSERT INTO `cps_parameters` VALUES ('56', 'SERVICE_TYPE', '21', 'KTV', '娱乐', null, '1');
INSERT INTO `cps_parameters` VALUES ('57', 'SERVICE_TYPE', '22', '电影院', '娱乐', null, '1');
INSERT INTO `cps_parameters` VALUES ('58', 'SERVICE_TYPE', '23', '酒吧', '娱乐', null, '1');
INSERT INTO `cps_parameters` VALUES ('59', 'SERVICE_TYPE', '24', '网吧', '娱乐', null, '1');
INSERT INTO `cps_parameters` VALUES ('60', 'SERVICE_TYPE', '29', '其他', '娱乐', null, '1');
INSERT INTO `cps_parameters` VALUES ('61', 'SERVICE_TYPE', '31', '餐馆', '餐饮', null, '1');
INSERT INTO `cps_parameters` VALUES ('62', 'SERVICE_TYPE', '32', '中餐', '餐饮', null, '1');
INSERT INTO `cps_parameters` VALUES ('63', 'SERVICE_TYPE', '33', '西餐', '餐饮', null, '1');
INSERT INTO `cps_parameters` VALUES ('64', 'SERVICE_TYPE', '34', '咖啡馆', '餐饮', null, '1');
INSERT INTO `cps_parameters` VALUES ('65', 'SERVICE_TYPE', '39', '其他', '餐饮', null, '1');
INSERT INTO `cps_parameters` VALUES ('66', 'SERVICE_TYPE', '41', '学校', '生活', null, '1');
INSERT INTO `cps_parameters` VALUES ('67', 'SERVICE_TYPE', '42', '医院', '生活', null, '1');
INSERT INTO `cps_parameters` VALUES ('68', 'SERVICE_TYPE', '43', '公园', '生活', null, '1');
INSERT INTO `cps_parameters` VALUES ('69', 'SERVICE_TYPE', '49', '其他', '生活', null, '1');
INSERT INTO `cps_parameters` VALUES ('70', 'SERVICE_TYPE', '501', '中国银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('71', 'SERVICE_TYPE', '502', '建设银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('72', 'SERVICE_TYPE', '503', '工商银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('73', 'SERVICE_TYPE', '504', '农业银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('74', 'SERVICE_TYPE', '505', '中国银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('75', 'SERVICE_TYPE', '506', '兴业银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('76', 'SERVICE_TYPE', '507', '招商银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('77', 'SERVICE_TYPE', '508', '厦门银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('78', 'SERVICE_TYPE', '509', '交通银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('79', 'SERVICE_TYPE', '510', '平安银行', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('80', 'SERVICE_TYPE', '511', '农村信用社', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('81', 'SERVICE_TYPE', '599', '其他', '银行', null, '1');
INSERT INTO `cps_parameters` VALUES ('82', 'SERVICE_TYPE', '61', '宾馆', '住宿', null, '1');
INSERT INTO `cps_parameters` VALUES ('83', 'SERVICE_TYPE', '62', '酒店', '住宿', null, '1');
INSERT INTO `cps_parameters` VALUES ('84', 'SERVICE_TYPE', '63', '旅馆', '住宿', null, '1');
INSERT INTO `cps_parameters` VALUES ('85', 'SERVICE_TYPE', '69', '其他', '住宿', null, '1');
INSERT INTO `cps_parameters` VALUES ('86', 'SERVICE_TYPE', '71', '超市', '购物', null, '1');
INSERT INTO `cps_parameters` VALUES ('87', 'SERVICE_TYPE', '72', '商场', '购物', null, '1');
INSERT INTO `cps_parameters` VALUES ('88', 'SERVICE_TYPE', '73', '菜市场', '购物', null, '1');
INSERT INTO `cps_parameters` VALUES ('89', 'SERVICE_TYPE', '74', '书店', '购物', null, '1');
INSERT INTO `cps_parameters` VALUES ('90', 'SERVICE_TYPE', '75', '花店', '购物', null, '1');
INSERT INTO `cps_parameters` VALUES ('91', 'SERVICE_TYPE', '79', '其他', '购物', null, '1');
INSERT INTO `cps_parameters` VALUES ('93', 'EXCHANGE_STATUS', '0', '已处理', '置换状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('94', 'EXCHANGE_STATUS', '1', '进行中', '置换状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('95', 'EXCHANGE_STATUS', '2', '待审批', '置换状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('96', 'LOVE_STATE', '0', '已结束', '爱心帮扶状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('97', 'LOVE_STATE', '1', '进行中', '爱心帮扶状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('98', 'LOVE_STATE', '2', '待审批', '爱心帮扶状态', null, '1');
INSERT INTO `cps_parameters` VALUES ('99', 'LOVE_TYPE', '1', '寻求帮助', '爱心帮扶类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('100', 'LOVE_TYPE', '2', '提供帮助', '爱心帮扶类型', null, '1');
INSERT INTO `cps_parameters` VALUES ('101', 'APART_TYPE', '1', '一室一厅', '户型', null, '1');
INSERT INTO `cps_parameters` VALUES ('102', 'APART_TYPE', '2', '两室一厅', '户型', null, '1');
INSERT INTO `cps_parameters` VALUES ('103', 'APART_TYPE', '3', '三室一厅', '户型', null, '1');
INSERT INTO `cps_parameters` VALUES ('104', 'APART_TYPE', '4', '一房', '户型', null, '1');
INSERT INTO `cps_parameters` VALUES ('105', 'APART_TYPE', '5', '两房', '户型', null, '1');
INSERT INTO `cps_parameters` VALUES ('106', 'APART_TYPE', '6', '三房', '户型', null, '1');
INSERT INTO `cps_parameters` VALUES ('107', 'DECOR_TYPE', '1', '精装', '装修', null, '1');
INSERT INTO `cps_parameters` VALUES ('108', 'DECOR_TYPE', '2', '简装', '装修', null, '1');
INSERT INTO `cps_parameters` VALUES ('109', 'DECOR_TYPE', '3', '毛胚', '装修', null, '1');
INSERT INTO `cps_parameters` VALUES ('111', 'APART_TYPE', '7', '两室两厅', '户型', null, '1');
INSERT INTO `cps_parameters` VALUES ('112', 'Rentmoney_TYPE', '1', '0~500', '租金', null, '1');
INSERT INTO `cps_parameters` VALUES ('113', 'Rentmoney_TYPE', '2', '500~1000', '租金', null, '1');
INSERT INTO `cps_parameters` VALUES ('114', 'Rentmoney_TYPE', '3', '1000~2000', '租金', null, '1');
INSERT INTO `cps_parameters` VALUES ('115', 'Rentmoney_TYPE', '4', '2000~3000', '租金', null, '1');
INSERT INTO `cps_parameters` VALUES ('116', 'Rentmoney_TYPE', '5', '3000~10000', '租金', null, '1');

-- ----------------------------
-- Table structure for cps_poster
-- ----------------------------
DROP TABLE IF EXISTS `cps_poster`;
CREATE TABLE `cps_poster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `orig` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL COMMENT '文件路径',
  `info` mediumtext NOT NULL COMMENT '信息',
  `add_time` datetime NOT NULL,
  `ordid` tinyint(4) NOT NULL,
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-待审核 1-已审核',
  `platform_id` int(10) unsigned NOT NULL COMMENT '分销机构（发布的时候可指定全部或者具体分行、子机构的人员能看到）',
  `data_state` tinyint(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `shop_id` int(10) unsigned DEFAULT '0' COMMENT '商户id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `origin_id` bigint(20) unsigned DEFAULT NULL COMMENT '商品原始id',
  `origin_name` varchar(32) DEFAULT NULL COMMENT '商品原始title',
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  PRIMARY KEY (`id`),
  KEY `is_best` (`is_best`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='5.2.15 海报二维码表';

-- ----------------------------
-- Records of cps_poster
-- ----------------------------
INSERT INTO `cps_poster` VALUES ('106', '0', '', '', 'data/items/m_5921aa70b469e.png', '', '', '', '0000-00-00 00:00:00', '0', '0', '0', '0', '0', '0', null, '0', '0', '61', '1', '商品名称', '1');
INSERT INTO `cps_poster` VALUES ('107', '0', '', '', 'data/items/m_5921aa70b469e.png', '', '', '', '2017-05-21 23:02:33', '0', '0', '0', '1', '0', '1', '0000-00-00 00:00:00', '1', '0', '2', '106', '商品名称', '1');
INSERT INTO `cps_poster` VALUES ('108', '0', '', '', 'data/items/m_5921aa70b469e.png', '', '', '', '2017-05-21 23:03:06', '0', '0', '0', '1', '0', '1', '0000-00-00 00:00:00', '1', '0', '3', '106', '商品名称', '1');
INSERT INTO `cps_poster` VALUES ('109', '0', '', '', 'data/items/m_5921aa70b469e.png', '', '', '', '2017-05-21 23:05:36', '0', '0', '0', '1', '0', '1', '2017-05-21 23:05:36', '1', '0', '4', '106', '商品名称', '1');
INSERT INTO `cps_poster` VALUES ('110', '0', '', '', 'data/items/m_5921aa70b469e.png', '', '', '', '2017-05-21 23:16:45', '0', '0', '0', '1', '0', '1', '2017-05-21 23:16:45', '1', '0', '8', '106', '商品名称', '1');
INSERT INTO `cps_poster` VALUES ('130', '0', '', '', './data/qrcode/poster_1__sku10880611_11_1502376369.jpg', '', '', '', '2017-08-10 22:46:09', '0', '0', '0', '1', '0', '1', '2017-08-10 22:46:09', '0', '11', 'sku10880611', null, '52度新品五粮液（普五） [500ml*2瓶]', '1');
INSERT INTO `cps_poster` VALUES ('131', '0', '', '', './data/qrcode/poster___sku10880611_11_1502379417.jpg', '', '', '', '2017-08-10 23:36:57', '0', '0', '0', '1', '0', '1', '2017-08-10 23:36:57', '0', '11', 'sku10880611', '6', null, '1');
INSERT INTO `cps_poster` VALUES ('132', '0', '', '', './data/qrcode/poster___sku10880611_11_1502379430.jpg', '', '', '', '2017-08-10 23:37:10', '0', '0', '0', '1', '0', '1', '2017-08-10 23:37:10', '0', '11', 'sku10880611', '6', null, '1');
INSERT INTO `cps_poster` VALUES ('133', '0', '', '', './data/qrcode/poster_20__sku10880611_11_1502379504.jpg', '', '', '', '2017-08-10 23:38:24', '0', '0', '0', '1', '0', '1', '2017-08-10 23:38:24', '0', '11', 'sku10880611', null, '52度新品五粮液（普五） [500ml*2瓶]', '1');
INSERT INTO `cps_poster` VALUES ('134', '0', '', '', './data/qrcode/poster_20__sku10880611_11_1502379508.jpg', '', '', '', '2017-08-10 23:38:28', '0', '0', '0', '1', '0', '1', '2017-08-10 23:38:28', '0', '11', 'sku10880611', null, '52度新品五粮液（普五） [500ml*2瓶]', '1');
INSERT INTO `cps_poster` VALUES ('135', '0', '', '', './data/qrcode/poster_20__sku10880611_11_1502379508.jpg', '', '', '', '2017-08-10 23:38:29', '0', '0', '0', '1', '0', '1', '2017-08-10 23:38:29', '0', '11', 'sku10880611', null, '52度新品五粮液（普五） [500ml*2瓶]', '1');
INSERT INTO `cps_poster` VALUES ('136', '0', '', '', './data/qrcode/poster_20__sku10880611_11_1502379509.jpg', '', '', '', '2017-08-10 23:38:29', '0', '0', '0', '1', '0', '1', '2017-08-10 23:38:29', '0', '11', 'sku10880611', null, '52度新品五粮液（普五） [500ml*2瓶]', '1');

-- ----------------------------
-- Table structure for cps_push_log
-- ----------------------------
DROP TABLE IF EXISTS `cps_push_log`;
CREATE TABLE `cps_push_log` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `sname` varchar(40) DEFAULT NULL,
  `op_time` datetime DEFAULT NULL,
  `con_id` bigint(10) DEFAULT NULL COMMENT '合同编号id=cps_contract.id',
  `cate_id` bigint(10) DEFAULT NULL COMMENT '商品类别id',
  `item_id` varchar(32) DEFAULT NULL COMMENT '商品id',
  `bank_id` bigint(20) DEFAULT NULL COMMENT '推广分行id',
  `bank_subid` int(11) unsigned DEFAULT '0' COMMENT '子机构id',
  `data_state` char(1) DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  `score` int(10) DEFAULT '0' COMMENT '所需积分',
  `sid` int(10) unsigned DEFAULT '0' COMMENT '推广人id',
  `app` int(11) DEFAULT NULL COMMENT '活动',
  `status` char(1) DEFAULT NULL COMMENT '数据状态：2成功，1审核中',
  `content` varchar(255) DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL COMMENT '审核时间',
  `add_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `ip` varchar(255) DEFAULT NULL,
  `update_time` int(10) unsigned DEFAULT NULL COMMENT '修改时间',
  `commission_id` int(10) DEFAULT NULL,
  `cate_name` varchar(128) NOT NULL DEFAULT '1' COMMENT '分类名称',
  `shop_id` varchar(10) DEFAULT NULL COMMENT '商城id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='5.2.13推广记录表';

-- ----------------------------
-- Records of cps_push_log
-- ----------------------------
INSERT INTO `cps_push_log` VALUES ('1', null, null, null, null, 'sku10880611', null, '18', null, '0', '20', null, null, null, null, '1502379615', null, null, '22', '1', '11');
INSERT INTO `cps_push_log` VALUES ('2', null, null, null, null, 'sku10880611', null, '18', null, '0', '20', null, null, null, null, '1502379623', null, null, '22', '1', '11');
INSERT INTO `cps_push_log` VALUES ('3', null, null, null, null, 'sku10880611', null, '18', null, '0', '20', null, null, null, null, '1502379624', null, null, '22', '1', '11');
INSERT INTO `cps_push_log` VALUES ('4', null, null, null, null, 'sku10880611', null, '18', null, '0', '20', null, null, null, null, '1502379632', null, null, '22', '1', '11');
INSERT INTO `cps_push_log` VALUES ('5', null, null, null, null, 'sku10880611', null, '18', null, '0', '20', null, null, null, null, '1502379847', null, null, '22', '1', '11');
INSERT INTO `cps_push_log` VALUES ('6', null, null, null, null, 'sku10880611', null, '18', null, '0', '20', null, null, null, null, '1502379927', null, null, '22', '1', '11');
INSERT INTO `cps_push_log` VALUES ('7', null, null, null, null, 'sku10880611', null, '18', null, '0', '20', null, null, null, null, '1502380238', null, null, '22', '1', '11');

-- ----------------------------
-- Table structure for cps_role
-- ----------------------------
DROP TABLE IF EXISTS `cps_role`;
CREATE TABLE `cps_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(20) NOT NULL COMMENT '角色名称',
  `status` tinyint(1) unsigned DEFAULT NULL COMMENT '状态',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` int(11) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL COMMENT '更新时间',
  `data_state` tinyint(1) unsigned DEFAULT NULL COMMENT '数据状态：0删除，1正常',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='5.2.2角色表';

-- ----------------------------
-- Records of cps_role
-- ----------------------------
INSERT INTO `cps_role` VALUES ('1', '管理员(CPS)', '1', 'CPS平台666', '1208784792', '1254325558', null);
INSERT INTO `cps_role` VALUES ('3', '商城', '1', '商城', '0', '0', null);
INSERT INTO `cps_role` VALUES ('4', '分行', '1', '分行', '0', '0', null);
INSERT INTO `cps_role` VALUES ('5', '支行', '1', '支行（机构）', '0', '0', null);
INSERT INTO `cps_role` VALUES ('6', '客户经理', '1', '客户经理', '0', '0', null);

-- ----------------------------
-- Table structure for cps_seller_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_seller_cate`;
CREATE TABLE `cps_seller_cate` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `cid` int(8) NOT NULL,
  `name` varchar(200) NOT NULL,
  `count` int(8) NOT NULL,
  `seller_status` int(1) NOT NULL DEFAULT '1',
  `status` int(1) NOT NULL,
  `sort` int(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `index_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_seller_cate
-- ----------------------------
INSERT INTO `cps_seller_cate` VALUES ('122', '22', '食品饮料', '20', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('121', '21', '箱包皮具', '22', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('120', '20', '宠物用品', '1', '0', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('119', '19', '成人保健', '3', '0', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('118', '18', '饰品配饰', '14', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('117', '17', '汽车用品', '4', '0', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('116', '16', '旅游订票', '2', '0', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('115', '15', '钟表眼镜', '8', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('103', '3', '电脑笔记本', '14', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('102', '2', '手机数码', '24', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('114', '14', '药品保健', '8', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('113', '13', '数字卡软件', '3', '0', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('112', '12', '玩具礼品', '8', '0', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('111', '11', '办公用品', '1', '0', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('110', '10', '母婴用品', '14', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('109', '9', '居家生活', '18', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('108', '8', '家用电器', '16', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('107', '7', '户外休闲', '2', '0', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('106', '6', '综合百货', '15', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('105', '5', '化妆美容', '31', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('104', '4', '服装服饰', '79', '1', '1', '10');
INSERT INTO `cps_seller_cate` VALUES ('101', '1', '图书音像', '9', '1', '1', '10');

-- ----------------------------
-- Table structure for cps_seller_list
-- ----------------------------
DROP TABLE IF EXISTS `cps_seller_list`;
CREATE TABLE `cps_seller_list` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `sid` int(8) NOT NULL,
  `cate_id` int(8) NOT NULL,
  `name` varchar(200) NOT NULL,
  `site_logo` varchar(200) DEFAULT NULL,
  `net_logo` varchar(200) NOT NULL,
  `recommend` int(1) NOT NULL,
  `click_url` varchar(400) NOT NULL,
  `sort` int(6) NOT NULL,
  `description` varchar(200) NOT NULL,
  `freeshipment` int(1) NOT NULL,
  `installment` int(1) NOT NULL,
  `has_invoice` int(1) NOT NULL,
  `cash_back_rate` varchar(64) NOT NULL,
  `status` int(1) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_status` (`status`),
  KEY `index_recommend` (`recommend`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_seller_list
-- ----------------------------
INSERT INTO `cps_seller_list` VALUES ('1', '0', '0', '测试商家', './data/seller_list/58be96a17c57e.jpg', '', '1', '', '0', '测试商家\r\n测试商家\r\n测试商家\r\n测试商家\r\n测试商家', '1', '1', '1', '11', '1', '0');
INSERT INTO `cps_seller_list` VALUES ('2', '0', '0', '测试商家2', './data/seller_list/58c89dc76a889.jpg', '', '1', '', '0', '测试商家2测试商家2测试商家2', '1', '0', '0', '1', '1', '0');

-- ----------------------------
-- Table structure for cps_seller_list_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_seller_list_cate`;
CREATE TABLE `cps_seller_list_cate` (
  `list_id` int(11) NOT NULL,
  `cate_id` int(11) NOT NULL,
  KEY `list_id` (`list_id`),
  KEY `cate_id` (`cate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_seller_list_cate
-- ----------------------------
INSERT INTO `cps_seller_list_cate` VALUES ('1', '101');
INSERT INTO `cps_seller_list_cate` VALUES ('1', '118');
INSERT INTO `cps_seller_list_cate` VALUES ('1', '104');
INSERT INTO `cps_seller_list_cate` VALUES ('1', '110');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '122');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '112');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '111');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '110');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '108');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '106');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '105');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '104');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '114');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '120');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '119');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '118');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '116');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '103');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '102');
INSERT INTO `cps_seller_list_cate` VALUES ('2', '101');

-- ----------------------------
-- Table structure for cps_seller_list_goods
-- ----------------------------
DROP TABLE IF EXISTS `cps_seller_list_goods`;
CREATE TABLE `cps_seller_list_goods` (
  `id` int(11) NOT NULL,
  `seller_list_id` int(11) NOT NULL,
  `seller_cate_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `seller_name` varchar(100) NOT NULL,
  `pic_url` varchar(400) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `original_price` decimal(10,2) NOT NULL,
  `desc` tinytext NOT NULL,
  `click_url` varchar(400) NOT NULL,
  `seller_url` varchar(400) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `seller_list_id` (`seller_list_id`),
  KEY `seller_cate_id` (`seller_cate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_seller_list_goods
-- ----------------------------

-- ----------------------------
-- Table structure for cps_send_email_log
-- ----------------------------
DROP TABLE IF EXISTS `cps_send_email_log`;
CREATE TABLE `cps_send_email_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `md5` char(32) NOT NULL,
  `create_time` varchar(20) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `status` int(1) NOT NULL COMMENT '0表示没有激活，1表示激活',
  `address` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` varchar(1024) NOT NULL,
  `result` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_send_email_log
-- ----------------------------

-- ----------------------------
-- Table structure for cps_seo
-- ----------------------------
DROP TABLE IF EXISTS `cps_seo`;
CREATE TABLE `cps_seo` (
  `description` text,
  `keywords` text,
  `title` varchar(250) DEFAULT NULL,
  `actionname` varchar(30) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `actionname` (`actionname`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_seo
-- ----------------------------
INSERT INTO `cps_seo` VALUES ('{$site_name}是国内最大的优质商品购物分享社区，{$site_name}支持300多家b2c商家的商品发布。各路扮美达人与你分享购物经验、搭配秘笈、美人心计，发现喜欢，逛宝贝，逛街无处不做，让你感受逛街的乐趣吧。', '{$site_name}，逛宝贝，促销活动，购物返现，购物返利', '{$site_name}（htt）_ 发现喜欢，逛宝贝，逛街无处不在,让你感受逛街的乐趣', 'index', '6');
INSERT INTO `cps_seo` VALUES ('{$site_name}2012火热促销活动，包括服装服饰数码产品、美妆配饰、家用电器、居家生活、母婴用品、户外用品、食品饮料、图书音像等热门促销活动，便宜，优惠，值得信赖，尽在{$site_name}\r\n', '2012，火热促销活动，便宜，优惠，{$site_name}', '2012火热促销活动，进行中 - {$site_name}', 'promo', '10');
INSERT INTO `cps_seo` VALUES ('返现商家', '返现商家', '返现商家 - {$site_name}', 'seller', '13');
INSERT INTO `cps_seo` VALUES ('{$site_name}是中国最大的购物分享社区。各路扮美达人与你分享购物经验、搭配秘笈、美人心计，发现喜欢，逛宝贝，逛街无处不做，让你感受逛街的乐趣吧。\r\n', '{$site_name}开放平台，购物分享，逛宝贝，淘宝网购物,淘宝网女装,衣服搭配', '发现喜欢，逛宝贝 -24小时最热 - {$site_name}', 'search', '14');
INSERT INTO `cps_seo` VALUES ('{$site_name}专辑，收录美好点滴，记录你的美丽成长。你也可以在这里成为最受关注的专辑达人，享受粉丝们的热情追随。\r\n', '专辑，逛街，时尚，{$site_name}', '{$name}{$uname}{$title}{$album} 分享 - {$site_name}', 'album', '15');
INSERT INTO `cps_seo` VALUES ('{$name}让你发现当前流行的服饰搭配元素，喜欢逛街，逛宝贝，想要把衣服搭得美丽，来{$site_name}看时尚网友精心挑选出的当季最流行的衣服单品、最佳搭配、购买心得、购物链接，购物分享，逛街分享无处不做，让你感受逛街的乐趣。\r\n', '{$name}最热单品', '{$name}{$pname}{$lname}{$site_name}', 'cate', '16');
INSERT INTO `cps_seo` VALUES ('{$site_name}让你发现当前流行的服饰搭配元素，喜欢逛街，逛宝贝，想要把衣服搭得美丽，来{$site_name}看时尚网友精心挑选出的当季最流行的衣服单品、最佳搭配、购买心得、购物链接，购物分享，逛街分享无处不做，让你感受逛街的乐趣。\r\n', '{$tags}', '【图】{$title}{$site_name}', 'item', '17');
INSERT INTO `cps_seo` VALUES ('积分兑换', '积分兑换', '积分兑换 - {$site_name}', 'exchange_goods', '18');

-- ----------------------------
-- Table structure for cps_setting
-- ----------------------------
DROP TABLE IF EXISTS `cps_setting`;
CREATE TABLE `cps_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_setting
-- ----------------------------
INSERT INTO `cps_setting` VALUES ('1', 'site_name', 'CPS联盟系统');
INSERT INTO `cps_setting` VALUES ('2', 'site_title', 'CPS联盟系统');
INSERT INTO `cps_setting` VALUES ('3', 'site_keyword', 'CPS联盟系统');
INSERT INTO `cps_setting` VALUES ('4', 'site_description', 'CPS联盟系统');
INSERT INTO `cps_setting` VALUES ('5', 'site_status', '1');
INSERT INTO `cps_setting` VALUES ('6', 'site_icp', '京ICP备88888888号');
INSERT INTO `cps_setting` VALUES ('7', 'statistics_code', '');
INSERT INTO `cps_setting` VALUES ('8', 'closed_reason', '升级');
INSERT INTO `cps_setting` VALUES ('9', 'site_domain', 'http://msec.jieqiangtec.com');
INSERT INTO `cps_setting` VALUES ('10', 'taobao_usernick', '');
INSERT INTO `cps_setting` VALUES ('11', 'taobao_pid', '');
INSERT INTO `cps_setting` VALUES ('12', 'taobao_appkey', '');
INSERT INTO `cps_setting` VALUES ('13', 'taobao_appsecret', '');
INSERT INTO `cps_setting` VALUES ('14', 'weibo_url', 'http://www.weibo.com');
INSERT INTO `cps_setting` VALUES ('15', 'qqweibo_url', 'http://www.qq.com');
INSERT INTO `cps_setting` VALUES ('16', 'renren_url', '');
INSERT INTO `cps_setting` VALUES ('17', '163_url', '');
INSERT INTO `cps_setting` VALUES ('18', 'qqzone_url', '');
INSERT INTO `cps_setting` VALUES ('19', 'douban_url', '');
INSERT INTO `cps_setting` VALUES ('20', 'default_kw', '欧美,复古,日系,古典,女装,时尚');
INSERT INTO `cps_setting` VALUES ('21', 'template', 'default');
INSERT INTO `cps_setting` VALUES ('22', 'taobao_app_key', '12504724');
INSERT INTO `cps_setting` VALUES ('23', 'qq_app_key', '');
INSERT INTO `cps_setting` VALUES ('24', 'qq_app_Secret', '');
INSERT INTO `cps_setting` VALUES ('25', 'sina_app_key', '100308089');
INSERT INTO `cps_setting` VALUES ('26', 'sina_app_Secret', '25ee4d31ca98edea230885985e1cf2e1');
INSERT INTO `cps_setting` VALUES ('27', 'taobao_app_secret', '9d6877190386092d4288dcae32811081');
INSERT INTO `cps_setting` VALUES ('28', 'url_model', '0');
INSERT INTO `cps_setting` VALUES ('29', 'waterfall_sp', '15');
INSERT INTO `cps_setting` VALUES ('30', 'waterfall_items_num', '5');
INSERT INTO `cps_setting` VALUES ('31', 'client_hash', '');
INSERT INTO `cps_setting` VALUES ('32', 'search_words', '欧美,复古,日系,古典,女装,时尚,韩版');
INSERT INTO `cps_setting` VALUES ('33', 'miao_appkey', '1003336');
INSERT INTO `cps_setting` VALUES ('34', 'miao_appsecret', '0847c5008f99150de65fad8e8ec342fa');
INSERT INTO `cps_setting` VALUES ('35', 'is_cashback', '0');
INSERT INTO `cps_setting` VALUES ('36', 'cashback_rate', '50');
INSERT INTO `cps_setting` VALUES ('37', 'lowest_get_cash', '1');
INSERT INTO `cps_setting` VALUES ('38', 'integralback_rate', '12');
INSERT INTO `cps_setting` VALUES ('39', 'user_register_score', '51');
INSERT INTO `cps_setting` VALUES ('40', 'user_login_score', '2');
INSERT INTO `cps_setting` VALUES ('41', 'share_goods_score', '21');
INSERT INTO `cps_setting` VALUES ('42', 'delete_share_goods_score', '21');
INSERT INTO `cps_setting` VALUES ('43', 'mail_smtp', 'smtp.exmail.qq.com');
INSERT INTO `cps_setting` VALUES ('44', 'mail_username', 'cps@adjyc.com');
INSERT INTO `cps_setting` VALUES ('45', 'mail_password', 'Cps@017');
INSERT INTO `cps_setting` VALUES ('46', 'mail_port', '25');
INSERT INTO `cps_setting` VALUES ('47', 'mail_fromname', 'CPS管理员');
INSERT INTO `cps_setting` VALUES ('48', 'register_send_mail', '1');
INSERT INTO `cps_setting` VALUES ('49', 'lately_like_max', '10');
INSERT INTO `cps_setting` VALUES ('50', 'goods_save_images', '0');
INSERT INTO `cps_setting` VALUES ('51', 'lately_like_rand', '1,10');
INSERT INTO `cps_setting` VALUES ('52', 'check_code', '0');
INSERT INTO `cps_setting` VALUES ('53', 'comment_time', '10');
INSERT INTO `cps_setting` VALUES ('54', 'site_share', '<meta property=\"qc:admins\" content=\"271503564761116217636\" /> ');
INSERT INTO `cps_setting` VALUES ('55', 'ban_sipder', 'youdaobot|bingbot');
INSERT INTO `cps_setting` VALUES ('56', 'ban_ip', '192.168.1.50');
INSERT INTO `cps_setting` VALUES ('57', 'site_logo', './data/setting/58d9d2b3a7db9.jpg');
INSERT INTO `cps_setting` VALUES ('58', 'collect_time', '2');
INSERT INTO `cps_setting` VALUES ('59', 'goods_collect', '0');
INSERT INTO `cps_setting` VALUES ('60', 'article_count', '10');
INSERT INTO `cps_setting` VALUES ('61', 'show_masonry', '0');
INSERT INTO `cps_setting` VALUES ('62', 'seller_list_collect', '0');
INSERT INTO `cps_setting` VALUES ('63', 'seller_list_collect_time', '1');
INSERT INTO `cps_setting` VALUES ('64', 'html_suffix', '.html');
INSERT INTO `cps_setting` VALUES ('65', 'ucenterlogin', '0');
INSERT INTO `cps_setting` VALUES ('66', 'commission_rate_min', '500');
INSERT INTO `cps_setting` VALUES ('67', 'commission_rate_max', '2000');
INSERT INTO `cps_setting` VALUES ('68', 'levelstart', '1crown');
INSERT INTO `cps_setting` VALUES ('69', 'levelend', '2goldencrown');
INSERT INTO `cps_setting` VALUES ('70', 'tao_session', '6200712ae4ddb31d4cdegi04ee44b79a43a81cad4606ee0673992689');
INSERT INTO `cps_setting` VALUES ('71', 'lowest_get_jifen_cash', '100');
INSERT INTO `cps_setting` VALUES ('72', 'cashback_type', '1');
INSERT INTO `cps_setting` VALUES ('73', 'tb_fanxian_name', '红包');
INSERT INTO `cps_setting` VALUES ('74', 'tb_fanxian_unit', '个');
INSERT INTO `cps_setting` VALUES ('75', 'tb_fanxian_bili', '100');
INSERT INTO `cps_setting` VALUES ('76', 'display_b2c_ad', '1');
INSERT INTO `cps_setting` VALUES ('77', 'collect_cate', '');
INSERT INTO `cps_setting` VALUES ('78', 'tao_collect_set', '0');
INSERT INTO `cps_setting` VALUES ('79', 'taobao_search_pid', '');

-- ----------------------------
-- Table structure for cps_ucenter
-- ----------------------------
DROP TABLE IF EXISTS `cps_ucenter`;
CREATE TABLE `cps_ucenter` (
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_ucenter
-- ----------------------------
INSERT INTO `cps_ucenter` VALUES ('dbcharset', 'utf8');
INSERT INTO `cps_ucenter` VALUES ('charset', 'utf-8');
INSERT INTO `cps_ucenter` VALUES ('dbconnect', '0');
INSERT INTO `cps_ucenter` VALUES ('ppp', '20');
INSERT INTO `cps_ucenter` VALUES ('appid', '2');
INSERT INTO `cps_ucenter` VALUES ('key', '123456');
INSERT INTO `cps_ucenter` VALUES ('api', 'http://192.168.1.53/vgoubbs/uc_server');
INSERT INTO `cps_ucenter` VALUES ('ip', '');
INSERT INTO `cps_ucenter` VALUES ('connect', 'mysql');
INSERT INTO `cps_ucenter` VALUES ('dbhost', '192.168.1.100');
INSERT INTO `cps_ucenter` VALUES ('dbuser', 'root');
INSERT INTO `cps_ucenter` VALUES ('dbpw', '123456');
INSERT INTO `cps_ucenter` VALUES ('dbname', 'vgou_bbs');
INSERT INTO `cps_ucenter` VALUES ('dbtablepre', '`vgou_bbs`.pre_ucenter_');
INSERT INTO `cps_ucenter` VALUES ('uc_config', null);

-- ----------------------------
-- Table structure for cps_user
-- ----------------------------
DROP TABLE IF EXISTS `cps_user`;
CREATE TABLE `cps_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  `passwd` varchar(50) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `last_time` int(11) NOT NULL DEFAULT '0',
  `last_ip` varchar(15) DEFAULT '0',
  `is_majia` int(1) DEFAULT '0' COMMENT '0表示普通用户 1表示马甲',
  `login_count` int(10) DEFAULT '0',
  `mobile` varchar(13) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `add_time` (`add_time`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user
-- ----------------------------
INSERT INTO `cps_user` VALUES ('4', 'jieqiang', 'de562e3ceca28974c305237f2751ee6c', 'jieqiang@qq.com', '127.0.0.1', '1489051295', '1', '1489543034', '127.0.0.1', '0', '1', '18959269002');

-- ----------------------------
-- Table structure for cps_user_comments
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_comments`;
CREATE TABLE `cps_user_comments` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `uname` varchar(100) NOT NULL,
  `pid` int(10) NOT NULL DEFAULT '0',
  `info` text,
  `type` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `index_pid` (`pid`),
  KEY `index_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_comments
-- ----------------------------
INSERT INTO `cps_user_comments` VALUES ('1', '4', 'jieqiang', '1', 'ggggggggggggggg', 'item,index', '1', '1489544161');

-- ----------------------------
-- Table structure for cps_user_consignee
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_consignee`;
CREATE TABLE `cps_user_consignee` (
  `uid` int(11) NOT NULL,
  `region_lv1` int(11) NOT NULL DEFAULT '0',
  `region_lv2` int(11) NOT NULL DEFAULT '0',
  `region_lv3` int(11) NOT NULL DEFAULT '0',
  `region_lv4` int(11) NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL DEFAULT '',
  `mobile_phone` varchar(255) NOT NULL DEFAULT '',
  `fix_phone` varchar(255) NOT NULL DEFAULT '',
  `consignee` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(255) NOT NULL DEFAULT '',
  `qq` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(11) NOT NULL DEFAULT '0',
  `fax_phone` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_consignee
-- ----------------------------
INSERT INTO `cps_user_consignee` VALUES ('4', '0', '0', '0', '0', '福建省厦门市集美区', '18888888888', '', '街墙', '366200', '1569501393', '18888888888@163.com', '1489553243', '05922222222');

-- ----------------------------
-- Table structure for cps_user_follow
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_follow`;
CREATE TABLE `cps_user_follow` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fans_id` int(10) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fans_id` (`fans_id`,`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_follow
-- ----------------------------

-- ----------------------------
-- Table structure for cps_user_history
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_history`;
CREATE TABLE `cps_user_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `uname` varchar(100) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  `info` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_history
-- ----------------------------
INSERT INTO `cps_user_history` VALUES ('1', '4', 'jieqiang', '1489544165', '喜欢了一个宝贝~<br/><a href=\'http://www.ctw.com/index.php?a=index&m=item&id=1\' target=\'_blank\'><img src=\'http://www.ctw.com/data/items/m_58c8a3a5417e5.jpg\'/></a>');
INSERT INTO `cps_user_history` VALUES ('2', '4', '', '1489544175', '添加了一个宝贝到专辑中~<br/><a href=\'http://www.ctw.com/index.php?a=index&m=item&id=1\' target=\'_blank\'><img src=\'http://www.ctw.com/data/items/m_58c8a3a5417e5.jpg\'/></a>');

-- ----------------------------
-- Table structure for cps_user_info
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_info`;
CREATE TABLE `cps_user_info` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `sex` tinyint(4) NOT NULL DEFAULT '0' COMMENT '//0表示男，1表示女，2表示未知',
  `brithday` varchar(50) NOT NULL DEFAULT '1985|1|1',
  `address` varchar(50) NOT NULL DEFAULT '请选择|请选择',
  `blog` varchar(200) NOT NULL DEFAULT 'http://',
  `info` varchar(500) NOT NULL DEFAULT '自我介绍',
  `share_num` int(11) DEFAULT '0',
  `like_num` int(11) DEFAULT '0',
  `follow_num` int(10) DEFAULT '0',
  `fans_num` int(10) DEFAULT '0',
  `album_num` int(10) DEFAULT '0',
  `exchange_num` int(8) NOT NULL DEFAULT '0',
  `integral` int(10) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '用户资金',
  `jifenbao` decimal(10,0) DEFAULT '0',
  `constellation` tinyint(4) NOT NULL DEFAULT '0' COMMENT '星座',
  `job` tinyint(4) NOT NULL DEFAULT '0' COMMENT '职业',
  `qq` varchar(20) DEFAULT NULL,
  `realname` varchar(64) DEFAULT NULL,
  `alipay` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `integral` (`integral`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_info
-- ----------------------------
INSERT INTO `cps_user_info` VALUES ('4', '4', '2', '1985|1|1', '1|1', 'http://', '自我介绍', '0', '1', '0', '0', '0', '6', '49', '0.00', '0', '0', '0', '655555555', '街墙', 'jieqiangzhifubao@qq.com');

-- ----------------------------
-- Table structure for cps_user_msg
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_msg`;
CREATE TABLE `cps_user_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to_user` varchar(40) NOT NULL,
  `from_user` varchar(40) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `del` tinyint(1) NOT NULL,
  `date` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_msg
-- ----------------------------
INSERT INTO `cps_user_msg` VALUES ('1', 'jieqiang', 'admin', '用户注册短信', '尊敬的jieqiang您好:欢迎注册v购,凡是通过v购提供的链接去淘宝购物进行购物，都将享受到1%到50%成交额的返现，推广其他用户，即可获取被推广用户返现额的50%的推广佣金，推广越多挣钱越轻松。祝您购物愉快！也欢迎您把我们的网站告诉更多的淘宝买家，谢谢！', '0', '1489051295');
INSERT INTO `cps_user_msg` VALUES ('2', 'jieqiang', 'admin', '赠送积分短信', '恭喜您，您获得本站注册赠送积分51。', '0', '1489051295');
INSERT INTO `cps_user_msg` VALUES ('3', 'jieqiang', '', '积分兑换短信', '', '0', '1490240337');
INSERT INTO `cps_user_msg` VALUES ('4', 'jieqiang', '', '积分兑换短信', '', '0', '1490240344');

-- ----------------------------
-- Table structure for cps_user_openid
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_openid`;
CREATE TABLE `cps_user_openid` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `uname` varchar(100) NOT NULL,
  `openid` varchar(50) NOT NULL DEFAULT '0',
  `info` text,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `openid` (`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_openid
-- ----------------------------

-- ----------------------------
-- Table structure for cps_user_setmsg
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_setmsg`;
CREATE TABLE `cps_user_setmsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(20) NOT NULL,
  `val` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_setmsg
-- ----------------------------
INSERT INTO `cps_user_setmsg` VALUES ('51', 'msg_zhuce', '尊敬的[name]您好:欢迎注册[WEBTITLE],凡是通过[WEBTITLE]提供的链接去淘宝购物进行购物，都将享受到1%到50%成交额的返现，推广其他用户，即可获取被推广用户返现额的[tg]%的推广佣金，推广越多挣钱越轻松。祝您购物愉快！也欢迎您把我们的网站告诉更多的淘宝买家，谢谢！');
INSERT INTO `cps_user_setmsg` VALUES ('52', 'msg_zhucesong', '恭喜您，您获得本站注册赠送现金[ZHUCESONG]元。');
INSERT INTO `cps_user_setmsg` VALUES ('53', 'msg_zsjifen', '恭喜您，您获得本站注册赠送积分[ZSJIFEN]。');
INSERT INTO `cps_user_setmsg` VALUES ('54', 'msg_tabao', '交易号为：[trade_id]的交易确认完毕，您获得了[fxje]元的返现！');
INSERT INTO `cps_user_setmsg` VALUES ('55', 'msg_taobaotuiguang', '您推荐的会员[ddusername]，完成一笔交易，交易号为：[trade_id]确认完毕，您获得了[tgje]元的推广佣金！');
INSERT INTO `cps_user_setmsg` VALUES ('56', 'msg_tixianok', '尊敬的[ddusername]，您好：您的提现申请已经受理完毕！本次提现金额[txje]已经支付到您提供的账户，查看明细进入“我的账户明细”！[addition]');
INSERT INTO `cps_user_setmsg` VALUES ('57', 'msg_tixianfail', '您有一笔提现申请失败，原因是：[why]');
INSERT INTO `cps_user_setmsg` VALUES ('58', 'msg_deltrade', '交易号为：[trade_id]的交易确被取消，您减少了[fxje]元的返现！');
INSERT INTO `cps_user_setmsg` VALUES ('59', 'msg_deltradetuiguang', '您推荐的会员[ddusername]，取消了一笔交易，交易号为[trade_id]被确认无效，您减少了[tgje]元的推广佣金！');
INSERT INTO `cps_user_setmsg` VALUES ('60', 'msg_dhjifen', '您在本站使用积分兑换的商品订单[STATE]。');

-- ----------------------------
-- Table structure for cps_user_tixian
-- ----------------------------
DROP TABLE IF EXISTS `cps_user_tixian`;
CREATE TABLE `cps_user_tixian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `money` decimal(10,2) DEFAULT NULL,
  `jifenbao` decimal(10,0) DEFAULT '0',
  `remark` varchar(1000) NOT NULL,
  `addtime` varchar(40) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `reply` varchar(1000) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '//0表示没正在处理，1表示已经审核，2表示退回',
  `realname` varchar(64) DEFAULT NULL,
  `alipay` varchar(255) DEFAULT NULL,
  `is_money` int(1) DEFAULT '1' COMMENT '1表示钱2表示集分宝',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_user_tixian
-- ----------------------------

-- ----------------------------
-- Table structure for cps_wegoapi
-- ----------------------------
DROP TABLE IF EXISTS `cps_wegoapi`;
CREATE TABLE `cps_wegoapi` (
  `name` varchar(100) NOT NULL,
  `data` text NOT NULL,
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_wegoapi
-- ----------------------------
INSERT INTO `cps_wegoapi` VALUES ('username', '');
INSERT INTO `cps_wegoapi` VALUES ('password', '');
INSERT INTO `cps_wegoapi` VALUES ('weburl', '');
INSERT INTO `cps_wegoapi` VALUES ('token', '');
INSERT INTO `cps_wegoapi` VALUES ('commission_rate_min', '');
INSERT INTO `cps_wegoapi` VALUES ('commission_rate_max', '');
INSERT INTO `cps_wegoapi` VALUES ('levelstart', '1heart');
INSERT INTO `cps_wegoapi` VALUES ('levelend', '5goldencrown');
INSERT INTO `cps_wegoapi` VALUES ('tao_collect_set', '0');
INSERT INTO `cps_wegoapi` VALUES ('order', '3');
INSERT INTO `cps_wegoapi` VALUES ('price_min', '');
INSERT INTO `cps_wegoapi` VALUES ('price_max', '200');
INSERT INTO `cps_wegoapi` VALUES ('sign', '123456789');

-- ----------------------------
-- Table structure for cps_word
-- ----------------------------
DROP TABLE IF EXISTS `cps_word`;
CREATE TABLE `cps_word` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `cid` smallint(6) NOT NULL DEFAULT '0',
  `word` varchar(255) NOT NULL DEFAULT '',
  `replacement` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(2) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `cid` (`cid`),
  KEY `word` (`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_word
-- ----------------------------

-- ----------------------------
-- Table structure for cps_word_cate
-- ----------------------------
DROP TABLE IF EXISTS `cps_word_cate`;
CREATE TABLE `cps_word_cate` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cps_word_cate
-- ----------------------------
INSERT INTO `cps_word_cate` VALUES ('3', '政治', '1');
INSERT INTO `cps_word_cate` VALUES ('4', '时政', '1');
