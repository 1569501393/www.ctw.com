<?php
define("IN_KEKE", TRUE);
$poster_bg = './qrcode/poster_bg.jpg';  // 海报背景图
//$qrcode_thumb = './qrcode/qrcode.jpg'; // 二维码
$qrcode = './qrcode/qrcode.jpg'; // 二维码
$head_source = @imagecreatefromjpeg('./qrcode/header.jpg'); // imagecreatefromjpeg — 由文件或URL创建一个新图象


$qrcode_path = $poster_path = './qrcode/'; //存放目录
$openid = 'a123456' . time(); // 文件命名
header("Content-type: image/jpeg");

//创建目标图像
//$dst_im = imagecreatetruecolor(150, 150);
$dst_im = @imagecreatefromjpeg("./qrcode/poster_bg.jpg");

//源图像
//$src_im = @imagecreatefromjpeg("./qrcode/qrcode.jpg");
$src_im = @imagecreatefromjpeg("./qrcode/qrcode2.jpg");
$qrcode_srouce = @imagecreatefromjpeg("./qrcode/qrcode.jpg");

//微信二维码默认是430像素，将其缩放成300像素，核心代码如下
$qrcode_thumb = imagecreatetruecolor(300, 300);
imagecopyresampled($qrcode_thumb, $qrcode_srouce, 0, 0, 0, 0, 300, 300, 430, 430);

//头像合成到二维码图片上
imagecopy($qrcode_thumb, $head_source, 118, 118, 0, 0, 64, 64);

//拷贝源图像左上角起始 150px 150px
//imagecopy( $dst_im, $src_im, 0, 0, 0, 0, 150, 150 );
//imagecopy( $dst_im, $src_im, 0, 0, 0, 0, 430,  430 );

//加水印
//imagecopy($dst_im, $src_im, 212, 410, 0, 0, 300, 300);    //水印位置
imagecopy($dst_im, $qrcode_thumb, 212, 410, 0, 0, 300, 300);    //水印位置

//输出拷贝后图像
imagejpeg($dst_im);//输出
imagejpeg($dst_im, $qrcode_path . $openid . ".jpg", 90);//保存图片

imagedestroy($dst_im);
imagedestroy($src_im);

exit;
//header("Content-type: text/html; charset=utf-8");
header('Content-type: image/jpeg');
define("IN_KEKE", TRUE);
$poster_bg = './qrcode/poster_bg.jpg';
$qrcode_thumb = './qrcode/qrcode.jpg';
$head_source = './qrcode/header.jpg';
$qrcode_path = $poster_path = './qrcode/';
$openid = 'a123456';


//拷贝源图像左上角起始 150px 150px
imagecopy($poster_bg, $qrcode_thumb, 0, 0, 0, 0, 15, 15);

//输出拷贝后图像
imagejpeg($poster_bg);

imagedestroy($dst_im);
imagedestroy($src_im);
exit;
//imagecopy($poster_bg, $qrcode_thumb, 118, 118, 0, 0, 64, 64);

//输出拷贝后图像
imagejpeg($poster_bg);
exit;

//var_dump(Create_img());
//var_dump(111);
$qr_content = $qrcode_thumb;
//header('Content-type: image/jpg');
ob_end_clean();
//缩放二维码大小为需要的大小，并将二维码加入到海报中
//$thumb = imagecreatetruecolor(200, 200);
$thumb = './qrcode/poster_bg.jpg';
//var_dump($thumb);

//获取源文件资源句柄。接收参数为图片流，返回句柄
//$source = imagecreatefromstring($qr_content);
$source = $qr_content;
//var_dump($source);
//将源文件剪切全部域并缩小放到目标图片上，前两个为资源句柄
imagecopyresampled($thumb, $source, 0, 0, 0, 0, 200, 200, 430, 430);
//创建图片的实例，接收参数为图片
$dst_qr = @imagecreatefromstring(file_get_contents($head_source));
var_dump($dst_qr);
//加水印
imagecopy($dst_qr, $thumb, 320, 50, 0, 0, 200, 200);
//销毁
imagedestroy($thumb);
$openid = 'a' . time();
var_dump($dst_qr, $qrcode_path . $openid . ".jpg");

ob_start();//启用输出缓存，暂时将要输出的内容缓存起来
imagejpeg($dst_qr, $qrcode_path . $openid . ".jpg", 90);//输出

$poster = ob_get_contents();//获取刚才获取的缓存
ob_end_clean();//清空缓存
imagedestroy($dst_qr);
$post_data['media'] = '@' . $qrcode_path . $openid . ".jpg";
//$result = $this->uploadMedia($this->getAccessToken(), "image", $post_data);
//if ($result) {
//    $media_id = $result->media_id;
//}
//var_dump($post_data);

exit;


/*
    @$poster_path  海报路径
    @$openid       当前用户openid
    @$qrcode_path  生成的目录
   */
//function Create_img($poster_path = "./qrcode/", $qrcode_path = "./qrcode/", $openid = 'o123456')
//{
//    if ($openid) {
//        $this->Check_dir($poster_path);
//        $qrcode = @file_get_contents($qrcode_path . $openid . ".jpg");
//        if ($qrcode) {
//            $url = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=" . $this->getAccessToken();
//            $data = [
//                'action_name' => 'QR_LIMIT_STR_SCENE',
//                'action_info' => [
//                    'scene' => ['scene_str' => 'invite_' . $openid],
//                ],
//            ];
//            //通过curl post请求
//            $result = $this->curlPost($url, json_encode($data));
//            $url = 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=' . urlencode($result->ticket);
//            $ch = curl_init();
//            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
//            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//            curl_setopt($ch, CURLOPT_URL, $url);
//            ob_start();
//            curl_exec($ch);
//            $qr_content = ob_get_contents();
//            $qr_content = $qrcode;
//            header('Content-type: image/jpg');
//            ob_end_clean();
//            //缩放二维码大小为需要的大小，并将二维码加入到海报中
//            $thumb = imagecreatetruecolor(200, 200);
//
//            //获取源文件资源句柄。接收参数为图片流，返回句柄
//            $source = imagecreatefromstring($qr_content);
//            //将源文件剪切全部域并缩小放到目标图片上，前两个为资源句柄
//            imagecopyresampled($thumb, $source, 0, 0, 0, 0, 200, 200, 430, 430);
//            //创建图片的实例，接收参数为图片
//            $dst_qr = @imagecreatefromstring(file_get_contents($poster_path));
//            //加水印
//            imagecopy($dst_qr, $thumb, 320, 50, 0, 0, 200, 200);
//            //销毁
//            imagedestroy($thumb);
//
//            ob_start();//启用输出缓存，暂时将要输出的内容缓存起来
//            imagejpeg($dst_qr, $qrcode_path . $openid . ".jpg", 90);//输出
//            $poster = ob_get_contents();//获取刚才获取的缓存
//            ob_end_clean();//清空缓存
//            imagedestroy($dst_qr);
//            $post_data['media'] = '@' . $qrcode_path . $openid . ".jpg";
//            $result = $this->uploadMedia($this->getAccessToken(), "image", $post_data);
//            if ($result) {
//                $media_id = $result->media_id;
//            }
//        } else {
//            $post_data['media'] = '@' . $qrcode_path . $openid . ".jpg";
//            $result = $this->uploadMedia($this->getAccessToken(), "image", $post_data);
//            if ($result) {
//                $media_id = $result->media_id;
//            }
//        }
//        return $media_id;
//    }
//}

//上传到微信临时素材方法
function uploadMedia($accessToken, $type = 'image', $mediaArr)
{
    $url = "http://api.weixin.qq.com/cgi-bin/media/upload?access_token=" . $accessToken . "&type=" . $type;
    $doPost = $this->curlPost($url, $mediaArr);
    return $doPost;
}

//注意php5.5 curl上传需 new \CURLFile类


//$res = imagecopy($qrcode_thumb, $head_source, 118, 118, 0, 0, 64, 64);


//为背景图片添加图片水印（位置随机），背景图片格式为jpeg，水印图片格式为gif
function watermark($filename, $water)
{
//获取背景图片的宽度和高度
    list($b_w, $b_h) = getimagesize($filename);
//获取水印图片的宽度和高度
    list($w_w, $w_h) = getimagesize($water);
//在背景图片中放水印图片的位置随机起始位置
    $posX = rand(0, ($b_w - $w_w));
    $posY = rand(0, ($b_h - $w_h));
//创建背景图片的资源
    $back = imagecreatefromjpeg($filename);
//创建水印图片的资源
    $water = imagecreatefromgif($water);
//使用imagecopy()函数将水印图片复制到背景图片指定的位置中
    imagecopy($back, $water, $posX, $posY, 0, 0, $w_w, $w_h);
//保存带有水印图片的背景图片
    imagejpeg($back, $filename);
    imagedestroy($back);
    imagedestroy($water);
}

//watermark("brophp.jpg", "logo.gif");
watermark($qrcode_thumb, $head_source);

echo "<img src=$head_source>";
exit;

$w = $_GET['w'] ?: 100;
$h = isset($_GET['h']) ? $_GET['h'] : $w;    // h est facultatif, =w par défaut
$x = isset($_GET['x']) ? $_GET['x'] : 0;    // x est facultatif, 0 par défaut
$y = isset($_GET['y']) ? $_GET['y'] : 0;    // y est facultatif, 0 par défaut
$filename = $_GET['src'] ?: './qrcode/qrcode.jpg';
header('Content-type: image/jpg');
header('Content-Disposition: attachment; filename=' . $src);
$image = imagecreatefromjpeg($filename);
$crop = imagecreatetruecolor($w, $h);
imagecopy($crop, $image, 0, 0, $x, $y, $w, $h);
//imagejpeg($crop);
var_dump($crop);

echo '<img src="crop.php?x=10&y=20&w=30&h=40&src=photo.jpg">';


var_dump($res);

exit;

//本机IP: 218.6.78.20福建省厦门市 电信
$zone_brand = kekezu::ip2brand('218.6.78.20');
//$this->_reg_zone = $zone_brand['zone'];
var_dump($zone_brand);


$data = array(
    'shop_id' => $shop_info['shop_id'],
    'shop_id' => $shop_info['shop_id'],
    'shop_id' => $shop_info['shop_id'],
    'shop_id' => $shop_info['shop_id'],
    'shop_id' => $shop_info['shop_id'],
    'on_time' => time(),
    'come' => $source,
    'device' => $device
);


// 添加中标次数task_bid_num as take_num By jieqiang 2016年9月19日 下午3:38:09
$sql = "select space.task_bid_num  as take_num , space.uid,space.username,space.user_type, shop.shop_id, shop.shop_name, shop.shop_desc,shop.is_close,shop.shop_level,
            space.w_good_rate,space.brand,space.auth_realname,space.auth_email,
            space.credit_score,space.task_income_credit,space.auth_mobile,space.task_income_cash,
            space.auth_bank,space.currency ,space.w_level,space.seller_credit,space.phone,space.mobile,space.email,space.qq,
            space.w_good_rate,space.integrity,space.integrity_ids,space.chief_designer 
            from " . TABLEPRE . "witkey_shop shop left join " . TABLEPRE . "witkey_space space on shop.uid = space.uid where shop.uid= 1519430 ";
$sql = sprintf($sql, 1519430);


$sql and $shop_info = db_factory::get_one($sql, 0);
//var_dump($shop_info);exit;
keke_shop_class::add_shop_visit($shop_info, $user_info);
exit;

var_dump(date('Y-m-01'));
$month_first = strtotime(date('Y-m-01'));
var_dump($month_first);
exit;
//$arr = array(array(),null,'1',2,3,4,5,array(array('三维数组值',null,123)));
//kekezu::echojson('无法查找银行卡号信息',0,$arr);
//exit;

//$items = array(
//    1=>array('id' => 1, 'pid' => 0, 'name' => '1级11' ),
//    2=>array('id' => 2, 'pid' => 1, 'name' => '2级22' ),
//    3=>array('id' => 3, 'pid' => 2, 'name' => '3级33' ),
//    4=>array('id' => 4, 'pid' => 3, 'name' => '4级44' ),
//);

$items = array(
    array('id' => 1, 'pid' => 0, 'name' => '1级11'),
    array('id' => 2, 'pid' => 1, 'name' => '2级22'),
    array('id' => 3, 'pid' => 2, 'name' => '3级33'),
    array('id' => 4, 'pid' => 3, 'name' => '4级44'),
);

//获取某个分类的所有父分类
//方法一，递归
function getParents($categorys, $catId)
{
    $tree = array();
    foreach ($categorys as $item) {
        if ($item['id'] == $catId) {
            if ($item['pid'] > 0)
                $tree = array_merge($tree, getParents($categorys, $item['parentId']));
            $tree[] = $item;
            break;
        }
    }
    return $tree;
}

//方法二,迭代
function getParents2($categorys, $catId)
{
    $tree = array();
    while ($catId != 0) {
        foreach ($categorys as $item) {
            if ($item['categoryId'] == $catId) {
                $tree[] = $item;
                $catId = $item['parentId'];
                break;
            }
        }
    }
    return $tree;
}

function formatTree($array, $pid = 0)
{
    $arr = array();
    $tem = array();
    foreach ($array as $v) {
        if ($v['pid'] == $pid) {
            $tem = formatTree($array, $v['id']);
            //判断是否存在子数组
            $tem && $v['son'] = $tem;
            $arr[] = $v;
        }
    }
    return $arr;
}

function tree($arr, $id)
{
    static $list = array();
    foreach ($arr as $u) {
        if ($u['pid'] == $id) {
            $list[] = $u;
            If ($u['pid'] > 0) {
                tree($arr, $u['pid']);
            }
        }
    }
    return $list;
}

/**
 * 获取顶级父类id
 * @param  [type] $id [description]
 * @return [type]     [description]
 */
function get_top_parentid($arr, $id)
{
//    $r = M('Category')->where('id = '.$id)->field('id,parentid')->find();
    var_dump($arr);
    $r = $arr[$id];

    if ($r['pid'] != '0') {
        get_top_parentid($arr, $r['pid']);
        var_dump($r['pid']);
        exit;
    }
    return $r['id'];
}


function formatParents($array, $id = 0)
{
    $arr = array();
    $tem = array();
    /*foreach ($array as $v) {
        var_dump($v);
        if ($v['pid'] != '0') {
            $tem = formatParents($array, $v['id']);
            //判断是否存在子数组
            $tem && $v['parents'] = $tem;
            $arr[] = $v;
        }
    }*/

    // 重组数组
    foreach ($array as $val) {
        $array_new[$val['id']] = $val;
    }

    var_dump($array_new);

    /*$key = 1;
    foreach($admin_list as $k=>$val){
        if ($val['pid'] <1 ){
            $admin_list[$k]['pid_name'] = '顶级';
        }else{
            $admin_list[$k]['pid_name'] = $admin_list_new[$val['pid']]['user_name'];
        }
    }*/

//    var_dump($array);
//    var_dump($array_new[$id]['pid']);exit;
    if ($array_new[$id]['pid'] != '0') {
        $pid = $array_new[$id]['pid'];
        $id = $array_new[$pid];
        var_dump('pid======', $pid);
        var_dump('id====', $id);
        exit;
        $tem = formatParents($array_new, $id);
        //判断是否存在子数组
        $tem && $v['parents'] = $tem;
        $arr[] = $v;
    }
    return $arr;
}


//$getParents = get_top_parentid($items,2);
$getParents = formatParents($items, 2);
//$getParents = formatTree($items,2);
//$getParents = tree($items,0);
//$getParents = kekezu::list_tree($items,'',12);

//$getParents = getParents2($items,10);
var_dump($getParents);
exit;


$tree = formatTree($items, 2);
var_dump($tree);
exit;


$location = '118.057533,24.612451';

// #34857 用户坐标问题检查并修改
if (empty($location) || ($location == ',') || ($location == '4.9E-324,4.9E-324') || ($location == 2)) {
    $location = keke_base_class::getIpToPoint($last_login_ip);
    var_dump(111);
} else {
    var_dump(222);
    $tmp = explode(',', $location);
    if ((substr($tmp[0], 0, 3) == '0.0') || (substr($tmp[1], 0, 3) == '0.0')) {
        var_dump(223);
        $location = keke_base_class::getIpToPoint($last_login_ip);
    }
}
var_dump($location);

exit;
if (($location != '') && ($location != 2) && ($location != '4.9E-324,4.9E-324')) {
    $tmp = explode(',', $location);
    var_dump($tmp, 'substr==' . substr($tmp[0], 0, 3));

    if (substr($tmp[0], 0, 3) != '0.0' && substr($tmp[1], 0, 3) != '0.0') {
        $meb->create_keke_witkey_member_ext();
    } else {
        keke_exception::write_to_file('位置信息不正确，$location==' . $location, 'location');
    }
} else {
    keke_exception::write_to_file('位置信息不正确，$location==' . $location, 'location');
}
exit;

var_dump($_SERVER['HTTP_ORIGIN']);

var_dump($_SERVER);
exit;


$arr = array(array('id' => 1, 'card_pre' => 3), array('id' => 2, 'card_pre' => 6));

var_dump(max($arr));


foreach ($arr as $v) {
    $arrMax[] = $v['card_pre'];
}

var_dump(max($arrMax));

exit;
$banks = db_factory::query(sprintf(" select * from %switkey_member_bank WHERE bank_sub_name IS NULL limit 9 ", TABLEPRE));
//var_dump($banks);exit;

foreach ($banks as $bank) {
//    var_dump('uid=='.$bank['uid']);
    //根据银行卡号获取银行信息
    $card_length = strlen($bank['card_num']);
    $card_pre = db_factory::get_one(sprintf(" select card_pre from %switkey_bank_list WHERE cark_length = '%d'", TABLEPRE, $card_length));
    $card_bin = substr($bank['card_num'], 0, $card_pre['card_pre']);
    var_dump($card_bin);
    $liq_no = db_factory::get_one(sprintf(" select * from %switkey_bank_list WHERE card_bin = '%d' limit 1", TABLEPRE, $card_bin));
    if (!$liq_no) {
        keke_exception::write_to_file('无法查找银行卡号信息==' . $bank['card_num'] . ' | uid=' . $bank['uid'] . ' | real_name=' . $bank['real_name'], 'auth_bank');
//        kekezu::echojson('无法查找银行卡号信息',0,$liq_no);
    }

    var_dump($liq_no['bank_address'], $bank['uid']);

    $sql1 = sprintf(" UPDATE %switkey_member_bank set bank_sub_name='%s' WHERE bank_sub_name IS NULL AND uid=%d ", TABLEPRE, $liq_no['bank_address'], $bank['uid']);

    $sql2 = sprintf(" UPDATE %switkey_auth_bank set deposit_name='%s' WHERE deposit_name IS NULL AND uid=%d ", TABLEPRE, $liq_no['bank_address'], $bank['uid']);

    keke_exception::write_to_file($sql1 . ' | ' . $sql2, 'auth_bank');

    // 更新数据
    /*db_factory::execute(sprintf(" UPDATE %switkey_member_bank set bank_sub_name='%s' WHERE bank_sub_name IS NULL AND uid=%d ",TABLEPRE,$liq_no['bank_address'],$bank['uid']));


    db_factory::execute(sprintf(" UPDATE %switkey_auth_bank set deposit_name='%s' WHERE deposit_name IS NULL AND uid=%d ",TABLEPRE,$liq_no['bank_address'],$bank['uid']));*/


    var_dump($liq_no);

}

exit;

$plus_sale_num = keke_shop_class::plus_sale_num($service_id);
var_dump($plus_sale_num);
exit;

//var_dump(S_ROOT); // string(55) "D:\software\phpStudy\WWW\00_app2.api.epweike.netWeekly\"

//$files = getfiles(__DIR__);
//$files = getfiles(S_ROOT.'up/'.$uptype);

$dir = read_all_dir(S_ROOT . 'up/');
var_dump($dir);
exit;

$postfields = array(
    'do' => 'upload',
    'type' => 2, // 类型  2 头像
//    'task_id'=>$obj_id, // 批量上传图片用  1 logo设计 2、平面设计

    'is_thumb' => 1,
    's_size' => '100,100',
    'is_water' => 1,

);

$urlBase = 'http://10.0.90.108/00_app2.api.epweike.netWeeklyIM/';
$url = $urlBase . 'm.php?symbol=99';

foreach ($dir as $k => $files) {
//    var_dump($k,$files);

    foreach ($files as $file) {

        $file_arr = array('file' => '@' . $file, 'task_id' => $k);

//        var_dump($file_arr);
//        $res = kekezu::curl_request($url,3,true,'post',$postfields,'',$file_arr,300,'nothrow');
        var_dump($res);

        $up_res = json_decode($res, true);
        keke_exception::write_to_file(iconv('UTF-8', 'GBK', $up_res['msg']) . ' | ' . $file . ' | ' . $res, 'uploadPatch');
        var_dump($up_res);
    }

    /*$file_arr = array('file'=>'@'.$file);
    $urlBase = 'http://10.0.90.108/00_app2.api.epweike.netWeeklyIM/';
    $url = $urlBase.'m.php?symbol=99';
    $res = kekezu::curl_request($url,3,true,'post',$postfields,'',$file_arr,300,'nothrow');
    var_dump($res);

    $up_res = json_decode($res,true);
    keke_exception::write_to_file($up_res['msg'].' | '.$file.' | '.$res,'uploadPatch');
    var_dump($up_res);*/


    /*if($up_res['status'] !=1){
        return false;
    }else{
        return true;
    }*/
}

exit;


$auth_id = 654910;
$data = db_factory::get_one(sprintf("select * from %switkey_auth_mobile where mobile_a_id=%d ; ", TABLEPRE, $auth_id));
var_dump('$data==', $data);

$keys = array_keys($data);
var_dump('$keys0==', $keys);

$keys = array_map('addslashes', $keys);
var_dump('$keys1==', $keys);

//$keys=join('`,`',$keys);
//var_dump('$keys2==',$keys);
//
//$keys="`".$keys."`";
//var_dump('$keys3==',$keys);

$keys = implode(',', $keys);
var_dump('$keys3==', $keys);

$vals = array_values($data);
var_dump('$vals==', $vals);

$vals = array_map('addslashes', $vals);
$vals = join("','", $vals);
$vals = "'" . $vals . "'";
$mysql = "insert into `keke_witkey_auth_mobile`($keys) values($vals);";
var_dump($mysql);
exit;


//if ($testupdata=='on'){
var_dump('执行开始');

//检查是否认证过
$authMobiles = db_factory::query(sprintf("select * from %switkey_auth_mobile where uid IS NULL AND username IS NULL ORDER BY mobile_a_id DESC ;", TABLEPRE));

// TODO 记录认证日志
//keke_exception::write_to_file('$authMobiles=='.json_encode($authMobiles),'authmobilenew_exe');

foreach ($authMobiles as $v) {
    // 判断是否存在已认证的记录，同个手机号
    $hasMobiles = db_factory::query(sprintf("select * from %switkey_auth_mobile where mobile='%s' AND uid IS not NULL AND auth_status=1 ;", TABLEPRE, $v['mobile']));
    if ($hasMobiles) {

        // keke_witkey_auth_mobile存在同一条正确记录
        $delSql = sprintf("delete from %switkey_auth_mobile where mobile_a_id=%d AND uid IS NULL AND username IS NULL; ", TABLEPRE, $v['mobile_a_id']);

        // 备份记录
        mysql_bak($v['mobile_a_id'], 1, $delSql);

        $res = db_factory::execute($delSql);
        if ($res) {
            // TODO 记录认证日志
            keke_exception::write_to_file('info | 删除成功witkey_auth_mobile表mobile,keke_witkey_auth_mobile存在同=' . $res . '=条正确记录==' . $v['mobile_a_id'] . '==$delSql==' . "\n" . $delSql, 'authmobilenew_exe');
        } else {
            // TODO 记录认证日志
            keke_exception::write_to_file('info | 删除失败witkey_auth_mobile表mobile,keke_witkey_auth_mobile存在同一条正确记录==' . $v['mobile_a_id'] . '==$delSql==' . "\n" . $delSql, 'authmobilenew_exe');

        }

    } else {
        if ($v['mobile']) {
            // keke_witkey_auth_mobile不存在同一条正确记录
            // 判断是否存在space表
            $useinfo = db_factory::get_one(sprintf("select * from %switkey_space where mobile='%s' ;", TABLEPRE, $v['mobile']));

            if ($useinfo) {
                // 改手机号存在space表中，更新到keke_witkey_auth_mobile表
                if ($useinfo['auth_mobile']) {
                    $updateSql = sprintf("update %switkey_auth_mobile set uid=%d, username='%s', auth_status=1,end_time=%d,auth_source='%s' where mobile_a_id=%d ;", TABLEPRE, $useinfo['uid'], $useinfo['username'], time(), $useinfo['come'], $v['mobile_a_id']);
                } else {
                    $updateSql = sprintf("update %switkey_auth_mobile set uid=%d, username='%s',auth_source='%s' where mobile_a_id=%d ;", TABLEPRE, $useinfo['uid'], $useinfo['username'], $useinfo['come'], $v['mobile_a_id']);
                    // TODO 记录认证日志
                    keke_exception::write_to_file('info | space表未认证的手机号mobile==' . $v['mobile'], 'authmobilenew_exe');
                }

                // 备份记录
                mysql_bak($v['mobile_a_id'], 0, $updateSql);

                $res = db_factory::execute($updateSql);
                if ($res) {
                    // TODO 记录认证日志
                    keke_exception::write_to_file('info | ==更新成功witkey_auth_mobile表mobile==' . $v['mobile_a_id'] . '==$updateSql==' . "\n" . $updateSql, 'authmobilenew_exe');
                } else {
                    // TODO 记录认证日志
                    keke_exception::write_to_file('info | ==更新失败witkey_auth_mobile表mobile==' . $v['mobile_a_id'] . '==$updateSql==' . "\n" . $updateSql, 'authmobilenew_exe');
                }

            } else {
                // 删除脏数据
                $delSql = sprintf("delete from %switkey_auth_mobile where mobile_a_id=%d AND uid IS NULL; ", TABLEPRE, $v['mobile_a_id']);

                // 备份记录
                mysql_bak($v['mobile_a_id'], 1, $delSql);

                $res = db_factory::execute($delSql);

                // TODO 记录认证日志
                keke_exception::write_to_file('info | 手机号不存在space表mobile==' . $v['mobile'] . '==authmobile==' . json_encode($v), 'authmobile_execute');
            }
        } else {
            // TODO 记录认证日志
            keke_exception::write_to_file('info | 手机号为空mobile==' . $v['mobile'] . '==authmobile==' . json_encode($v), 'authmobile_execute');
        }
    }
}

var_dump('执行完成');
//}

// 遍历目录和文件
function read_all_dir($dir)
{
    $result = array();
    $handle = opendir($dir);
    if ($handle) {
        while (($file = readdir($handle)) !== false) {
            if ($file != '.' && $file != '..') {
                $cur_path = $dir . DIRECTORY_SEPARATOR . $file;
                if (is_dir($cur_path)) {
                    // $result['dir'][$cur_path] = read_all_dir ( $cur_path );
                    $result[substr($cur_path, -1)] = read_all_dir($cur_path);
                } else {
                    $result[] = $cur_path;
                }
            }
        }
        closedir($handle);
    }
    return $result;
}

function getfiles($path)
{
    foreach (scandir($path) as $afile) {
        if ($afile == '.' || $afile == '..') continue;
        if (is_dir($path . '/' . $afile)) {
            getfiles($path . '/' . $afile);
        } else {
            $files[] = $path . '/' . $afile;
        }
    }

    return $files;
} //简单的demo,列出当前目录下所有的文件


function uploadCurl($filename = 'a.jpg')
{
    $uri = "http://localhost/tqj/date/p822.php";

// post参数数组
    $data = array(
        'author' => 'tianquanjun',
        'upload' => '@C:\Users\tianquanjun.DANGDANG\Pictures\/' . $filename,
    );

//初始化
    $ch = curl_init();

//各种项设置，网上参考而来，可以查看php手册，自己设置
    curl_setopt($ch, CURLOPT_URL, $uri);
    curl_setopt($ch, CURLOPT_POST, 1);//post方式
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

//执行
    $return = curl_exec($ch);

//容错机制
    if ($return === false) {
        var_dump(curl_error($ch));
    }

//curl_getinfo()获取各种运行中信息，便于调试
    $info = curl_getinfo($ch);

    echo "执行时间" . $info['total_time'] . PHP_EOL;

//释放
    curl_close($ch);

    print_r($return);
}

function mysql_bak($auth_id, $del = 1, $sql)
{
    $data = db_factory::get_one(sprintf("select * from %switkey_auth_mobile where mobile_a_id=%d AND uid IS NULL AND username IS NULL AND auth_status IS  NULL; ", TABLEPRE, $auth_id));
    $keys = array_keys($data);
    $keys = array_map('addslashes', $keys);
    $keys = join('`,`', $keys);
    $keys = "`" . $keys . "`";
    $vals = array_values($data);
    $vals = array_map('addslashes', $vals);
    $vals = join("','", $vals);
    $vals = "'" . $vals . "'";
    $mysql = "insert into `keke_witkey_auth_mobile`($keys) values($vals);";

    if ($del) {
        // TODO 记录认证日志
        keke_exception::write_to_file('delete | ' . $mysql . ' | ' . $sql, 'authmobile_execute');
    } else {
        keke_exception::write_to_file('update | ' . $mysql . ' | ' . $sql, 'authmobile_execute');
    }
    return $mysql;
}


?>