<?php
require dirname(__FILE__).'/init.php';
@header("Content-type: text/css;");
$url = $_GET['r'];
if(!empty($url))insert_spider('',$url);
echo '#php_stats{font:10px;}';
?>