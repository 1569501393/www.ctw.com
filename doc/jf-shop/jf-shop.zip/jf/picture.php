<?php 
require dirname(__FILE__).'/init.php';
$w = to_int($_GET['w']);
$h = to_int($_GET['h']);
$s = $_GET['s'];
$w = empty($w)?160:$w;
$h = empty($h)?110:$h;
$site_url = get_cache(array('siteBase','siteurl'));
$f = str_replace($site_url,'',$s);
$c = trim($_GET['c']);
$color = empty($c)?'#FFFFFF':'#'.trim($_GET['c']);
$tag = get_self();
$tag = $tag=='/'?'':$tag;
$file = PHP_ROOT.str_replace(array($site_url,$tag,'../'),'',$f);
if(!file_exists($file) || !@getimagesize($file))$file = PHP_ROOT.'shopdata/images/no_picture.jpg';
$new_f = str_replace(PHP_ROOT,'',$file);
$new_file = PHP_ROOT.'temp/temp_small_picture/'.$new_f.'-'.$w.'x'.$h.'.jpg';
$isfocus = $_GET['focus']==1?true:false;
if($isfocus || !is_file($new_file)){
		import('@.core.picwater');
		$water = new picWater();
		$path = dirname($new_file);
		if(!is_dir($path))mkdirs($path);
		$water->bgColor=$color;
		$do = $water->createImage($file,$w,$h,$new_file);
		if($do){
			@header("Content-type:image/png");
			@readfile($new_file);
		}else{
			dump($water->getMsg());
		}
}else{
	header("Content-type:image/png");
	@readfile($new_file);
}
?>