<?php exit('die'); ?>
{if !$php188_goods_category}{get_category assign='php188_goods_category'}{/if}
<div class="middle"><!--����--> 	
     {include file="widget/goods_category_brand_small.php"}
     {if $php188_goods_category}
        <div id="goods_category_tress_list">
        {foreach from=$php188_goods_category item=c key=key}
        <div class="cat_tag_main {if $key eq 0} cat_tag_main_hover {/if}">
            <h3><a href="{$c.view_category}" title="{$c.cate_name}" target="_blank">{$c.cate_name}</a></h3>
            <div class="cat_tag">
            {if $c.childrens}
               <div class="cate_two_div">
                {foreach from=$c.childrens item='cc' name='son'}<a class="mms" href="{$cc.view_category}" title="{$cc.cate_name}" target="_blank">{$cc.cate_name}({$cc.total|default:0})</a>
                    <!--������-->
                        {if $cc.childrens}
                            <div class="cate_three_div">
                             {foreach from=$cc.childrens item='s' name='son_t'}<a class="mms" href="{$s.view_category}" title="{$s.cate_name}" target="_blank">{$s.cate_name}({$s.total|default:0})</a>
                             {/foreach}
                         </div>
                        {/if}
                    {/foreach}
                    </div>
                {/if}
                </div><div class="clear"></div>
                </div>
            {/foreach}
            </div>
        {else}
        <div class="notice_msg">�޿��÷���</div>
    {/if}
<div class="clear"></div>
</div><!--���� end-->
<script type="text/javascript" src="{$template_url}js/Product.js" charset="utf-8"></script>