function KefuStart(val){$("#e").css("display","none");$("#kefu").css("left","0px");}
function closekf(){$("#e").css("display","block");$("#kefu").css("left","-148px");}
function ShowKeFu(){
if (document.body.offsetWidth >900) {
    if (document.getElementById("kefu")!= null){document.getElementById("kefu").style.top = (document.body.scrollTop+document.documentElement.scrollTop + 100) + "px";
    }else{return false}}else{document.getElementById("kefu").style.display="none";}
}
function ShowTimes(){setTimeout("ShowKeFu();",100);}
window.onscroll=ShowKeFu;window.onresize=ShowTimes;
function fullScreen(){
  this.moveTo(0,0);this.outerWidth=screen.availWidth;this.outerHeight=screen.availHeight;
}
window.maximize=fullScreen;
document.write('<div id="kefu">');
document.write('<div class="kf_box">');
document.write('<div class="kf_title"></div>');
document.write('  <div class="kf_by">');
document.write('  <table width="0" border="0" align="center" cellpadding="0" cellspacing="0"><tr><td colspan="3"><b>����ʱ��</b></td></tr>');
document.write('  <tr><td height="26" colspan="3" style="border-bottom:1px dotted #CCC">{$web_jobtime}</td></tr>');
{foreach from=$web_qq item='qq'}
document.write('  <tr><td width="20" height="35"></td>');
document.write('  <td width="24"><img src="{$template_url}images/kefu/smallqq.jpg" border="0" /></td>');
document.write('  <td width="86"><a href="http://wpa.qq.com/msgrd?v=3&uin={$qq.num}&site=qq&menu=yes" target="_blank" title="QQ�ͷ�:{$qq.desc}">{$qq.desc}</a></td></tr>');
{/foreach}
{foreach from=$web_msn item='msn'}
document.write('  <tr><td width="20" height="35"></td>');
document.write('  <td width="24"><img src="{$template_url}images/kefu/smallmsn.gif" border="0" /></td>');
document.write('  <td width="86"><a href="msnim:chat?contact={$msn.num}" target="_blank" title="MSN�ͷ�:{$msn.desc}">{$msn.desc}</a></td></tr>');
{/foreach}
{foreach from=$web_taobao item='tb'}
document.write('  <tr><td width="20" height="35"></td>');
document.write('  <td width="24"><img border="0" src="http://amos.alicdn.com/online.aw?v=2&uid=justdoit
&site=cntaobao&s=2&charset=utf-8" alt="��������ҷ���Ϣ" /></td>');
document.write('  <td width="86"><a target="_blank" href="http://amos.alicdn.com/getcid.aw?v=2&uid={$tb.num}
&site=cntaobao&s=2&groupid=0&charset=utf-8">{$tb.desc}</a></td></tr>');
{/foreach}
document.write('</table>');
document.write('  <div class="closekf" onclick="closekf();">�ر����߿ͷ�</div>');
document.write('  </div><div class="kf_ft"></div>');
document.write('</div><div class="show_box" id="e" onmouseover="KefuStart(this);"></div></div>');