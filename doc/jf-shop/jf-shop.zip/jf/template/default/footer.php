<?php exit('die'); ?>
<div class="footer_bg"><!--β��-->
	<div class="footer">
    	<p>{get_ads place_name="��ҳ�ײ����λ"}</p>
        <div class="footer_box">
        {foreach from = $php188_nav.footer_nav name=navs item=nav}
        	<a href="{$nav.link}">{$nav.name}</a>{if !$smarty.foreach.navs.last}|{/if}
        {/foreach}
        </div>    
    </div>
    <div class="clear"></div>
    <div class="footer_copy" style="border:1px solid #FFF; text-align:center; line-height:20px;margin-top:5px;">{$php188_footer_content}</div>
    <div class="clear" style="height:25px;"></div>
</div><!--β�� end-->
{include file="footer_common.php"}