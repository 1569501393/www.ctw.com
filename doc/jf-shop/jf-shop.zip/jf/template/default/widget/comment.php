<?php exit('die'); ?>
{if $action eq 'comment_list'}	
 <div id="ajax_call_comment_data">          
	{include file="widget/goods_comment/comment_part.php"}
</div> 
{else}
 <div id="ajax_call_comment_data">          
	{include file="widget/goods_comment/comment_part.php"}
</div>
{/if}