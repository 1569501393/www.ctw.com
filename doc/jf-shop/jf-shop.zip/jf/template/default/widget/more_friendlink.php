<?php  exit('die');?>
{include file='header.php'}
{include file="widget/site_top.php"}
<div class="dh">{include file="nav.php"}</div>
<div class="clear"></div>
<div id="link_pannel" class="middle" style="border:1px solid #CCC">
    {get_friend_link assign='friendlink'}
     <div class="friend_link_box">
        {foreach from=$friendlink item=fl name="fllink"}
<a title="{$fl.friendlink_name}" target="_blank" href="{$fl.friendlink_url}">{$fl.friendlink_name}</a>{if !$smarty.foreach.fllink.last} | {/if}
        {/foreach}
     </div>
<div class="clear"></div>
</div>
{include file="footer.php"}