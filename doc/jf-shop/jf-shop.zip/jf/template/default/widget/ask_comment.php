<?php exit('php');?>
{if $action eq 'askcomment_index'}
<div class="FormWrap"><!--FormWrap start-->
{include file="widget/user_small_login.php"}
<script type="text/javascript">
var ajax_load_extend_url = "{building_link model='member@comment' action='goodsanswer' param="id=$goods_id"}";
function changecodenumber_img(){return $("#cap_img").click();}
function _clear(){$("#comment_content").val('');$("#cap_input").val('')}
$(function(){
	$("#php188_from_goods_comment").submit(function(){
		if(!check_form_is_empty('must_comment_input'))return false;
		$(this).ajaxSubmit(function(data){
			var add_content = '';
			switch ($.trim(data)){
				case "NEED_CHECK":showNotice("�������ʳɹ�����ȴ�����Ա���");
				$(".must_comment_input").val('');
				break;
				case "NOT_EXIST_GOODS":showNotice("��Ʒ�Ų�����");break;
				case "EMPTY_CONTENT":showNotice("��Ʒ�������ݲ���Ϊ��");break;
				case "ERROR_CAP":showNotice("��֤�벻��ȷ");return changecodenumber_img();
				break;
				case "NEED_LOGIN":
					return call_member_login();
				//showNotice("ֻ�е�¼�û��ſ�������");
				break;
				case "ERROR":showNotice("����ʧ�ܣ�");break;
				case 'OK':
					_close_grd_window(this);		
					_clear();
					$.get(ajax_load_extend_url,function(d){window.parent.$("#ajax_call_ansercomment_data").html(d);})
					return showNotice("�����ɹ���");
				default:alert(data);
			}
		});
		return false;
	});
	$("#comment_content").grd_maxLength({length:500});
});
</script>
<form action="{building_link model='member@comment' action = 'addgoodscomment' http='false'}" method="post" id="php188_from_goods_comment" autocomplete="off"  class="division1"> 
    <table class="forform">
        <tbody>
            <tr>
              <td class="one" nowrap="nowrap">��&nbsp;&nbsp;�ݣ� 
              <td><input name="addcomment" type="hidden" value="ask" /><textarea  rows="5"  class="form_textarea must_comment_input" type="textarea"  name="comment_content"   id="comment_content" />              
              <p class="comment_desc">������������ <span class="text_limiter red">500</span> ���ַ�</p></td>
          </tr>
            <tr>
                <td class="one" nowrap="nowrap">��֤�룺</th>
                <td><input type="text" maxlength="4" size="10" name="checknumber" class="form_input_small must_comment_input" id="cap_input" onfocus="changecodenumber_img();" /><img id="cap_img" class="php188_codenumber_img" title="���������֤��ͼƬ" alt="���������֤��ͼƬ" style="cursor:pointer; margin-bottom:-13px;" src="{$siteurl}captcha.php?hash=0&w=100&h=30" onclick="this.src='{$siteurl}captcha.php?hash=0&w=100&h=30&rand='+Math.random()" /></td>
            </tr>
           <tr>
            <td colspan="4" style="padding-left:50px; padding-top:10px;"><input type="submit" value="�ύ"  class="form_submit"/></td>
          </tr>
        </tbody>
    </table>
    <input type="hidden" name="goods_id" value="{$goods_id}" />
</form>              
</div>
{/if}