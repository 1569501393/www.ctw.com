<?php exit('die'); ?>
<script language="javascript">
	function _dh_reset(obj){
		$('.ahovers').removeClass('ahovers');$(obj).addClass('ahovers');	
	}
	$(function(){
		var _dh_set = $.cookies('__dh_click_pannel__');
		_dh_set = _dh_set==null || empty(_dh_set)?0:_dh_set;
		$("#menus a").each(function(ii){//alert(i);
			$(this).click(function(){
				$.cookies('__dh_click_pannel__',ii,cookies_path);
				_dh_reset($(this));
			});
			if(_dh_set==ii){
				_dh_reset($(this));
			}
		});
	});
</script>
<div class="header_bg"><!--ͷ��-->
	<div class="header">
    	<div class="header_top">
       		<p class="fl"><span id="PHP188_member_panel"></span></p>
            <div class="info fr">
                <a href="javascript:;" onclick="SetHome(this,'{$siteurl}');">��Ϊ��ҳ</a>|
                <a href="javascript:;" onclick="addBookmark('{$title}','{$siteurl}');">�ղر�վ</a>|
                <a href="{building_link model='member@order'}" target="_blank">�ҵĶ���</a>|
                <a href="{building_link model='help'}" target="_blank">��������</a>
            </div>
            <div class="clear"></div>	
        </div>
    	<div class="header_con">
        	<p class="fl"><a href="{$site_url}" title="{$site_name}" id="site_logo"><img src="{$siteurl}{$logo}" title="{$site_name}"></a></p>	
            <form method="get" id="php188_search_goods" action="{building_link model='search' action = 'searchgoods'}">
            <div class="search fl">
            	<p class="search_box"><input type="text" id="focus_search_input" maxlength="20" value="" name="searchname"/><em class="s_btn"><input type="submit" value="����" class="" style="background:none;border:0px;width:40px;"/></em>
                </p>
              <p>{get_search_keys assign='search_key' hot='true' limit='5'}
                 {foreach from=$search_key item='item' name='c'} <a href="{building_link model='search' action='searchgoods'}{$connetor}searchname={$item.words}" target="_blank">{$item.words}</a>{/foreach}</p>	
            </div>
            </form>            
    <script type="text/javascript">
    //����JS
	$(function(){
	   $("#php188_search_goods").submit(function(){
			var o = $("#focus_search_input");
			var f = o.val();
			$(o).focus();
			if(f=='�����������ؼ���'){
				$(o).val('');	
			}
			var u = _c('php188_search_goods');
			window.location.href=u;
			return false;
		});	
	});
	//ȥ���㰴ť
	function to_pays(){
	   if($("#un_pay_goods").html()==0){
		  return showNotice('���ﳵ��������!'); 
	   }else{
		  window.open('{building_link model='goods@flow' action='checkOut' http='false'}','_blank');
	   }
	}
	//ȫ�����ఴť�Ӽ���ť
	$(function(){
	  $("#cate_all").mouseover(function(){
		 $(this).addClass("cate_all_b");
	   });
	  $("#cate_all").mouseout(function(){
		 $(this).removeClass("cate_all_b");
		 $(this).addClass("cate_all");
	   });
	});
</script>
<script type="text/javascript" src="{$template_url}js/category_all.js" charset="utf-8"></script>
<script type="text/javascript">anylinkcssmenu.init("anchorclass")</script>
<div class="fr index_tel" style="padding-top:6px;"><em style="font-size:16px;">�������ߣ�</em>{$sitecfg.siteBase.tel}</div>
            <div class="clear"></div>
        </div>
	  	<div class="header_nav">
            <div class="cate_btn fl"><a rel="submenu1" id="cate_all" class="cate_all anchorclass" href="{building_link model='category'}"></a></div>
      		<div class="menu" id="menus">
                <a href="{$siteurl}" class="ahovers">��ҳ</a>
    	        <a href="{building_link model='tuangou'}">�Ź�</a>
                <a href="{building_link model='region'}">����</a>
    	        <a href="{building_link model='goods' action='brands'}">Ʒ��</a>
                <a href="{building_link model='goods' action='type' param='tag=new'}">��Ʒ</a>
                <a href="{building_link model='goods' action='type' param='tag=pro'}">����</a>
                <a href="{building_link model='goods' action='type' param='tag=rec'}">�Ƽ�</a>
                <a href="{building_link model='goods' action='type' param='tag=spec'}">�ؼ�</a>
                <a href="{building_link model='goods' action='type' param='tag=zenpin'}">��Ʒ</a>
                <a href="{building_link model='goods' action='pointgoods'}">����</a>
    	        <a href="{building_link model='goods' action='packgoods'}">��װ</a>
    	        <a href="{building_link model='article'}">��Ѷ</a>
          	</div>
            <div style="display:none">
          {foreach from = $php188_nav.center_nav name=navs item=nav}
        	<a href="{$nav.link}">{$nav.name}</a>{if !$smarty.foreach.navs.last}|{/if}
          {/foreach}
        </div>
   		  	<div class="cart_box">
          		<a href="javascript:;" class="cart_1" onclick="view_my_cart(this);">���ﳵ<samp id="un_pay_goods">0</samp>��</a>
                <a href="javascript:;" class="cart_2" onclick="to_pays();">����</a> 	
          	</div>		
        </div>	
    </div>	
</div><!--ͷ�� end-->
{get_category assign="php188_goods_category"}
{if $php188_goods_category}                
<div id="submenu1" class="anylinkcsscols">
{foreach from=$php188_goods_category name='cn' item='c1' key=key}
  <div class="column">
    <b><a href="{$c1.view_category}" class="tabaa">{$c1.cate_name}</a></b>
    {if $c1.childrens}
     <ul>
     {foreach from=$c1.childrens item='c2' name='jname'}
        <li><a href="{$c2.view_category}" title="{$c2.cate_name}">{$c2.cate_name}</a></li>
     {/foreach}
     </ul>
     {/if}
   </div>
 {/foreach}              
</div>
{/if}