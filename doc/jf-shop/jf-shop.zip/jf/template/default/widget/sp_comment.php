<?php exit('die'); ?>
{if $action neq 'comment_list'}
<div class="FormWrap"><!--FormWrap start-->
{include file="widget/user_small_login.php"}<script type="text/javascript">
var ajax_load_extend_url = "{building_link model='member@comment' action='goodsCommnetList' param="id=$goods_id"}";
function changecodenumber_img(){return $("#cap_img").click();}
function _clear(){$("#comment_content").val('');$("#cap_input").val('')}
$(function(){
	$("#php188_from_goods_comment").submit(function(){
		if(!check_form_is_empty('must_comment_input'))return false;
		$(this).ajaxSubmit(function(data){
			var add_content = '';
			switch ($.trim(data)){
				case "NEED_CHECK":showNotice("���ӳɹ�����ȴ�����Ա���");
				$(".must_comment_input").val('');
				break;
				case "NOT_EXIST_GOODS":showNotice("��Ʒ�Ų�����");break;
				case "EMPTY_CONTENT":showNotice("��Ʒ�������ݲ���Ϊ��");break;
				case "ERROR_CAP":showNotice("��֤�벻��ȷ");return changecodenumber_img();
				break;
				case "NEED_LOGIN":
					return call_member_login();
				//showNotice("ֻ�е�¼�û��ſ�������");
				break;
				case "ERROR":showNotice("����ʧ��");break;
				case 'OK':
					add_content = $.trim(data);
					changecodenumber_img();_close_grd_window(this);
					_clear();
					$.get(ajax_load_extend_url,function(d){$("#ajax_call_comment_data").html(d);})
					return showNotice("���ӳɹ�");
				default:alert(data);
			}
		});
		return false;
	});
	$("#comment_content").grd_maxLength({length:500});
});
</script><form action="{building_link model='member@comment' action = 'addgoodscomment' http='false'}" method="post" id="php188_from_goods_comment" autocomplete="off"  class="division1"> 
    <table width="90%" cellspacing="1" class="forform">
        <tbody>
            <tr class="td_btm">
              <td width="110" height="36" align="center" nowrap="nowrap">�ۺ����֣�
              <td width="891"><input type="radio" name="sp_sum" id="radio" value="1" />
              <img src="{$template_url}images/star/1.jpg" />
              <input type="radio" name="sp_sum" id="radio2" value="2" />
              <img src="{$template_url}images/star/2.jpg" />
              <input type="radio" name="sp_sum" id="radio3" value="3" />
              <img src="{$template_url}images/star/3.jpg" />
              <input type="radio" name="sp_sum" id="radio4" value="4" />
              <img src="{$template_url}images/star/4.jpg" />
              <input name="sp_sum" type="radio" id="radio5" value="5" checked="checked" />
              <img src="{$template_url}images/star/5.jpg" /></td>
          </tr>
            <tr class="td_btm">
              <td height="36" align="center" nowrap="nowrap">������֣�              
              <td><input type="radio" name="wg_sum" id="radio6" value="1" />
                <img src="{$template_url}images/star/1.jpg" />
                <input type="radio" name="wg_sum" id="radio7" value="2" />
                <img src="{$template_url}images/star/2.jpg" />
                <input type="radio" name="wg_sum" id="radio8" value="3" />
                <img src="{$template_url}images/star/3.jpg" />
                <input type="radio" name="wg_sum" id="radio9" value="4" />
                <img src="{$template_url}images/star/4.jpg" />
                <input name="wg_sum" type="radio" id="radio10" value="5" checked="checked" />
              <img src="{$template_url}images/star/5.jpg" /></td>
          </tr>
            <tr class="td_btm">
              <td height="36" align="center" nowrap="nowrap">�� �� �ȣ�
              <td><input type="radio" name="ss_sum" id="radio11" value="1" />
                <img src="{$template_url}images/star/1.jpg" />
                <input type="radio" name="ss_sum" id="radio12" value="2" />
                <img src="{$template_url}images/star/2.jpg" />
                <input type="radio" name="ss_sum" id="radio13" value="3" />
                <img src="{$template_url}images/star/3.jpg" />
                <input type="radio" name="ss_sum" id="radio14" value="4" />
                <img src="{$template_url}images/star/4.jpg" />
                <input name="ss_sum" type="radio" id="radio15" value="5" checked="checked" />
              <img src="{$template_url}images/star/5.jpg" /></td>
          </tr>
            <tr class="td_btm">
              <td align="center" nowrap="nowrap">��&nbsp;&nbsp;�ݣ� 
              <td><textarea  rows="5"  class="form_textarea must_comment_input" type="textarea"  name="comment_content"   id="comment_content" /><p class="comment_desc">������������ <span class="text_limiter red">500</span> ���ַ�</p></td>
          </tr>
            <tr>
                <td align="center" nowrap="nowrap">��֤�룺</th>
              <td><input type="text" maxlength="4" size="10" name="checknumber" class="form_input_small must_comment_input" id="cap_input" onfocus="changecodenumber_img();" /><img id="cap_img" class="php188_codenumber_img" title="���������֤��ͼƬ" alt="���������֤��ͼƬ" style="cursor:pointer; margin-bottom:-13px;" src="{$siteurl}captcha.php?hash=0&w=100&h=30" onclick="this.src='{$siteurl}captcha.php?hash=0&w=100&h=30&rand='+Math.random()" /></td>
          </tr>
            <tr>
                <td colspan="4" align="center" style="padding-left:50px; padding-top:10px;"><input type="hidden" name="com_type" id="com_type" value="1"/>                  <input type="submit" value="�ύ"  class="form_submit"/></td>
            </tr>
        </tbody>
    </table>
    <input type="hidden" name="goods_id" value="{$goods_id}" />
</form>              
</div>
{/if}