<?php if(!defined('IN_SYS'))exit('php188'); ?>
{if $sitecfg.php_memeber_not_register_username.logincomment eq 'no'}<!--ǿ�Ƶ�½ϵͳ-->
  <div id="php188_cur_username" name="{$smarty.session.php188curruser.mem_username}">  {if $smarty.session.php188curruser.mem_username}
  <div class="comment_user_m">��ӭ����<b>{$smarty.session.php188curruser.mem_username} </b> <a href="{building_link model='member@membermanage'}" target="_blank">��Ա����</a> | <a href="{building_link model='member@membermanage' action='memberquit'}" target="_blank">�˳�</a></div>
{else}
<script type="text/javascript">
var member_panel = "{building_link model='member@membermanage'}";
var quit_url = "{building_link model='member@membermanage' action='memberquit'}";
function change_code(){return $("#ajax_login_captcha").click();}
function empty_val(){$(".login_input").val('');}
$(document).ready(function(){
	$("#php188_ajax_login").submit(function(){											
		if(!check_form_is_empty('login_input'))return false;	
		var username = $("#php188_comment_land_username").val();		
		$(this).ajaxSubmit({success:function(data){							
			var successflg = false;
				switch($.trim(data)){					
					case 'ERROR_CAPTCHA':
						empty_val();showNotice("��֤�벻��ȷ");change_code();return false;
					break;
					case 'ERROR_USER':
						showNotice("�û�������ȷ");change_code();return false;
					break;
					case 'ERROR_LOGIN':
				showNotice("��½ʧ�ܣ��û��������벻��ȷ�������ѱ�����");change_code();return false;
						break;
					case 'ERROR_REQUEST':
					empty_val();return showNotice('�������!');
					case 'LOGIN_OK':
					default:
						successflg = true;
						showNotice("��¼�ɹ�");
						break;
				}
				if(successflg){
					$("#php188_cur_username").attr("name", username);
					var string = '<div class="comment_user_m">��ӭ����<b>'+username+'</b> <a href="'+member_panel+'" target="_blank">��Ա����</a> | <a href="'+quit_url+'" target="_blank">�˳�</a></div>';
					$("#php188_cur_username").html(string);
					$("#php188_ajaxklandcomment").remove();
				}
		}});
		return false;
	})
})
  </script>
<form action="{building_link model='member' action='loginajax'}" autocomplete="off" id="php188_ajax_login" method="post"> 
 <table>
    <tr>
        <td valign="middle">�û�����<input maxlength="50" class="login_input form_input_small w120" name="username" id="php188_comment_land_username" type="text"  /> </td>
        <td valign="middle">�ܡ��룺<input maxlength="30" type="password" class="login_input form_input_small w120" name="password" /> </td>
        <td valign="middle">��֤�룺<input type="text"  maxlength="6" class="login_input form_input_small"  onfocus="change_code();" name="codenumber"/></td>
        <td valign="middle"><img class="php188_codenumber_img pointer" alt="���������֤��"  src="{$siteurl}captcha.php?hash=0" title="���������֤��" id="ajax_login_captcha" onclick="this.src='{$siteurl}captcha.php?hash=0&rand='+Math.random()"></td>
        <td valign="middle"><input  type="submit" class="form_submit" value="�ǡ�¼" id="form_subbtncomment_land" /></td>
    </tr>
</table></form>
    {/if}
    </div>
<div class="clear"></div>
{/if}