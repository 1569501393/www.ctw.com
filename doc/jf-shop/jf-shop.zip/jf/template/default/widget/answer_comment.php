<?php exit('die'); ?>
{if $data.total>0}
                {foreach from=$data.data key=key item=com}
                <div class="consulting"{if $key mod 2 neq 0} style="background:#f0f0f0;"{/if}>
                	<p><span class="more2">{$com.com_time|date_format:"%Y/%m/%d %H:%M:%S"}</span>{if $com.com_mem_username }���ѣ�{$com.com_mem_username}{else}�ο�{/if}�ʣ�<strong>{$com.com_content|truncate:'8':'...'}</strong></p>
                    <p style="padding-left:15px;">{$com.com_content}</p>
                    {if $com.com_back_content}<br /><br />
                    <p><strong>����Ա�Ļش�</strong></p>
                    <p style="padding-left:15px;">�װ��Ŀͻ���{$com.com_back_content}</p>
                    <p style="padding-left:15px;">�ظ�ʱ�䣺{$com.com_back_time|date_format:"%Y-%m-%d %H:%M:%S"}</p>
                    <div class="consulting_bt" style="padding-left:15px;">�����ظ����ң�<a href="javascript:;" onClick="dight('jia','{$com.com_id}_d',{$com.com_id});">����<span id="{$com.com_id}_d">(<font color="#792f76">{$com.com_goods|default:'0'}</font>)</span></a><a href="javascript:;" onClick="dight('jian','{$com.com_id}_n',{$com.com_id});">û��<span id="{$com.com_id}_n"><font color="#792f76">({$com.com_bads|default:'0'})</font></span></a></div>
                    {/if}<div style="text-align:right;margin-top:20px;color:#999;">����{if $com.com_back_content}1{else}0{/if}���ش�&nbsp;&nbsp;</div>  
                </div>
                {/foreach}
                {if $data.page}<script type="text/javascript">$(function(){page_function("php188_goods_comment_pageurl","ajax_call_comment_data");});</script><div id="php188_goods_comment_pageurl">{$data.page}</div>{/if}
{else}{/if}
<script language="javascript">
function dight(obj,dtag,pl_id){
	  var strurl = '?dtype='+obj+"&dtag="+dtag+"&plid="+pl_id;
	  var callurl = '{building_link model='member@comment' action='ajaxdign'}'+connetor+strurl; 
		$.get(callurl,{dtype:obj,dtag:dtag,plid:pl_id},function(data){
	  var sdata = data.split('|');
			switch(sdata[0]){
				case 'ERROR':
					window.parent.showNotice('����δ�ɹ�!');
				break;
				case 'NEED_LOGIN':
					window.parent.showNotice('��Ҫ��¼�󣬲��ܲ���!');
				break;
				case 'NO_REPERT':
				    window.parent.showNotice('��Ǹ�����Ѿ���������!');
				break;
				case 'NO_INFO':
				    window.parent.showNotice('����δ�ɹ�!');
				break;
				case 'OK':
				    _close_grd_window(this);
					$('#'+dtag).html(sdata[1]);
				break;
				default:alert(data);
			}
		});
	}
</script>