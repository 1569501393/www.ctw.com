<?php exit('die'); ?>
{get_goods cate_sign=$cate_py limit=$loop_num assign='goods_data'}
{foreach from=$goods_data key=key item='goods'}
<li>
  <p style="margin-bottom:10px;"><a class="img" title="{$goods.goods_name}" href="{$goods.goods_url}" target="_blank"><img alt="{$goods.goods_name}" title="{$goods.goods_name}" src="{$goods.goods_end_thumb_pic}" /></a></p>
  <p>{$goods.goods_name}</p>
  <p style="color:#790002;">{if $site_promition eq 'true'}�����ۣ�{/if}{if $goods.only_use_point eq '1'}{$goods.goods_point_fee}��{else}{$goods.goods_shop_price}{if $goods.goods_point_fee>0}+{$goods.goods_point_fee}��{/if}{/if}</p>
  {if $site_promition eq 'true'}
  <p><samp class="promotion_show yahei red"  id="promotion_times_{$key}" ></samp></p>
  <script type="text/javascript">
            function GetRTime_{$key}(){
                var EndTime  = {$goods.goods_promotion_end_time_format};
                var NowTime = new Date();
                var nMS =EndTime - NowTime.getTime();
                var nD =Math.floor(nMS/(1000 * 60 * 60 * 24));
                var nH=Math.floor(nMS/(1000*60*60)) % 24;
                var nM=Math.floor(nMS/(1000*60)) % 60;
                var nS=Math.floor(nMS/1000) % 60;
                var string = 'ʣ��'+nD+'��'+nH+'ʱ'+nM+'��'+nS+'��';
                document.getElementById("promotion_times_{$key}").innerHTML = string;
                 setTimeout("GetRTime_{$key}()",1000);
            }
           $(function(){
				GetRTime_{$key}();
			});
        </script>	
    {/if}
  <a href="{$goods.goods_url}"><img src="{$template_url}images/bt_2.gif" /></a>
</li>
{/foreach}