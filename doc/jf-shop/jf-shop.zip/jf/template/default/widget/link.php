<?php exit('die'); ?>
{get_friend_link assign='friendlink'}
 {if $friendlink}
  <div class="link mt">
  {foreach from=$friendlink item=fl name="fllink"}
  <a href="{$fl.friendlink_url}" title="{$fl.friendlink_name}" target="_blank"><img src="{$fl.friendlink_image}"></a>
 {/foreach}	
  </div>
{/if}