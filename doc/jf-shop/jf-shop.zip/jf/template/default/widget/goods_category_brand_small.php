<?php  exit('due');?>
<div class="d_menubox">
    <ul>
        <li {if $category_all_list} class="litwo"{/if}><a  href="{building_link model='category' action='categoryList'}" {if $category_all_list} class="white"{/if} >ȫ������</a></li>
        <li {if $brand_index} class="litwo"{/if}><a href="{building_link model='goods' action='brands'}" {if $brand_index} class="white"{/if}>ȫ��Ʒ��</a></li>
    </ul>
</div>
<div class="clear"></div>