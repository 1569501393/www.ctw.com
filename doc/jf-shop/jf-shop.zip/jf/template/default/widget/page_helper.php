<?php exit('die'); ?>
{get_help_category assign='help_cat'}
<div class="help_bg"><!--����-->
	<div class="help">
    {foreach from=$help_cat item='help' key=key}
    {if $key<=3}
    	<ul>
        	<h3>{$help.category_name}</h3>
            {assign var='cat_id' value=$help.category_id}
            {get_article assign='help_art' category_id=$cat_id limit=5}
            {foreach from=$help_art.data item='list'}
            <li><a href="{$list.url}" target="_blank">{$list.article_long_title}</a></li>
            {/foreach}
        </ul>
        {/if}
        {/foreach}
        <ul style="text-align:center; width:280px;">
       		<p style="padding-top:35px;color:#FFF;"> 
<!-- ShareTo Button BEGIN -->
<a class="shareto_button" href="http://shareto.com.cn/share.html"><img src="http://s.shareto.com.cn/btn/lg-fav-cn.gif" width="125" height="21" alt="������" style="border:0"/></a>
<script type="text/javascript" src="http://s.shareto.com.cn/js/shareto_button.js" charset="utf-8"></script>
<!-- ShareTo Button END --><br><br>�ͷ����ߣ�<font size="+1"><b>{$sitecfg.siteBase.tel}</b></font></p>
        </ul>
        <div class="clear"></div>
    </div>	
</div><!--���� end-->
