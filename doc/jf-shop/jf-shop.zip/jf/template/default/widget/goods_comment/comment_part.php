<?php exit('die'); ?>
{if $data.total>0}
  <div class="comments_1 mt" style="border-bottom:none;">
            {foreach from=$data.data key=key item=com}
            <div class="comments_2">
            <div class="name"><span class="more2">ʱ�䣺{$com.com_time|date_format:"%Y-%m-%d %H:%M:%S"}</span>{if $com.com_mem_username }���ѣ�{$com.com_mem_username}{else}�ο�{/if}&nbsp;</div>
            <div class="wenzi">{$com.com_content}</div></div>
            {/foreach}
            {if $data.page} 
             <script type="text/javascript">$(function(){page_function("php188_goods_comment_pageurl","ajax_call_comment_data");});</script><div id="php188_goods_comment_pageurl" style="border-bottom:1px solid #CCC;">{$data.page}</div>{/if}
            </div>
{else}{/if}