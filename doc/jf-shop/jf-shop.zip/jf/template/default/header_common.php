<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>{$title}</title>
{if $index}<meta name="robots" content="all"/>{/if}
{if $meta_title}<meta name="title" content="{$meta_title}"/>{/if}
<meta name="sitemap" content="{$siteurl}sitemap/site_sitemap_index.xml" />
<link rel="index" href="{$siteurl}sitemap/site_sitemap_index.xml" title="{$sitename}" />
<META NAME="Revisit-After" CONTENT="3 days "> 
<meta name="keywords" content="{$keywords}" />
<meta name="description" content="{$description}" />
{if $xml}<link rel="alternate" type="application/rss+xml" title="{$title}" href="{$xml}">{/if}
<!--[if IE 6]>
<script type="text/javascript" src="/template/default/js/iepng.js"></script>
<![endif]-->
{insert_css files='style/red.css'}
</head>
{$stats}
{insert_template_scripts_root files='shopdata/js/jquery-1.3.2.min.js'}
{insert_template_scripts files='js/global.js'}
<script type="text/javascript" src="{$template_url}js/base.js" charset="utf-8"></script>
<script type="text/javascript">
var site_url = "{$siteurl}";
var part_url = "{$part_url}";
var tpl_url = '{$template_url}';
var memberlanding = "{building_link model='member' action ='loginajax'}";
var member_login_url = "{building_link model='member' action = 'showLoginRegister'}";
var ajax_call_compare_data_url = "{building_link model='goods' action='ajaxCallJson'}";
var call_out_stcok_link = "{building_link model='outstock' action = ''}";
var goods_submit_compare_url = "{building_link model='goods' action='compare'}";
var ajax_to_cart = "{building_link model='goods@flow' action='cart'}";
var connetor = '{$connetor}';
var cookies_path = {path:part_url};
var no_pay_order="{building_link model='goods@flow' action='nopayorderlist'}"+connetor+'iframe=1';/*δ���㶩��*/
var befor_pay_order="{building_link model='goods@flow' action='countgoods'}";/*ȥ���㶩��*/
{foreach from=$lang.js_languages key=key item=item}var {$key} = "{$item}";{/foreach}
function _set_logins(){
 var c_url = "{building_link model='member' action='showLoginPanel'}"+connetor+'jsoncallback=?';
 $.getJSON(c_url,{rid:'{$region_id}'},function(data){
	$("#PHP188_member_panel").html(data.result);
  });	
}
</script>