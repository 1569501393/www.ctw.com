<?php exit('die'); ?>
{include file="page/widget/header.php"}
<div  class="dh">{include file="nav.php"}</div>
<div id="page_content_info" class="middle" style="border:1px solid #CCC;">
	{$page_content}
</div>
<div class="clear"></div>
{include file="page/widget/footer.php"}