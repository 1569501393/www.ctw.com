<?php exit('die'); ?>
{if $action eq 'delivery_list'}
{include file="delivery/widget/header.php"}
<div id="site_cart_deliery_pannel" class="middle">
<script type="text/javascript">
var ajax_call_opt = "{building_link model='delivery' action='getRegion'}";/*�����ַ*/
var call_back_link = "{building_link model='delivery' action='calldeliery'}";/*�����ַ*/
function _setLoading(obj){
	var img = "<img src='{$template_url}images/windows_loading.gif' />";
	$(obj).html(img);
}
/*��ȡ�û���ַ*/
 function getRegionChild(obj){
		var val = $(obj).val();
		if(val != ''){
			$.get(ajax_call_opt,{'parentid':val},function(callback){
				$(obj).parent().nextAll().remove(); 
				$(obj).nextAll().remove();
				$(obj).parent().append(callback);
			});
		}
  }
$(function(){
	$("#call_region_deliverys").submit(function(){
		var flag = true;
		$(".need_remove_node select").each(function(){
			if(empty($(this).val())){
				$(this).addClass('empty_input_val');	
				flag = false;
			}else{
				$(this).removeClass('empty_input_val');	
			}
		});
		if(!flag){
			return showNotice('��ѡ��Ҫ��ѯ������!');
			return false;
		}
		var ctags = $('.need_remove_node').find('select').map(function(){
			return $(this).val();
		}).get().join(',');
		$("#region_all_args").val(ctags);
		var url = _c($(this).attr('id'));
		var ot =  $("#call_tags");
		_setLoading(ot);
		$.get(url,function(data){
			$(ot).html(data);
		});
		return false;
	});
});
</script>
<div class="delivery_tags">
  <div class="region_pannel">
    <div class="etnotice">������ջ��˵�ַѡ����ȷ��ʡ���С���/�غ�,ϵͳ����ʾ���ɹ�ѡ����ͻ���ʽ�����������Ϣ</div>
    <form method="post" action="{building_link model='delivery' action='calldeliery'}" id="call_region_deliverys">
      <input type="hidden" value="" name="regions" id="region_all_args" />
      <div id="region_g_pannel">
        <div class="ename">��ѡ�������</div>
        <div id='region_all_info' class="eregion_select"> <span class="need_remove_node">
          <select class="get_all_node_all_adress" onchange="getRegionChild(this)"  style="float: left; width:150px;">
            <option  value=''>��ѡ��</option>
            {foreach from=$regions item=re}
            <option value="{$re.region_id}">{$re.region_name}</option>
            {/foreach}
          </select>
          </span> </div>
        <div class="delivery_search_pannel">
          <input type="submit" value="�� ѯ" class="form_btn" />
        </div>
        <div class="clear"></div>
      </div>
    </form>
    <div class="clear"></div>
    <div id="call_tags"> {include file="delivery/fee_list.php"} </div>
  </div>
  <div class="clear"></div>
</div>
</div>
{include file="delivery/widget/footer.php"}
{/if}
<!--AJAX �ص�-->
{if $action eq 'call_back_delivery'}
	{include file="delivery/fee_list.php"}
{/if}