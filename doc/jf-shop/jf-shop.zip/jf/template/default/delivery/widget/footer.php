<?php exit('die'); ?>
{include file='widget/page_helper.php'}
{include file='footer.php'}