<?php exit('die');?>
{if $data}

<table class="deliery_table">
	<tr>
    	<th>�ͻ���ʽ</th>
    	<th>�ͻ���Χ</th>
    	<th>�ͻ�ʱ��<br />(�Գ�����)</th>
		<th>���ͷ���</th>
    </tr>
{foreach from=$data item='dl'}
	<tr>
    	<td>
        {if $dl.delivery_extend.url}<a href="{$dl.delivery_extend.url}" target="_blank">{$dl.delivery_name}</a>{else}{$dl.delivery_name}{/if}</td>
        <td style="text-align:left;">
        <div style="width:550px; overflow:hidden;">
        {if $dl.deliery_money_method eq '1'}
        		ȫ��
          {elseif $dl.deliery_money_method eq '2'}

                 {if $dl.peisong_data.area}
                    {$dl.peisong_data.area}
                  {elseif $dl.peisong_data.extend_area_set}
                     {$dl.peisong_data.extend_area_set}
                    {else}
                    ȫ��
                 {/if}
          {elseif $dl.deliery_money_method eq '3'}
         	 ȫ��
          	{else}
            N/A
        {/if}
        </div>
        </td>
        <td>{$dl.time_limit|default:'2-3��'}</td>
        <td>
        <div style="width:140px; overflow:hidden;  text-align:justify;">
        {if $dl.deliery_money_method eq '1'}
        	{$dl.delivery_fee_format}
          {elseif $dl.deliery_money_method eq '2'}
         	 {if $dl.peisong_data.edata.only_use_money>0}
             	{$dl.peisong_data.edata.only_use_money_format}
                {elseif $dl.peisong_data.edata.shouzhong>0}
                ���� {$dl.peisong_data.edata.shouzhong}�� {$dl.peisong_data.edata.shouzhong_fee_format} ���� {$dl.peisong_data.edata.xuzhong_fee_format}
                {else}
                �����͵����������
             {/if}
          {elseif $dl.deliery_money_method eq '3'}
          	������Ʒ�ܶ��{$dl.delivery_fee_rate}%
          	{else}
            N/A
        {/if}
        </div>
        </td>
    </tr>
{/foreach}
</table>
{else}
<div class="enoti_nodata">�޿������ͷ�ʽ!</div>
{/if}