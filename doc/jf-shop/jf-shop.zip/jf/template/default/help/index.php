{include file="help/widget/header.php"}
<div class="clear"></div>
<div class="middle"><!--����--> 	
  <div class="d_menubox">
    <ul>
      <li><a href="javascript:;">��������</a></li>
    </ul>
  </div>
  <div class="clear"></div>
  <div id="goods_category_tress_list">
  {get_help_category assign='help_categorys'}
    {foreach from=$help_categorys item='cate'}
    <h3><a href="{$cate.url}">{$cate.category_name}</a></h3>
      {get_article category_id  = $cate.category_id assign='article'}
       <div class="cat_tag">
         <div class="cate_two_div">
         {foreach from=$article.data item='help'}
           <a href="{$help.url}" class="mms">{$help.article_long_title|truncate:4:''}</a>
         {/foreach}
         </div>            
       </div>
    {/foreach} 
    <div class="clear"></div>   
   </div>
</div><!--���� end-->
{include file="footer.php"}