<?php exit('die'); ?>
{include file="header.php"}
{include file="widget/site_top.php"}
{insert_css files='style/help.css'}
<div class="dh">{include file="nav.php"}</div>