<?php exit('die'); ?>
<div class="h10"></div>
{include file='footer.php'}