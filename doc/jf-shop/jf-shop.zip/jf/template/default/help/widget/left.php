<?php exit('die'); ?>
{get_help_category assign='cat'}
<div class="Product">
        	<h3 class="title2"><a href="{building_link model='help'}">��������</a></h3>	
        	<ul id="root">
            {foreach from=$cat item='list'}
                <li>
                    <label><a href="{$list.url}" title="{$list.category_name}" class="bhk">{$list.category_name}</a></label>
                    {if $article.data}
                    <ul class="two" style="display:none">
                    {foreach from=$article.data item='help'}
                        <li><a href="{$help.url}" title="{$son.alias_name}" target="_self">{$help.article_long_title}</a></li>
                    {/foreach}
                    </ul>
                    {/if}
                </li>              
                {/foreach}
            </ul>
        </div>