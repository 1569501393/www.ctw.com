<?php exit('die'); ?>
{include file="help/widget/header.php"}
<div class="clear"></div>
  <div id="help_list" class="middle">
  <div class="middle_left fl">
	{include file="help/widget/left.php"}
  </div>
  <div class="middle_right help_contents fr"><!--�Ҳ�-->
    	{if $artList}        
           <ul class="art_list">
            {foreach from=$artList item='list'}
                <li>
                <div class="tt"><a href="{$list.url}" title="{$list.article_long_title}" target="_blank">{$list.article_long_title|truncate:20:'...'}</a></div>
                <span>{$list.article_date|date_format:"%Y-%m-%d"}</span><div class="line"></div>
                </li>
            {/foreach}
            </ul>
        {else}
        <div class="notice_msg">�޿�������!</div>
        {/if}
  </div>
</div>
{include file="footer.php"}