<?php  exit('188');?>
{include file='help/widget/header.php'}
<div class="clear"></div>
<div id="site_region_index_list" class="middle"><!--����-->
  <div class="middle_left fl">
	{include file="help/widget/left.php"}
  </div>
  <div class="middle_right help_contents fr"><!--�Ҳ�-->
    	<div class="help_contents_detail">{$art.article_content}</div>
  </div>
  <div class="clear"></div>
</div>
{include file="footer.php"}