<?php exit('die'); ?>
{include file="tuangou/widget/header.php"}
<div class="middle"><!--����-->
{include file="tuangou/widget/city.php"}
<div style="border-top:1px solid #CCC;">
  {include file="tuangou/widget/small_goods_pannel.php"}
  <div class="tuan_right fr">
     {include file="tuangou/widget/tuan_mial.php"}
     <div class="clear"></div>     
     {include file="tuangou/widget/tuan_tj.php"}
  </div>
  <div class="clear"></div>
</div>
</div>
{include file="tuangou/widget/footer.php"}