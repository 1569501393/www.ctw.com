<?php exit('die'); ?>
{include file="tuangou/widget/header.php"}
<div class="middle"><!--����-->
<div style="border-top:1px solid #CCC;">
  <div class="tuan_left fl">
     <div class="details_one" style="overflow:hidden;">
         <p class="details_tle">[{$data.project_name}]<em>{$data.goods_name}</em><br/><br/></p>		
             <div class="ds_one_left fl"><!--����-->
                <p class="ds_price">
                  <span>ԭ��<br />{$data.market_price|money_format:'��%s'}</span>
                  <span>�ۿ�<br />{$data.discount}��</span>
                  <span style="background:none;">��ʡ<br />{$data.discount_money|money_format}</span>
                </p>
                {if !$data.will_start}
                {if $data.type eq '1'}
                <p class="ds_bt">{$data.shop_price}<input type="button" class="ds_bt1" onclick="window.location.href='{if $data.has_expired}javascript:;{else}{$data.buy_link}{/if}'"/></p>
                {elseif $data.type eq '2'}
                {if $data.has_expired}
                <p class="ds_bt">{$data.shop_price}<input type="button" class="ds_bt1" onclick="window.location.href='{if $data.has_expired}javascript:;{else}{$data.buy_link}{/if}'"/></p>
                {/if}
           {/if}
       {else}<p class="ds_bt">{$data.shop_price}<input type="button" class="ds_bt1" onclick="window.alert('������ʼ�������ĵȺ�...')"/></p>{/if}
                <div class="ds_time">
                <p style="padding-left:20px;"><img src="{$template_url}images/time.gif" /></p>
                <div class="time_1">
                {if !$data.will_start}
                   ���뱾���Ź��������У�<br />
                   <div class="lxftime1">
                     {if !$data.has_expired}
          <samp class="time" id="show_expire_time_1">
                    <strong id="D_1">0</strong>��<strong id="H_1">0</strong>Сʱ<strong id="M_1">0</strong>��<strong class="time_sec" id="S_1">0</strong>��
                </samp>
           <script type="text/javascript">
            var EndTime_1 = {$data.end_time_format_2};
            var h = 9;
            function _get_sec(){
                h--; if(h==0)h=9;
                setTimeout("_get_sec()",1000);
            }
            function GetRTime_1(){
                var NowTime = new Date();
                var nMS = EndTime_1 - NowTime.getTime();
                var nD = Math.floor(nMS/(1000 * 60 * 60 * 24));
                var nH = Math.floor(nMS/(1000*60*60)) % 24;
                var nM = Math.floor(nMS/(1000*60)) % 60;
                var nS = Math.floor(nMS/1000) % 60;
                var nss = Math.floor(nMS) % 60;
                //var str = nD+'��'+nH+'Сʱ'+nM+'��'+nS+'.'+nss+'��';
                document.getElementById("D_1").innerHTML=nD;
                document.getElementById("H_1").innerHTML=nH;
                document.getElementById("M_1").innerHTML=nM;
                document.getElementById("S_1").innerHTML=nS+'.'+h;
                _get_sec();
            setTimeout("GetRTime_1()",100);
        }
        GetRTime_1();
    </script>
    {/if}{else} <br />
                   <div class="lxftime1"><samp class="time" id="show_expire_time_1">������ʼ {$data.start_time|date_format:"%Y-%m-%d %H:%M:%S"}</samp></div>{/if}
                   </div>
                </div>	
                </div>
                {if $data.goods_extend_prefix_temp}<div class="otherf">
                {foreach from=$data.goods_extend_prefix_temp item='pre'}
                <b>��ѡ������</b> {foreach from=$pre item='se'}<i>{$se}</i>{/foreach}
                <div class="clear"></div>
                {/foreach}
                </div>{/if}
                   {if !$data.will_start}<div class="ds_time ds_time1"><em>{$data.pre_number}</em>���ѹ���</div>{/if}	
                   <div class="ds_time ds_time2">�Ź��ɹ������Լ�������</div>			
                </div><!--���� end-->
                  <ul class="ds_one_right fr">
                    <li style="width:445px;"><p class="tuan_detail_img">{foreach from=$data.pic_temp item='list' key=key}{if $key eq 0}<img src="{$list}" width="420" onload="setimg(this,420,300)"/>{/if}{/foreach}</p></li>	
                  </ul>
          <div class="clear"></div>
                </div>
     <div class="clear"></div>
     {if $data.short_desc}
     <div class="comment" style="overflow:hidden;word-break:break-all">
        <h3>��Ŀ���</h3>
        <div class="clear"></div>
        <p>{$data.short_desc}</p>
     </div>{/if}
     <div class="clear"></div>
     <div class="comment" style="overflow:hidden;word-break:break-all">
        <h3>��Ʒ����</h3>
        <div class="clear"></div>
        <p>
            {if $data.flv}
            <div id="tuan_detail_flv">
            <object width='650' height='500' id='flvPlayer'>
            <param name='allowFullScreen' value='true'>
            <param name="allowScriptAccess" value="always"> 
            <param name='movie' value='{$template_url}tuangou/swf/OSplayer.swf?movie={$data.flv}&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle={$data.project_name}&showTitle=yes'>
            <embed src='{$template_url}tuangou/swf/OSplayer.swf?movie={$data.flv}&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle={$data.project_name}&showTitle=yes' width='650' height='500' allowFullScreen='true' type='application/x-shockwave-flash' allowScriptAccess='always'></embed>
            </object>
            </div>
            <div class="clear"></div>
            {/if}
         {$data.goods_detail}
        </p>
     </div>
     <div class="clear"></div>
     <div class="comment" style="overflow:hidden;word-break:break-all">
        <h3>�ر���ʾ</h3>
        <div class="clear"></div>
        <p>{$data.spec_content}</p>
     </div>
  </div>
  
  <div class="tuan_right fr">
     {include file="tuangou/widget/tuan_mial.php"}
     <div class="clear"></div>
     {include file="tuangou/widget/tuan_tj.php"}
  </div>
  <div class="clear"></div>
</div>
</div>
{insert_template_scripts files='js/top.js'}
{include file="tuangou/widget/footer.php"}