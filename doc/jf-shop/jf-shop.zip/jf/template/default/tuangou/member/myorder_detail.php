<?php exit('die'); ?>
{insert_css files="tuangou/style/tuangou.css"}
{if $action eq 'show_tuangou_detail'}
<div id="tuangou_order_detail">
    <table class="tuan_table_cart" cellpadding="0" cellspacing="0">
      <tr>
        <th>��Ŀ����</th>
        <th>����</th>
        <th></th>
        <th>�۸�</th>
        <th></th>
        <th>�ܼ�</th>
      </tr>
      <tr>
        <td class="pname"><a href="{$data.view_link}" target="_blank">{$data.project_name} {$data.goods_name}</a></td>
        <td class="p_input">{$data.count}
        </td>
        <td class="center">X</td>
        <td class="center">{$data.goods_money|money_format}</td>
        <td class="center">=</td>
        <td class="center"><strong  id="tuan_goods_price_{$data.id}">{$data.total_goods_money|money_format}</strong></td>
      </tr>
      <tr>
        <td>��ݷ���</td>
        <td id="tuan_buy_number" class="center">{$data.count}</td>
        <td class="center">X</td>
        <td class="center" id="one_peison_fee">{$data.delivery_fee}</td>
        <td class="center">=</td>
        <td class="center" id="all_peison_fee">{$data.total_delivery_fee|money_format}</td>
      </tr>
      <tr>
        <td><strong class="e_red">�����ܶ�</strong></td>
        <td></td>
        <td></td>
        <td></td>
        <td class="center">=</td>
        <td class="center e_red"><strong  class="e_red" id="tuan_total_fee">{$data.total_order_fee|money_format}</strong></td>
      </tr>
     
        <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td class="center e_red"><strong  class="e_red" id="tuan_total_fee"> {if $data.pay_status eq '1'}���׳ɹ�{else}�ȴ�֧��{/if}</strong></td>
      </tr>
     
    </table>
    <div class="clear"></div>
    <h3 class="tmsg">����˵��</h3>
    <table class="table_common">
      <tr>
        <td>�ռ��ˣ�</td>
        <td>{$data.re_name}</td>
      </tr>
      <tr> 
        <td>�ֻ����룺</td>
        <td>{$data.re_phone}</td>
      </tr>
      <tr>
        <td>�ռ���ַ��</td>
        <td>{$data.re_address}</td>
      </tr>
      <tr>
        <td>�������룺</td>
        <td>{$data.re_zip}</td>
      </tr>
    </table>
        <div class="clear"></div>
    <h3 class="tmsg">��&nbsp;&nbsp;&nbsp;��</h3>
    <table class="table_common">
      <tr>
        <td>
        	{if $data.wuliu_sn}
            	<p>������ʽ��{$data.wuliu_name}</p>
                <br />
                <p>�������ţ�{$data.wuliu_sn}</p>
            {else}
           <samp class="red"> �����ĵȴ�,����Ϊ�����</samp>
            {/if}
        </td>
      </tr>
    </table>
     <h3 class="tmsg">������Ϣ</h3>
    <table class="table_common">
    {if $data.goods_extend_prefix_temp}
      <tr>
        <td>����ѡ��</td>
        <td>
        	{foreach from=$data.goods_extend_prefix_temp item='son'}
            	{$son}&nbsp;
            {/foreach}
        </td>
      </tr>
      {/if}
      <tr>
        <td>�������ԣ�</td>
        <td>{$data.re_extend}</td>
      </tr>
    </table>
    
<!--<h3 class="tmsg">��Ҫ����</h3>
    <table class="table_common">
      <tr>
        <td>���ݣ�</td>
        <td><textarea class="form_textarea w600 h100" name="comment"></textarea></td>
      </tr>
    </table>--->
    
<div class="tuangou_pay_right" style="text-align:center;">
<input type="button" value="�����б�"  onclick="window.location.href='{$call_back_url}'" class="form_submit"/>
<!--&nbsp;&nbsp;
<input type="button" value="��Ҫ����"  onclick="window.location.href='{$call_back_url}'" class="form_submit"/>-->
&nbsp;&nbsp;
{if $data.pay_status neq 1}
<input type="button" value="ȥ֧��"  onclick="window.location.href='{$data.pay_link}'"  style="font-weight:bold;"   class="form_submit"/>
{/if}
</div>
  </div>
{/if}
