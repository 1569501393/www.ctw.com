<?php exit('die'); ?>
{insert_css files="tuangou/style/tuangou.css"}
{if $action eq 'tuangou_order'}
<div id="tuangou_">
	{if $data.total>0}
    <table class="table_list tuangou_order_list" cellpadding="0" cellspacing="0">
      <tr>
        <th>��Ŀ����</th>
        <th>����</th>
        <th>�ܼ�</th>
        <th>״̬</th>
        <th>����</th>
      </tr>
      {foreach from=$data.data item='list'}
       	<tr>
        	<td class="ename"><a href="{$list.link}" target="_blank">{$list.project_name}{$list.goods_name}</a></td>
            <td>{$list.count}</td>
            <td>{$list.total_order_fee|money_format}</td>
            <td>{if $list.pay_status eq '1'}��֧��{else}δ֧��{/if}</td>
            <td>
            	{if $list.pay_status neq '1'}<a href="{$list.pay_link}" target="_blank"><img src="{$template_url}tuangou/images/to_pay.jpg" /></a>{/if}
                <a href="{$list.view_link}" target="_blank">�� ��</a>
            </td>
        </tr>
       {/foreach}
        </table>
        {$data.page}
    	{else}
        <div class="notice_msg">�����޿����Ź�������Ϣ!</div>
    {/if}
{/if}