<?php exit('die'); ?>
{include file="header.php"}
{insert_template_scripts files='tuangou/js/jquery.jcountdown1.4.js'}
{insert_css files="tuangou/style/tuangou.css"}
{include file="widget/site_top.php"}
<div class="dh">{include file="nav.php"}</div>