<?php exit('die'); ?>
<div class="sy_Product">
        	<div class="sy_title">
            	<a href="{building_link model='tuangou'}{$connector}{$elink}" {if $eget.t eq ''} class="curent_fix_link"{/if}>ȫ����Ʒ</a>
            	<span></span>
            </div>
        	<div class="sy_pp">
            {get_tuangou_city assign='city'}
                <!--����-->
           		<p class="fl">����:</p>
                <div class="box_more fl">
                    <a href="{$main_link}" {if $eget.city eq ''} class="curent_tuan_nav"{/if}>ȫ��</a> 
    	{foreach from=$city item='ct'} <a {if $eget.city eq $ct.en_name || $eget.city_id eq $ct.id} class="curent_tuan_nav"{/if} href="{$main_link}{$connector}cate_id={$eget.cate_id}&city={$ct.en_name}">{$ct.name}</a> {/foreach}
                </div>
                <div class="clear"></div>
                {get_tuangou_category assign='category'}
                <!--���-->
                <p class="fl">���:</p>
                <div class="box_more fl">
                    <a href="{$main_link}" {if $eget.cate_id eq ''} class="curent_tuan_nav"{/if}>ȫ��</a> {foreach from=$category item='ct'} <a href="{$main_link}{$connector}cate_id={$ct.id}&city={$eget.city}" {if $eget.cate_id eq $ct.id} class="curent_tuan_nav"{/if}>{$ct.name}</a> {/foreach}
                </div>
                <div class="clear"></div>
                <!--����-->
                <p class="fl">ɸѡ:</p>
                <div class="box_more fl">
                    <a href="{building_link model='tuangou'}{$connector}t=today&{$elink}" {if $eget.t eq 'today'} class="curent_fix_link"{/if}>������Ʒ</a>
                    <a href="{building_link model='tuangou'}{$connector}t=visttop&{$elink}" {if $eget.t eq 'visttop'} class="curent_fix_link"{/if}>��������</a>
                    <a href="{building_link model='tuangou'}{$connector}t=pricedesc&{$elink}" {if $eget.t eq 'pricedesc'} class="curent_fix_link"{/if}>�۸����</a>
                    <a href="{building_link model='tuangou'}{$connector}t=willexpire&{$elink}" {if $eget.t eq 'willexpire'} class="curent_fix_link"{/if}>��������</a>
                </div>
                <div class="clear"></div>	
            </div>	
        </div>