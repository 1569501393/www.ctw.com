<?php exit('die'); ?>
<div class="right_box">
     <h1>��֪��������ʲô��</h1>
       <div class="box">
       <form method="post" action="{$do_action}" id="do_sub_form"> 
        <p class="mails">
           <span class="f">
             <input type="text" class="form_input must_fill_data" style="width:120px;"  name="email" /> 
             <input type="submit" value="�� ��"  class="form_submit" />
           </span>
           <div class="clear"></div>
           <span class="m">ÿ�춼���¾�ϲ�����ǻ��ʼ�֪ͨ����</span>
        </p>
        </form>
        <script type="text/javascript">
    	$(function(){
			$("#do_sub_form").submit(function(){
				if(!check_form_is_empty('must_fill_data'))return false;
				$(this).ajaxSubmit(function(data){
					switch(data){
						case 'OK':
							$(".must_fill_data").val('');
							window.parent.showNotice('���ĳɹ�,��л����֧��!');
						break;
						case 'ERROR_MAIL':
							$(".must_fill_data").val('');
							window.parent.showNotice('�����ʽ����!');
						break;
					}
				});
				return false;
			});
		});
    </script>
       </div>  
     </div>