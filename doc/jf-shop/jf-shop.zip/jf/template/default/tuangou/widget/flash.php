<?php exit('die'); ?>
{assign var='flash_group' value='tuangou'}
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" id="scriptmain" name="scriptmain" codebase="http://download.macromedia.com/pub/shockwave/cabs/
flash/swflash.cab#version=6,0,29,0" width="980" height="296">
  <param name="movie" value="{$template_url}bcastr.swf?bcastr_xml_url={building_link model='flash' action='bcastr' param='group=$flash_group'}">
  <param name="quality" value="high">
  <param name="scale" value="noscale">
  <param name="LOOP" value="true">
  <param name="menu" value="false">
  <param name="wmode" value="transparent">
  <embed src="{$template_url}bcastr.swf?bcastr_xml_url={building_link model='flash' action='bcastr' param='group=$flash_group'}" width="980" height="296" loop="false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" salign="T" name="scriptmain" menu="false" wmode="transparent"></embed>
</object>