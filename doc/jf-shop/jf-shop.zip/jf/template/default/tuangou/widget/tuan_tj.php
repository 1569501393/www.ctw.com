<?php exit('die');?>
<div class="right_box">
     <h1>����ϲ��</h1>
     {get_tuangou_goods limit='4' assign='rand_tuan' type='rand' exclued='$data.id'}
       <div class="box">
       {if $rand_tuan}
         <ul>
         {foreach from=$rand_tuan item='list'}
           <li>
           <p class="fl"><a href="{$list.link}" titsle="{$list.project_name}"><img src="{$site_url}picture.php?s={$list.pic1}&w=64&h=62"  title="{$list.project_name}" alt="{$list.project_name}"/></a></p>
           <p class="fr">
             <span><a href="{$list.link}" title="{$list.project_name}">{$list.project_name|truncate:'8':'...'}</a></span>
             <span>�۸�<em>{$list.shop_price}</em></span>
             <span>�ۿۣ�<em>{$list.discount}</em></span>
           </p>
           <div class="clear" style="padding-top:5px;"></div>
           </li>
         {/foreach}
         </ul>
         {/if}
       </div>  
     </div>