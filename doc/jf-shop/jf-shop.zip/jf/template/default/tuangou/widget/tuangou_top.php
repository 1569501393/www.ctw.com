<?php exit('die'); ?>
  <div id="top_nav" class="bg_gray_fc">
    <div class="w980">
      <h1><span id="PHP188_member_panel"><!--#AJAX�ص���Աע������--></span><!--<a href="javascript:call_member_login(this);">��½</a>--></h1>
      <div class="mp">
        <p class="mp_login"><a href="javascript:;" onclick="view_my_cart(this);">�ҵĹ��ﳵ ( <samp id="un_pay_goods" class="yellow yehei">0</samp> ) ��</a> |  <a href="{building_link model='member@order'}" target="_blank">�̳Ƕ���</a> | <a href="{building_link model='help'}" target="_blank">��������</a></p>
      </div>
    </div>
  </div>
  <!--#top_nav-->
 
<div class="w980 bg_gray_fc" id="site_header">
	<a href="{$site_url}" title="{$site_name}" id="site_logo"><img src="{$siteurl}{$logo}" title="{$site_name}"></a>
    <div id="site_header_right">
    <p class="phone"><!--010-87875188-->{$sitecfg.siteBase.tel}</p>
    </div>
</div>
<!--#site_header-->
<div  class="w980 bg_gray_fc" id="site_nav">
	<div class="site_nav_container">
    	<a href="{$siteurl}">�̳���ҳ</a>
    	<a href="{building_link model='tuangou'}">�Ź���ҳ</a>
       <a href="{building_link model='tuangou' action='last'}" target="_blank">�����Ź�</a>

       <a href="{building_link model='tuangou' action='subscribe'}">�ʼ�����</a>
      <!-- <a href="{building_link model='tuangou'}{$connector}m=miaosha">��ɱ����</a>-->
    </div>
    <div class="site_search_pannel">
     <form method="get" id="php188_search_goods" action="{building_link model='tuangou'}"> 
      <table>
        <tr>
          <td><input type="text" class="wenben" id="focus_search_input" maxlength="20" value="" name="key"/></td>
          <td><input value="" type="submit" class="sousuo" /></td>
        </tr>
      </table>
    </form>
    </div>
</div>