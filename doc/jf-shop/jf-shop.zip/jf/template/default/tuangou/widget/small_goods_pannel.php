<?php exit('die'); ?>
<div class="tuan_left fl">
  {if $data.total>0}
	{foreach from=$data.data item='list' key=key}
     <div class="tuan_shop">
     <div class="tuan_info fl">
           <h2><a href="{$list.link}" target="_blank">{$list.project_name|truncate:'72':'...'}</a></h2>
           <div class="clear"></div>
           <div class="lines">
             <span class="je">{$list.shop_price|money_format}</span>
             <span class="gm"><a href="{$list.link}"><img src="{$template_url}images/tuan_buy.jpg"></a></span>
             
             <span class="other">
             <table width="100%" border="0" cellspacing="0" cellpadding="0">
               <tr>
                 <td>ԭ��</td>
                 <td>�ۿ�</td>
                 <td>��ʡ</td>
               </tr>
               <tr>
               <td>��{$list.market_price}</td>
               <td>{$list.discount}��</td>
               <td>{$list.discount_money}</td>
               </tr>
              </table>
             </span>
           </div>
           <div class="clear"></div>
           <div>{if !$list.will_start}
           <span class="money mms fl">{if !$list.has_expired}
            <samp class="time" id="show_expire_time_{$key}">
            	<strong id="D_{$key}">0</strong>��<strong id="H_{$key}">0</strong>Сʱ<strong id="M_{$key}">0</strong>��<strong class="time_sec" id="S_{$key}">0</strong>
            </samp>
            {/if}
            {if $list.will_expire && !$list.has_expired}<samp class="time_exp yahei">��Ҫ����</samp>{/if}
            {if $list.has_expired}<samp class="time_exp yahei">�ѽ���</samp>{/if}
            </span>
           <span class="times mms fr" style="font-size:12px"><b>{$list.pre_number+$list.order_total}</b><em>�˹���</em></span>
           {else}
           <span class="money mms">������ʼ ʱ�䣺{$list.start_time|date_format:"%Y-%m-%d %H:%M:%S"}</span>
           {/if}</div>   
        </div>
        <div class="tuan_img fr"><img alt="{$list.project_name}" title="{$list.project_name}" src="{$site_url}picture.php?s={$list.pic1}&w=220&h=198"/></div>
        <div class="clear"></div>        
     </div>
     <div class="clear"></div>
{if !$list.has_expired}
<script type="text/javascript">
	var EndTime_{$key} = {$list.end_time_format_2} ;
	function GetRTime_{$key}(){
		var NowTime = new Date();
		var nMS = EndTime_{$key} - NowTime.getTime();
		var nD = Math.floor(nMS/(1000 * 60 * 60 * 24));
		var nH = Math.floor(nMS/(1000*60*60)) % 24;
		var nM = Math.floor(nMS/(1000*60)) % 60;
		var nS = Math.floor(nMS/1000) % 60;
		var nss = Math.floor(nMS) % 60;
		var str = nD+'��'+nH+'Сʱ'+nM+'��'+nS+'.'+nss+'��';
		document.getElementById("D_{$key}").innerHTML=nD;
		document.getElementById("H_{$key}").innerHTML=nH;
		document.getElementById("M_{$key}").innerHTML=nM;
		document.getElementById("S_{$key}").innerHTML=nS;
		setTimeout("GetRTime_{$key}()",100);
	}
	GetRTime_{$key}();
</script>
{/if}
{/foreach}{else}<div class="tuan_shop">�޿�������!</div>
{/if}
</div>