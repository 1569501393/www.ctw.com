<?php exit('die'); ?>
{include file="tuangou/widget/cart_header.php"}
{if $action eq 'show_buy_goods_list'}
<form method="post" id="do_tuangou_cart" action="{building_link model='tuangou' action='toOrder'}">
<input type="hidden" value="{$data.id}" name="id" />
<div id="tuangou_buy_info" class="middle">
  <div class="tuan_cart_left">
    <h2 class="o_msg">�ύ����{if $data.mian_dan_num>0}<strong>({$data.mian_dan_num}�����˷�)</strong>{/if}</h2>
    <script type="text/javascript">
    	function load_tuan_price(obj){
			var i = $(obj).attr('tuan_goods_id');
			$.getJSON('{building_link model="tuangou" action="load_price"}',{id:i,num:$(obj).val()},function(data){
				switch(data.msg){
					case 'ERROR':
						showNotice('��������!');
					break;
					case 'NOT_EXIST':
						showNotice('���¼ܻ���ɾ��!');
					break;
					case 'OK':
						$("#tuan_goods_price_"+i).html(data.goods_money);
						$(obj).val(data.end_buy_num);
						$("#tuan_buy_number").html(data.end_buy_num);
						$("#all_peison_fee").html(data.end_delivery_total_fee);
						$("#one_peison_fee").html(data.end_peisong_fee);
						$("#tuan_total_fee").html(data.total_money);
					break;
					default:alert(data);
				}
			});
		}
    </script>
    <table class="tuan_table_cart" cellpadding="0" cellspacing="0">
      <tr>
        <th>��Ŀ����</th>
        <th>����</th>
        <th></th>
        <th>�۸�</th>
        <th></th>
        <th>�ܼ�</th>
      </tr>
      <tr>
        <td class="pname">{$data.project_name}</td>
        <td class="p_input">
        <input type="text" value="{$data.end_buy_num}" name="num" onkeyup="value=value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" {if $data.per_buy_number <= 1} readonly="readonly"{/if} onchange="load_tuan_price(this);" tuan_goods_id="{$data.id}" class="tuan_cart_input form_input must_fill_data" />
        <span class="t_desc">��๺��{$data.per_buy_number|default:'1'}��</span>
        </td>
        <td class="center">X</td>
        <td class="center">{$data.shop_price}</td>
        <td class="center">=</td>
        <td class="center"><strong  id="tuan_goods_price_{$data.id}">{$data.end_goods_total_money|money_format}</strong></td>
      </tr>
      <tr>
        <td>��ݷ���</td>
        <td id="tuan_buy_number" class="center">{$data.end_buy_num}</td>
        <td class="center">X</td>
        <td class="center" id="one_peison_fee">{$data.end_peisong_fee}</td>
        <td class="center">=</td>
        <td class="center" id="all_peison_fee">{$data.end_delivery_total_fee|money_format}</td>
      </tr>
      <tr>
        <td><strong class="e_red">�����ܶ�</strong></td>
        <td></td>
        <td></td>
        <td></td>
        <td class="center">=</td>
        <td class="center e_red"><strong  class="e_red" id="tuan_total_fee">{$data.end_order_total_money|money_format}</strong></td>
      </tr>
    </table>
    <div class="clear"></div>
    <h3 class="tmsg">����˵��</h3>
    <table class="tuan_table">
      <tr>
        <td>�ռ���</td>
        <td><input type="text" class="form_input w300 must_fill_data" name="rename" />
          <span class="t_desc">�ռ���������Ч֤����������һ�£�������ȡ��Ʒ</span></td>
      </tr>
      <tr> 
        <td>�ֻ�����</td>
        <td><input type="text" onkeyup="value=value.replace(/[^\d]/g,'')"  onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));"  class="form_input w300 must_fill_data" value="" name="phone" />
          <span class="t_desc">�ֻ�������������ϵ������Ҫ�ķ�ʽ����׼ȷ��д</span></td>
      </tr>
      <tr>
        <td>�ռ���ַ</td>
        <td><input type="text" value="" class="form_input w300 must_fill_data" name="address" />
          <span class="t_desc">Ϊ���ܼ�ʱ�յ���Ʒ���밴�ո�ʽ��д��_ʡ_��_�أ�����_</span></td>
      </tr>
      <tr>
        <td>��������</td>
        <td><input type="text" value="" onkeyup="value=value.replace(/[^\d]/g,'')"   onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" class="form_input w100 must_fill_data" name="zip" /></td>
      </tr>
    </table>
    
        <h3 class="tmsg">������Ϣ</h3>
    <table class="tuan_table">
    {if $data.goods_extend_prefix_temp}
      <tr>
        <td>����ѡ��</td>
        <td>
        	{foreach from=$data.goods_extend_prefix_temp  item='select'}
            <select class="form_select w100 must_fill_data" name="order_type[]">
            	<option value="">��ѡ��</option>
            	{foreach from=$select item='opt'}
                	<option value="{$opt}">{$opt}</option>
                {/foreach}
            </select>
            {/foreach}
        </td>
      </tr>
      {/if}
      <tr>
        <td>��������</td>
        <td><textarea class="form_textarea" name="re_extend"></textarea></td>
      </tr>
    </table>
      <div class="tuan_submit_form">
  	<input type="submit" value="�ύ" class="form_submit"/>
  </div>
  </div>
  <script type="text/javascript">
  	$(function(){
		$(".tuan_table td:even").addClass('tuan_cart_left_one');
		$("#do_tuangou_cart").submit(function(){
			var flag = true;
			if($('.form_select').size()){
				$('.form_select').each(function(){
					var v = $(this).val();
					if(empty(v)){
						$(this).addClass('empty_input_val');	
						flag = false;
	
					}else{
						$(this).removeClass('empty_input_val');
					}
				});	
			}
			if(!flag || !check_form_is_empty('must_fill_data')){
				showNotice('�����������!');	 return false;
			}
		});
	});
  </script>
  <div class="tuan_cart_right">
  	<h2 class="o_msg">�˻����</h2>
    {get_login_member_info assign="member"}
    <p class="show_money">�����˻���<strong>{$member.mem_money_format|default:'0'}</strong></p>
  </div>
</div>
</form>
{/if}
<div class="clear"></div>
{include file="goods/widget/footer.php"}