<?php exit('die'); ?>
{include file="tuangou/widget/cart_header.php"}
{if $action eq 'show_tuan_pay_info'}
<div id="tuangou_buy_info" class="middle">
  <div class="tuan_cart_left">
    <h2 class="o_msg">���Ķ���</h2>
    <table class="tuan_table_cart" cellpadding="0" cellspacing="0">
      <tr>
        <th>��Ŀ����</th>
        <th>����</th>
        <th></th>
        <th>�۸�</th>
        <th></th>
        <th>�ܼ�</th>
      </tr>
      <tr>
        <td class="pname"><a href="{$data.view_link}" target="_blank">{$data.project_name} {$data.goods_name}</a></td>
        <td class="p_input">{$data.count}
        </td>
        <td class="center">X</td>
        <td class="center">{$data.goods_money|money_format}</td>
        <td class="center">=</td>
        <td class="center"><strong  id="tuan_goods_price_{$data.id}">{$data.total_goods_money|money_format}</strong></td>
      </tr>
      <tr>
        <td>��ݷ���</td>
        <td id="tuan_buy_number" class="center">{$data.count}</td>
        <td class="center">X</td>
        <td class="center" id="one_peison_fee">{$data.delivery_fee}</td>
        <td class="center">=</td>
        <td class="center" id="all_peison_fee">{$data.total_delivery_fee|money_format}</td>
      </tr>
      <tr>
        <td><strong class="e_red">Ӧ���ܶ�</strong></td>
        <td></td>
        <td></td>
        <td></td>
        <td class="center">=</td>
        <td class="center e_red"><strong  class="e_red" id="tuan_total_fee">{$data.total_order_fee|money_format}</strong></td>
      </tr>
    </table>
    <div class="clear"></div>
    <h3 class="tmsg">����˵��</h3>
    <table class="tuan_table">
      <tr>
        <td>�ռ��ˣ�</td>
        <td>{$data.re_name}</td>
      </tr>
      <tr> 
        <td>�ֻ����룺</td>
        <td>{$data.re_phone}</td>
      </tr>
      <tr>
        <td>�ռ���ַ��</td>
        <td>{$data.re_address}</td>
      </tr>
      <tr>
        <td>�������룺</td>
        <td>{$data.re_zip}</td>
      </tr>
    </table>
    
     <h3 class="tmsg">������Ϣ</h3>
    <table class="tuan_table">
    {if $data.goods_extend_prefix_temp}
      <tr>
        <td>����ѡ��</td>
        <td>
        	{foreach from=$data.goods_extend_prefix_temp item='son'}
            	{$son}&nbsp;
            {/foreach}
        </td>
      </tr>
      {/if}
      <tr>
        <td>�������ԣ�</td>
        <td>{$data.re_extend}</td>
      </tr>
    </table>
<form method="post" id="payment_form" action="{building_link model='tuangou@tuanPayment' action='dopay'}">
<input type="hidden" value="{$data.order_id}"  name="order_id" />
{get_payment assign='payment'}
     <h3 class="tmsg">����֧��</h3>
        <table class="table_common">
          {foreach from=$payment item=pm key=k}
          	{if $pm.pay_code neq 'cash_delivery'}
          <tr>
            <td nowrap="nowrap" align="right" style="padding-right:30px; width:200px;">{$pm.pay_name}&nbsp;
              <input type='radio' class="pay_method" name='payment' value="{$pm.pay_id}" pay_name="{$pm.pay_code}"  onclick="show_user_pay_pass(this);" /></td>
            <td>{$pm.pay_desc} {if $pm.pay_extend_fee>0}<strong class="red">���������{$pm.pay_extend_fee|money_format}</strong>{/if}</td>
          </tr>
          {/if}
          {/foreach}
          <tr id="show_user_pay" style="display:none;" show="0">
          	<td align="right">������֧������:</td>
            <td><input type="password" value=""  name="pay_pass" id="show_pay_pass"  class="form_input must_fill_data" disabled="disabled"/>
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><input type="submit" value="ȥ֧��" class="form_submit"/></td>
          </tr>
        </table>
  </form>
  <script type="text/javascript">
var show_pay_pass = false;
function show_user_pay_pass(obj){
	show_pay_pass = true;
	var o = $("#show_user_pay");
	var b= $("#show_pay_pass");
	if($(obj).attr('pay_name')=='usermoney'){
		$(o).show().attr({"show":"1"});
		$(b).attr({"disabled":""});	
	}else{
		$(o).hide().attr({"show":"0"});
		$(b).attr({"disabled":"disabled"});	
	}
}
$(function(){
	$(".tuan_table td:even").addClass('tuan_cart_left_one_all');
	$("#payment_form").submit(function(){
		if(!get_checkbox_val('pay_method')){
			showNotice('��ѡ��֧����ʽ��');return false;
		}
		var c  = $("#show_user_pay").attr('show')==1?true:false;
		if(c && !check_form_is_empty('must_fill_data')){
			showNotice('������֧������!');
			return false;	
		}
	});
});
</script>
  </div>
  <div class="tuan_cart_right">
  	<h2 class="o_msg">�˻����</h2>
    {get_login_member_info assign="member"}
    <p class="show_money">�����˻���<strong>{$member.mem_money_format|default:'0'}</strong></p>
  </div>
</div>

{/if}
<div class="clear"></div>
{include file="goods/widget/footer.php"}