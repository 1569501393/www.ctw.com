<?php exit('die'); ?>
{include file="tuangou/widget/header.php"}
<div class="dh">{include file="nav.php"}</div>
{include file="tuangou/widget/city.php"}
<div class="middle" id="site_tuangou_index">
    <!--#���-->
    <div class="gonggao">
    {get_tuangou_announce assign='assign'}
    {$announce.site_base}
    </div>

<div class="clear"></div>
<div class="hd">
	<p class="hd1"><a href="{building_link model='tuangou'}{$connector}{$elink}" {if $eget.t eq ''} class="curent_fix_link"{/if}>ȫ����Ʒ</a></p>
<!--    <p class="hd2"><a href="{building_link model='tuangou'}{$connector}t=today&{$elink}" {if $eget.t eq 'today'} class="curent_fix_link"{/if}>������Ʒ</a> | <a href="{building_link model='tuangou'}{$connector}t=visttop&{$elink}" {if $eget.t eq 'visttop'} class="curent_fix_link"{/if}>��������</a> | <a href="{building_link model='tuangou'}{$connector}t=pricedesc&{$elink}" {if $eget.t eq 'pricedesc'} class="curent_fix_link"{/if}>�۸����</a>| <a href="{building_link model='tuangou'}{$connector}t=willexpire&{$elink}" {if $eget.t eq 'willexpire'} class="curent_fix_link"{/if}>��������</a>
    </p>
    -->
</div>

<div class="clear"></div>

{include file="tuangou/widget/small_goods_pannel.php"}

</div>
<div class="clear"></div>
{include file="tuangou/widget/footer.php"}