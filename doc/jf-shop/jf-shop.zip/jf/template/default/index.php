<?php exit('die'); ?>
{include file="header.php"}
{include file="widget/site_top.php"}
<div class="middle_bg"><!--����-->
	<div class="middle">
    	<div class="middle_one">
        	<ul class="one_nav fl"><!--����-->
            	<span class="color"></span>
                {get_category assign="php188_goods_category"}
                {if $php188_goods_category}
                {foreach from=$php188_goods_category name='cn' item='c1' key=key}
                {if $key<=12}
                <li class="left_cate {if $key mod 2 eq 1}side_1{else}side_2{/if}"><!--//����ƶ���ȡ��ʽ fsides--><em></em><a href="{$c1.view_category}" class="tabaa">{$c1.cate_name}</a>
                {if $c1.childrens}                
                <span class="fdiv" style="display:none">
                <table border="0" cellspacing="0" cellpadding="0" class="fl_tab">
                {foreach from=$c1.childrens item='c2' name='jname'}
                  <tr>
                    <td nowrap="nowrap" class="lone" valign="top">
                     <a href="{$c2.view_category}" title="{$c2.cate_name}"{if $smarty.foreach.jname.first} class="alinks"{/if}><b>{$c2.cate_name}</b></a></td>
                    <td class="rtwo">{foreach from=$c2.childrens item='c3' key=jkey name='sons'}<a href="{$c3.view_category}" title="{$c3.cate_name}">{$c3.cate_name}</a>{if !$smarty.foreach.sons.last} | {/if}{/foreach}</td>
                  </tr>
                 {/foreach}
                 </table>
                </span>
                {/if}
              </li>
              {/if}
              {/foreach}
              {/if}
                <span style="font-size:0px;"><img src="{$template_url}images/x.gif" /></span>
            </ul><!--���� end-->
            <script language="javascript">
			$(document).ready(function(){
              $('.left_cate').mousemove(function(){
	          $(this).find('.fdiv').show();
	          $(this).addClass('fsides');
	        });
	          $('.left_cate').mouseleave(function(){
	          $(this).find('.fdiv').hide();
	          $(this).removeClass('fsides');
	         });
            });
            </script>
            <div id="focus" class="d1"><!--�ֲ�-->	
                {assign var='flash_group' value='index'}
    	        {include file="widget/flash.php"}
            </div><!--�ֲ� end-->
			<div class="one_right fr">
           		<ul class="base_list">
                {get_article cate_sign='shangchenggonggao' assign='article_data' limit=5}
                	<h3 class="title"><a href="{building_link model='article' action='artlist' param='categoryid=37'}" class="more"><img src="{$template_url}images/more.gif" /></a><em>����</em></h3>
                    {foreach from=$article_data.data item='list'}		
                	<li><span class="more1">{$list.category_date|date_format:"%Y-%m-%d"}</span><a href="{$list.url}" target="_blank">{$list.article_long_title|truncate:12:'..'}</a></li>
                    {/foreach}
                </ul>
                <ul class="base_list1">
                {get_brands limit='6' assign='brands'}
                	<h3 class="title"><a href="{building_link model='goods' action='brands'}" class="more"><img src="{$template_url}images/more.gif" /></a><em>Ʒ��</em></h3>		
               		{foreach from=$brands item='c'}
                    <li><a href="{$c.link}" title="{$c.brand_name}"><img src="{$site_url}picture.php?s={$c.brand_logo}" onload="setimg(this,106,50);"/></a></li>
                    {/foreach}
                </ul>	
            </div>
            <div class="clear"></div>	
        </div>        
        <div class="middle_two mt">
        	<h3 class="title1"><a href="{building_link model='tuangou'}" class="more"><img src="{$template_url}images/more.gif" /></a><em>�Ź�</em></h3>
            {get_tuangou_goods assign='data' limit='2'}
            {if $data}
            {foreach from=$data item='list' key=key}
   	    <dl class="tg fl">
            	<dt><img src="{$site_url}picture.php?s={$list.pic1}&w=170&h=180" title="{$list.project_name}"/></dt>
                <dd class="tg_1"><a href="{$list.link}">{$list.project_name|truncate:'18':'...'}</a></dd>
                <dd class="tg_2">
                	<strong>{$list.shop_price|money_format}</strong>
                    <a href="{$list.link}"><img src="{$template_url}images/bt_1.gif" /></a>	
                </dd>
                <dd class="tg_time">
                	<div class="lxftime fl">
                {if !$list.will_start}
                {if !$list.has_expired}<samp id="show_expire_time_{$key}"><strong id="D_{$key}">0</strong>��<strong id="H_{$key}">0</strong>Сʱ<strong id="M_{$key}">0</strong>��<strong id="S_{$key}">0</strong></samp>{/if}
                {if $list.will_expire && !$list.has_expired}<samp>��Ҫ����</samp>{/if}
                {if $list.has_expired}<samp>�ѽ���</samp>{/if}
                {else}<samp>������ʼ ʱ�䣺{$list.start_time|date_format:"%Y-%m-%d %H:%M:%S"}</samp>
                {/if}
                </div>	
                </dd>
                {if !$list.has_expired}
                <script type="text/javascript">
 	            var EndTime_{$key} = {$list.end_time_format_2} ;
	            function GetRTime_{$key}(){
		              var NowTime = new Date();
		              var nMS = EndTime_{$key} - NowTime.getTime();
		              var nD = Math.floor(nMS/(1000 * 60 * 60 * 24));
		              var nH = Math.floor(nMS/(1000*60*60)) % 24;
		              var nM = Math.floor(nMS/(1000*60)) % 60;
		              var nS = Math.floor(nMS/1000) % 60;
		              var nss = Math.floor(nMS) % 60;
		              var str = nD+'��'+nH+'Сʱ'+nM+'��'+nS+'.'+nss+'��';
		         document.getElementById("D_{$key}").innerHTML=nD;
		         document.getElementById("H_{$key}").innerHTML=nH;
		         document.getElementById("M_{$key}").innerHTML=nM;
		         document.getElementById("S_{$key}").innerHTML=nS;//+'.'+nss
		         setTimeout("GetRTime_{$key}()",100);
	             }
	             GetRTime_{$key}();
                 </script>
                 {/if}
          </dl>
            {/foreach}
            {else}
            {/if}
            <div class="clear"></div>
        </div>
        <!--�м���λ-->
        <div class="mt">{get_ads place_name="��ҳ�м���"}</div>        
        {assign var='cate_py' value='mianyilei'}
        {assign var='loop_num' value='5'}
        <ul class="middle_two shop_list lindex mt" id="lindex">
        	<h3 class="title1" style="margin-bottom:10px;"><a href="{building_link model='goods' action='catagory' param='id=35'}" class="more"><img src="{$template_url}images/more.gif" /></a><em>��װ����</em></h3>
      		{include file="widget/goods_index.php"}
            <div class="clear"></div>	
        </ul>
        {assign var='cate_py' value='jiayongdianqi'}
        {assign var='loop_num' value='5'}
        <ul class="middle_two shop_list lindex mt">
        	<h3 class="title1" style="margin-bottom:10px;"><a href="{building_link model='goods' action='catagory' param='id=1'}" class="more"><img src="{$template_url}images/more.gif" /></a><em>���õ���</em></h3>
      		{include file="widget/goods_index.php"}
            <div class="clear"></div>	
        </ul>
        {assign var='cate_py' value='gezhongbaobao'}
        {assign var='loop_num' value='5'}
        <ul class="middle_two shop_list lindex mt">
        	<h3 class="title1" style="margin-bottom:10px;"><a href="{building_link model='goods' action='catagory' param='id=15'}" class="more"><img src="{$template_url}images/more.gif" /></a><em>���ְ���</em></h3>
      		{include file="widget/goods_index.php"}
            <div class="clear"></div>	
        </ul>
        {assign var='cate_py' value='shipinyinliao'}
        {assign var='loop_num' value='5'}
        <ul class="middle_two shop_list lindex mt">
        	<h3 class="title1" style="margin-bottom:10px;"><a href="{building_link model='goods' action='catagory' param='id=32'}" class="more"><img src="{$template_url}images/more.gif" /></a><em>ʳƷ����</em></h3>
      		{include file="widget/goods_index.php"}
            <div class="clear"></div>	
        </ul>
        {assign var='cate_py' value='riyongbaihuo'}
        {assign var='loop_num' value='5'}
        <ul class="middle_two shop_list lindex mt">
        	<h3 class="title1" style="margin-bottom:10px;"><a href="{building_link model='goods' action='catagory' param='id=34'}" class="more"><img src="{$template_url}images/more.gif" /></a><em>���ðٻ�</em></h3>
      		{include file="widget/goods_index.php"}
            <div class="clear"></div>	
        </ul>
       {include file='widget/link.php'}
    </div>	
</div><!--���� end-->
{include file='widget/page_helper.php'}
{include file='footer.php'}
