<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<meta http-equiv="Content-Language" content="zh-CN" />
<title>ϵͳ��ʾ��Ϣ</title>
{insert_template_scripts_root files='shopdata/js/jquery-1.3.2.min.js'}
<base target="_blank" />
<meta http-equiv="expires" content="0" />
<style type="text/css">
body {text-align:center;font-family:����,serif;background:#ffffff;font-size:12px;}
body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,form,fieldset,input,textarea,blockquote{padding:0; margin:0;}   
table,td,tr,th{font-size:12px;}li{list-style-type:none;}table{ margin:0 auto;}img{vertical-align:top;border:0;}
ol,ul {list-style:none;} caption,th {text-align:left;}
h1,h2,h3,h4,h5,h6 {font-size:12px; font-weight:normal;} q:before,q:after {content:'';}   
abbr,acronym {border:0;}address,caption,cite,code,dfn,em,th,var {font-weight:normal; font-style:normal;}
strong {font-weight:normal;}
a {color:#E42829;text-decoration:none;}
.areaT{width:630px; text-align:left; color:#DCDDDD; font-family:Verdana, Arial, Helvetica, sans-serif; margin:100px auto 0;}
.areaB{width:630px; text-align:right; color:#DCDDDD; font-family:Verdana, Arial, Helvetica, sans-serif; margin:0 auto 100px;}.area{width:630px; border:1px solid #DCDDDD; margin:0 auto; padding:50px 0;}
.area{}
.area .tips{float:left; margin-left:25px; margin-top:-20px;}.area h2{text-align:left; font-size:20px; font-family:"����"; border-bottom:1px solid #DCDDDD; padding:20px 0 10px; margin:0 35px 10px 190px;}.area h3{text-align:left; font-size:18px; font-family:"����"; margin:0 35px 0 190px;}
</style>
</head>
<body>
<div class="areaT">��ʾ��Ϣ</div>
<div class="area clearfix">
	<div class="tips"><img src="{$template_url}images/error/notice_run.gif" width="89" height="140"  /></div>
    <h2>{$message|default:'ҳ�������,���Ժ�...'}</h2>
   {if $show_url} <h3><a href="{$url_forward}" target="_self">������������û���Զ���ת����������</a></h3>{/if}
     <script type="text/javascript">setTimeout("window.location.replace('{$url_forward}');", {$time});</script>
</div>
</body>
</html>