<?php  exit('die');?>
{if $is_frame}
{include file='header.php'}
{/if}
<div id="view_cart_data">
<!--#δ���㶩��-->
{if $action eq 'berforder'}
{if !$carshop && !$no_pay_order}<div class="notice_msg">�޿�������!</div>{/if}
 {if $no_pay_order.total>0}  
    <script type="text/javascript">
    function to_pay(obj,order_id){window.parent.location.href=$(obj).attr('name'); }
	function show_data(obj){
		var url = "{building_link model='default' action='searchOrder'}"+connetor+'order_sn='+$(obj).attr('sn'); 
		window.open(url);
	}
	function to_edit_order(obj){
		window.open($(obj).attr('rel'));
	}
    </script>
 <div class="m_notice"><h3>&nbsp;&nbsp;δ���㶩��({$no_pay_order.total})</h3></div>
 <div class="no_pay_cart">
      <table class="table_list">        
            <tr>   
                <th>����</th>
                <th>����</th>
                <th>����</th>
                <th>ʱ��</th>               
                <th>����</th>
            </tr>    	        
        {foreach from=$no_pay_order.list name=name item=item}
            <tr>
                <td class="center">{$item.order_sn}</td>
                <td class="center">{$item.order_count}</td>
                <td class="center">{$item.order_money|money_format} {if $item.order_total_point_fee>0}+{$item.order_total_point_fee}��{/if}</td>
                <td class="center">{$item.add_time|date_format:"%Y-%m-%d"}</td>
                <td class="center"><input type="button" value="֧��" onclick="to_pay(this,'{$item.order_id}');" name="{building_link model='goods@flow' action='berforder' param='id=$item.order_id' http='false'}"  class="form_submit"/>
                {if $item.mem_id}
                <input type="button" value="����" class="form_submit"  onclick="to_edit_order(this);" rel="{building_link model='member@money' action='orderinfo' param='id=$item.order_id'}" />
                {/if}
                </td>
            </tr>       
        {/foreach} 
        <tr>
        	<td colspan="10" align="right">
            <samp class="red">����{$no_pay_order.total_goods}����Ʒ �ϼƣ�{$no_pay_order.total_order_money_format} {if $no_pay_order.total_order_fees>0}+ {$no_pay_order.total_order_fees}��{/if}</samp>&nbsp;&nbsp;&nbsp;</td>
        </tr>
      </table>
     </div> 
      {/if} 

      {if $carshop.total_goods_count>0} 
       <div class="m_notice"><h3>���ﳵ�е���Ʒ({$carshop.total_goods_count})</h3></div>
       <div class="no_pay_cart">
        <table class="table_list">
        <tr>
        	<th></th>
            <th align="center">����</th>
            <th>����</th>
             <th>����</th>
            <th>����(����)</th>
            <th>С��</th>
        </tr>
        {foreach from = $carshop.list item=item name=name}
           <tr>
          	<td align="center" width="100"><img src="{$siteurl}picture.php?s={$item.goods_list_small_pic}&w=30" /></td>
            <td align="center">{if $item.is_additional neq '1'}<a href="{$item.goods_link}" target="_blank">{$item.goods_name}</a>{else}{$item.goods_name}{/if}</td>
            <td align="center">{$item.buy_num}</td>
             <td align="center">{$item.goods_price_format}</td>
              <td align="center">{$item.goods_point_fee}</td>
            <td align="center">
            {if $item.only_use_point eq '1'}
                    {$item.total_goods_point_fee}��
            {else}
                    {$item.total_money_format}{if $item.total_goods_point_fee}+{$item.total_goods_point_fee}{/if}
            {/if}
            </td>
          </tr>
          {/foreach}
          <tr><td colspan="6" align="right">
          <samp class="red">�ϼƣ�{$carshop.total_goods_price_fromat}{if $carshop.total_goods_point_fee}+{$carshop.total_goods_point_fee}��{/if}</samp>
          <input type="button" rel="{building_link model='goods@flow' action='toCart' http='false'}"  class="form_submit" onclick="window.parent.location.href=$(this).attr('rel');return false;" value="��Ҫ�༭">&nbsp;
          <input type="button" rel="{building_link model='goods@flow' action='checkOut' http='false'}" class="form_submit" onclick="window.parent.location.href=$(this).attr('rel');return false;" value="ȥ����" />&nbsp;&nbsp;</td></tr>
        </table>
        </div>
      {/if}  
    {/if}
<div>