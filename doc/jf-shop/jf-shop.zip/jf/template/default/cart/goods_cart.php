<?php exit('cart'); ?>
{include file="cart/widget/header.php"}
<div id="site_cart_main_index" class="middle">
<!--#���ﳵ�б�-->
 {if $action eq 'to_cart'}
 <form method="post" action="{$cart_opt_url}" id="change_cart_number">
   {include file="cart/widget/to_cart.php"}
 </form>
 {else}
 <!--#�����û���Ϣ-->
 {if $action eq 'to_consignee'}
	  {include file="cart/widget/to_consignee.php"}
 {else}
      {include file="cart/widget/to_show.php"}
 {/if}
 <!--#����������Ϣ-->
 {include file="cart/widget/cart_delivery.php"}
 <div class="to_cart_css" style="overflow:hidden;">
 <div style="clear:both;padding-top:15px;"></div>
  <span style="float:left"><input type="button" value="�༭����" class="form_submit" onclick="window.location.href='{$edit_goods_url}'"></span>
  <span style="float:right"><a href="javascript:;" onclick="_check_deliery();"><img src="{$template_url}images/to_order.gif"/></a>
  </span>
 </div>
 {/if}
</div>
<div class="clear"></div>
{include file="cart/widget/footer.php"}