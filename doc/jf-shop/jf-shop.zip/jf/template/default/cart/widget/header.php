<?php exit('die'); ?>
{include file="header.php"}
{insert_css files="style/cart.css"}
{include file="widget/site_top.php"}
<div class="dh" style="border-bottom:1px dotted #CCC;padding-bottom:10px;">{include file="nav.php"}</div>