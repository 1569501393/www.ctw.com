<?php  exit('die');?>
<div id="goods_consignee_pannel">
  <script type="text/javascript" src="{$region_json_link}"></script>
  <script type="text/javascript">
$(function(){
	$(".table_cart_consignee td:even").addClass('table_cart_con_one');
	$("#submit_order_form").submit(function(){
		var flag = true;
		$(".need_remove_node select").each(function(){
			if(empty($(this).val())){
				$(this).addClass('empty_input_val');	
				flag = false;
			}else{
				$(this).removeClass('empty_input_val');	
			}
		});
		if(!flag)return showNotice('����д��������!');
		if(!check_form_is_empty('must_fill_in'))return showNotice('����д������!');		
		/*����ͻ�ʱ��*/
		var  del = $("#php188_receive_date").val();
		if(del=='specal'){
			var dom =  $("#specal_date");
			var d = dom.val();
			if(empty(d)){
				$(dom).addClass('empty_input_val');
				return showNotice('�������ͻ�����!');
			}else{
				$(dom).removeClass('empty_input_val');	
			}
		}
		//���绰����
		var phone = $.trim($("#php188_receive_phone").val());
		var mobile = $.trim($("#php188_receive_mobile").val());
		if(empty(phone) && empty(mobile))return showNotice('�绰���ֻ����������е�һ��!');
	});//end submit
/*�������ڵĴ���*/
 $("#php188_receive_date").change(function(){
		var v = $(this).val();
		if(v=='specal'){
			$('#specal_date').show();
		}else{
			$('#specal_date').hide();
			$("#specal_date").val('');
		}
  });
});
function getRegionChild(obj){
	var pid = $(obj).val();
	pid = !pid?0:pid;
	var temp = php_region_json_data[pid];
	if(temp){
		var str = '';
		var option = '<option value="">��ѡ��...</option>';
		str += option;
		$(temp).each(function(j){
			str+='<option value="'+temp[j].id+'">'+temp[j].name+'</option>';
		});
		$(obj).parents('span').nextAll().find('select').html(option);
		$(obj).parents('span').next().find('select').html(str);
	}
}
$(function(){
	$(".edit_order").click(function(){
		if($(this).text()!='[չ��]'){
		   $(this).text('[չ��]');
		   $('#'+$(this).attr('rev')).css("display",'none');
		}else{
		   $(this).text('[����]');
		   $('#'+$(this).attr('rev')).css("display",'block');
		}
	});
});
 </script>
  {insert_template_scripts_root files='shopdata/js/calendar/WdatePicker.js'}
  <div class="car_m_notice" id="cart_consignee_bar">
    <h3>��д�˶Զ�����Ϣ</h3>
    <a href="javascript:;" rev="cars" class="edit_order">[����]</a></div>
  <div class="to_consinee_cart" id="cars"> {include file="cart/widget/cart_goods_list.php"} </div>
  <div class="clear"></div>
  <!--#���õ�ַ-->
  <div class="crderInfo">
    <div class="car_m_notice">
      <h3>�ջ�����Ϣ</h3><a href="javascript:;" rev="shdz" class="edit_order">[����]</a>
    </div>
    <table border="0" cellpadding="1" cellspacing="1" class="table_common table_cart_consignee_ted" id="shdz" bgcolor="#FAFAFA">
      <tr class="btm_line">
        <td width="94" align="right" bgcolor="#FFFFFF">�ջ���������</td>
        <td width="392" align="left" bgcolor="#FFFFFF">{$info.receive_realname}</td>
        <td width="87" align="right" bgcolor="#FFFFFF">���͵�����</td>
        <td width="440" align="left" bgcolor="#FFFFFF">{if $history_receive}
         {foreach from=$history_receive item=item}
        {if $item.receive_id eq $area_address}{$item.receive_area_text}{/if}
        {/foreach}{/if}</td>
      </tr>
      <tr class="btm_line">
        <td align="right" bgcolor="#FFFFFF" >�ͻ����ڣ�</td>
        <td align="left" bgcolor="#FFFFFF">{$info.receive_date_type}</td>
        <td align="right" bgcolor="#FFFFFF">��Ʊ��Ϣ��</td>
        <td align="left" bgcolor="#FFFFFF">{if $is_open_fapiao}<script type="text/javascript">
	function set_fapiao_data(obj){
		var tag = $("#fapiao_taitou_info");
		var status = $(obj).attr('checked');
		var val = 0;
		if(status){
			$(tag).show(); val = 1;
		}else{
			$(tag).hide();val = 0;
		}
	}
</script>
      <div class="cart_pannel" id="cart_fapiao_info_all">
        <table border="0" cellpadding="0" cellspacing="0" style="background:#FFF;border:1px solid #CCC;">
          <tr>
            <td width="65">��Ʊ��</td>
            <td width="225"><input type="checkbox" value="1" onclick="set_fapiao_data(this);" {if $info.is_use_fapiao eq '1'} checked="checked"{/if} name="is_use_fapiao" /></td>
          </tr>
          <tr id="fapiao_taitou_info" style="{if $info.is_use_fapiao neq '1'}display:none;{/if}">
            <td>��Ʊ̧ͷ��</td>
            <td><textarea name="receive_invoice" class="w300" >{$info.receive_invoice}</textarea></td>
          </tr>
        </table>
      </div>{/if}</td>
      </tr>
      <tr class="btm_line">
        <td align="right" bgcolor="#FFFFFF" >���͵�ַ��</td>
        <td align="left" bgcolor="#FFFFFF">{$info.receive_address}</td>
        <td align="right" bgcolor="#FFFFFF">ȱ��������</td>
        <td align="left" bgcolor="#FFFFFF">{$info.out_of_stock}</td>
      </tr>
      <tr class="btm_line">
        <td align="right" bgcolor="#FFFFFF" >�����ʼ���</td>
        <td align="left" bgcolor="#FFFFFF">{$info.receive_email}</td>
        <td align="right" bgcolor="#FFFFFF">�� �� ����</td>
        <td align="left" bgcolor="#FFFFFF">{if $info.coupon.fix_money}
          	�Ż�ȯ��{$info.coupon.fix_number} ��Ӧ��{$info.coupon.fix_money}
        {/if}</td>
      </tr>
      <tr class="btm_line">
        <td align="right" bgcolor="#FFFFFF" >�̶��绰��</td>
        <td align="left" bgcolor="#FFFFFF">{$info.receive_phone}</td>
        <td align="right" bgcolor="#FFFFFF">������ע��</td>
        <td align="left" bgcolor="#FFFFFF">{$info.receive_note}</td>
      </tr>
      <tr class="btm_line">
        <td align="right" bgcolor="#FFFFFF" >�ֻ����룺</td>
        <td align="left" bgcolor="#FFFFFF">{$info.receive_mobile}</td>
        <td align="right" bgcolor="#FFFFFF">&nbsp;</td>
        <td align="left" bgcolor="#FFFFFF"></td>
      </tr>
      <tr class="btm_line">
        <td align="right" bgcolor="#FFFFFF" >�������룺</td>
        <td align="left" bgcolor="#FFFFFF">{$info.receive_postno}</td>
        <td align="left" bgcolor="#FFFFFF">&nbsp;</td>
        <td align="left" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4" bgcolor="#FFFFFF" style="text-align:left;padding:6px;"><input type="submit" class="car_btn" value="�����޸�" onclick="window.location.href='{building_link model='goods@flow' action='consignee'}'"></td>
      </tr>        
    </table>
</div>
</div>