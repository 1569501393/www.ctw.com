<?php exit('die'); ?>
<div id="goods_cart_list">
    <div class="car_m_notice"><h3>�ҵĹ��ﳵ</h3></div>
    <div class="clear"></div>
      {include file="cart/widget/cart_goods_list.php"}
    <div class="clear"></div>
</div>
<!--������Ʒ-->
{get_additional_goods assign='extend_list'}
 {if $extend_list}
<div class="car_m_notice"><h3>�յ���Ʒ</h3></div>
<div class="extend_goods_list w980">
  <table class="car_table_list_two car_table">
  <thead>
  <tr>
  	<th>��Ʒͼ</th>
    <th>����</th>
    <th>����</th>
    <th></th>
  </tr>
    {foreach from=$extend_list item='list'}
    <tr>
      <td><img src="{$site_url}picture.php?s={$list.goods_source_pic}&w=30&h=45" /></td>
      <td>{$list.goods_contents.detail}</td>
      <td>{$list.goods_shop_price_f}</td>
      <td><input type="button" value="����" class="form_submit" onclick="php188_goods_tocart(this,'{$list.goods_id}');" /></td>
    </tr>
    {/foreach}
  </table>
</div>
{/if}
<div class="h10"></div>
<div id="goods_cart_btn">
 <span class="car_left_btn">
  <a href="{$referer_link}"><img src="{$template_url}images/cart/btn-goto-buy.gif" /></a>
  <a href="{$clearcart}"><img src="{$template_url}images/cart/btn-clear-cat.gif" /></a>
 </span>
 <span class="car_right_btn">
 <a href="{$check_out_url}"><img src="{$template_url}images/cart/to_check_out.gif"/></a>
 </span>
<!--<input type="image" src="{$template_url}images/cart/update_cart.gif " />-->
</div>

