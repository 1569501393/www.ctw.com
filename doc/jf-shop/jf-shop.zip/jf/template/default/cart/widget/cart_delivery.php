<?php exit('die'); ?>
{if $action eq 'goods_cart_delivery'}
<form method="post" action="{$do_url}" id="submit_form_deliery">
<div id="goods_deliery_dom">
    <div class="car_m_notice">
        <h3>���ͷ�ʽ</h3><a href="{building_link model='delivery'}" target="_blank" class="show_deliery_area">�鿴������ͷ�Χ��ʱ�估�۸�</a>
    </div>
<div class="clear"></div>
<div id="delivery_payment_list">
	<input type="hidden" value="" name="delivery_fee"  id="delivery_fee"/>
    <input type="hidden" value="" name="delivery_name"  id="delivery_name"/>
    <table class="table_common table_cart_consignee">
    {foreach from=$delivery_data item=dl}
    <tr>
    <td align='right'>{$dl.delivery_name}��</td>
    <td width="12%" align="center">
<input  type="radio" name="delivery_id" onclick="alert_delivery_method(this);" class="check_pay_method" value="{$dl.id}" delivery_fee="{$dl.curent_deliver_alculate_fee}" delivery_name="{$dl.delivery_name}"/>
</td>
    <td align="left">
    	<span class="red">{$dl.curent_deliver_alculate_fee_format}</span>
    </td>
    <td align="left">{$dl.desc}</td>
    <td style="width:400px">{if $dl.curent_deliver_alculate_fee_method_all.temp}<samp>{$dl.curent_deliver_alculate_fee_method_all.temp} = <font color="#FF0000">{$dl.curent_deliver_alculate_fee_format}</font></samp>{/if}</td>
    <td width="15%">
    {if $dl.is_special eq '1'}<p style="border:0px;color:#868686"><strong>֧�ֵ����͵�����</strong>
    	{if $dl.deliery_money_method eq '1'}ȫ��{elseif $dl.deliery_money_method eq '2'}{if $dl.peisong_data.area}{$dl.peisong_data.area}{elseif $dl.peisong_data.extend_area_set}{$dl.peisong_data.extend_area_set}{else}ȫ��{/if}{elseif $dl.deliery_money_method eq '3'}ȫ��{else}N/A
        {/if}</p>
        {/if}
       {if $dl.time_limit}
       <strong>	�ͻ�ʱ�ޣ�</strong>{$dl.time_limit}
       {/if}
    </td>
    </tr>
    {/foreach}
    </table>
<script type="text/javascript">
function _check_deliery(){
	if(!get_checkbox_val('check_pay_method')){
		window.parent.showNotice('��ѡ�����ͷ�ʽ!');return false;
	}
	$("#submit_form_deliery").submit();
}
function alert_delivery_method(obj){
	$("#delivery_fee").val($(obj).attr('delivery_fee'));
	$("#delivery_name").val($(obj).attr('delivery_name'));
}
</script>
</div>
 </div>
    <div class="clear"></div>
<div id="delivery_bot_button" style="display:none">
<input type="button" class="car_btn" onclick="_check_deliery();" value="�������ͷ�ʽ">
</div>
</form>
{/if}