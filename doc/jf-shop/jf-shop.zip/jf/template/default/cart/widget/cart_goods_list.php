<?php exit('die'); ?>
{if $goods_cart}
<input type="hidden" value="1" name="hide_location" />
<table class="car_table_list car_table" cellpadding="0" cellspacing="0">
  <thead>
    <tr>
      <th>��Ʒͼ</th>
      <th>����</th>
      <th>���ͻ���</th>
      <th>����</th>
      <th>����</th>
      <th>����</th>
      <th>(����)����</th>
      <th>С��</th>
      {if $can_alert_cart}
      <th>����</th>
      {/if} </tr>
  {foreach from=$goods_cart.list item=ga key=k}
  <tr class="allindex_all" id="rowIndex{$ga.goods_id}">
    <td class="center img"><img src="{$siteurl}picture.php?s={$ga.goods_list_small_pic}&w=30&h=45"/></td>
    <td class="center">
    {if !$ga.is_additional}<a href="{$ga.goods_link}" target="_blank">{$ga.goods_name}{if $ga.goods_spec_extend_name}<samp class="spec_extend_name yellow">��{$ga.goods_spec_extend_name}��</samp>{/if}</a>
 {if $ga.temp_tao}
<div class="cart_taozhuang">
<p>��װ��</p>
    {foreach from=$ga.temp_tao item='tao' name='extend_name'} {$tao.goods_name} {if !$smarty.foreach.extend_name.last}��{/if}{/foreach}
  </div>
{/if}

 {if $ga.temp_zenpin}
<div class="cart_taozhuang">
<p>��Ʒ��</p>
    {foreach from=$ga.temp_zenpin item='tao' name='extend_zenpin_name'} {$tao.goods_name} {if !$smarty.foreach.extend_zenpin_name.last}��{/if}{/foreach}
  </div>
{/if}

    {else}{$ga.goods_name}{/if}
    
    </td>
    <td class="center">{$ga.goods_points}</td>
    <td class="center">{if $can_alert_cart}
    	<div class="cart_buy_number_pannel">
    		 <span class="d_cline cart_span">-</span>
            <input onkeyup="value=value.replace(/[^\d]/g,'')"  readonly="readonly" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" type="text" maxlength="2"  class="cart_form_input_lite" value="{$ga.buy_num}"  name="goods_cart[{$ga.goods_id}]" />
            <span class="d_add cart_span">+</span>
            <div class="clear"></div>
            </div>
      {else}{$ga.buy_num}{/if}</td>
    <td class="center">{if !$ga.is_additional}{$ga.goods_weight|default:'0'}��{else}-{/if}</td>
    <td class="center">{$ga.goods_price_format}</td>
     <td class="center">{$ga.goods_point_fee}</td>
    <td  class="center xiaoji">
    	{if $ga.only_use_point eq '1'}
        		{$ga.total_goods_point_fee}��
        {else}
	            {$ga.total_money_format}{if $ga.total_goods_point_fee}+{$ga.total_goods_point_fee}{/if}
        {/if}
    </td>
    {if $can_alert_cart}
    <td class="center">
    <a href="javascript:;" name="{$ga.delurl}" onclick="return php188_goods_delGoodFromcart(this,'{$k}');">ɾ��</a></td>
    {/if} </tr>
  {/foreach}
</table>
{if $can_alert_cart}
<script type="text/javascript">
	$(function(){
		$(".d_cline").click(function(){
			var o = $(this).next();
			 var v = parseInt($(o).val());
			 var vv = v>=1?parseInt(v-1):1;
			 $(o).val(vv<=1?1:vv);
			 $("#change_cart_number").submit();
		});
		$(".d_add").click(function(){
			var o = $(this).prev();
			var v = parseInt($(o).val());
			 var vv = v>=1?parseInt(v + 1):1;
			 $(o).val(vv>=99?99:vv);
			 $("#change_cart_number").submit();
		});
	});
var ajax_delete_cart = "{building_link model='goods@flow' action='deleteCart'}";				
	function php188_goods_delGoodFromcart(obj,id){
		$.getJSON(ajax_delete_cart,{id:id},function(data){
			switch(data.status){
				case 'ERROR':
					showNotice('��������!');return false;
				break;
				case 'NOT_EXIST':
					showNotice('�޸ö�������!');return window.location.reload();
				break;
				case 'EMPTY':
					return window.location.href=site_url;
				break;
				case 'OK':
					$(obj).parents('tr').remove();
					if($(".allindex_all").size()<=0)return window.location.reload();	
				break;
				default:
				alert(data);
			}
		});
	}
</script>
{/if}
<div id="cart_content_info_pannel">
 ��<span class="price" id='total_goods_count'>{$goods_cart.total_goods_count}</span>��
 ���úϼƣ�<span class="price" id='total_shop_price'>{$goods_cart.total_goods_price_fromat}{if $goods_cart.total_goods_point_fee}+{$goods_cart.total_goods_point_fee}��{/if}</span>
 �����ϼƣ�<span class="price" id='total_shop_price'>{$goods_cart.total_goods_weight}g</span>
 ���ͻ��֣�<span class="points" id='total_shop_can_get_points'>{$goods_cart.total_goods_point}��</span>
</div>
{/if}