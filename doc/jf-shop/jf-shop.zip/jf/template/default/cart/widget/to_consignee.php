<?php  exit('die');?>
<div id="goods_consignee_pannel">
  <script type="text/javascript" src="{$region_json_link}"></script>
  <script type="text/javascript">
$(function(){
	$(".table_cart_consignee td:even").addClass('table_cart_con_one');
	$("#submit_order_form").submit(function(){
		var flag = true;
		$(".need_remove_node select").each(function(){
			if(empty($(this).val())){
				$(this).addClass('empty_input_val');	
				flag = false;
			}else{
				$(this).removeClass('empty_input_val');	
			}
		});
		if(!flag)return showNotice('����д��������!');
		if(!check_form_is_empty('must_fill_in'))return showNotice('����д������!');		
		/*����ͻ�ʱ��*/
		var  del = $("#php188_receive_date").val();
		if(del=='specal'){
			var dom =  $("#specal_date");
			var d = dom.val();
			if(empty(d)){
				$(dom).addClass('empty_input_val');
				return showNotice('�������ͻ�����!');
			}else{
				$(dom).removeClass('empty_input_val');	
			}
		}
		//���绰����
		var phone = $.trim($("#php188_receive_phone").val());
		var mobile = $.trim($("#php188_receive_mobile").val());
		if(empty(phone) && empty(mobile))return showNotice('�绰���ֻ����������е�һ��!');
	});//end submit
/*�������ڵĴ���*/
 $("#php188_receive_date").change(function(){
		var v = $(this).val();
		if(v=='specal'){
			$('#specal_date').show();
		}else{
			$('#specal_date').hide();
			$("#specal_date").val('');
		}
  });
});
function getRegionChild(obj){
	var pid = $(obj).val();
	pid = !pid?0:pid;
	var temp = php_region_json_data[pid];
	if(temp){
		var str = '';
		var option = '<option value="">��ѡ��...</option>';
		str += option;
		$(temp).each(function(j){
			str+='<option value="'+temp[j].id+'">'+temp[j].name+'</option>';
		});
		$(obj).parents('span').nextAll().find('select').html(option);
		$(obj).parents('span').next().find('select').html(str);
	}
}
$(function(){
	$(".edit_order").click(function(){
		if($(this).text()!='[չ��]'){
		   $(this).text('[չ��]');
		   $('#'+$(this).attr('rev')).css("display",'none');
		}else{
		   $(this).text('[����]');
		   $('#'+$(this).attr('rev')).css("display",'block');
		}
	});
});
 </script>
  {insert_template_scripts_root files='shopdata/js/calendar/WdatePicker.js'}
  <div class="car_m_notice" id="cart_consignee_bar">
    <h3>��д�˶Զ�����Ϣ</h3>
    <a href="javascript:;" rev="cars" class="edit_order">[����]</a></div>
  <div class="to_consinee_cart" id="cars"> {include file="cart/widget/cart_goods_list.php"} </div>
  <div class="clear"></div>
  <!--#���õ�ַ-->
  {if $history_receive}
  {foreach from=$history_receive item=item}
  <div style="display:none;" id="call_user_reciver_data_{$item.receive_id}">{$item.receive_area_select}</div>
  {/foreach}
  {/if}
  <form method='post'  action='{$suburl}' id="submit_order_form" autocomplete="off">
    <div class="crderInfo">
    <div class="car_m_notice">
      <h3>�ջ�����Ϣ</h3><a href="javascript:;" rev="shdz" class="edit_order">[����]</a>
    </div>
    <div class="crderInfo_box">
      <table class="table_common table_cart_consignee" id="shdz">
        {if $history_receive}
        <tr>
          <td>���õ�ַ��</td>
          <td><div id="history_receive_data">
              <script type="text/javascript">
function append_receiver_info(obj){
	$("#php188_receive_realname").val($(obj).attr('receive_realname'));
	$("#php188_receive_address").val($(obj).attr('receive_address'));
	$("#php188_receive_postno").val($(obj).attr('receive_postno'));
	$("#php188_receive_phone").val($(obj).attr('receive_phone'));
	$("#php188_receive_mobile").val($(obj).attr('receive_mobile'));
	$("#php188_receive_email").val($(obj).attr('receive_email'));
	/*��������ʱ��*/
	try{
		var data_type = $(obj).attr('receive_date_type').split(' ');
		$("#php188_receive_date").val(data_type[0]);
		if(!isNaN(data_type[0].substr(0,4))){
			$("#php188_receive_date").val('specal');
			$('#specal_date').show();
			$('#specal_date').val(data_type[0]);
		}else{
			$('#specal_date').hide();
		}
		$("#php188_receive_time").val(data_type[1]);
	}catch(e){}	
	/*���͵���*/
	$("#call_user_deliery_area").html($("#call_user_reciver_data_"+$(obj).attr('receive_id')).html());
}
</script>
              {foreach from=$history_receive item=item}
              <p style="border:0px">
                <label>
                  <input type="radio" name="fix_user_region" receive_id="{$item.receive_id}" receive_realname='{$item.receive_realname}' receive_address='{$item.receive_address}' receive_postno='{$item.receive_postno}' receive_phone='{$item.receive_phone}' receive_mobile='{$item.receive_mobile}' receive_email='{$item.receive_email}' receive_date_type='{$item.receive_date_type}' onclick="append_receiver_info(this);"/>
                </label>
                <samp>{$item.receive_realname} {if $item.receive_mobile}{$item.receive_mobile}{/if}</samp> {$item.receive_area_text}{$item.receive_address} </p>
              {/foreach} </div></td>
        </tr>
        {/if}
        <tr>
          <td>�ջ���������</td>
          <td><input type="text" maxlength="30"  class="must_fill_in input" name='receive_realname' value="{$info.receive_realname}" id="php188_receive_realname"/>
            <font class="red"> * </font></td>
        </tr>
        <tr>
          <td >���͵�����</td>
          <td id="call_user_deliery_area"><div id='region_all_info' > {if $assign_region}{$assign_region}
              {else}
              {foreach from=$cart_con_region item=item} <span class="need_remove_node">
              <select class="get_all_node_all_adress" onchange="getRegionChild(this);" name="receive_area[]">
                <option  value=''>��ѡ��...</option>
                 {if $item.region_id}
                <option value="{$item.region_id}">{$item.region_name}</option>
	              {/if}
              </select>
              </span> {/foreach}
              {/if} </div></td>
        </tr>
        <tr>
          <td >���͵�ַ��</td>
          <td><input id="php188_receive_address" value="{$info.receive_address}" class="must_fill_in input" type="text" size="60" name='receive_address'>
            <font class="red">*</font></td>
        </tr>
        <tr>
          <td >�������룺</td>
          <td><input type="text" id="php188_receive_postno" value="{$info.receive_postno}" class="must_fill_in input" maxlength="10"  name='receive_postno'/>
            &nbsp;&nbsp;&nbsp;&nbsp;<span class="desc"><font class="red">*</font>�����ڿ���ȷ���ͻ���ַ</span></td>
        </tr>
        <tr>
          <td >�̶��绰��</td>
          <td><input type="text" value="{$info.receive_phone}" id="php188_receive_phone" class="input" maxlength="13" name='receive_phone'/>
            &nbsp;&nbsp;&nbsp;&nbsp;<span class="desc">�磺010-12345678���̻����ֻ�������дһ��</span></td>
        </tr>
        <tr>
          <td >�ֻ����룺</td>
          <td><input type="text" id="php188_receive_mobile" maxlength="13" name='receive_mobile' class="input" value="{$info.receive_mobile}"/>
            &nbsp;&nbsp;&nbsp;&nbsp;<span class="desc">��д�ֻ��ű��ڽ��շ���֪ͨ���ż��ͻ�ǰȷ��</span></td>
        </tr>
        <tr>
          <td >�����ʼ���</td>
          <td><input type="text" value="{$info.receive_email}" id="php188_receive_email" maxlength="30" class="must_fill_in input" name='receive_email'/>
            &nbsp;&nbsp;&nbsp;&nbsp;<span class="desc"><font class="red">*</font>�������ն��������ʼ�����������ʱ�˽ⶩ��״̬</span></td>
        </tr>
        <tr>
          <td >�ͻ����ڣ�</td>
          <td><select id="php188_receive_date" class="selectstyle" name="receive_date_type[date]"  style="width:130px;">
              <option value="��������" {if $info.receive_date_type.date eq '��������'} selected="selected"{/if}>��������</option>
              <option value="��������" {if $info.receive_date_type.date eq '��������'} selected="selected"{/if}>��������</option>
              <option value="����Ϣ��" {if $info.receive_date_type.date eq '����Ϣ��'} selected="selected"{/if}>����Ϣ��</option>
              <option value="specal" {if $info.receive_date_type.date eq 'specal'} selected="selected"{/if}>ָ������</option>
            </select>
<script type="text/javascript">
var mini_date = '{$mini_date}'; var max_date = '{$max_date}';
</script>
            <input id='specal_date' name='specal_date' value="{$info.specal_date}"  type="text" onfocus="WdatePicker({dateFmt:'yyyy-MM-dd',minDate:mini_date,readOnly:true,maxDate:max_date});" {if !$info.specal_date}style='display:none'{/if}/>
            &nbsp;&nbsp;&nbsp;&nbsp;<span class="desc"><font class="red">*</font>����ȷ��������Ա�ͻ�ʱ��</span></td>
        </tr>
        <tr>
          <td >�ͻ�ʱ�䣺</td>
          <td><select id="php188_receive_time" class="selectstyle" name="receive_date_type[time]" style="float:left;width:130px;">
              <option value='����ʱ���'>����ʱ���</option>
              <option value='����'>����</option>
              <option value='����'>����</option>
              <option value='����'>����</option>
            </select>&nbsp;&nbsp;&nbsp;&nbsp;<span class="desc"><font class="red">*</font>����ȷ��������Ա�ͻ�ʱ��</span></td>
        </tr>
        {if $is_open_fapiao}
        <tr>
          <td>��Ʊ��Ϣ��</td>
          <td>
      <script type="text/javascript">
	function set_fapiao_data(obj){
		var tag = $("#fapiao_taitou_info");
		var status = $(obj).attr('checked');
		var val = 0;
		if(status){
			$(tag).show(); val = 1;
		}else{
			$(tag).hide();val = 0;
		}
	}
</script>
      <div class="cart_pannel" id="cart_fapiao_info_all">
        <table style="background:#FFF;border:1px solid #CCC;">
          <tr>
            <td width="61">��Ʊ��</td>
            <td width="188"><input type="checkbox" value="1" onclick="set_fapiao_data(this);" {if $info.is_use_fapiao eq '1'} checked="checked"{/if} name="is_use_fapiao" /></td>
          </tr>
          <tr id="fapiao_taitou_info" style="{if $info.is_use_fapiao neq '1'}display:none;{/if}">
            <td>��Ʊ̧ͷ��</td>
            <td><textarea name="receive_invoice" class="w300" >{$info.receive_invoice}</textarea></td>
          </tr>
        </table>
      </div>
     </td>
        </tr>
        {/if}
        <tr>
          <td >������ע��</td>
          <td><textarea name='receive_note' cols="45" class="w300">{$info.receive_note}</textarea></td>
        </tr>
        <tr>
          <td >ȱ��������</td>
          <td><textarea name='out_of_stock' cols="45" class="w300">{$info.out_of_stock}</textarea></td>
        </tr>
        <tr>
          <td >�� �� ����</td>
          <td><script type="text/javascript">
var ajax_call_coupon="{building_link model='goods@flow' action='getcouponinfo'}";
function coupon_submit(obj){
	var curent_val = $(obj).val();
	var d = $("#coupon_num");
	var coupon_number=$(d).val();	
	if(coupon_number==""){
		$(d).addClass('empty_input_val');
		$("#coupon_num").focus();
		return false;
	}	
	$(d).removeClass('empty_input_val');
	var waiting = '�ύ��...';
	$(obj).val(waiting);
	$.post(ajax_call_coupon,{number:coupon_number},function(callback){
		$(obj).val(curent_val);
		var o =  $('#coupon_notice');
		callback = callback.split('|');
		var data = callback[0];
		switch(data){
			case 'OK':
			   o.html('����ɹ�,�ɵֿ�'+callback[1]+'Ԫ');
			   $("#coupon_fix_money").val(callback[1]);
			   $("#coupon_fix_number").val(coupon_number);
			    $(d).val('');
			break;
			case 'HAS_ADD':
				o.html('�Ѽ��벻���ظ�����,���Ż�ȯ�ɵֿ�'+callback[1]+'Ԫ');
			   $("#coupon_fix_money").val(callback[1]);
			   $("#coupon_fix_number").val(coupon_number);
			   $(d).val('');
			break;
			case 'NO_ORDER':	
			   o.html('�����¶���');
			break;
			case 'PLEASE_LOGIN':
				o.html('���ȵ�¼!');
			break;
			case 'NOT_EXIST':	
			 o.html('����ȯ������');
			break;
			case 'NOENOUGH':
				o.html('�����ܽ�������Żݽ��');
			break;
			case 'EMPTY':
				o.html('�������Ż�ȯ��!');
			break;
			case 'CAN_NOT_USED':
				o.html('���Ż�ȯ������');
			break;
			case 'USED':
				o.html('��ʹ��');
			default:
			 alert(data);
			break;
		}
	});
}
</script><input type="text" value="" id='coupon_num' name="coupon_num" class="input"/>
          <input  type="hidden" value="{$info.coupon.fix_money}"  id="coupon_fix_money" name="coupon[fix_money]" />
          <input  type="hidden" value="{$info.coupon.fix_number}"  id="coupon_fix_number" name="coupon[fix_number]"/>
          <input type="button" value="ʹ���Ż�ȯ" onclick="coupon_submit(this)" class="form_submit"/>
          <span id="coupon_notice" class="red">
          {if $info.coupon.fix_money}
          	�Ż�ȯ��{$info.coupon.fix_number} ��Ӧ��{$info.coupon.fix_money}
          {/if}</span></td>
        </tr>
        <tr>
          <td colspan="2" style="text-align:left"><input type="image" src="{$template_url}images/cart/save_info.gif"></td>
        </tr>        
      </table>
    </div>
    </div>
  </form>
</div>