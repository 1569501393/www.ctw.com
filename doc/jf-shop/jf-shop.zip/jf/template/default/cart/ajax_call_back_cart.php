<?php exit('die'); ?>
{if $action eq 'call_back_cart_pannel'}
<script type="text/javascript">
function close_pannel(){
	$(".call_back_cart_pannel").remove();
}
</script>
<div class="call_back_cart_pannel">
	<div class="l_pannel"></div>
    <div class="c_pannel">
    	<h4>�ѳɹ����ӵ����ﳵ��</h4>
        <p>�� <samp class="num">{$cart_data.total_goods_count}</samp> ����Ʒ���ϼƣ�<samp class="money">{$cart_data.total_goods_price_fromat}{if $cart_data.total_goods_point_fee}+{$cart_data.total_goods_point_fee}��{/if}</samp></p>
        <span class="tb-btn"><a href="{building_link model='goods@flow' action='toCart'}">ȥ����</a></span>
        <span class="re_cart"><a href="javascript:;" onclick="close_pannel(this);">�ٹ��</a></span>
    </div>
    <div class="close" onclick="close_pannel(this);">&nbsp;</div>
</div>
{/if}