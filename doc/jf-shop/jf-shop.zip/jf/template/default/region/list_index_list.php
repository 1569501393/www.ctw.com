<?php exit('die'); ?>
<!--#�������б�ҳ-->
{include file="region/widget/header.php"}
<div class="clear"></div>
<div id="site_region_index_list" class="middle"><!--����-->
 {if $is_open_region}
 <div class="middle_left fl" id="region_list_left">
 <!--#���г���-->
 {include file="region/widget/region_locate_pannel.php"} 
 <!--#��Ӧ�����µĲ���-->
 {include file="region/widget/region_origin_pannel.php"}	    
  </div>
    <div class="middle_right fr" id="region_list_right"><!--�Ҳ�-->
     <!--#ɸѡ����-->
     <div class="sy_Product">
        	<div class="sy_title">
            	<a href="javascript:;">���в�Ʒ</a>
            	<span></span>
                <em>����<strong>{$goods_list.total|default:0}</strong>��������������Ʒ</em>
            </div>
        	{include file="goods/widget/search_filter_pannel.php"}
        	<div class="sy_order">
                <div class="sy_1 fl" style="width:128px; line-height:20px; color:#666;">���� Ĭ������</div>
                <div class="sy_1 fl" style="width:210px; line-height:20px; color:#666;">
                <form action="{$post_do_url}"  method="post" id="do_form_search" style="display:inline;" autocomplete="off">
                	�۸�����&nbsp;<input name="moneystart" type="text" maxlength="6" class="sy_bt"  value="{if $pathinfo.moneystart>0}{$pathinfo.moneystart}{/if}"  onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" />&nbsp;-&nbsp;<input name="moneyend" type="text" class="sy_bt" value="{if $pathinfo.moneyend>0}{$pathinfo.moneyend}{/if}" maxlength="6"  onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));"/>&nbsp;&nbsp;<input  type="submit" value="����" style="font-size:12px;border:1px solid #F5F5F5; background:none;color:#333;" id="price_search_filter" /></form>
                </div>
                <div class="sy_1 fl" style="width:90px; line-height:20px; color:#666; border-right:none;"></div>		
            	<div class="clear"></div>
            </div>	
        </div>
     <div>
        {include file="goods/widget/goods_list_filter_common.php"}
     </div>
  {else}
 	 <div class="pro_bar clearfix" style="height:400px;"> {$region_data.alias_name}���ڽ�����! </div>
  {/if}
  </div>
<div class="clear"></div>
</div>
{include file="region/widget/footer.php"}