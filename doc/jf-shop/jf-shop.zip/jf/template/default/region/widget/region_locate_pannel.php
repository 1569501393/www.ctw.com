<?php  exit('die'); ?>
{get_locate assign='locate_data'}
<div class="Product">
        	<h3 class="title2">�ѿ�ͨ����</h3>	
        	<ul id="root">
            {if $locate_data}
            {foreach from=$locate_data item='list'}
                <li>
                    <label><a href="javascript:;" class="bhk">{$list.region_main_name}</a></label>
                    {if $list.son_temp}
                    <ul class="two" style="display:none">
                    {foreach from=$list.son_temp item='son' name='sons'}
                        <li><a href="{$son.link}" title="{$son.alias_name}">{$son.alias_name}</a></li>
                    {/foreach}
                    </ul>
                    {/if}
                </li>
              
                {/foreach}
                {else}
                 <li>��������!</li>
                {/if}
            </ul>
        </div>
<script type="text/javascript" src="{$template_url}js/Product.js" charset="utf-8"></script>