<?php exit('die'); ?>
{if $category_data}
 <div class="cat_bar_pannel"> <strong>{$category_data.cate_name}</strong>
 	{foreach from=$curent_category_tree item='cate'}
    <span><a href="{$cate.view_category}" title="{$cate.cate_name}">{$cate.cate_name}</a></span>
	    {if $cate.childrens}
        <ul>
        {foreach from=$cate.childrens item='son'}
          <li><a href="{$son.view_category}" title="{$son.cate_name}">{$son.cate_name}</a></li>
        {/foreach}
        </ul>
       {/if}
	{/foreach}
</div>
{/if}