<?php exit('die'); ?>
<div class="clear" style="height:10px;"></div>
{get_chandi assign='origin_data'}
<div class="Product">
  <h3 class="title2">����</h3>	
    <ul id="root">
     {if $origin_data}
       {foreach from=$origin_data item='origin'}
         {if $origin.region_id eq $region_id && $origin.childrens}
           {foreach from=$origin.childrens item='sons'}
           {if $sons.childrens}
           {foreach from=$sons.childrens item='tson'}
           <li><label><a href="{$tson.link}" class="bhk" {if $origin_id eq $tson.region_id}{/if}>{$tson.region_ename}</a></label></li>
           {/foreach}
           {/if}
           {/foreach}
         {else}
        {/if}
       {/foreach}
      {else}
	 <li>��������!</li>
    {/if}
   </ul>
 </div>