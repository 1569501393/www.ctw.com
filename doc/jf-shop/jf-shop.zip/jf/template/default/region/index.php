<?php exit('die'); ?>
{include file="region/widget/header.php"}
<div class="clear"></div>
<div class="middle"><!--����--> 	
  <div class="d_menubox">
    <ul>
      <li><a href="javascript:;">�ѿ�ͨ����</a></li>
    </ul>
  </div>
<div class="clear"></div>
  <div id="goods_category_tress_list">
    {get_locate assign='locate_data'}
    {foreach from=$locate_data item='list'}
            <h3><a href="javascript:;">{$list.region_main_name}</a></h3>
            {if $list.son_temp}
            <div class="cat_tag">
               <div class="cate_two_div">
                {foreach from=$list.son_temp item='son' name='sons'}<a class="mms" href="{$son.link}" title="{$son.alias_name}" target="_blank">{$son.alias_name}</a>{/foreach}
                </div>            
            </div>
            {/if}
            <div class="clear"></div>
        {/foreach}
    <div class="clear"></div>
  </div>
</div><!--���� end-->
{include file="region/widget/footer.php"}