<?php exit('die'); ?>
{include file="header.php"}
{insert_css files="style/article.css"}
{include file="widget/site_top.php"}
<div class="dh">{include file="nav.php"}</div>
<div class="clear"></div>