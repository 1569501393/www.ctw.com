<?php exit('die'); ?>
{get_article_by_type type='rand' limit = '10' assign = 'rand_article'}
<ul>
  {foreach from=$rand_article item='ls'}
  <li><A href="{$ls.url}">{$ls.article_long_title}</A></li>
  {/foreach}
</ul>
