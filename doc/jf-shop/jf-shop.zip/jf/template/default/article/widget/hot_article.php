<?php exit('die'); ?>
{get_article_by_type type='vist' sort='desc' limit = '10' assign = 'article'}
<ul>
  {foreach from=$article item='ls'}
  <li><A href="{$ls.url}">{$ls.article_long_title}</A></li>
  {/foreach}
</ul>
