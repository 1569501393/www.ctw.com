<?php exit('die'); ?>
<script type="text/javascript">
function search_article(){
		var d = $("#search_article_form");
		var data = $(d).formToArray();
		var url = $(d).attr("action")+connetor;
		var c = '';
		for(var i = 0; i < data.length; i++){url = url + c + data[i].name + "=" + data[i].value;c = '&';}
		return url;
}
</script>

<div id="article_search">
  <form method="get" autocomplete="off" onsubmit="window.location.href=search_article();return false;" action="{building_link model='article' action='search'}" id="search_article_form">
    <label for="��������"><input type="text" value=""  name="key" class="form_input"/></label>
    <label> <input type="submit" value="����" class="form_submit"/> </label>
  </form>
</div>
