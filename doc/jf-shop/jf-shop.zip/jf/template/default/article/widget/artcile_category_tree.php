<?php exit('die'); ?>
<div class="site_all_categorys">
  <div class="site_all_categorys_pannel"> 
{get_article_category assign='article_cat' building_tree='true'}
    {foreach from =$article_cat item=item name=name}
      <h3><a href="{$item.url}" target="_blank" title="{$item.category_name}">{$item.category_name}</a></h3>
      {if $item.childrens}
      <p> 
      {foreach from = $item.childrens item=children name=name}
      	<a href="{$children.url}" target="_blank" title="{$children.category_name}">{$children.category_name}</a> 
        {if $children.childrens}
        	<samp>{foreach from=$children.childrens item='sons'}
        	<a href="{$sons.url}" target="_blank" title="{$sons.category_name}">{$sons.category_name}</a> 
            {/foreach}</samp>
        {/if}
      {/foreach}
      </p>
      {/if}
    {/foreach} </div>
</div>
