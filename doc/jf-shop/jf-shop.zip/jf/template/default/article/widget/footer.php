<?php exit('die'); ?>
<div class="h10"></div>
{include file='widget/page_helper.php'}
{include file='footer.php'}