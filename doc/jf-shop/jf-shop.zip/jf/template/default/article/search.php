<?php exit('die'); ?>
{include file="article/widget/header.php"}
<div class="middle">
  <div class="article_left_pannel mt20">{if $search_data.total>0}
    <ul class="art_list">
      {foreach from=$search_data.data item='list'}
      <li>
        <div class="tt"><a href="{$list.url}" title="{$list.article_long_title}" target="_blank">{$list.article_long_title|truncate:20:'...'}</a></div>
        <span>{$list.article_date|date_format:"%Y-%m-%d"}</span>
        <div class="line"></div>
      </li>
      {/foreach}
    </ul>
    <div class="clear"></div>
    {$article_data.page}
    {else}
    <div class="notice_msg">�޿�������!</div>
    {/if}
    <!--neirong end-->
  </div>
<!--#article_left_pannel end-->
  <div class="art_right">
  <div class="art_right_pannel mt20"> <strong>վ������</strong> {include file="article/widget/article_search_pannel.php"} </div>
    
  </div>
  <!--art_right end-->
  <div class="clear"></div>
</div>
{include file="article/widget/footer.php"}