<?php exit('die'); ?>
{include file="article/widget/header.php"}
<div class="middle">
  <div class="article_index_left"> {include file="article/widget/artcile_category_tree.php"} </div>
  <div> {assign var='flash_group' value='article'}
    {include file="article/widget/flash.php"} </div>
  <div class="bar_line"></div>
  <div class="artile_index_art_pannel">
  	{get_article_category assign='arts_cates' building_tree='true'}
    {if $arts_cates}
    	{foreach from=$arts_cates item='cat'}
        	<div class="art_cats">
            	<h2><a href="{$cat.url}" class="ttitle" target="_blank">{$cat.category_name}</a><a href="{$cat.url}" class="more" target="_blank"><!--<img src="{$template_url}images/article/more_info.gif" />-->����...</a></h2>
                {get_article category_id=$cat.category_id assign='article_data' limit=8}
                <div class="art_pannel_sl">
                {if $article_data.data}
                    <ul class="art_list">
                      {foreach from=$article_data.data item='list'}
                      <li>
                        <div class="tt"><a href="{$list.url}" title="{$list.article_long_title}" target="_blank"><samp class="dot">��</samp>{$list.article_long_title|truncate:20:'...'}</a></div>
                        <span>{$list.article_date|date_format:"%Y-%m-%d"}</span>
                        <div class="line"></div>
                      </li>
                      {/foreach}
                    </ul>
                  {else}
                  <div class="gray">��������!</div>
				{/if}
                </div>
            </div>
        {/foreach}
    {/if}
  </div>
</div>
<div class="clear"></div>
{include file="article/widget/footer.php"}