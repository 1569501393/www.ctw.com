<?php exit('die'); ?>
{include file="article/widget/header.php"}
<div class="middle">
  <div class="article_left_pannel  flo">
    <h1 class="art_title"><a href="{$url}" title="{$art.article_long_title}">{$art.article_long_title}</a></h1>
    <div class="xiux">����ʱ�䣺{$art.article_date|date_format:"%Y-%m-%d %H:%M:%S"} �����<span id="php188_hits_numbers"></span> {if $art.article_source}��Դ��<a href="{$art.article_surl}" target="_blank" title="{$art.article_long_title}">{$art.article_source}</a>{/if}</div>
    <div class="neirong">
      <div id="article_contents"> {foreach from=$content.data item='ct'}
        {$ct}
        {/foreach} </div>
      <div class="clear"></div>
      <div class="art_content_page">{$content.page}</div>
      <div class="clear"></div>
      <div class="clear"></div>
      <!--#����-->
      <div class="comment_data"> {if $allow_comment}
        <div id="ajax_call_comment_data"><a href="{building_link model='article' action='comment' param='id=$article_id'}" target="_blank">����<samp id="ajax_call_comment_data_callback">(0)</samp>������,��˲鿴����...</a></div>
			<script type="text/javascript">
            $(function(){
                var url = "{building_link model='article' action='callArtCommentNum' param='id=$article_id'}?&jsoncallback=?";
                $.getJSON(url,function(data){
                    $("#ajax_call_comment_data_callback").html('('+data.total+')');
                });
            });
        </script>
        {/if} </div>
        <!--comment-->
        <div id="article_comment_form">
        {if !$allow_guest_post}
        	{include file="article/widget/user_small_login.php"}
        {/if}
        	<form method="post" action="{building_link model='article' action='comment' http='false'}" autocomplete="off" id="php188_comment_form">
             <div>
              <p><textarea name="content" style="width:634px;" id="article_comment_area" class="form_textarea check_conmment_form"></textarea></p>
              <p class="article_comment_desc">������������ <span class="text_limiter red">500</span> ���ַ�</p>
              <div class="spacer"></div>
              <div style="padding:8px;">
	          <label>��֤�룺<input type="text" class="form_input_small check_conmment_form" maxlength="10" name="numcode" onfocus="change_comment_code();"/> <img class="cap_img" style="cursor:pointer; margin-bottom:-7px;" onclick="change_comment_code();" id="comment_cap" src="{$siteurl}captcha.php?rand=1&h=25&w=100&hash=0" alt="���������֤��ͼƬ" title="���������֤��ͼƬ" /></label>
              <label><input type="submit" class="form_submit" name="Submit" value="��������"></label>
              </div>
	          <input type="hidden" value="{$is_num_code}" id="php188_comm_iscode" />
              <input type="hidden" value="{$article_id}"  name="artid"/>
            </div>
          </form>
        </div>
        <script type="text/javascript">
		function _reset(){$(".check_conmment_form").val('');}
		$(function(){
		$("#php188_comment_form").submit(function(){
		if(!check_form_is_empty('check_conmment_form'))return false;
		$(this).ajaxSubmit(function(data){
			switch($.trim(data)){
					case "notdata":
						window.parent.showNotice("�������ݲ���Ϊ��");
						break;
					case "length":
						window.parent.showNotice("��������̫��");
						break;
					case "codeerror":
						window.parent.showNotice("��֤�벻��ȷ!");
						break;
					case "notvisitor":
						window.parent.showNotice("���¼��������!");
						_reset();
						break;
					case "auditing":
						window.parent.showNotice("���۳ɹ�,��ȴ�����Ա���!");
						_reset();
						break;
					case "notauditing":
						window.location.reload();
						break;
					case "posttime":
						window.parent.showNotice("������Ϣ�£����ϴλ�û�г���1����");
						_reset();
						break;
					default:
						alert(data);
						break;
					}
					});
		return false;
		});
	$("#article_comment_area").grd_maxLength({length:500});
});
function change_comment_code(){
	var url = site_url + 'captcha.php?h=25&w=100&hash=0&rand='+Math.random()
	$("#comment_cap").attr('src', url);
}
</script>
        <!--end comment-->
    </div>
    <!--neirong end-->
  </div>
  <!--drxiu end-->
  <div class="art_right"> {include file="article/widget/article_right.php"} </div>
  <!--xgzx end-->
  <div class="clear"></div>
</div>
{include file="article/widget/footer.php"}