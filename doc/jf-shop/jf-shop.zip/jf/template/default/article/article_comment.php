<?php exit('die'); ?>
{include file="article/widget/header.php"}
<div class="middle">
<div class="old_article"><a href="{$article_detail}" target="_blank">�������£�{$article_long_title}</a></div>
<div id="article_comment_content">
        <div class="clear"></div>
        <div class="comment_content">
        	{if $comments.data}
					{foreach from=$comments.data item=comment}
						<div class="aritclecomments_Messag">
							<p class="aritclecomments_name">�û� <b class="uanme"> {$comment.user_name} </b> ��{$comment.comment_post_time|date_format:"%Y-%m-%d %H:%M:%S"}��</p>
							<div class="aritcle_com_content">{$comment.comment_content|nl2br}</div>
							{if $comment.comment_admin}
								<div class="aritcle_com_admin_content">
							<div class="aritclecomments_name">����Ա {$comment.comment_admin_post_time|date_format:"%Y-%m-%d %H:%M:%S"} �ظ�����������</div>
									<div class="content">{$comment.comment_admin_content|nl2br}</div>
								</div>
							{/if}
						</div>
					{/foreach}
                    <div class="spacer"></div>
				<div id="article_comment_page">{$comments.page}</div>
                <script type="text/javascript">
                	$(function(){
						page_function('article_comment_page','ajax_call_comment_data');
					});
                </script>
				{/if}
        </div>
        <div class="spacer"></div>
        <div id="article_comment_form">
        {if !$allow_guest_post}
        	{include file="article/widget/user_small_login.php"}
        {/if}
        	<form method="post" action="{building_link model='article' action='comment' http='false'}" autocomplete="off" id="php188_comment_form">
             <div><p><textarea name="content" id="article_comment_area" class="form_textarea check_conmment_form"></textarea></p>
             <p class="article_comment_desc">������������ <span class="text_limiter red">500</span> ���ַ�</p>
             <div class="spacer"></div>
             <div style="padding:8px;">
             {if $is_num_code}      
	          <label>��֤�룺<input type="text" class="form_input_small check_conmment_form" maxlength="10" name="numcode" onfocus="change_comment_code();"/> <img class="cap_img" style="cursor:pointer; margin-bottom:-7px;" onclick="change_comment_code();" id="comment_cap" src="{$siteurl}captcha.php?rand=1&h=25&w=100&hash=0" alt="���������֤��ͼƬ" title="���������֤��ͼƬ" /></label>
              {/if}
	          <label><input type="submit" class="form_submit" name="Submit" value="��������"></label>
             </div>
	          <input type="hidden" value="{$is_num_code}" id="php188_comm_iscode" />
              <input type="hidden" value="{$article_id}"  name="artid"/>
             </div>
           </form>
        </div>
        <div class="clear"></div>
        <div class="spacer"></div>
</div>
<script type="text/javascript">
function _reset(){$(".check_conmment_form").val('');}
$(function(){
	$("#php188_comment_form").submit(function(){
		if(!check_form_is_empty('check_conmment_form'))return false;
		$(this).ajaxSubmit(function(data){
			switch($.trim(data)){
					case "notdata":
						window.parent.showNotice("�������ݲ���Ϊ��");
						break;
					case "length":
						window.parent.showNotice("��������̫��");
						break;
					case "codeerror":
						window.parent.showNotice("��֤�벻��ȷ!");
						break;
					case "notvisitor":
						window.parent.showNotice("���¼��������!");
						_reset();
						break;
					case "auditing":
						window.parent.showNotice("���۳ɹ�,��ȴ�����Ա���!");
						_reset();
						break;
					case "notauditing":
						window.location.reload();
						break;
					case "posttime":
						window.parent.showNotice("������Ϣ�£����ϴλ�û�г���1����");
						_reset();
						break;
					default:
						alert(data);
						break;
				}
			});
		return false;
	});
	$("#article_comment_area").grd_maxLength({length:500});
});
function change_comment_code(){
	var url = site_url + 'captcha.php?h=25&w=100&hash=0&rand='+Math.random()
	$("#comment_cap").attr('src', url);
}
</script>
<div class="clear"></div>
</div>
{include file="article/widget/footer.php"}