<?php if(!defined('PHP188_TEMPLATE'))exit();?>
<script type="text/javascript">
function change_code(){ $("#cap_img").click(); }
$(function(){
	$("#php188feedback").submit(function(){
		if(!check_form_is_empty('must_in'))	return false;
		$(this).ajaxSubmit(function(data){
			data = $.trim(data);
			switch(data){
				case "1":
					return showNotice("�ϴ��ļ�����");
					break;
				case "2":
					return showNotice("��֤�벻��ȷ");
					break;
				case "3":
					return showNotice("��ѡ����������");
					break;
				case "4":
					return showNotice("���ⲻ��Ϊ��");
					break;
				case "5":
					return showNotice("���ݲ���Ϊ��");
					break;
				case "6":
					return showNotice("����ʧ�ܣ������ԣ�");
					break;
				case "7":
					window.location.reload();
					break;
				case "99":
					return showNotice("�ظ������ݲ�����");
					break;
				default:
					return showNotice(data);
			}
		});
		return false;
	})
	$("#php188_sub_btn").click(function(){
		value = $.trim($("#feedbackrar").val());
		if(!empty(value)){
			var filename = value.split(".");
			var type = filename[filename.length - 1];
			if(type != "rar" && type != "zip"){
				showNotice("�ϴ���ʽ����ȷ");
				return false;
			}
		}
		$("#php188feedback").submit();
	});
});
</script>

<div class="member_panel">
  <div class="spacer"></div>
  {if $action eq ''}
  {if $feedbacks}
  <table class="table_list">
    <tr>
      <th>����</th>
      <th>����</th>
      <th>״̬</th>
      <th>ʱ��</th>
      <th>����</th>
    </tr>
    {foreach from=$feedbacks item=fb}
    <tr>
      <td class="center">{if $fb.feedback_type eq '1'}����{elseif $fb.feedback_type eq '2'}Ͷ��{elseif $fb.feedback_type eq '3'}ѯ��{elseif $fb.feedback_type eq '4'}�ۺ�{else}��{/if}</td>
      <td nowrap="nowrap"><a href="{$fb.lookfeedback}">{$fb.feedback_title}</a></td>
      <td nowrap="nowrap" align="center"><font class="red">{if $fb.feedback_state eq '2'}����Ա�ѻظ� {elseif $fb.feedback_state eq '3'}�ȴ�����Ա����{else}�ȴ�����{/if}</font></td>
      <td nowrap="nowrap"  align="center">{$fb.feedback_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
      <td nowrap="nowrap"  align="center"> {if $fb.feedback_state eq '1'}<a href="{$fb.deletefeedback}" >ɾ��������</a>{else}<a href="{$fb.lookfeedback}">����</a>{/if} </td>
    </tr>
    {/foreach}
  </table>
  {if $pageurl}
  <div class="page_list">{$pageurl}</div>
  {/if}
  {else}
  <div class="notice_msg">û������</div>
  {/if}
  {/if}
  <div class="clear"></div>
  {if $action == 'feedbacklock'}
  {if $feedbacks}
  <table class="table_list ptop w100">
    {foreach from=$feedbacks item=fb}
    {if $feedbackid == $fb.feedback_id}
    <tr>
      <td class="left"><b>���⣺</b>{$fb.feedback_title} <b>ʱ�䣺</b>{$fb.feedback_time|date_format:"%Y-%m-%d %H:%M:%S"} </td>
    </tr>
    {/if}
    <tr>
      <td class="left"> {if !$fb.admin_name}
        <p class="Message_title"><b>��������</b> {if $fb.feedback_rar}<font class="red">���ϴ�����!</font>{/if}</p>
        <div class="Message_content">
          <p>{$fb.feedback_content}</p>
        </div>
        {else}
        <p class="Message_title">����Ա�ظ�</p>
        <div class="Reply"> {$fb.feedback_content} </div>
        {/if} </td>
    </tr>
    {/foreach}
  </table>
  {/if}
  {/if} </div>
<div class="clear"></div>
<div  class="member_panel">
  <form id="php188feedback" action="{$subaction}" method="post" autocomplete="off"  enctype="multipart/form-data">
    {if $action eq  'feedbacklock'}
    <input type="hidden" value="block"  name="actions"/>
    {/if}
    <table class="table_list">
      {if $action != 'feedbacklock'}
      <tr>
        <td  nowrap="nowrap" class="f right">�������ͣ�</td>
        <td><input name="feedbacktype" class="form_radio" type="radio" value="1" checked="checked" />
          ����
          <input name="feedbacktype" class="form_radio" type="radio" value="2" />
          Ͷ��
          <input name="feedbacktype" class="form_radio" type="radio" value="3" />
          ѯ��
          <input name="feedbacktype" class="form_radio" type="radio" value="4" />
          �ۺ�
          <input name="feedbacktype" class="form_radio" type="radio" value="5" />
          �� </td>
      </tr>
      <tr>
        <td class="f right">����</td>
        <td nowrap="nowrap"><input  type="text" name="feedbacktitle" value="" class="form_input must_in" id="feedbacktitle" maxlength="20"/></td>
      </tr>
      {/if}
      <tr>
        <td class="f right">����</td>
        <td><textarea class="form_textarea  must_in member_book_text" id="feedbackcontent" name="feedbackcontent"></textarea></td>
      </tr>
      <tr>
        <td class="f right">����</td>
        <td><input type="file" id="feedbackrar"  name="feedbackrar" value=''/>
          <span class="red"> ֻ֧��.rar��.zipѹ���ļ�������ϴ�1M</span></td>
      </tr>
      <tr>
        <td class="f right">��֤��</td>
        <td><input type="text" onfocus="change_code();" class="form_input img_cp must_in" name="checknumber" id="checknumber" maxlength="10" size="6" />
          <img id="cap_img" class="cap_img" title="���������֤��ͼƬ" alt="���������֤��ͼƬ" style="cursor:pointer; margin-left:10px; margin-bottom:-5px;" src="{$siteurl}captcha.php" onclick="this.src='{$siteurl}captcha.php?rand='+Math.random()"/> <span class="img_cp red" ></span></td>
      </tr>
      <tr>
        <td></td>
        <td><input class="form_submit" type="button" id="php188_sub_btn" value="�ύ" />
          &nbsp;&nbsp;&nbsp;&nbsp;
          {if $action == 'feedbacklock'}
          <input type="button" class="form_submit"  onclick="window.location.href='{building_link model='member@feedback' action='feedbacklist'}'" value="����" />
          {/if} </td>
      </tr>
    </table>
    <input id="feedbackid"  type="hidden" value="{$feedbackid}" name="feedbackid" />
    <input id="curpage"  type="hidden" name="curpage" value="{$curpage}"/>
  </form>
  <input type="hidden" id="feedbacklist" value="{$feedbacklist}" />
</div>
