<?php if(!defined('PHP188_TEMPLATE'))exit();?>
{insert_template_scripts_root files='shopdata/static/calendar/WdatePicker.js'}
<script type="text/javascript" src="{building_link model='default' action='loadRegionJson'}"></script>
	<script type="text/javascript">
		$(function(){
			$("#email").blur(function(){checkEmail();});
			$("#mobile").change(function(){checkMobile();});
			<!-- �������ύ�¼� -->
			$("#php188_submit_btn").click(function(){
				<!-- ��ʼ ��� ���� �Ƿ���д -->
				var flg = true;
				var typename;
				var val = "";
				var obj = "";
				$("#php188register").find(".require").each(function(i){
					obj = $(this).prev();
					<!-- ������� -->
					typename = $(obj).attr("type");
					if(typename == "text/javascript"){
						obj = $(obj).prev();
						<!-- ������� -->
						typename = $(obj).attr("type");
					}
					if(typename == "checkbox" || typename == "radio"){
						var name  = $(obj).attr("name");
						val = $("[name='"+name+"'][checked]").val();
					}else{val = $(obj).val();}
					<!-- �ж�ֵ -->
					if(empty(val)){
						$(this).html("�������");<!-- ������� -->
						flg = false;
					}else{$(this).html("*");}
				});
				<!-- ����б����û����д �� ���� -->
		var tag = false;
				$(".need_remove_node select").each(function(){
					var v = $(this).val();
					if(empty(v)){
						tag = true;
						$(this).addClass('empty_input_val');
					}else{
						tag = false;
						$(this).removeClass('empty_input_val');
					}
				});
				if(!check_form_is_empty('must_fill_in') || tag){
					window.parent.showNotice('����д������!');
					return false;	
				}
				if(!flg){
					showNotice("�б�����û����д");<!-- �б�����û����д -->
					return false;
				}
				<!-- �����ύ ·��-->
				$("#php188register").ajaxSubmit(function(data){
					switch(data){
						case 'ERROR':
							return showNotice('��������ȷ!');
						break;
						case 'ERROR_EMAIL':
							return showNotice("�����ʽ����ȷ!");
						break;
						case 'HAS_EXIST_EMAIL':
							return showNotice("�Ѵ��ڴ�����!");
						break;
						case 'ERROR_MOBILE':
							return showNotice("�ֻ����벻��ȷ!");
						break;
						case 'HAS_EXIST_MOBILE':
							return showNotice("�Ѵ��ڴ��ֻ�����!");
						break;
						case 'UNKNOW_ERROR':
							return showNotice('δ֪����!');
						break;
						case 'OK':
							 showNotice("�޸ĳɹ�");
							 window.location.reload();
						break;
						default:alert(data);
					}
				});
				return false;
			});
		});
		<!-- ��� ���� -->
		function checkEmail(){
			var c_email = $.trim($("#email").val());
			if(empty(c_email)){
				$("#email").next().html("����Ϊ��");
				return false;
			} 
			if(!checkemail(c_email)){ 
				$("#email").next().html("email����ȷ");
				return false;
			}
			<!-- �ж� �Ƿ� ������ ���� -->
			var oldemail = $("#oldemail").val();
			if(c_email == oldemail){
				return true;
			}
			<!-- ��� ���� �Ƿ���� -->
			var u = $("#checkemail").val();
			u = u.replace(/replaceemail/, c_email);
			$.post(u,{email:c_email},function(call){
					switch($.trim(call)){
						case "HAS_EXIST":
							$("#email").next().html("�������Ѵ���");
							return false;
							break;
						case "EMPTY_EMAIL":
							$("#email").next().html("����Ϊ��");
							return false;
							break;
						case 'NOT_ALLOW':
							return $("#email").next().html("������������ע��!");
						case 'ERROR_EMAIL':
							return $("#email").next().html("�������!");
						break;
						case 'OK':
						default:
							$("#email").next().html("");
							return true;
							break;
					}
					return true;
			})
		}
		function checkMobile(){
			var mobile = $.trim($("#mobile").val());
			if(mobile == ""){return true;}
			if(!is_mobile(mobile)){
				$("#mobile").next().html("�ֻ����벻��ȷ");
				return false;
			}
			<!-- �ж��Ƿ� �޸� �ֻ����� -->
			var oldmobile = $("#oldmobile").val();
			if(oldmobile == mobile){return true;}
			<!-- �ж�  �Ƿ� ����-->
			var u = $("#checkmobile").val();
			u = u.replace(/replacemobile/, mobile);
			var call = $.ajax({url:u,async:false,cache:false});
			call = call.responseText;
			switch($.trim(call)){
				case "HAS_EXIST":
					$("#mobile").next().html("�Ѵ��ڴ��ֻ�����");
					return false;
				case "ERROR":
					$("#mobile").next().html("�����ֻ�����");
					return false;
				default:
					$("#mobile").next().html("");
					return true;
			}
			$("#mobile").next().html("");
			return  true;
		}
	function check_user_up_pic(obj){
		var ary = new Array('jpg','gif','png');
		var ext = $(obj).val().split('.').pop();
		if($.inArray(ext,ary)=='-1'){
			alert('��ѡ��ϵͳ������ʽ��ͼƬ!');	
			cleanFile('');
			return false;
		}
	}
function getRegionChild(obj){
	var pid = $(obj).val();
	pid = !pid?0:pid;
	var temp = php_region_json_data[pid];
	if(temp){
		var str = '';
		var option = '<option value="">��ѡ��...</option>';
		str += option;
		$(temp).each(function(j){
			str+='<option value="'+temp[j].id+'">'+temp[j].name+'</option>';
		});
		$(obj).parents('span').nextAll().find('select').html(option);
		$(obj).parents('span').next().find('select').html(str);
	}
}
    </script>
<div class="spacer"></div>
<form id="php188register" autocomplete="off" action="{building_link model='member@membermanage' action='memberinfo'}" method="post" >
    <table  class="table_list member_pannel_info">
        <tr>
            <td class="left" colspan="4">��������</td>
        </tr>
        <tr>
            <td class="one">��Ա�ʺ�</td>
            <td>{$curruser.mem_username}      	  </td>
            <td class="one">�û�ͷ��</td>
            <td rowspan="4"><div style="border:1px dotted #CCC; background:#FFF;margin:3px;padding:10px;"><div style="width:142px;padding:5px;margin:0px auto;border:1px solid #F3F3F3;background:#FFF;text-align:center;"><img src="{$siteurl}picture.php?s={$curruser.thumb}&w=140&h=120" /></div>
          <input type="hidden" value="{$curruser.thumb}"  name="u_thumb"/>
          <div style="border:1px dotted #CCC;padding:2px; clear:both;margin-top:10px;"><input  type="file" value="" id="user_thumb_pic" onchange="check_user_up_pic(this);" name="thumb"/>(֧�� *.jpg,*.gif,*.png ��С��500K��)</div></div>
        </td>
        </tr>
        <tr>
            <td  class="one">��������</td>
            <td>
                <input id="email" value="{$curruser.mem_email}" style="ime-mode: disabled;"  type="text" maxlength="30" class="form_input" name="email" />
                <span class="red"></span>
            </td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td  class="one">�û��ȼ�</td>
            <td>
	          {$curruser.mem_level_name} 
            </td>
            <td>&nbsp;</td>
        </tr>
            <tr>
                <td  class="one">�� �� ��</td>
                <td>{$member_group.group_name}
                     {if $member_group.discount neq '1'}<span class="red">�����ܹ���������Ʒ��{$member_group.discount * 10}�۵��Ż�</span>{/if}</td>
                <td>&nbsp;</td>
            </tr>
        <tr>
            <td  class="left" colspan="4">�û�ѡ����</td>
        </tr>
        <tr>
            <td  class="one">�ֻ�</td>
            <td colspan="3">
                <input id="mobile" type="text" value="{$curruser.mem_mobile}" name="mobile" style="ime-mode: disabled;" class="form_input" maxlength="11" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')" />
                <span class="red"></span> ����д��������ڵ�½
            </td>
        </tr>
        {foreach from=$regitem item=attr}
            <tr>
                <td  style="text-align:right" class="one">
                    {$attr.attr_name}
                </td>
                <td colspan="3">
                <!-- ��ͨ���ı��� -->
                {if $attr.attr_type == 'text'}
                    <input  value="{$attr.value_name}" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text" class="form_input"  maxlength="50" />
                <!-- ֻ���������� -->
                {elseif $attr.attr_type == 'textnumber'}
                    <input value="{$attr.value_name}" class="form_input" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"  maxlength="50" style="ime-mode: disabled;"  onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')"/>
                <!-- ֻ�� �������ֺ��ַ� -->
                {elseif $attr.attr_type == 'textcharnumber' }
                    <input value="{$attr.value_name}"  class="form_input" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"  maxlength="50" style="ime-mode: disabled;" />
                <!-- ֻ�� ���� �ַ� -->
                {elseif $attr.attr_type == 'textchar'}
                    <input value="{$attr.value_name}" class="form_input" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"  maxlength="50" style="ime-mode: disabled;" onkeyup="this.value=this.value.replace(/[^a-zA-Z]/g,'')"/>
                <!-- ���ı� -->
                {elseif $attr.attr_type == 'textarea'}
                    <textarea class="form_textarea" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"  row="20" cols="40" >{$attr.value_name}</textarea>
                <!-- �Ա� -->
                {elseif $attr.attr_type == 'sex'}
                    <input type="radio" class="form_radio" value="1"{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if}   checked="true"  />&nbsp;��&nbsp;&nbsp;&nbsp;&nbsp;<!-- �� -->
                    <input type="radio" {if $curruser.mem_sex == '2'} checked="checked"{/if} class="form_radio" value="2"{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if}  />&nbsp;Ů<!-- Ů -->
                <!-- ���� -->
                {elseif $attr.attr_type == 'date'}
                    <input type="text" value='{$attr.value_name|date_format:"%Y-%m-%d"}'{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if}  class="Wdate"
                    {literal}
                         onClick="WdatePicker({dateFmt:'yyyy-MM-dd',minDate:'1950-01-01'})"
                    {/literal} /><!-- ����ѡ���� -->
                <!-- ��ͨ ������ -->
                {elseif $attr.attr_type == 'select'}
                    <select class="form_select" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} style="width:130px">
                        <option >--��ѡ��--</option><!-- --��ѡ��-- -->
                        {foreach from=$attr.attr_option  item=item}
                            <option value="{$item}" {if $item == $attr.value_name} selected="selected"{/if}>{$item}</option>
                        {/foreach}
                    </select>
                <!-- ����  -->
                {elseif $attr.attr_type == 'area'}
                <!--#ϵͳ�Զ����-->
                	{if !$attr.is_string}
                        {foreach from=$attr.attr_option item=item}
                            <span class='need_remove_node'>
                            <select class="get_all_node_all_adress" {if $attr.attr_typename != 'system'} name="registerreg{$attr.attr_id}[]"{else}  name="{$attr.attr_valname}[]" {/if} onchange="getRegionChild(this)">
                                    <option  value=''>��ѡ��...</option>
                                    {if $item.region_id}<option value="{$item.region_id}">{$item.region_name}</option>{/if}
                            </select>
                            </span>
                        {/foreach}
                        {else}
                        {$attr.attr_option}
                        
                    {/if}
                <!-- ��ѡ -->
                {elseif $attr.attr_type == 'radio'}
                    {foreach from=$attr.attr_option item=item}
                        <input type="radio" class="form_radio" {if $item == $attr.value_name} checked="checked" {/if} {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} value="{$item}" />{$item}
                    {/foreach}
                <!-- ��ѡ -->
                {elseif $attr.attr_type == 'checkbox'}
                    <input type="hidden" value="{$attr.value_name}"  id="checkboxval" />
                    <input type="hidden"  id="checkboxvalname" value="{if $attr.attr_typename != 'system'}registerreg{$attr.attr_id}{else} {$attr.attr_valname} {/if}" />
                    {foreach from=$attr.attr_option item=item}
                         <input type="checkbox"{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}[]"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}[]" {/if} class="form_checkbox" value="{$item}"/>{$item}
                    {/foreach}
                    {literal}
                         <script type="text/javascript" language="javascript">
                            var val = $("#checkboxval").val();
                            var oop = val.split("-");
                            var count = oop.length;
                            var name = $.trim($("#checkboxvalname").val()) + "[]";
                            for(var i = 0; i < count; i++){
                                $("input[name='" + name + "'][value='"+ oop[i] + "']").attr("checked", true);
                            }
                            $("#checkboxval").remove();
                            $("#checkboxvalname").remove();
                         </script>
                     {/literal}
                {/if}
                <!-- ��� ���� ��ʾ  -->
                {if $attr.attr_required == '1'}
                    <span class="red require">*</span>
                {/if}
            </td>
           </tr>
        {/foreach}
        <tr>
        	<td class="one"></td>
        	<td colspan="3"><input type="button" class="form_submit" value="�� ��" id="php188_submit_btn" /></td>
        </tr>
    </table>
<input type="hidden" name="oldemail" id="oldemail" value="{$curruser.mem_email}" />
	<input type="hidden" name="oldmobile" id="oldmobile" value="{$curruser.mem_mobile}" />
</form>
<input type="hidden" id="subaction" value="{$subaction}" />
<input type="hidden" name="checkmobile" id="checkmobile" value="{$checkmobile}"/>
<input type="hidden" name="getarea" id="getarea" value="{$getarea}" />
<input type="hidden" name="checkemail" id="checkemail" value="{$checkemail}"/>
<div class="spacer"></div>