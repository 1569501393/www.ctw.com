<?php if(!defined('IN_SYS'))exit('php188'); ?>
<div id="messagebox">
<div class="spacer"></div>
{if $action neq 'view'} 
{if $data.total>0}
  {literal}
  <script type="text/javascript">
  	$(document).ready(function(){
		 checkAllFormData('delete_msg_box','msg');
		$("#delete_msg_form").submit(function(){
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
					 showNotice('�����ɹ�!');
					 window.location.reload();
					break;
					default:alert(data);
				}
			});return false;
		})
	})
	function delete_form(){
		var v = get_checkbox_val('msg');
		if(empty(v)){return showNotice('��ѡ��Ҫɾ�����ż�!');}
		if(confirm('��ȷ��Ҫɾ����?�˲������ɻָ�!'))$("#delete_msg_form").submit();
	}
  </script>
  {/literal}
  <form method="post" action="{building_link model='member@feedback' action='messagebox' http='false'}" id="delete_msg_form">
    <table  class="table_list">
		<thead>
        <tr>
        <th class="f"  style="width:20px;"><input type="checkbox" value=""  id="delete_msg_box"/></th>
       <th  class="f" nowrap="nowrap">����</th>
        <th class="f" nowrap="nowrap"  style="100px;">����ʱ��</th>
        <th class="f" nowrap="nowrap">״̬</th>
         <th class="f" nowrap="nowrap">�鿴</th>
        </tr>
        </thead>
        <tbody>
        {foreach from=$data.data item='item'}
        	<tr>
            <td class="center"><input type="checkbox" value="{$item.id}" class="msg"  name="message[]"/></td>
            	<td><a href="{$item.link}" title="{$item.title}">{$item.title}</a></td>
                <td class="center" nowrap="nowrap">{$item.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
                <td class="center">{if $item.is_read eq '1'}�Ѷ�{else}<font class="red">δ��</font>{/if}</td>
                <td class="center"><a href="{$item.link}" title="{$item.title}">�鿴</a></td>
            </tr>
            {/foreach}
        </tbody>
    </table>
    </form>
    <input type="button" value="ɾ����ѡ" class="form_submit" onclick="delete_form(this);"/>
    <div class="spacer"></div>
    {$data.page}
    {else}
<div class="notice_msg">�޿�������!</div>
    {/if}
   {/if}
 {if $action eq 'view'}
 	<div  class="message_box_detail">
	<table class="table_common">
    	<tr>
        	<td><b>���⣺</b></td>
            <td>{$data.title}</td>
        </tr>
            	<tr>
        	<td><b>����ʱ�䣺</b></td>
            <td>{$data.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        </tr>
            	<tr>
        	<td colspan="2">
            <div class="message_box_content">{$data.content}</div>
            </td>
        </tr>
    </table>
    <div class="right"><input type="button" value="�� ��"  class="form_submit" onclick="window.location.href='{building_link model='member@feedback' action = 'messagebox'}'" /></div>
    </div>
 {/if}
</div>