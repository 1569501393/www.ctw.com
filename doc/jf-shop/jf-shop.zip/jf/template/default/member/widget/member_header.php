<?php exit('die'); ?>
{include file='header.php'}
{insert_css files='style/member.css'}
{include file="widget/site_top.php"}