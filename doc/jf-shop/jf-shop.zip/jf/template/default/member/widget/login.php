<?php exit('die'); ?>
<div id="m_main_pannel_left" class="m_pannel">
      <h1 class="yahei">�û���¼</h1>
      <div class="call_pannel">
        <form action="{building_link model='member' action='login'}" id="common_login_pannel"  autocomplete="off" method="post">
          <table cellpadding="0" cellspacing="0" class="login_table table_form">
            <tr>
              <td>ģ&nbsp;&nbsp;&nbsp;ʽ��</td>
              <td><label><input type="radio" value="common"   checked="checked" name="login_type"/>�û���</label>
                <label><input type="radio" value="mobile" class=""  name="login_type"/>�ֻ���</label>
                <label><input type="radio" value="email" name="login_type" />����</label>
                </td>
            </tr>
            <tr>
              <td>�û�����</td>
              <td><input  name="loginusername" type="text" value="" class="dmember must_fill_input need_append" /> <a href="{building_link model='member' action='reactive'}" class="reactive login_links" target="_blank">���¼���</a></td>
            </tr>
            <tr>
              <td>��&nbsp;&nbsp;&nbsp;�룺</td>
              <td><input name="password"  type="password"  value=""  class="dmember must_fill_input need_append" /> <a href="{building_link model='member' action='findpass'}" class="forget_pass login_links" target="_blank">��������</a></td>
            </tr>
            <tr>
              <td>��֤�룺</td>
              <td><input onfocus="change_code(document.getElementById('cap_img1'));" class="yhming must_fill_input"  style="width:78px;" name="codenumber" maxlength="6" type="text" />
                <img class="cap_img" id="cap_img1"  style="cursor:pointer; margin-bottom:-7px;" src="{$siteurl}captcha.php?hash=0&w=100&h=25&rand=1" alt="���������֤��ͼƬ" title="���������֤��ͼƬ" onclick="change_code(this);"/> 
                
                </td>
            </tr>
            <tr>
              <td></td>
              <td><input type="image" src="{$template_url}images/login/login.gif"  /> {if $unlogin_buy}<img  style="cursor:pointer;" src="{$template_url}images/login/button_buy.jpg" value="ֱ�ӹ���"  class="" onclick="window.location.href='{$unlogin_buy_url}'" />{/if}</td>
            </tr>
          </table>
        </form>
      </div>
      <!--#��������½-->
	<div id="other_login_pannel">
    	<div class="btn_bar_top"></div>
        <div class="btn_bar_center">
        	<p class="eline yahei"><samp class="yahei">�������֧�����û�������</samp>&nbsp;<a href="{building_link model='member' action='apiLogin' param='app=etao'}"><img src="{$template_url}images/api/etao.png" /></a></p>
            <!--<p class="other_app_login yahei">����������վ��½�� <a href="">������</a> <a href="">QQ</a> <a href="">����</a></p>-->
        </div>
    	<div class="btn_bar_bot"></div>
    </div> 
    <!--#��������½����-->
    </div>