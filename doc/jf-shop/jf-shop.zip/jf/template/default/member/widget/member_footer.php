<?php exit('die'); ?>
{include file="footer.php"}