<?php exit('die'); ?>
<div class="member_left" id="member_menu_pannel">
<a href="{building_link model='member@membermanage'}"><strong>��Ա<samp>����</samp></strong></a>
  <div class="member_left_list">
    <b>�˻�����</b>
    <ul>
      <li><a href="{building_link model='member@membermanage' action='memberinfo'}">�ҵ�����</a></li>
      <li><a href="{building_link model='member@membermanage' action='updatepassword'}">�޸�����</a></li>
      <li><a href="{building_link model = 'member@popularize' action = 'popularize'}">�ҵ��ƹ�</a></li>
      <li><a href="{building_link model = 'member@coupon' action = 'membercoupon'}">�ҵĹ���ȯ</a></li>
	  <li><a href="{building_link model='member@collect' action = 'goodsvistlog'}">��Ʒ�����¼</a></li>
    </ul>
   <b>��������</b>
    <ul>
      <li><a href="{building_link model='member@money' action = 'orderlist'}">�ҵĶ���</a></li>
      <li><a href="{building_link model = 'member@receive' action = 'receivelist'}">�ջ���ַ</a></li>
      <li><a href="{building_link model='member@collect' action = 'collectlist'}">�ҵ��ղ�</a></li>
    </ul>
    <b>�ͻ�����</b>
    <ul>
      <li><a href="{building_link model='member@feedback' action='messagebox'}">վ����</a></li>
      <li><a href="{building_link model='member@feedback' action='feedbacklist'}">�ҵ���ѯ</a></li>
    </ul>
    <b>��������</b>
    <ul>
      <li><a href="{building_link model='member@money' action='pay_pass'}">֧������</a></li>
      <li><a href="{building_link model='member@money'}">���߳�ֵ</a></li>
      <li><a href="{building_link model='member@money' action = 'moneyrecord'}">�˻����</a></li>
      <li><a href="{building_link model='member@pointlog' action = 'pointlist'}">�ҵĻ���</a></li>
    </ul>
    <!--��չ����-->
    {foreach from=$site_member_menu item='list'}
    <b>{$list.name}</b>
    {if $list.son}
    <ul>
    {foreach from=$list.son item='son'}
      <li><a href="{$son.link}">{$son.name}</a></li>
      {/foreach}
    </ul>
    {/if}
    {/foreach}
    <b>��������</b>
    <ul>
      <li><a  href="{building_link model='help'}" target="_blank">��������</a></li>
    </ul>
  </div>
  <h5></h5>
</div>
<script type="text/javascript">
	function _reset(obj){
		$('.curent_hover').removeClass('curent_hover');$(obj).parents('li').addClass('curent_hover');	
	}
	$(function(){
		var _set = $.cookies('__member_click_pannel__');
		_set = _set==null || empty(_set)?0:_set;
		$("#member_menu_pannel li a").each(function(i){
			$(this).click(function(){
				$.cookies('__member_click_pannel__',i,cookies_path);
				_reset($(this));
			});
			if(_set==i){
				_reset($(this));
			}
		});
	});
</script>
