<?php if (! defined ( 'PHP188_TEMPLATE' ))exit (); ?>
<div class="member_panel">
{if $action eq 'receive_list'}
{if $data.data}
	<script type="text/javascript">
		var url = "{$sub_action}";
		{literal}
			$(document).ready(function(){
				$(".from_checkbox").css("cursor", "pointer");
				$(".check_all").click(function(){
					$(".check_value").attr("checked", $(this).attr("checked"));
				});
				$("#php188_receive_delete").click(function(){
					var che = $("input[name='reid[]']:checked").attr("checked");
					if(che != true){
						showNotice("����ѡ��Ҫɾ������");
						return false;
					}
					var op = {success:subsuc}
					$("#php188_receive_hist").attr("action", url);
					$("#php188_receive_hist").ajaxSubmit(op);
				});
				function subsuc(data){
					switch($.trim(data)){
						case "notid":
							showNotice("���ύ������");
							break;
						case "notdata":
							showNotice("����ѡ��Ҫɾ������");
							break;
						case "success":
							location.href=url;
							break;
						default:
							showNotice("ɾ��ʧ��");
					}
				}
			});
		{/literal}
	</script>
    <div class="spacer"></div>
	<form id="php188_receive_hist" action="" method="post" autocomplete="off">
		<table class="table_list">
			<tr>
				<th class="input" nowrap="nowrap">
					<input type="checkbox" class="from_checkbox check_all"/></th>
				<th nowrap="nowrap">�ջ���</th>
                <th>��������</th>
				<th>���͵�ַ</th>
				<th>����</th>
				<th>�绰</th>
				<th>�ֻ�</th>
                <th nowrap="nowrap">����</th>
			</tr>
			{foreach from=$data.data item=item}
				<tr>
					<td align="center" class="center"><input name="reid[]"  type="checkbox" value="{$item.receive_id}" class="from_checkbox check_value"/></td>
					<td align="center" nowrap="nowrap">{$item.receive_realname}</td>
                    <td align="center" nowrap="nowrap">{$item.receive_area}</td>
					<td align="center" nowrap="nowrap">{$item.receive_address}</td>
					<td align="center"  nowrap="nowrap">{$item.receive_email}</td>
					<td align="center" nowrap="nowrap">{$item.receive_phone}</td>
					<td align="center" nowrap="nowrap">{$item.receive_mobile}</td>
                    <td  class="center" nowrap="nowrap"><a href="{$item.edit_link}">�޸�</a></td>
				</tr>
			{/foreach}
		</table>
        <div class="spacer"></div>
        <input id="php188_receive_delete" type="button"  class="form_submit" value="����ɾ��" />
        <input type="button" value="���ӵ�ַ" class="form_submit"  onclick="window.location.href='{building_link model='member@receive' action = 'opt' param='task=add'}'" />
            {if $data.page}
				<div class="pannel_page">{$data.page}</div>
            {/if}
	</form>
{else}
	<div class="notice_msg">�޿�������! <input type="button" value="���ӵ�ַ" class="form_submit"  onclick="window.location.href='{building_link model='member@receive' action = 'opt' param='task=add' http='false'}'" /></div>
{/if}
</div>
{/if}
{if $action eq 'operator'}
<script type="text/javascript" src="{building_link model='default' action='loadRegionJson'}"></script>
<script type="text/javascript">
function getRegionChild(obj){
	var pid = $(obj).val();
	pid = !pid?0:pid;
	var temp = php_region_json_data[pid];
	if(temp){
		var str = '';
		var option = '<option value="">��ѡ��...</option>';
		str += option;
		$(temp).each(function(j){
			str+='<option value="'+temp[j].id+'">'+temp[j].name+'</option>';
		});
		$(obj).parents('span').nextAll().find('select').html(option);
		$(obj).parents('span').next().find('select').html(str);
	}
}
$(function(){
	$("#submit_recive").submit(function(){
		var tag = false;
		$(".need_remove_node select").each(function(){
			var v = $(this).val();
			if(empty(v)){
				tag = true;
				$(this).addClass('empty_input_val');
			}else{
				tag = false;
				$(this).removeClass('empty_input_val');
			}
		});
		if(!check_form_is_empty('must_fill_in') || tag)return false;
		var mail = $("#rel_email").val();
		if(!is_email(mail) && !empty(mail))return showNotice('�����ʽ����!');
	});
});
</script>
{/literal}
    <div class="spacer"></div>
    <div>
    <form  id="submit_recive" method="post"  action="">
<input type="hidden"  value="{$task}" name="task" />
	<input type="hidden" value="{$data.receive_id}"  name="receive_id"/>
      <table class="table_list ">
      	<tr>
        	<td class="one">�� �� ��</td> 
            <td><input type="text"  value="{$data.receive_realname}" name="receive_realname" class="form_input must_fill_in"/> <font class="red"> * </font></td>
        </tr>
        <tr>
        	<td class="one">��������</td>
            <td>         
            {if $task eq 'add'}
            {foreach from=$region item=item}
                <span class='need_remove_node'>
                <select class="get_all_node_all_adress" name="receive_area[]" onchange="getRegionChild(this)">
                 <option  value=''>��ѡ��...</option>
 				   {if $item.region_id}
		           	<option value="{$item.region_id}">{$item.region_name}</option>
	    		   {/if}
                </select>
                </span>
            {/foreach}
            {else}
            {$region}
            {/if}
            </td>
        </tr>
        <tr>
        	<td class="one">���͵�ַ</td>
            <td><input type="text" value="{$data.receive_address}"  name="data[receive_address]" class="form_input must_fill_in"/>
            <font class="red"> * </font></td>
        </tr>
        <tr>
        	<td class="one">��ϵ����</td>
            <td><input type="text" id="rel_email"  value="{$data.receive_email}" name="data[receive_email]"  class="form_input must_fill_in"/><font class="red"> * </font></td>
        </tr>
        <tr>
        	<td class="one">��ϵ�ʱ�</td>
            <td><input type="text" value="{$data.receive_postno}" class="form_input" name="data[receive_postno]" /></td>
        </tr>
        <tr>
        	<td class="one">��ϵ�绰</td>
            <td><input type="text" value="{$data.receive_phone}" name="data[receive_phone]"  class="form_input"/></td>
        </tr>
        <tr>
        	<td class="one">��ϵ�ֻ�</td>
            <td><input type="text" value="{$data.receive_mobile}"  name="data[receive_mobile]"  class="form_input"/></td>
        </tr>
        <tr>
        	<td class="one"></td>
            <td><input type="submit" value="�� ��" class="form_submit" /> <input type="button" value="�� ��"  onclick="window.location.href='{building_link model='member@receive' action='list'}';" class="form_submit" /></td>
        </tr>
      </table>
    </form>
    	<div class="clear"></div>
        <div class="spacer">&nbsp;</div>
    </div>
{/if}