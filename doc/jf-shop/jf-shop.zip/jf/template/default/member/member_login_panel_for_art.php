<?php exit('die'); ?>
{if $smarty.session.php188curruser == ''}
{if !$region_id}
<script type="text/javascript">
  function location_href(str){
	 if(str.length==0) return false;
	  	location.href=str;
	  }
</script>
<div class="dr">
<form  method="get" action="{building_link model='member' action='loginajax'}" id="ajax_post_login" autocomplete="off">
<input type="hidden" value="script"  name="calltype"/>
<input type="hidden" value="ajaxlandindex"   name="subnametype"/>
           		<table cellpadding="0" cellspacing="0" border="0" width="100%">
                	<tr><td align="center"><span>�û�:</span><input type="text"  name="username" class="check_ajax_login top_input" id="ajax_login_name" /></td></tr>
                    
                    <tr><td align="center"><span>����:</span><input type="password" name="password"  class="check_ajax_login top_input" id="ajax_login_pass" /></td></tr>
                   
                    <tr><td align="center"><input type="submit" value="��¼" class="buttom_1"/> <input type="button" value="ע��" class="buttom_1" onclick="location_href('{building_link model='member' action='register'}')"/>
                    <!--call_member_login(this);-->
                    </td></tr>
                    
                    <tr><td align="center">
                    <a href="{building_link model='member' action = 'findpass'}" target="_blank">��������?</a>
                    </td></tr>                    
                </table>
                </form>
           </div>
<!--<form  method="get" action="{building_link model='member' action='loginajax'}" id="ajax_post_login" autocomplete="off">
<input type="hidden" value="script"  name="calltype"/>
<input type="hidden" value="ajaxlandindex"   name="subnametype"/>
<p class="top_zi">�û�����</p>	
<p class="w"><input type="text"  name="username" class="check_ajax_login top_input" id="ajax_login_name" /></p>
<p class="top_zi">���룺</p>	
<p class="w"><input type="password" name="password"  class="check_ajax_login top_input" id="ajax_login_pass" /></p>
<p style=""><input type="image" src="{$template_url}images/reg1.gif" /></a></p>
<p style="float:left; padding:4px 0px 1px 3px;"><a href="javascript:;" onclick="call_member_login(this);">�û�ע��</a> <a href="{building_link model='member' action = 'findpass'}" target="_blank">��������?</a> </p>
</form>-->

<script type="text/javascript">
		function empty_val(){$("#ajax_login_pass").val('');$("#ajax_login_name").val('');}
		$(function(){
			$("#ajax_post_login").submit(function(){												
				var url = _c("ajax_post_login");				
				$.getScript(url,function(){	
					switch(call_back_string){
						case 'ERROR_CAPTCHA':
							empty_val();return showNotice('��֤�����!');
						break;
						case 'ERROR_USER':
							empty_val(); return showNotice('�û���Ϊ��!');
							break;
						case 'ERROR_LOGIN':
							empty_val();
							return showNotice('��½ʧ��!');
						break;
						case 'ERROR_REQUEST':
							empty_val();return showNotice('�������!');
						break;
						case 'OK':						  
							//_set_logins();
							_set_logins_article();
							show_nopay_car();
						break;
						default:
						alert('error');
					}
				});
				return false;
			});
		});
</script>
{/if}
{if $region_id}<!--��¼-->


	        <p style="padding:0px 20px 0px 40px;"><a href="javascript:;" onclick="call_member_login(this);" title="�û�ע���¼"><img src="{$template_url}images/button_3.gif" /></a></p>
        <p><a href="javascript:;" onclick="call_member_login(this);" title="�û�ע���¼"><img src="{$template_url}images/button_4.gif" /></a></p>
 
{/if}
{else}
<div class="dr">
    <div id="user_login_ok">
    <script type="text/javascript">
        var quit_url = "{building_link model='member@membermanage' action='memberquit' param='quittype=quit&c_model=article'}"+connetor+'jsoncallback=?';
        var opts = {rid:{$region_id|default:'0'}};
        function ajaxQuit(){
            $.getJSON(quit_url,opts,function(data){
                $("#PHP188_member_panel").html(data.result);
                show_nopay_car();	
            });
        }
    </script>
    
 
    
    <p style="width:220px; height:40px; line-height:40px;"><b>{if $smarty.session.php188curruser.mem_name}{ $smarty.session.php188curruser.mem_name}{else}{ $smarty.session.php188curruser.mem_username}{/if} </b> ��ӭ����</p>
      <p class="right" style="width:220px;"><a href="{building_link model='member@membermanage' action='memberinfo'}">��������</a> | <a  href="{building_link model='member@money' action='orderlist'}" >�ҵĶ���</a></p> 
        <p class="right" style="width:220px;"><a href="{building_link model='member@feedback' action='feedbacklist'}">�ҵ�����</a> | <a href="{building_link model='member@pointlog' action='pointlist'}" >���ּ�¼ </a></p> 
        <p class="right" style="width:220px;"><a href="{building_link model='member@membermanage' action=''}">�û�����</a> | <a href="javascript:;" onclick="ajaxQuit();" >�˳�ϵͳ</a></p> 
    </div>
</div>
{/if}