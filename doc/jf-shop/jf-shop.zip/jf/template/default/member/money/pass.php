<?php exit('die'); ?>
<div id="do_pay_pass">
<div class="spacer"></div>
<form id="do_user_pass_pass" action="{$subaction}" method="post" autocomplete="off">
	<table class="table_list">
    {if !$no_old_pass}
        <tr>
            <td class="one">��&nbsp;&nbsp;��&nbsp;&nbsp;��</td>
            <td >
            	<input type="password" value="" class="ln form_input must_fill" maxlength="30" name="old_pass"  />
                <span class="red"></span>
            </td>
        </tr>
        {/if}
        <tr>
            <td class="one">��&nbsp;&nbsp;��&nbsp;&nbsp;��</td>
            <td>
            	<input type="password" maxlength="30"  class="ln form_input must_fill"   name="newpassword" />
                <span class="red"></span>
            </td>
        </tr>
        <tr>
            <td class="one"> ȷ������</td>
            <td>
            	<input type="password" maxlength="30"  class="ln form_input must_fill"  name="repass"/>
                <span class="red"></span>
            </td>
        </tr>
        <tr>
	        <td></td>
            <td><input type="submit" id="form_sub_btn" class="form_submit" value="ȷ���޸�"/></td>
        </tr>
	</table>
</form>
<script type="text/javascript">
$(function(){
	$("#do_user_pass_pass").submit(function(){
		if(!check_form_is_empty('must_fill'))return showNotice('����������!');
	});
});
</script>
<div class="spacer"></div>
</div>