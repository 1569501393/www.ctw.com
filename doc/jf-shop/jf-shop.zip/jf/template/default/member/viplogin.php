<?Php  if(!defined('PHP188_TEMPLATE'))exit();?>
{include file="header.php"}
{include file="nav.php"}
<div class="spacer"></div>
	<div id="middle"><!--middle start-->
    {literal}
    	<style type="text/css">
		.line{ text-align:center;}
		#vip_login{ margin:0px auto; text-align:center;}
		.login_panel{ border:1px solid #CCC; border-top:none; border-bottom:none; width:748px; margin:0px auto;}
       .login_panel .login_input{ background-color:#E8F9FF; border:1px solid #817F84; font:14px; height:20px; padding-top:4px; width:300px;}
	   .login_panel .r{ text-align:right; font-size:14px; font-weight:bold;}
	   .login_panel .l{ text-align:left;}
	  .login_panel .empty_input_val{border:2px solid #FF0000;background-color:#FFFFD5;height:18px; line-height:18px; color:#FF0000;}
        </style>
        <script type="text/javascript">
        	$(document).ready(function(){
				$("#cap").focus(function(){
					$("#image_capt").click();
				})
				//login_input
				$("#active_member").submit(function(){
					if(!check_form_is_empty('login_input'))return false;
				})
			})
			
        </script>
    {/literal}
    <div id="vip_login">
    	<p class="line"><img src="{$template_url}images/v_t.gif" /></p>
        	<div class="login_panel">
          <form action="{building_link model='member' action = 'login'}"  id="active_member" autocomplete="off" method="post">
            	<table border="0" cellspacing="4" cellpadding="4" align="center">
              <tr>
                <td colspan="2"><img src="{$template_url}/images/active.gif" /></td>
                </tr>
              <tr>
                <td class="r">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��:</td>
                <td class="l"><input type="text" name="loginusername" value="" class="login_input" /></td>
              </tr>
              <tr>
              	<td class="r">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��:</td>
                <td class="l"><input  type="password" value=""  name="password" class="login_input" /></td>
              </tr>
              <tr>
              	<td class="r">�� ֤ ��:</td>
                <td class="l"><input type="text"  name="codenumber" id="cap" style="width:200px;" value=""  class="login_input"/><img class="cap_img"  style="cursor:pointer;" src="{$siteurl}captcha.php" alt="���������֤��ͼƬ" id="image_capt" onclick="this.src='{$siteurl}captcha.php?rands='+Math.random()" title="���������֤��ͼƬ" /></td>
              </tr>
              <tr>
              	<td align="center" colspan="2"><input type="image" src="{$template_url}images/vip_button.gif"/></td>
              </tr>
            </table>
            <input  type="hidden"  name="is_vip" value="vip" />
            </form>
            </div>
        <p class="line"><img src="{$template_url}images/v_f.gif" /></p>
    </div>
    <br  class="clear"/>
	</div>
{include file="footer.php"}