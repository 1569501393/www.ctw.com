<?php exit('die'); ?>
{if $pay_log_data}
<table class="table_list">
<tr>
	<td colspan="10"><h3>֧����־(RMB)</h3></td>
</tr>
<tr>
    <th>�������</th>
    <th>ʵ��֧��</th>
    <th>ʱ��</th>
    <th>��ʽ</th>
    <th>��ˮ��</th>
</tr>
{foreach from=$pay_log_data item='tag'}
    <tr>
        <td align="center">{$tag.order_sn}</td>
        <td align="center">{$tag.payed_money}</td>
        <td align="center">{$tag.pay_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        <td align="center">{$tag.pay_name}</td>
        <td align="center">{$tag.pay_sn}</td>
    </tr>
{/foreach}
<tr>
    <td colspan="6" align="right" style="padding-right:10px;">�ܶ{$pay_log_all_payed_money.money_format}</td>
</tr>
</table>
{/if}

{if $order_data.order_payed_points_log.pay_log_data}
<table class="table_list">
<tr>
	<td colspan="10"><h3>֧����־(����)</h3></td>
</tr>
<tr>
    <th>���</th>
    <th>֧��</th>
    <th>ʱ��</th>
    <th>��ʽ</th>
    <th>��ˮ��</th>
</tr>
{foreach from=$order_data.order_payed_points_log.pay_log_data item='tag'}
    <tr>
        <td align="center">{$tag.order_sn}</td>
        <td align="center">{$tag.payed_points}</td>
        <td align="center">{$tag.pay_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        <td align="center">{$tag.pay_name}</td>
        <td align="center">{$tag.pay_sn|default:'-'}</td>
    </tr>
{/foreach}
<tr>
    <td colspan="6" align="right" style="padding-right:10px;">�ܶ{$order_data.order_payed_points_log.total_points}��</td>
</tr>
</table>
{/if}