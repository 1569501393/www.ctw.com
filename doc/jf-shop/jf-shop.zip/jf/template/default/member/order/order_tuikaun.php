<?php exit('die');  //�˿����� ?>
{if $action eq 'tuikuan_flag'}
<div class="spacer"></div>
<form method="post" action="{$do_link}" id="do_post_order_tuikuan">
<table class="table_common">
	<tr>
    	<td class="one" align="right"><strong>��ϵ��ʽ</strong></td>
        <td><input type="text" value="" maxlength="50" name="contact"  class="form_input etags_must_full_tag"/>  �����ǵ绰</td>
    </tr>
    <tr>
    	<td class="one" align="right"><strong>�˿�ԭ��</strong></td>
        <td>
        <textarea id="etags_must_full_tag" name="remark" class="form_textarea etags_must_full_tag" style="width:350px; height:100px;"></textarea>
        <p>������������(<span class="red text_limiter">1000</span>)���ַ�!</p>
        </td>
    </tr>
    <tr>
        <td colspan="2"><input type="submit" value="�ύ" class="form_submit" /></td>
    </tr>
</table>
</form>
<script type="text/javascript">
	$(function(){
		$("#etags_must_full_tag").grd_maxLength({length:1000});
		$("#do_post_order_tuikuan").submit(function(){
			if(!check_form_is_empty('etags_must_full_tag'))return false;
			if(!confirm('��ȷ��Ҫ�ύ�˿�������?\r\n�˲�����Ҫ����Ա�ֹ���˴���!\r\n���ܺķѵ�ʱ��Ƚϳ�!'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'EMPTY':
						alert('����д����!');
					break;
					case 'MAX_LENGTH':
						alert('����д������̫���˰�?');
					break;
					case 'OK':
						_close_grd_window();
						window.location.reload();
						alert('�ύ�ɹ�!���ǽ��������ȷ��!');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
{/if}

{if $action eq 'tuikuan_log'}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�˿����봦����־-{$order_sn}</title>
{insert_template_scripts_root files='shopdata/js/jquery-1.3.2.min.js,shopdata/js/jquery.form.js'}
<script src="{$template_url}js/global.js"></script>
<style type="text/css">
body,div,p,h1,h2,h3,h4,h5,h6{ font-variant:normal;margin:0px; padding:0px; font-family:"����",Verdana, Geneva, sans-serif; font-size:12px; line-height:normal;}
a{ text-decoration:none;}
img{ border:none;}
.tui_title{ line-height:25px; font-size:14px; border-bottom:1px solid #EAEAEA; padding-left:5px; margin:4px 0px; font-weight:bold;}
#tuikuan_logs{ margin:4px 3px;  padding:0px 2px;}
.user_post_content{ color: #5D5D5D; line-height:20px; padding-top:0px;}
.admin_content{ color:#F00;}
.all_pannel_tag{ padding:10px 5px;}
.ccolor{ clear:both; display:block; height:2px; border-bottom:1px solid #EEBB77; margin:2px 0px 4px 0px;}
.replay_contents{ margin-top:4px;}
.user_post_list{ height:auto; clear:both; margin-bottom:3px;}
.lines{ color:#B1B1B1;}
.empty_input_val{ background-color:#FFE59E;}
.red{color:#F00;}
textarea{ font-size:13px; padding:3px; line-height:160%;}
.closed{ font-size:14px; line-height:180%; color:#369; padding:8px; border:1px solid #CCC;}
.ttt{ line-height:25px; height:25px;}
</style>
</head>
<body>
<div id="tuikuan_logs">
	<h1 class="tui_title">�˿����봦��-SN{$order_sn} </h1>
{if $data}
    <div class="all_pannel_tag">
    {foreach from=$data item='list' key=key}
    <!--�û�-->
    {if $list.content}
    <div class="user_post_list">
    <div class="user_post_bar">[#{$key+1}]�ύʱ�䣺{$list.time|date_format:"%Y-%m-%d %H:%M:%S"} IP��{$list.ip} </div>
    <span class="lines">---------------------------------------------------------------------------------------------------------------------</span>
    <div class="user_post_content">{$list.content|nl2br}</div>
    <div class="clear"></div>
    </div>
    {/if}
    <!--����Ա-->
    {if $list.who_do}
    <div class="adminpannel">
    <div class="user_post_bar">[#{$key+1}]�ظ��ˣ�{$list.who_do} �ظ�ʱ�䣺{$list.time|date_format:"%Y-%m-%d %H:%M:%S"}</div>
    <span class="lines">---------------------------------------------------------------------------------------------------------------------</span>
        <div class="admin_content">{$list.do_remark|nl2br}</div>
         <div class="ccolor"></div>
    </div>
    {/if}
    {/foreach}
    </div>
<div class="replay_contents">
    {if $check.tuikuan_flag!='2'}
        <form method="post" action="{$tuikuan_link}" id="do_admin_replay">
            <textarea name="replay_content" id="etags_must_full_tag" class="do_tags_post_must" style="width:450px; height:100px;"></textarea>
            <p class="ttt">������������(<span class="red text_limiter">1000</span>)���ַ�!</p>
            <br />
            <input type="submit" value="�ظ�"  class="form_submit" />          <input onClick="window.location.reload();" type="button" value="ˢ��"   class="form_submit" />
        </form>
    </div>
    <script type="text/javascript">
        $(function(){
             $("#etags_must_full_tag").grd_maxLength({length:1000});
            $("#do_admin_replay").submit(function(){
                if(!check_form_is_empty('do_tags_post_must'))return false;
                $(this).ajaxSubmit(function(data){
                    switch(data){
                        case 'OK':
                            alert('�ύ�ɹ�,���ǻ�Ӿ��촦����������!');
                            window.location.reload();
                        break;
                        case 'NO_DATA':
                            alert('�Ƿ�����!');
                        break;
                        case 'CAN_NOT_REPLAY':
                            alert('����Ա�ѹر�,��������!');
                        break;
                        case 'EMPTY':
                            alert('����д������!');
                        break;
                        case 'HAS_CLOSE':
                            alert('����Ա�ѹرջظ�!');
                        break;
                        default:
                            alert(data);
                    }
                });
                return false;
            });
        });
    </script>
    {else}
    	<div class="closed">�����!</div>
    {/if}
{else}
<div class="no_data">�޿�������!</div>
{/if}

</body>
</html>
{/if}