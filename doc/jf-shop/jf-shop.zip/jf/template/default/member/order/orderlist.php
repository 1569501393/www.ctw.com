<?php if(!defined('PHP188_TEMPLATE'))exit();?>
{if $action eq 'orderlist'}
<div class="o_search_pannel">
<script type="text/javascript">
	$(function(){
		$('#submit_search_form').submit(function(){
			var u = _s($(this));
			window.location.href=u;
			return false;
		});
	});
	function location_tag(obj){
		window.location.href="{$main_url}tag="+$(obj).val();
	}
</script>
<div class="o_search_form">
<form method="post" action="{$search_url}" id="submit_search_form" autocomplete="off">
<input type="text" value="{$egets.order_sn}"  class="must_fill_tag form_input"  name="sn"/>
<input type="hidden" value="search" name="tag" />
<input type="submit" value="��������" class="form_submit" />
</form>
</div>
<div class="o_search_select">
    <select name="" onchange="location_tag(this);" style="float:left">
        <option value="">ȫ������</option>
        <option value="unpay" {if $etag eq 'unpay'} selected="selected"{/if}>δ֧���Ķ���</option>
        <option value="confirm" {if $etag eq 'confirm'} selected="selected"{/if}>��ȷ�ϵĶ���</option>
        <option value="unconfirm" {if $etag eq 'unconfirm'} selected="selected"{/if}>δȷ�ϵĶ���</option>
        <option value="send" {if $etag eq 'send'} selected="selected"{/if}>�ѷ����Ķ���</option> 
        <option value="cacnel" {if $etag eq 'cacnel'} selected="selected"{/if}>��ȡ���Ķ���</option>  
        <option value="invaild" {if $etag eq 'invaild'} selected="selected"{/if}>��Ч�Ķ���</option>     
        <option value="refund" {if $etag eq 'refund'} selected="selected"{/if}>�˻��Ķ���</option>
        <option value="remoney" {if $etag eq 'remoney'} selected="selected"{/if}>�˿�Ķ���</option>
    </select>
    </div>
    <div class="clear"></div>
</div>
    {if $data.total>0}
      <table  class="order_table_list">
        {foreach from=$data.data item='list'}
            <tr class="epanenl_order_list_{$list.order_id} etag_pannel">
            	<td  colspan="8" class="order_top2"><strong>������ţ�</strong>{$list.order_sn} <strong>�ɽ�ʱ�䣺</strong>{$list.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
            </tr>
            <tr class="epanenl_order_list_{$list.order_id} etag_pannel">
            <td>
            	{foreach from=$list.goods_data item='goods'}
                	<div class="order_goods_list">
            <div class="img">{if $goods.goods_url}<a href="{$goods.goods_url}" target="_blank"><img src="{$site_url}picture.php?s={$goods.goods_list_small_pic}&w=50&h=50" /></a>{else}<img src="{$site_url}picture.php?s={$goods.goods_list_small_pic}&w=40" />{/if}</div>
            <div class="name">{if $goods.goods_url}<a href="{$goods.goods_url}" target="_blank">{$goods.goods_name}</a>{else}{$goods.goods_name}{/if}</div>
             <div class="clear"></div>
                    </div>
                {/foreach}
            </td>
            <td align="center" valign="middle">{$list.order_count}��</td>
            <td align="center" valign="middle" class="order_top3">
            <p class="order_money_desc">{$list.order_money_format} {if $list.order_total_point_fee>0}+{$list.order_total_point_fee}��{/if}</p>
            <p class="pay_fee gray">(�����ͷ�{$list.delivery_fee_format|default:'0'})</p>
            <p class="gray">{$list.delivery_name} {if $list.huodaofukuan}<span class="red">��������</span>{/if}</p>
            {*}
            <p class="gray">{if $list.pay_status eq '0'}<span class="red">δ֧��</span>{elseif $list.pay_status eq '1'}��֧��{elseif $list.pay_status eq '3'}֧����һ����{/if}</p>{*}
            </td>
            <td align="center" valign="middle">
            	<div class="do_btn">
                <p class="ee"><strong>
                {assign var=order_data value=$list}
                {include file="member/order/widget/order_status.php"}
                </strong></p>
                <p class="ee"><a href="{$list.detail_link}" target="_blank">��������</a></p>
				{*}<p class="ee"><a href="">������Ϣ</a></p>{*}
                <p class="ee"><a href="{$list.print_link}" target="_blank">��ӡ����</a></p>
<!--#�˿�����-->
{if $can_tuikuan}
    {if $list.pay_status eq '1' && $list.shiping_status eq '0' && $list.tuikuan_flag eq '0'}
        <p class="ee"><a href="javascript:;" onclick="do_tuikuan(this);" rel="{$list.tuikuan_link}">�����˿�</a></p>
    {/if}
    
    {if $list.tuikuan_flag >0}
        <p class="ee"><a href="javascript:;" onclick="do_tuikuan_log(this);" rel="{$list.tuikuan_list_link}"><strong>�˿����¼</strong></a>
        {if $list.tuikuan_flag eq '1'}
            {if $list.tuikuan_do_flag eq '1'}<strong class="red">����Ա�ѻظ�</strong>{/if}
            {else}
            <strong class="red">�ѹر�</strong>
        {/if}
        </p>
    {/if}
{/if}
{if $allow_cancel_order}
    {if $list.pay_status eq '0' && $list.order_confirm_status neq '2' &&  $list.shiping_status eq '0' && $list.user_cancel_flag neq '1'}
        <p class="ee"><a href="javascript:;" onclick="cancel_order(this);" rel="{$list.cacnel_order_link}">ȡ������</a></p>
    {/if}
{/if}

{if $list.shiping_status eq '2' && !$list.huodaofukuan}
	<p class="ee"><a href="javascript:;" onclick="confirm_order(this);" rel="{$list.order_id}">ȷ�ϵ���</a></p>
{/if}
 
 {if $list.allow_tuihuo}
     <!--#�˿��˻�-->
    {if $list.shiping_status eq '3' && $list.tuihuo_sign eq '0' && $list.pay_status eq '1'}
        <p class="ee"><a href="javascript:;" onclick="to_tuikuantuihuio(this);" rel="{$list.shengqing_tuihuo_url}">�����˿��˻�</a></p>
    {/if}
    {if $list.tuihuo_sign>=1}
        <p class="ee"><a href="javascript:;" onclick="show_tuihuo_log(this);"  rel="{$list.tuihuo_log_url}">�˻���־</a> 
        {if $list.tuihuo_sign eq '1'}
        
        {if $list.tuihuo_do_flag eq '1'}<strong class="red">����Ա�ѻظ�</strong>{elseif $list.tuihuo_do_flag eq '2'}<strong class="red">����Ա�ѻظ�</strong>{elseif $list.tuihuo_do_flag eq '0'}<strong class="red">�ȴ�����</strong>{else}<strong class="red">�ѹر�</strong>{/if}
        
         {elseif $list.tuihuo_sign eq '2'}
            <strong class="red">�ѹر�</strong>
        {else}
            <strong class="red">�ȴ�����</strong>
        {/if}
        </p>
    {/if}
{/if}

                </div>
            </td>
            <td>{if $list.can_pay}<a href="{$list.to_pay_link}" target="_blank"><img src="{$template_url}images/member/to_pay.jpg" /></a>{/if}</td>
            </tr>
        {/foreach}
	</table>
<script type="text/javascript">
	function do_tuikuan(obj){
		showWindow($(obj).html(),$(obj).attr('rel'),800,280,false);
		//$(document).grd_window({title:$(obj).html(),url:$(obj).attr('rel'),width:800,height:280,iframe:false});
	}
	function do_tuikuan_log(obj){
		showWindow($(obj).html(),$(obj).attr('rel'),900,400,true);
		//$(document).grd_window({title:$(obj).html(),url:$(obj).attr('rel'),width:900,height:400,iframe:true});
	}
/*�˻���־*/
	function show_tuihuo_log(obj){
		showWindow($(obj).html(),$(obj).attr('rel'),800,350,true);
		//$(document).grd_window({title:$(obj).html(),url:$(obj).attr('rel'),width:800,height:350,iframe:true});
	}
/*�˿��˻�*/
	function to_tuikuantuihuio(obj){
		showWindow($(obj).html(),$(obj).attr('rel'),700,300,false);
		//$(document).grd_window({title:$(obj).html(),url:$(obj).attr('rel'),width:700,height:300,iframe:false});	
	}
	function cancel_order(obj){
		showWindow('ȡ������',$(obj).attr('rel'),700,300,false);
		//return $(document).grd_window({title:'ȡ������',url:$(obj).attr('rel'),width:700,height:300,iframe:false});	
	}
	function confirm_order(obj){
		var id = $(obj).attr('rel');
		var url = "{building_link model='member@order' action='confirmOrder'}";
		$.post(url,{id:id},function(data){
			switch(data){
				case 'EMPTY':
					alert('�Ƿ�����!');
				break;
				case 'NO_AUTH':
					alert('�����㻹����������ȷ�ϲ���!');
				break;
				case 'OK':
					window.location.reload();
					alert('�����ɹ�,��л�������ǵ�֧��!');
				break;
				default:alert(data);
			}
		});
	}
</script>
<div align="center">{$data.page}</div>
{else}
<div class="notice_msg">�޿��ö�������</div>
{/if}

{/if}
