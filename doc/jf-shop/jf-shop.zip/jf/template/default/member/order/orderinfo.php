<?php exit('die'); ?>
{if $action eq 'show_order_detail'}
{insert_template_scripts_root files='shopdata/static/calendar/WdatePicker.js'}
<div id="order_detail_info">
  <table class="table_list">
    <td>������ţ�{$order_data.order_sn}</td>
      <td>����״̬�� <strong>{include file='member/order/widget/order_status.php'} </strong></td>
    </tr>
    <tr>
      <td>����ʱ�䣺{$order_data.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
      <td>�������ţ�{$order_data.delivery_no|default:' -'}</td>
    </tr>
    <tr>
      <td>���͸��ӷѣ�{$order_data.delivery_extend_money|money_format}</td>
      <td></td>
    </tr>
  </table>
  <table class="table_list">
    <tr>
      <td colspan="10"><h3>��Ʒ����</h3></td>
    </tr>
    <th></th>
      <th>���</th>
      <th>����</th>
      <th>����</th>
	 <th>����(����)</th>
      <th>����</th>
      <th>����</th>
      <th>С��</th>
    </tr>
    {foreach from=$order_data.order_goods_data item=gd key=k}
    <tr>
      <td align="center"><img src="{$site_url}picture.php?s={$gd.pic}&w=40&h=70" /></td>
      <td align="center">{$gd.goods_sn}</td>
      <td align='center'><a  target="_blank" href="{$gd.url}">{$gd.goods_name}</a>
 {if $gd.taozhuang_extend_data}
<div class="cart_taozhuang">
<strong>��װ��</strong>{foreach from=$gd.taozhuang_extend_data item='tao' name='ename'} {$tao.goods_name} {if !$smarty.foreach.ename.last}��{/if}{/foreach}
  </div>
{/if}
 {if $gd.zenpin_extend_data}
<div class="cart_taozhuang">
<strong>��Ʒ��</strong>{foreach from=$gd.zenpin_extend_data item='zp' name='zp_name'} {$zp.goods_name} {if !$smarty.foreach.zp_name.last} ��{/if}{/foreach}
</div>
{/if}
      </td>
      <td align='center'>{$gd.goods_curent_price_format}</td>
	 <td align="center">{$gd.goods_point_fee|default:'0.00'}</td>
      <td align='center' name='goods_total'>{$gd.goods_total}</td>
      <td align='center' name='goods_total'>{$gd.goods_weight} ��</td>
      <td align='center' name='price_total'>{$gd.subtotal_format}{if $gd.sub_point_total>0}+{$gd.sub_point_total}��{/if}</td>
    </tr>
    {/foreach}
    <tr>
      <td  align="right" colspan="10" >��Ʒ������{$order_data.order_count} ��������{$order_data.goods_total_weight} �� �ܼƣ�{$order_data.order_goods_total_fee} 
      {if $order_data.order_total_point_fee>0}+{$order_data.order_total_point_fee}��{/if}
      </td>
    </tr>
  </table>
  <div class="spacer"></div>
  <!--#֧����־-->
  {assign var='pay_log_data' value=$order_data.order_pay_log}
  {assign var='pay_log_all_payed_money' value=$order_data.pay_log_all_payed_money}
  {include file="member/order/widget/order_pay_log_part.php"}
  <div class="spacer"></div>
  <table class="table_list">
    <tr>
      <td colspan='4'><h3>������Ϣ</h3></td>
    </tr>
    <tr id='delivery_row'>
      <td class='tdone' colspan="5">
      ������ʽ��{$order_data.delivery_name} 
      <br /> ���ͷ��ã�{$order_data.delivery_fee|money_format}
      <br />�������ţ�{$order_data.delivery_no|default:'����'}
         </td>
    <tr>
{if $can_allow_fix_delivery}
    <tr>
    	<td colspan="10"><h3>��������</h3>
        <script type="text/javascript">
		function ajax_call_express_data(){
			$.get('{$call_express_link}',{no:'{$can_allow_fix_delivery.delivery_no}',name:'{$can_allow_fix_delivery.extend_name}'},function(data){
				$("#ajax_call_express_data").html(data);
			});	
		}
		$(function(){
			ajax_call_express_data();
		});
    </script>
    </td>
    </tr>
    <tr>
    	<td><div id="ajax_call_express_data"><img src="{$template_url}images/zoomloader.gif" /></div></td>
    </tr>
{/if}
    <tr>
      <td colspan="10"><h3>��������</h3></td>
    </tr>
    <tr>
      <td colspan="10"><div id="order_tracking_log"><img src="{$template_url}images/zoomloader.gif" /></div>
        <script type="text/javascript">
		function get_order_tracking_log(){
			$.get('{$order_tracking_log_link}',{sn:'{$order_data.order_sn}',id:'{$order_data.order_id}'},function(data){
				$("#order_tracking_log").html(data);
			});	
		}
		$(function(){
			get_order_tracking_log();
		});
        </script></td>
    </tr>
  </table>
  <div class="spacer"></div>
  <table class='table_list'>
    <tr>
      <td colspan='4'><h3>�ջ�����Ϣ</h3></td>
    </tr>
    <tr>
      <td class='tdone'>�ջ���������</td>
      <td align='left' id='name'>{$order_data.receive_realname}</td>
      <td class='tdone'>���͵�����</td>
      <td align='left' id='area'>{$order_data.receive_area}</td>
    </tr>
    <tr>
      <td class='tdone'>�����ַ��</td>
      <td align='left' id='receive_address_q' >{$order_data.receive_address}</td>
      <td class='tdone'>�������룺</td>
      <td align='left' id='postno'>{$order_data.receive_postno}</td>
    </tr>
    <tr>
      <td class='tdone'>�̶��绰��</td>
      <td align='left' id='phone'>{$order_data.receive_phone}</td>
      <td class='tdone'>�ֻ����룺</td>
      <td align='left' id='mobile'>{$order_data.receive_mobile}</td>
    </tr>
    <tr>
      <td class='tdone'>�ջ���Email��</td>
      <td align='left' id='email'>{$order_data.receive_email}</td>
      <td class='tdone'>�ͻ����ڣ�</td>
      <td align='left' id='date_time'>{$order_data.receive_date_type}</td>
    <tr>
      <td class='tdone'>��Ա�ۿۣ�</td>
      <td align='left'>{if $order_data.discount_money}{$order_data.discount*10} �� ��{$order_data.discount_money_format}{else}���ۿ�{/if}</td>
      <td class='tdone'>��Ʊ��Ϣ��</td>
      <td align='left' id='invoice'>{$order_data.receive_invoice}</td>
    </tr>
    <td class='tdone'>��Ʊ���ã�</td>
      <td align='left'>{$order_data.fapiao_money_format}</td>
      <td class='tdone'>������ע��</td>
      <td align='left' id='note'>{$order_data.receive_note}</td>
    </tr>
    <tr>
      <td class='tdone' >ȱ��������</td>
      <td align='left' colspan="4">{$order_data.receive_out_of_stock}</td>
    </tr>
  </table>
  {if $order_data.coupon_number}
  <div class="coupon price_left">
    <div class="m_notice">
      <h3>�Ż�ȯ</h3>
    </div>
    <div class="coupon_info_money"> �Ż�ȯ:{$order_data.coupon_number}      ��ȥ:{$order_data.coupon_money|money_format} <span id="coupon_notice"></span> </div>
  </div>
  {/if}
  <div class="spacer"></div>
  <div class="finally"> <span class="price_left cart_count_string" id="order_temp_tag"> {include file='order/cart_fee_string.php'} </span> </div>
  <p class="can_pay"> 
  {if $can_pay}
    <input value="ȥ֧��"  type="button"  onclick="window.open('{$to_order_link}')" class="form_submit"/>
    {/if}
    <input type="button" onclick="window.open('{$print_url}')" value="��ӡ����" class="form_submit" />
    <input type="button" value="�����б�" onclick="window.location.href='{building_link model='member@order'}'" class="form_submit" />
  </p>
</div>
{/if}