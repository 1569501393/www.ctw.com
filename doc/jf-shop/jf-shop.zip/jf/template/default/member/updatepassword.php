<?php  exit('die');?>
	<script type="text/javascript">
		$(function(){
			$("#form_sub_btn").click(function(){
				var loginflg = true;
				$("#php188updatepassword").find("input").each(function(i){
					if(empty($.trim($(this).val()))){
						$(this).addClass("empty_input_val");
						loginflg = false;
					}
				});
				if(!loginflg){
					loginflg = true;
					return false;
				}
				var oldpassword = $("#oldpassword").val();
				if(oldpassword.length < 6){
					$("#oldpassword").next().html("�����볤�Ȳ���С��6λ");
					return false;
				}else{
					$("#oldpassword").next().html("");
				}
				var newpassword = $("#newpassword").val();
				if(oldpassword.length < 6){
					$("#newpassword").next().html("�����볤�Ȳ���С��6λ");
					return false;
				}else{
					$("#newpassword").next().html("");
				}
				var repass = $("#repass").val();
				if(repass != newpassword){
					$("#repass").next().html("��ȷ����������һ��!");
					return false;
				}else{
					$("#repass").next().html("");
				}
				$("#php188updatepassword").ajaxSubmit(function(data){
					switch($.trim(data)){
						case "TOO_SHORT_NEW_PASS":
							showNotice("�����벻��С��6λ");
							break;
						case "NOT_PASS":
							showNotice("�������벻һ��");
							break;
						case "ERROR_OLD_PASS":
							showNotice("�����벻��ȷ");
							break;
						case "OK":
							alert("�޸ĳɹ�,�����µ�¼ϵͳ!");
							window.location.reload();
							$(".ln").val("");
							break;
						case "ERROR":
							showNotice("�޸�ʧ��");
							break;
						default:
							alert(data);
							break;
					}
				});
				return false;
			});
		});
    </script>
<div class="spacer"></div>
<form id="php188updatepassword" action="{$subaction}" method="post" autocomplete="off">
	<table class="table_list">
        <tr>
            <td class="one">�� �� ��</td>
            <td >
            	<input type="password" value="" class="ln form_input" maxlength="20" id="oldpassword" name="oldpassword" />
                <span class="red"></span>
            </td>
        </tr>
        <tr>
            <td class="one">�� �� ��</td>
            <td>
            	<input type="password" maxlength="20"  class="ln form_input" id="newpassword" name="newpassword" />
                <span class="red"></span>
            </td>
        </tr>
        <tr>
            <td class="one"> ȷ������</td>
            <td>
            	<input type="password" maxlength="20"  class="ln form_input"  id="repass" name="repass"/>
                <span class="red"></span>
            </td>
        </tr>
        <tr>
	        <td></td>
            <td><input type="submit" id="form_sub_btn" class="form_submit" value="ȷ���޸�"/></td>
        </tr>
	</table>
</form>
<div class="spacer"></div>