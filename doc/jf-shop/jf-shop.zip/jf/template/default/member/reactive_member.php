<?php exit('die'); ?>
{include file="member/widget/member_header.php"}
<div class="page_nav w980">{include file="nav.php"}</div>
<div class="h10"></div>
<div id="content" class="w980">
<div class="clear spacer"></div>
<div class="reactive_member">
 {if $action eq 'reactive_member'}
 <form action="{$do_url}" method="post" id="reactive_member" autocomplete="off">
<table class="table_list">
<tr>
    <td class="one">�û�����</td>
    <td><input type="text" id="username" name="username"  class="must_fille_in form_input" /> <span class="red">*</span></td>
</tr>
<tr>
    <td class="one">���������ַ��</td>
    <td><input type="text" id="username" name="remail"  class="form_input " /> ��������д�����������ַ</td>
</tr>
    <tr>
        <td></td>
        <td><input type="submit" class="form_submit" value="�� ��" /> <a href="{building_link model='member' action='login'}" class="reactive_login_link yahei">�Ѽ����˵�½</a></td>
    </tr>
</table>
</form>
<script type="text/javascript">
	$(function(){
		$("#reactive_member").submit(function(){
			if(!check_form_is_empty('must_fille_in'))return false;
		});
	});
</script>
 {/if}	
</div>
</div>

{include file="member/widget/member_footer.php"}