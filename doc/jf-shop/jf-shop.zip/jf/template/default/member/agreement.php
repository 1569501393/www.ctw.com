{include file='member/widget/member_header.php'}
<div class="page_nav w980">{include file='nav.php'}</div>
<div class="h10"></div>
<div id="member_agreement" class="w980">{$agreement}</div>
<div class="h10"></div>
{include file='member/widget/member_footer.php'}

