<?php exit('die'); ?>
<div class="m_notice" id="curent_member_money">
  <h3 class="yahei">��ǰ���û��֣�<samp>{$mem_point|default:'0'}��</samp></h3>
</div>
<div class="clear"></div>
<div id="php188_pointlog_comment">
  <div class="member_point_desc"> {if $can_exchange}
    <script type="text/javascript">
				var ajax_call_url = "{building_link model='member@pointlog' action='exchangePoint'}";
				 {literal}
                	function exchange_point(obj){
						if(!check_form_is_empty('exchange_point_input'))return false;
						var options = {
								exchange_value:$("#exchange_point_input_id").val()
								};
						$(obj).attr("disabled",true);
						$.post(ajax_call_url,options,function(data){
							var d = data.split('|');
							$(obj).attr("disabled",false);
							switch($.trim(d[0])){
								case '1':
									showNotice(d[1],350);
									return false;
								break;
								case '2':
									showNotice(d[1]);
								break;
								default:alert(data);return false;
							}
						});
					}
                </script>
    {/literal}
    <div class="notice_msg">��ǰ���ֶһ�����Ϊ:{$curent_exchange_rate} ({$sitecfg.siteBase.rate_point.php188_point_rates}�ֿɶһ�1Ԫ) ��С�һ����Ϊ:{$sitecfg.siteBase.rate_point.php188_point_small_point}��<br />
      <b class="red">���ҽ������Ļ��������ڵ���ϵͳ�趨����С�һ���Ȳ��ܶһ�!</b> <br />
      ��������Ҫ�һ��Ļ�������
      <input type="text" value="" name="exchange_point" id="exchange_point_input_id" class="exchange_point_input form_input" />
      <input type="button"  value="�һ�" class="form_submit"  onclick="exchange_point(this);" />
      ��ȫ���һ���ǰ���ɻ��: <font>{$total_exchange_all}</font> </div>
    {/if} </div>
  <div class="clear"></div>
  {if $points}
  <div class="clear"></div>
  <table  class="table_list">
    <tr>
      <th>����</th>
      <th>ʱ��</th>
      <th>��ע</th>
    </tr>
    {foreach from=$points item=point}
    <tr>
      <td align="center">{$point.point}</td>
      <td align="center" nowrap="nowrap">{$point.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
      <td class="gray">{$point.msg}</td>
    </tr>
    {/foreach}
    </tr>
  </table>
  <div class="clear"></div>
  <div id="php188_page_pageurl"> {$pageurl} </div>
  {else}
  <div class="notice_msg">��ʱû�л��ּ�¼</div>
  {/if} </div>
