<?php exit('die'); ?>
{include file="member/widget/member_header.php"}
<div class="page_nav w980">{include file="nav.php"}</div>
<div class="h10"></div>
<div id="content" class="bg_gray w980">
<div class="clear spacer"></div>
<div class="findpass w980">
 {if $action == 'findpassone'}
<script type="text/javascript">
	$(document).ready(function(){
		$("#findpass").submit(function(){
			var name = $.trim($("#username").val());
			var unlen = name.replace(/[^\x00-\xff]/g, "**").length;
			if(empty(name)){
				$("#username").addClass("empty_input_val");
				$("#username").next().html("�û�������Ϊ��");
				return false;
			}
			if(unlen < 4){
				$("#username").next().html("�û������Ȳ���С��4λ");
				return false;
			}
			if(!chkstr(name)){
				$("#username").next().html("���������������ַ�");
				return false;
			}
			$(this).attr("action", $("#subaction").val());
			return true;
		});
	});
</script>
<div id="find_pass_one">
<form action="" method="post" id="findpass" autocomplete="off">
<table class="table_list">
<tr>
    <td class="one">�û�����</td>
    <td><input type="text" id="username" name="username"  class="ln form_input" /> <span class="red"></span></td>
</tr>
{if $findpassmode != ''}
    <tr>
    <td  class="one">�����һط�ʽ��</td>
        <td >
            <input type="radio" value="email" name="findmode" checked="checked" />��������
            {foreach from=$findpassmode item=fpm}
                {if $fpm == 'question'}
                    <input type="radio" value="question" name="findmode" />��ʾ����
                {/if}
            {/foreach}
        </td>
    </tr>
{/if}
    <tr>
        <td></td>
        <td><input type="submit" class="form_submit" value="�� ��" /></td>
    </tr>
</table>
</form>
</div> 
 <input type="hidden" value="{$subaction}" id="subaction"/>
{elseif $action == 'findpasstwo'}
<script type="text/javascript">
$(document).ready(function(){
	$("#php188findpasstwo").submit(function(){
		$("#php188findpasstwo").find("input").each(function(){
			if(empty($(this).val())){
				$(this).addClass("empty_input_val");
			}
		});
		var codenumber = $("#codenumber").val();
		if(empty(codenumber)){
			return false;
		}
		<!-- �õ�  ��ʽ-->
		findpassmode = $("#findpassmode").val();
		if(findpassmode == 'question'){
			<!-- ����� -->
			if(empty($.trim($("#answer").val()))){
				$("#answer").next().html("�𰸲���Ϊ��");
				return false;
			}
			<!-- ������ -->
			if(!checkPassWord()){
				return false;
			}
			if(!checkRePass()){
				return false;
			}
		}else{
			<!-- ����� -->
			var email = $("#email").val();
			if(empty(email)){
				$("#email").next().html("�������Ʋ���Ϊ��");
				return false;
			} 
			if(!checkemail(email)){ 
				$("#email").next().html("�������Ƹ�ʽ����ȷ");
				return false;
			}
		}
		$(this).attr("action", $("#subaction").val());
		return true;
	});
	<!-- ��֤���� -->
	$("#password").blur(function(){checkPassWord();});
	<!-- ��� ȷ�� ���� -->
	$("#repass").blur(function(){checkRePass();});
	<!-- ���� ��� -->
	function checkPassWord(){
		var password = $.trim($("#password").val());
		if(empty(password)){
			$("#password").next().html("���벻��Ϊ��");
			return false;
		}
		if(password.length < 6){
			$("#password").next().html("���벻��С��6λ");
			return false;
		}
		$("#password").next().html("");
		return true;
	}
	<!-- ��� ȷ�� ���� -->
	function checkRePass(){
		var repass = $.trim($("#repass").val());
		if(empty(repass)){
			$("#repass").next().html("ȷ�����벻��Ϊ��");
			return false;
		}
		var password = $.trim($("#password").val());
		if(password != repass){
			$("#repass").next().html("������������벻һ��");
			return false;
		}
		$("#repass").next().html("");
		return true;
	}
	$("#btnback").click(function(){
		location.href=$("#btnbackurl").val();
	});
});
</script>
<div class="find_pass_two">
<form action="" method="post" autocomplete="off" id="php188findpasstwo">

      <table class="table_list">
        <tr>
            <td class="one">�û�����</td>
            <td>
                {$username}
                <input  type="hidden" value="{$username}" name="username" />
            </td>
        </tr>
        {if $findpassmode == 'question'}
            <tr>
                <td class="one" > ���⣺</td>
                <td >
                    {$question}
                    <input type="hidden" class="ln form_input" value="{$question}" name="question" />
                </td>
            </tr>
            <tr>
                <td class="one">�𰸣�</td>
                <td>
                    <input type="text" name="answer" class="ln form_input"  id="answer"/>
                    <span class="red"></span>
                </td>
            </tr>
            <tr>
                <td class="one" >�����������룺</td>
                <td>
                    <input id="password" maxlength="20" type="password" class="ln form_input" name="password" />
                    <span class="red"></span>
                </td>
            </tr>
            <tr>
                <td class="one" >ȷ�����룺</td>
                <td>
                    <input id="repass" maxlength="20" class="ln form_input" type="password" name="repass" />
                    <span class="red"></span>
                </td>
            </tr>
        {else}
            <tr>
                <td class="one" >�������䣺</td>
                <td>
                    <input id="email" style="ime-mode: disabled;" class="ln form_input"  type="text" maxlength="30"name="email" />
                    <span class="red"></span>
                </td>
            </tr>
        {/if}
        <tr>
            <td class="one">��֤�룺</td>
            <td>
                <input maxlength="10" size="6" id="codenumber" type="text" onfocus="return $('#cap_img').click();" class="form_input ln" name="codenumber" />
                <span class="red"></span>
                <img id="cap_img" title="���������֤��" alt="���������֤��" style="cursor:pointer;" src="{$siteurl}captcha.php"   onclick="this.src='{$siteurl}captcha.php?rand='+Math.random()" />
            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type="submit" class="form_submit" value="�� ��" />  <input id="btnback" class="form_submit" type="button"  value="�� ��" />
            </td>
        </tr>
     </table>
     
     <input type="hidden" id="findpassmode" name="findmode" value="{$findpassmode}" />
 </form>
 <input type="hidden" id="btnbackurl" value="{$btnback}"  />
 <input type="hidden" id="subaction" value="{$subaction}" />
{/if}
</div>
<div class="clear"></div>
</div>
<div class="h10"></div>
{include file="member/widget/member_footer.php"}