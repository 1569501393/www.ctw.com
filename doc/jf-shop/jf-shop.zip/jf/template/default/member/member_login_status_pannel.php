<?php  exit('die');?>
{include file="member/member_login_panel.php"}