<?php exit('');/*��ҳ����ר��ΪAJAX����д�ĵ�¼ ��ע��*/ ?>
{include file="header_common.php"}
<style type="text/css">
body{ overflow:hidden;}
</style>
<div id="ajaxcall_member_main_pannel">
	<div class="ajax_login">
    	<h1 class="bar_tt">�û���½</h1>
        <div class="clear"></div>
        <div class="ajax_login_m_content">
        <form method="post" id="ajax_login_submit" action="{building_link model='member' action='login' http='false'}" autocomplete="off">
        	<table cellpadding="4" cellspacing="4" align="center">
            <tr>
            	<td class="r">ѡ���½���ͣ�</td>
                <td>
            <label><input type="radio" value="common"  checked="checked" name="login_type"/>(�û���)</label>
			<label><input type="radio" value="mobile"  name="login_type"/>(�ֻ���)</label>
            <label><input type="radio" value="email" name="login_type" />(����)</label>
</td>
            </tr>
            	<tr>
                	<td class="r">�û�����</td>
                    <td><input type="text" name="loginusername"  value="" maxlength="60" class="form_input login_must_in"/></td>
                </tr>
                <tr>
                	<td class="r">��&nbsp;&nbsp;�룺</td>
                    <td><input type="password" name="password" maxlength="20" class="form_input login_must_in login_clear" /></td>
                </tr>
                <tr>
                	<td class="r">��֤�룺</td>
                    <td><input type="text"  class="form_input_small login_must_in login_clear" id="login_cap"  name="codenumber" maxlength="6" onfocus="get_code(this);" /><img style="cursor:pointer; margin-bottom:-8px;"  width="100" height="25" src="{$siteurl}captcha.php?hash=0&rand=1&w=100&h=25" alt="���������֤��ͼƬ" title="���������֤��ͼƬ" onclick="get_code(this);"/></td>
                </tr>
                <tr>
                	<td colspan="4" align="center"><input type="submit" value="�� ½"  class="form_submit" /> <a href="{building_link model = 'member' action = 'findpass'}" target="_blank">��������?</a>  <a href="{building_link model = 'member' action = 'reactive'}" target="_blank">���¼���?</a></td>
                </tr>
            </table>
            </form>
            <script type="text/javascript">
				function get_code(obj){
					var link = '{$siteurl}captcha.php?hash=0&w=100&h=25&rand='+Math.random();
					var img = !empty($(obj).attr('src'))?true:false;
					if(img){
						$(obj).attr({"src":link});	
					}else{
						$(obj).next().attr({"src":link});	
					}
				}
            	$(function(){
					$("#ajax_login_submit").submit(function(){
						if(!check_form_is_empty('login_must_in'))return false;
						var self = $(this);
						$(this).ajaxSubmit(function(data){
								switch(data){
									case 'EMPTY_NAME':showNotice('�û���Ϊ��!');return false;
									break;
									case 'erro_answer':
										showNotice('��ȫ���ʴ���!');return false;
									break;
									case 'error_pass':
									
									case 'EMPTY_PASS':showNotice('����Ϊ�ջ����!');return false;
									break;
									case 'ERROR_CAP_CODE':
									   $("#login_cap").val('');return showNotice('��֤�����!');break;
									case 'NOT_EXIST_THIS_MEMBER':
									case 'not_exist':
										$(".login_clear").val('');showNotice('�û������������!');return false;
									break;
									case 'login_error':
										showNotice('��½ʧ��!');return ;
									break;
									case 'login_ok':
										try{
											window.parent._set_logins();
											window.parent._close_grd_window();
										}catch(e){}
									break;
									default:alert(data);
								}
						});
						return false;
					});
				});
            </script>
        </div>
    </div>
    <div class="ajax_register">
		<h1 class="bar_tt">�û�ע��</h1>
        <div class="clear"></div>
        <div class="ajax_pannel_ct_re">
        <form method="post" id="register_ajax_form" action="{building_link model='member' action='register' http='false'}" autocomplete="off">
        <table cellpadding="4" cellspacing="4">
        	<tr>
            	<td class="r">�û�����</td>
                <td> <input type="text" onblur="check_register_name(this);" name="username" value="" maxlength="25" id="register_name" class="form_input register_must_in r_remove"/></td>
                <td><font class="red1">*</font></td>
            </tr>
            <tr>
            	<td class="r">�趨���룺</td>
                <td> <input  type="password" name="first_pass" id="first_pass" onblur="check_pass(this);" value="" maxlength="20" class="form_input register_must_in r_remove"/>
</td>
                <td><font class="red1">*</font></td>
            </tr>
		<tr>
        	<td class="r">ȷ�����룺</td>
            <td><input type="password" id="rePass" name="repass" onblur="check_repass(this);" value="" maxlength="20" class="form_input register_must_in r_remove"/></td>
            <td><font class="red1">*</font></td>
        </tr>
        <tr>
        	<td class="r">E-MAIL��ַ��</td>
            <td><input type="text" onblur="check_emails(this);" id="register_email" name="email" value="" maxlength="50" class="form_input register_must_in r_remove"/></td>
            <td><font class="red1">*</font></td>
        </tr>
        <tr>
        	<td class="r">�ֻ��ţ�</td>
            <td><input type="text" id="user_mobile" maxlength="11" value="" class="form_input r_remove" onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" name="member_mobile" /></td>
            <td></td>
        </tr>
        <tr>
        <td class="r">��֤�룺</td>
        <td><input type="text" maxlength="6" id="register_cap" class="form_input_small register_must_in r_remove" name="codenumber" onfocus="get_code(this);" /><img  id="register_capp" style="cursor:pointer; margin-bottom:-8px;" width="100" height="25" onclick="get_code(this);" src="{$siteurl}captcha.php?hash=0&rand=2&w=100&h=25" alt="���������֤��ͼƬ" title="���������֤��ͼƬ" /></td>
        <td><font class="red1">*</font></td>
        </tr>
        <tr>
        	<td class="r">ע�����</td>
            <td><input name="agreement" checked="checked" value="agreement" id="is_agreement" type="checkbox" />�Ķ���ͬ��<a href="{building_link model='member' action='agreement'}" target="_blank" title="�û�ע��Э��">���û�ע��Э�顷</a></td>
            <td><font class="red1">*</font></td>
        </tr>
        <tr>
        	<td colspan="4"><input type="submit" value="ע ��" class="form_submit"/> 
            <!--<input onclick="window.open('{building_link model='member' action='reactive'}'"  type="button" value="���¼���" class="form_submit"/>-->
             </td>        </tr>
        </table>
        </form>
        <script type="text/javascript">
	var ajax_check_user = "{building_link model='member' action='checkusername' http='false'}";
	var ajax_check_email = "{building_link model='member' action='checkemail' http='false'}";
	var ajax_check_mobile = "{building_link model='member' action='ajaxPostCheckMobile' http='false'}";
	function _set(obj,notice){
		$(obj).parent().next().html('<font class="red1">'+notice+'</font>');$(obj).addClass('empty_input_val');return false;
	}
	function _ok(o){
		$(o).parent().next().html('<font class="gray">ok</font>');$(o).removeClass('empty_input_val');return true;
	}
function check_pass(o){var p = $(o).val();if(empty(p))return _set(o,'����Ϊ��!');if(p.length<6)return _set(o,'���볤�ȱ�����6λ����!');_set($("#rePass"),'����������һ������!');$("#p_hiden").val('0');return _ok(o);}
	function check_repass(o){
		var f_dom = $("#first_pass");
		if(!check_pass(f_dom)){_set(o,'����������һ������!');return false;}
		var f = f_dom.val();var r = $(o).val();
		if(f!=r)return _set(o,'�������벻һ��!');$("#p_hiden").val('1');
		return _ok(o);
	}
	function check_register_name(o){
	var n = $(o).val();if(empty(n))return _set(o,'������ע����û���!');if(n.length<4)return _set(o,'�û���������ڵ���4λ!');
		$.post(ajax_check_user,{username:n},function(data){
			switch($.trim(data)){
				case 'EMPTY_USERNAME':
					return _set(o,'������ע����û���!');	
				break;
				case 'SHORT_NAME':
					return _set(o,'�û���������ڵ���4λ!');	
				break;
				case 'HAS_EXIST':
					return _set(o,'������ͬ���û�!');	
				break;
				case 'NOT_ALLOW':
					return _set(o,'�벻Ҫʹ�������ַ�!');	
				break;
				default:return _ok(o);
			}
		})		
	}
	function check_emails(o){
		var e = $(o).val();
		if(empty(e)){return _set(o,'����Ϊ��!');}
		if(!checkemail(e)){return _set(o,'�����ʽ����!');}
		$.post(ajax_check_email,{email:e},function(data){
			switch($.trim(data)){
				case 'EMPTY_EMAIL':
					return _set(o,'����Ϊ��!');	
				break;
				case 'ERROR_EMAIL':
					return _set(o,'�����ʽ����!');	
				break;
				case 'HAS_EXIST':
					return _set(o,'������ͬ������,����!');	
				break;
				case 'NOT_ALLOW':
					return _set(o,'������������ע��!');	
				break;
				default:return _ok(o);
			}
		})
	}
        	$(function(){
				$("#register_ajax_form").submit(function(){
					if(!check_form_is_empty('register_must_in'))return false;
					var self = $(this);
					$(this).ajaxSubmit(function(data){
						data = $.trim(data);
						data = data.split('|');
						switch(data[0]){
							case 'NO_AGREE':showNotice('����ͬ��ע��Э��!');return ;
							break;
							case 'ERROR_CAP':showNotice('��֤�����!');$("#register_cap").val('');break;
							case 'TOO_SHORT_NAME':
								showNotice('�û�������!');$("#register_name").val('');return false;
							break;
							case 'ERROR_NAME':
							case 'NOT_ALL_USER':
								showNotice('ϵͳ�����������û����ֳ���!');$("#register_name").val('');return false;
							break;
							case 'ERROR_PHONE':
								showNotice('�ֻ������ʽ����!');$("#user_mobile").val('');return false;
							break;
							case 'HAS_EXIST_MOBILE':
								showNotice('������ͬ���ֻ�����!');$("#user_mobile").val('');return false;
							break;
							case 'HAS_EXIST_USER':
								showNotice('������ͬ���û���!');$("#register_name").val('');return false;
							break;
							case 'TOO_SHORT_PASS':
								showNotice('���볤�ȹ���!');$("#first_pass").val('');$("#rePass").val('');return false;
							break;
							case 'PASS_NOT_SAME':
								showNotice('�������벻һ��!');$("#first_pass").val('');$("#rePass").val('');return false;
							break;
							case 'EMPTY_MAIL':
							case 'ERROR_MAIL':
								showNotice('����Ϊ�ջ��ʽ����!');$("#register_email").val('');return false;
							break;
							case 'HAS_EXIST_MAIL':
								showNotice('������ͬ�����ַ!');$("#register_email").val('');return false;
							break;
							case 'ERROR':
								showNotice('SYS_ERROR');
							break;
							case 'NEED_CONFIRM':
							case 'OK':
								if(data[1]){
									$(data[1]).appendTo(document.body);
								}
								if(data[0]=='OK'){
									alert('ע��ɹ�!');
									_set_logins();
								}else if(data[0] =='NEED_CONFIRM'){
									alert('ע��ɹ�,����������伤�������˻�!');
								}
								$(".r_remove").val('');
								show_nopay_car();
								try{
									window.parent._set_logins();
									window.parent._close_grd_window();
								}catch(e){}
								return ;
							break;
							default:alert(data);
						}
					});
					return false;
				});
			});
        </script>
        </div>
    </div>
    <div class="clear"></div>
</div>
{insert_template_scripts_root files='shopdata/js/jquery.form.js'}