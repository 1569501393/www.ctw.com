<?php exit('die'); ?>
{if $smarty.session.php188curruser == ''}����,��ӭ����!&nbsp;<a href="{building_link model='member' action='login'}" class="yellow" title="{$site_name}�û���¼">��¼</a> <a href="{building_link model='member' action='register'}" class="yellow" title="{$site_name}�û�ע��">���ע��</a>{else}
<script type="text/javascript">
	var quit_url = "{building_link model='member@membermanage' action='memberquit' param='quittype=quit'}"+connetor+'jsoncallback=?';
	var opts = {rid:{$region_id|default:'0'}};
	function ajaxQuit(){
		$.getJSON(quit_url,opts,function(data){
			$("#PHP188_member_panel").html(data.result);show_nopay_car();	
		});
	}
</script>��ӭ��,{if $smarty.session.php188curruser.mem_name}{ $smarty.session.php188curruser.mem_name}{else}{ $smarty.session.php188curruser.mem_username}{/if}&nbsp;<a href="{building_link model='member@membermanage'}">[�û�����]</a>&nbsp;<a href="javascript:;" onclick="ajaxQuit();">�˳�</a>
{/if}