{include file='member/widget/member_login_header.php'}
<div id="member_login_register_pannel" class="w980">
  <script type="text/javascript">
function change_code(obj){
	obj.src='{$siteurl}captcha.php?hash=0&w=100&h=25&rand='+Math.random();
}
$(function(){
	$(".table_form td:even").addClass('login_table_one');
	$(".table_form td:odd").addClass('login_table_two');
});
</script>
<div class="w980 page_nav">{include file="nav.php"}</div>
<div class="h10 w980"></div>
 <div id="m_main"> {if $action eq 'login' || $action eq 'register'} 
    {include file="member/widget/login.php"}
    {include file="member/widget/register.php"}
    {/if} 
   </div>
</div>
<div class="d_line"></div>
<div class="h10"></div>
{include file='member/widget/member_login_footer.php'}