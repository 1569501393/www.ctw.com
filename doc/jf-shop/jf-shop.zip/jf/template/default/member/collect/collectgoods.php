<?php  exit('die');?>
<div id="php188_goods_collect">
  <script type="text/javascript">
	$(function(){
		checkAllFormData('check_all','check_collect');
		$("#do_collect_goods_list").submit(function(){
			var c = get_checkbox_val('check_collect');
			if(!c){
				showNotice('��ѡ��Ҫ����������!');return false;	
			}
			$(this).ajaxSubmit(function(data){
				switch($.trim(data)){
					case "1":
						showNotice("��½��ʱ�������˳����������µ�½");
						break;
					case "2":
						showNocie("����û���ղ���Ʒ");
						break;
					case "3":
						showNotice("��������ѡ����Ҫɾ������Ʒ");
						break;
					case "4":
						showNotice("ɾ��ʧ��");
						break;
					default:
						showNotice("ɾ���ɹ�");
						window.location.reload();
						break;
				}
			});
			return false;
		});		
	});
</script>
  <div class="spacer"></div>
  {if $result.data}
  <form action="{building_link model='member@collect' action='deletecollect'}" method="post" id="do_collect_goods_list">
    <table class="table_list">
      <tr>
        <th><input type="checkbox" id="check_all" class="check_all" /></th>
        <th>����</th>
        <th>�۸�</th>
        <th>����</th>
      </tr>
      {foreach from=$result.data item=cellect}
      <tr>
        <td align="center"><input class="check_collect" type="checkbox" value="{$cellect.goods_id}" name='collid[]' /></td>
        <td nowrap="nowrap">{$cellect.goods_name|truncate:'40'}</td>
        <td class="center" nowrap="nowrap">{$cellect.goods_shop_price}</td>
        <td align="center" class="center" nowrap="nowrap"><a href="{$cellect.goods_url}" target="_blank" >����</a>   <a name="{$cellect.goods_buy_url}" onclick="php188_goods_tocart(this, {$cellect.goods_id})" href="javascript:;">���빺�ﳵ</a></td>
      </tr>
      {/foreach}
      <tr>
        <td colspan="5"><div class="margin_15"> {if $result.data}
            <input type="submit" class="form_submit"  value="����ɾ��" />
            {/if} </div></td>
      </tr>
    </table>
    <div id="php188_collect_pageurl">{$result.page}</div>
    {else}
    <div class="notice_msg">�޿�������!</div>
    {/if}
    <input type="hidden" name="page" id="curpage" value="{$curpage}"/>
  </form>
</div>
