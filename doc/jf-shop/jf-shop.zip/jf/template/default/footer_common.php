<?php exit('die'); ?>
{insert_template_scripts files='js/window.js'}
<script type="text/javascript">
function show_mail_sub_item(obj){$(document).grd_window({title:$(obj).html(),url:"{building_link model='member@collect' action='mailsubscribe'}",width:450,height:200,iframe:true});}
function send_site_msg(obj){ $(document).grd_window({title:$(obj).html(),url:"{building_link model='default' action ='book'}",width:600,height:300,iframe:true});}
$(function(){
	$(".table_common tr:last td").css({"border":'none'});
	show_nopay_car();  _set_logins(); 
});
var kypLazy= new lazyLoad();
</script>
{$auto_do_plugin}
<!--<div class="center w980" style="text-align:left;">{debug_info show_log='true' file='true'}</div>-->
<script type="text/javascript" src="{building_link model='plugin' action='kefu'}"></script>
</body>
</html>