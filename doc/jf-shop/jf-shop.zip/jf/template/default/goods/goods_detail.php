<?php exit('die'); ?>
{include file="goods/widget/header.php"}
<form method="post" action="{$ajax_call_goods_cart}" id="ajax_call_goods_cart">
<div class="middle"><!--����-->
    <div class="middle_left fl"><!--���-->
    {get_rands_goods cate_id='$category_id' limit='4' assign='goods_data'}
    {if $goods_data}
    <div class="Product">
        <h3 class="title2">�����ܻ���Ҫ������Ʒ</h3>
    {include file="goods/widget/small/goods_bar_pannel.php"}
    </div>
    {/if}
    <!--#ͬ��Ʒ��-->
    {include file="goods/widget/small/the_same_category_brand.php"}  
    {assign var='goods_data' value=''}
    {get_goods_relative_goods goods_id=$goods_id limit='4' assign='goods_data'}
    {if $goods_data}
    <div class="Product mt">
        <h3 class="title2">�����Ʒ</h3>
    {include file="goods/widget/small/goods_bar_pannel.php"}
    </div>
    {/if}
    <!--#ͬ��������Ʒ-->
    {get_goods limit='4' assign = 'goods_data' cate_id='$category_id'}
    {if $goods_data}
    <div class="Product mt">
        <h3 class="title2">ͬ��������Ʒ</h3>
    {include file="goods/widget/small/goods_bar_pannel.php"}
    </div>
    {/if}    
    <!--#ͬƷ��������Ʒ-->
    {assign var='goods_data' value=''}
    {if $brand_id}
   	{get_goods limit='4' assign = 'goods_data' brand_id='$brand_id'}
    {if $goods_data}
    <div class="Product mt">
        <h3 class="title2">ͬƷ��������Ʒ</h3>
    {include file="goods/widget/small/goods_bar_pannel.php"}
        </div>
    {/if}
    {/if}
    <div class="Product mt">
      <h3 class="title2">��ʷ��¼<samp class="show_clear_log fr"><a style="color:#000;" href="javascript:clear_log(this);">���</a></samp></h3>
      <div id="ajax_call_visted_log"></div>
    </div>
    <script type="text/javascript">
	var none = '<samp class="gray">&nbsp;���޼�¼!</samp>';
    	$(function(){
			$.get("{building_link model='goods' action='vistedLog'}",function(data){
				var string = data = data?data:none;
				$("#ajax_call_visted_log").html(string);
			});
		});
		function clear_log(){
			$.get('{building_link model="goods" action="clear"}',function(){
				$("#ajax_call_visted_log").empty().html(none);
			});
		}
    </script>    
    </div><!--��� end-->
    <div class="middle_right fr"><!--�Ҳ�-->
    <!--#�⼸���Ǳ����� �м�-->
    <input  type="hidden" value="{$goods_detail.goods_name}"  id="call_goods_names"/>
    <input type="hidden" value="{$goods_id}" id="curent_goods_id" />
    <input type="hidden" value="0" id="ajax_call_sale_log_input" />
    <input type="hidden" value="0" name="olny_to_cart"  id="olny_to_cart"/>
    <input type="hidden" value="{$goods_id}" name="goods_id" />    
    <script type="text/javascript">
	   var ajax_call_back_cart_url = "{building_link model='goods@flow' action='callBackCart'}";
	$(document).ready(function(){
      click_show = function(obj){
	            $(".thumb_visted").removeClass('thumb_visted');
	            $(this).addClass('thumb_visted');
	       var source  = $(obj).attr('name');
	       var items = source.split('|');
	       var small_pic = items[0];
	       var water = items[1];
	       var source = items[2];
	           $("#goods_source_file").attr({"href":source});
	           $("#php188_picture_thumb").fadeOut("slow",function(){
	           $(this).fadeIn().attr({"src":water});
	       });
    }
    add_to_cart = function(){
	          $("#olny_to_cart").val('0');
	          $("#ajax_call_goods_cart").submit();
    }    
    _to_cart = function(obj,id){
	          $("#olny_to_cart").val('1');
	          $("#ajax_call_goods_cart").submit();
    }
    $(function(){
         $(".jqzoom").jqueryzoom({
			  xzoom:400,
	          yzoom:400,
	          offset:10,
	          position:"right",
	          preload:1,
	          lens:1
         });
         $("#ajax_call_goods_cart").submit(function(){
		    var o = $("#has_fixed_goods_data");
		     if (o.size() && empty($(o).val())){
			    window.parent.showNotice('����ѡ��ͬ���ͺ�!');
			 return false;
		}	
		$(this).ajaxSubmit(function(data){
			 data = data.split('|');
				switch(data[0]){
				   case 'ERROR':
						showNotice('��������!���޸���Ʒ����!'); return false;
				   break;
				   case 'NEED_XUNJIA':
						showNotice('����Ʒ����ֱ������,��ֱ����ϵ������Ա!');
					break;
					case 'HAS_OTHER_CHECK':
						showNotice('����ѡ����Ʒ�ͺ�!');
					break;
					case 'NOT_EXIST':
						showNotice('�޿�����Ʒ����!'); return false;
					break;
					case 'UNDER_STOCK':
					case 'LOW_STOCK':
						if(confirm('��治��,��Ҫ��дȱ���Ǽ���?')){
							call_out_stock_pannel();
							return ;		
						}
						break;
					case 'OK':
						window.location.href=data[1];
					break;
					case 'TO_CART_OK':
						var call_back_cart_obj = $("#_to_cart_imgs");
						return call_member_cart_info(call_back_cart_obj);
					break;
					default:alert(data);
				}
		});
		return false;
	});
  });
});
</script>
        <div class="sy_Product">
            <div class="sy_title"><a href="javascript:;">��Ʒ����</a>
            <span></span>
            <a href="{building_link model='goods' action='detail' param="id=$goods_id"}">{$goods_detail.goods_name}</a>
        </div>
     </div>
     
     <div class="details_box">
            <div id="preview" class="fl"><!--ͼƬչʾ-->
                <div class="jqzoom" id="spec-n1"><img onload="setimg(this,350,350)" src="{$goods_detail.goods_end_detail_pic}" jqimg="{$goods_detail.goods_end_detail_pic}" width=350></div>
                <div id="spec-n5">
                    <div class="control" id="spec-left"><img src="{$template_url}images/left.gif" /></div>
                    <div id="spec-list">
                    
                        <ul class="list-h">{if $goods_albums_data}
                        {foreach from=$goods_albums_data item=album key=k name=albums}
                            <li><img onload="setimg(this,50,50)" src="{$siteurl}picture.php?s={$album.album_small_pic}&w=50&h=50" height="50"  name="{$album.ablum_end_detail_big_pic}"/> </li>
                        {/foreach}{else}<li style="width:50px;height:50px;"></li>{/if}
                        </ul>
                    
                    </div>
                    <div class="control" id="spec-right"><img src="{$template_url}images/right.gif" /></div>
                </div>
      <div class="clear"></div>
      <span id="ckepop" style="padding-top:10px;display:block"> 
      <a href="http://www.jiathis.com/share/?uid=1500744" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank">������:</a> 
      <a class="jiathis_button_qzone">QQ�ռ�</a> <a class="jiathis_button_tsina">����΢��</a></span>
      <span class="bigImg"><em></em><a class="view" href="{building_link model='goods' action='showThumb' param="id=$goods_id"}"  target="_blank">�鿴��ͼ</a>
      <a class="view" href="javascript:;" name="{$goods_detail.goods_collect_url}" onclick="php188_goods_collect(this,'{$goods.goods_id}');">�����ղ�</a></span>
            </div><!--ͼƬչʾ end-->
            {if $goods_albums_data}
 <script type="text/javascript">
			$(function(){
			$("#spec-list").jdMarquee({
	        deriction:"left",
	        width:350,
			height:56,
			step:2,
			speed:4,
			delay:10,
			control:true,
			_front:"#spec-right",
			_back:"#spec-left"
			});
			$("#spec-list img").bind("mouseover",function(){
	        var src=$(this).attr("name");
			$("#spec-n1 img").eq(0).attr({
			src:src.replace("\/n5\/","\/n1\/"),jqimg:src.replace("\/n5\/","\/n0\/")
	});
	$(this).css({"border":"2px solid #ff6600","padding":"1px"});
}).bind("mouseout",function(){
	$(this).css({"border":"1px solid #ccc","padding":"2px"});
	});
})
</script>
            {/if}
			<script src="{$template_url}js/lib.js" type="text/javascript"></script>
            <script src="{$template_url}js/lib1.js" type="text/javascript"></script>
        	<div class="details_list fr">
            	<div class="details_1">
                	<h2 style="color:#000;"><a href="{building_link model='goods' action='detail' param="id=$goods_id"}">{$goods_detail.goods_name}</a></h2>
                    <p>��Ʒ��ţ�<samp id="goods_sn_data">{if !$goods_spec_extend_data}{$goods_detail.goods_sn}{else}����ѡ���ͺ�{/if}</samp> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;Ʒ  �ƣ�<em>{if $brand.data.brand_name} <a class="red b" href="{$brand.link}" target="_blank"><b>{$brand.data.brand_name}</b></a>{else}��Ʒ��{/if}</em></p>
                    {if !$is_xunjia}
                       {if $goods_detail.only_use_point eq '1'}
                           <p>�һ�������֣�<strong>{$goods_detail.goods_point_fee}��</strong></p>
                       {else}
                           <p>�̳Ǽۣ�<strong>{$goods_detail.goods_shop_price}</strong> {if $goods_detail.goods_point_fee >0}+ {$goods_detail.goods_point_fee}��{/if}</p>{/if}
                    {/if}
                    
                    {if $goods_detail.goods_chandi_id}
                    <p>���أ�<span><a href="{$goods_detail.chandi_data.link}" class="red" target="_blank">{$goods_detail.chandi_data.region_ename}</a></span></p>{/if}
                    {if $region_data}
                    <p>������<span><a href="{$region_data.link}" class="red" target="_blank">{$region_data.alias_name}</a></span></p>{/if}
                    <p>��    �ͣ� ���ҳе��˷�</p>
                    <!--#����-->
                    {if $goods_is_promotion && !$is_xunjia}
                    <script type="text/javascript">
			        var startTime = new Date();
			        var EndTime='{$promotion_end_time}';
			        function GetRTime(){
				    var NowTime = new Date();
				    var nMS =EndTime - NowTime.getTime();
				    var nD =Math.floor(nMS/(1000 * 60 * 60 * 24));
				    var nH=Math.floor(nMS/(1000*60*60)) % 24;
				    var nM=Math.floor(nMS/(1000*60)) % 60;
				    var nS=Math.floor(nMS/1000) % 60;
				    document.getElementById("RemainD").innerHTML=nD;
				    document.getElementById("RemainH").innerHTML=nH;
				    document.getElementById("RemainM").innerHTML=nM;
				    document.getElementById("RemainS").innerHTML=nS;
				    setTimeout("GetRTime()",1000);
			        }
			        window.onload=GetRTime;
			        </script>
                    <p><b>������:</b>{$goods_detail.goods_promotion_price}&nbsp;&nbsp;<span class="red b">ʣ��<b id="RemainD"></b>��<b id="RemainH"></b>ʱ<b id="RemainM"></b>��<b id="RemainS"></b>��</span></p>
        {/if}
        <!--#��������-->
                    <p>���ʽ��<em>֧����������</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em id="php_has_sale_numbers"></em></p>
                    <p>��Ʒ���֣�<img src="{$template_url}images/star/{$comment_data.commentaint}.jpg" />&nbsp; {$comment_data.commenta|default:'0'}��&nbsp;<a href="javascript:;">(����{$comment_data.totalpl.T}������)</a></p>
                </div>
                <div class="details_2">
                <!--��չ���԰�-->
                {if $goods_detail.bind_parame}
                {foreach from=$goods_detail.bind_parame item=b}
                <p><samp>{$b.key}��</samp>{$b.value}</p>
                {/foreach}
                {/if}
                <!--#��չ���԰󶨽���-->
                {if $goods_wholesale && !$goods_is_promotion}
                <div id="site_goods_butch_goods">
                <table class="table_list" cellpadding="0" cellspacing="0">
                <tr>
                  <th>��������</th>
                  <th>�����ܼ۸�</th>
                </tr>
                {foreach from=$goods_wholesale item=w}
                <tr>
                  <td>{$w.num1} �� {$w.num2}</td>
                  <td>{$w.price}</td>
                </tr>
                {/foreach}
              </table>
            </div>
           {/if}
           <!--#��Ʒ����-->
        {if $is_zenpin && $zenpin_data}
        <div class="goods_zenpin_append_data append_call_data" id="goods_zenpin_append">
          <h3>������Ʒ</h3>
          {foreach from=$zenpin_data item='list'}
          <p><a href="{$list.goods_url}" target="_blank" title="{$list.goods_name} {$list.goods_alias_name}" class="yahei">{$list.goods_name} <span>{$tlist.goods_alias_name}</span></a></samp></p>
          {/foreach} </div>
        {/if}
        <!--#��Ʒ��������-->        
        
        <table cellspacing="0" cellpadding="0" width="100%" border="0">
          <tbody><!--#��Ʒ��񸽼�����--->
          {if $goods_spec_extend_data}
                 <script type="text/javascript">
                	function fix_spec_extend_goods(obj,id,sn,stock){
						if(stock<=0){
							$("#show_buy_nums").hide();	
							$("#no_goods_can_pay").show();
							if(confirm('��治��,��Ҫ��дȱ���Ǽ���?')){
								call_out_stock_pannel();
								return ;		
							}
						}else{
							var o = $("#has_fixed_goods_data");
							$(o).val(id);
							$("#goods_sn_data").html(sn);
							$("#goods_out_stock_spec").html(stock);
							$("#goods_spec_extend_data").removeClass('curent_goods_select_spec');
							$(obj).addClass('curent_goods_select_spec');
							$("#show_buy_nums").show();	
							$("#no_goods_can_pay").hide();
						}
					}
                </script>
              <input type="hidden" value=""  id="has_fixed_goods_data" name="goods_spec_extend_id"/>
             <tr> 
                <td align="right" width="20%">�ߡ����룺</td>
                   <td>
                      <div class="Change_td1">
                      {foreach from=$goods_spec_extend_data item='spec'}
                      {foreach from=$spec.son_data  item='son'}<a href="javascript:;" onfocus="this.blur();" class="{if $son.goods_stock<=0} goods_spec_no_goods{/if}" onclick="fix_spec_extend_goods(this,'{$son.id}','{$son.goods_sn}','{$son.goods_stock}');">{$son.prefix_name}{if $son.prefix_alias_name}/{$son.prefix_alias_name}{/if}</a>{/foreach}
                       {/foreach}
                        </div>
                       </td>
                     </tr>
                   <tr><td colspan="2" height="20"></td></tr>
                 {/if}
                 <!--��չ���-->
                 {if $goods_detail.spec_main_data}                           
                            <tr> 
                                <td align="right">��ɫ���ࣺ</td>
                                <td>{if $goods_detail.spec_main_data.spec_display eq 'select'}
                                    <!--#����-->
                                    <select class="spec_fix_select" onchange="window.location.href=this.value;">
                                    {foreach from=$goods_detail.extend_spec_goods_data item='spec'}
                                    <option value="{$spec.goods_url}" {if $goods_detail.goods_id eq $spec.goods_id}  selected="selected" {/if}>{$spec.goods_spec_extend_name}</option>{/foreach}</select>
                                    {elseif $goods_detail.spec_main_data.spec_display eq 'radio'}
                                    <div class="Change_td2">
                                    {foreach from=$goods_detail.extend_spec_goods_data item='spec'}
                                    <input type="radio" onclick="window.location.href=this.value;" value="{$spec.goods_url}" {if $goods_detail.goods_id eq $spec.goods_id}  checked="checked" {/if} />
                  <samp>{$spec.goods_spec_extend_name}</samp>{/foreach}
            </div>{else}<div class="Change_td2">{foreach from=$goods_detail.extend_spec_goods_data item='spec'}<a href="{$spec.goods_url}"  class="{if $goods_detail.goods_id eq $spec.goods_id} curent_goods_select_spec {/if} goods_spec_fix">{$spec.goods_spec_extend_name}</a> {/foreach}
                                	</div>{/if}
                                    <div class="clear" style="height:10px;"></div>
                                    <div class="spec_extend_fixed">��ѡ"{$goods_detail.goods_spec_extend_name}"</div>
                                    {/if}
                                </td>
                            </tr>
                            <tr><td colspan="2" height="20"></td></tr>
                            <!--#ѯ���жϿ�ʼ-->
                            {if !$is_xunjia}
                            <tr> 
                                <td align="right">����������</td>
                              <td class="buynum"><p class="fl"><input onkeyup="value=value.replace(/[^\d]/g,'')" readonly="readonly" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" type="text" name="number" maxlength="2"  class="chang_bt" value="{$buy_num}" id="goods_buy_total_num" /></p>
                              <p class="jia"><a href="javascript:;" class="d_add"><img src="{$template_url}images/up.jpg"/></a><a href="javascript:;" class="d_cline"><img src="{$template_url}images/down.jpg"/></a></p>
             <script type="text/javascript">
				$(function(){
					var o = $("#goods_buy_total_num");
					$(".d_cline").click(function(){
						 var v = parseInt($(o).val());
						 var vv = v>=1?parseInt(v-1):1;
						 $(o).val(vv<=1?1:vv);
					});
				 	$(".d_add").click(function(){
						var v = parseInt($(o).val());
						 var vv = v>=1?parseInt(v + 1):1;
						 $(o).val(vv>=99?99:vv);
					});
				});
            </script>&nbsp;��&nbsp;<em style="color:#868686; line-height:29px;">({if !$goods_spec_extend_data}{if $goods_detail.goods_stock>0}��棺{$goods_detail.goods_stock} {$goods_detail.goods_danwei|default:'��'}{else}��ʱȱ��{/if}{else}<samp id="goods_out_stock_spec">����ѡ���ͺ�</samp>{/if}<div id="no_goods_can_pay" style="display:none;">ȱ��</div>)</em></td>
                          </tr>
                        	<tr><td colspan="2" height="20"></td></tr>
                            <tr>
                            	<td colspan="2">
                                	&nbsp;&nbsp;&nbsp;&nbsp;
                                	<a href="javascript:;"  onclick="add_to_cart();"><img src="{$template_url}images/bt_1.jpg" /></a>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <a href="javascript:;"  name="{$goods_detail.goods_buy_url}" id="_to_cart_imgs" onclick="_to_cart(this,'{$goods_id}');"><img src="{$template_url}images/bt_2.jpg" /></a>
                                </td>
                            </tr>
                            {else}
                            <tr><td colspan="2">����Ʒ����ֱ�ӹ���,����ϵ�ͷ�ѯ��!</td></tr>
                            {/if}
                        </tbody> 
                    </table>
                </div>	
          </div>	
          <div class="clear"></div>
        </div>
        <!--#��װ���ݴ���-->
        {if $is_taozhuang && $taozhuang_data}
    <div class="taoz taozhuang_append_data append_call_data" id="goods_taozhuang_append">
          <h3>����װ����������Ʒ <samp class="yahei" style="font-size:12px; font-weight:normal;">����ʡ��{$goods_detail.taozhuang_saved_money|money_format}</samp></h3>
             <ul class="taozimg">
             {foreach from=$taozhuang_data item='tlist' key=key}
                <li>
                  <p class="img"><img src="{$siteurl}{$tlist.goods_detail_pic}" width="120" height="100" onload="setimg(this,120,100);"/></p>
                   <br><a href="{$tlist.goods_url}" target="_blank" title="{$tlist.goods_name} {$tlist.goods_alias_name}">{$tlist.goods_name|truncate:'5':'...'}</a><br><em>�ۼۣ�{$tlist.goods_shop_price}</em>
                   <span class="psnjia">��</span>   
                </li>
                {/foreach}
        </ul>
          
      </div>
        {/if}
    <!--#��װ���ݽ���-->
   		<div class="Tab3"><!--ѡ�-->
            <div class="Menubox3">
                <ul>
                    <li id="two1" onclick="setTab('two',1,2)" class="hover">��Ʒ����</li>
                    <li id="two2" onclick="setTab('two',2,2)">�ۺ����</li>
                </ul>
            </div>
            <div class="Contentbox3">  
                <div id="con_two_1" class="tab_con">
                  {if $goods_detail.goods_contents}{$goods_detail.goods_contents}{else}�޿�������!{/if}	
                </div>
                <div id="con_two_2" class="tab_con" style="display:none">
                  {if $goods_detail.goods_after_service}{$goods_detail.goods_after_service}{else}����Ʒ�ۺ����˵��!{/if}
                </div>
            </div>
        </div><!--ѡ� end-->
       
        <!--start goods_getbook-->
        <div class="comments">
        	<h3><span>��Ʒ����</span></h3>	
        	<div class="comments_1 mt">
       	    <h4><span class="more2">���д�ּ����۶����Լ��������Ʒ</span>��Ʒ���ۣ���<font color="#792f76">{$comment_data.totalpl.T}</font>���û���<em>�ۺ�����</em>&nbsp;<img src="{$template_url}images/star/{$comment_data.commentaint}.jpg" /></h4>		
           		<div class="fs fl">������<br /><strong>{$comment_data.commenta * 10}%</strong></div>
                <div class="pj_left fl">
                    <div style="height:30px;">
                        <div style="float:left;">�ۺϣ�</div><div class="tp_1"><p style="width:{$comment_data.commenta * 10}%;" class="tp_hover"></p><span>{$comment_data.commenta * 10}%</span></div>
                    </div>
                    <div style="height:30px;">
                        <div style="float:left;">��ۣ�</div><div class="tp_1"><p style="width:{$comment_data.commentb * 10}%%;" class="tp_hover"></p><span>{$comment_data.commentb * 10}%</span></div>
                    </div>	
                    <div style="height:30px;">
                        <div style="float:left;">���ʣ�</div><div class="tp_1"><p style="width:{$comment_data.commentc * 10}%%;" class="tp_hover"></p><span>{$comment_data.commentc * 10}%</span></div>
                    </div>	
                </div>
                <div class="pj_left fl">
                    <div style="height:30px;">
                        <div style="float:left;">�ۺ����֣�</div><div style="float:left;"><img src="{$template_url}images/star/{$comment_data.commentaint}.jpg" /></div>
                    </div>
                    <div style="height:30px;">
                        <div style="float:left;">������֣�</div><div style="float:left;"><img src="{$template_url}images/star/{$comment_data.commentbint}.jpg" /></div>
                    </div>	
                    <div style="height:30px;">
                        <div style="float:left;">��&nbsp;��&nbsp;&nbsp;�ȣ�</div><div style="float:left;"><img src="{$template_url}images/star/{$comment_data.commentcint}.jpg" /></div>
                    </div>	
                </div>
                <div class="dp_bt fl">
                	���ѹ��������Ʒ<br /><br />
                    <a href="javascript:;" onclick="window.showWindow('��Ʒ����','{building_link model="member@comment" action="addcomment" param="id=$goods_id"}',800,450,false);"><img src="{$template_url}images/bt_5.jpg" /></a>
                </div>
            	<div class="clear"></div>
            </div>
                <div id="ajax_call_comment_data">���ݼ�����...</div>
            </div>  
        <script type="text/javascript">
			var callurl = "{building_link model='member@comment' action='comment' param="id=$goods_id"}";
			$.ajax({type:'GET',url:callurl,data:'',success:function(data){
			     $("#ajax_call_comment_data").html(data);
			}});
        </script>
        <!--end goods_getbook-->
        <!--start Anser_getbook-->
        <div class="comments mt">
            <h3><span>��Ʒ��ѯ</span></h3>
            <div class="comments_1 mt">
                <h4><a href="javascript:;" onclick="window.showWindow('��������','{building_link model="member@comment" action="askcomment" param="id=$goods_id"}',800,315,false);" class="wytw">��Ҫ����</a>�������ʣ���<font color="#792f76">{$askcomment_data.T}</font>����</h4>   
                <div id="ajax_call_ansercomment_data">���ݼ�����...</div>
            <div class="clear"></div>
            </div>
        </div>     
        <script type="text/javascript">
			var callanserurl = "{building_link model='member@comment' action='goodsanswer' param="id=$goods_id"}";
			$.ajax({type:'GET',url:callanserurl,data:'',success:function(data){
			     $("#ajax_call_ansercomment_data").html(data);
			}});
        </script>
        <!--end ansergetbook-->
        {get_goods_sales_log limit='10' goods_id=$goods_id  assign='doms'}
        {if $doms}
        <div class="comments mt">
            <h3><span>�����¼</span></h3>	
        	<div class="gmjl">            	
                <p>����ɽ���¼</p>                
            	<table cellspacing="0" cellpadding="0" width="100%" border="0">
                    <tbody> 
                        <tr align="center" style="background:url({$template_url}images/bg5.jpg) repeat-x;"> 
                            <td>���</td>
                            <td>������˫��</td>
                            <td>������Ԫ��</td>
                            <td>�ɽ�ʱ��</td>
                            <td>״̬</td>
                        </tr>
                        {foreach from=$doms item="cj" key=key}
                        <tr align="center" bgcolor="#ffffff"> 
                            <td>{$cj.format_user}</td>
                            <td>{$cj.goods_total}</td>
                            <td>{$cj.goods_shop_price}</td>
                            <td>{$cj.add_time|date_format:"%Y-%m-%d %H:%M:%S"} </td>
                            <td>�ɽ�</td>
                        </tr>
                        {/foreach}
                    </tbody> 
                </table>
            </div>
        </div>
        {/if}
    </div><!--�Ҳ� end-->
    <div class="clear"></div>
</div><!--���� end-->
</form>
<!--#����-->	
<script type="text/javascript">var jiathis_config = {"data_track_clickback":true};</script>
<script type="text/javascript" src="http://v1.jiathis.com/code/jia.js?uid=1500744" charset="utf-8"></script>
<!--#������վ�ײ���Ϣ-->
{insert_template_scripts files='js/top.js'}
{include file="goods/widget/footer.php"}