<?php exit('die'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset={$outputchar|default:'gbk'}" />
{if $meta_title}<meta name="title" content="{$meta_title}"/>{/if}
<meta name="keywords" content="{$keywords}" />
<meta name="description" content="{$description}" />
<title>{$title}-���Ԥ��</title>
<link rel="shortcut icon" href="{$template_url}/favicon.ico" type="image/x-icon">
{if $xml}<link rel="alternate" type="application/rss+xml" title="{$title}" href="{$xml}">{/if}
{insert_template_scripts_root files='shopdata/js/jquery-1.3.2.min.js'}
<script type="text/javascript" src="{$template_url}js/global.js"></script>
<script type="text/javascript">
var site_url = "{$siteurl}";
var part_url = "{$part_url}";
var tpl_url = '{$template_url}';
var memberlanding = "{building_link model='member' action ='loginajax' http='false'}";
var member_login_url = "{building_link model='member' action = 'showLoginRegister'}";
var ajax_call_compare_data_url = "{building_link model='goods' action='ajaxCallJson' http='false'}";
var call_out_stcok_link = "{building_link model='outstock' action = '' http='false'}";
var goods_submit_compare_url = "{building_link model='goods' action='compare' http='false'}";
var ajax_to_cart = "{building_link model='goods@flow' action='cart' http='false'}";
var connetor = '{$connetor}';
var no_pay_order="{building_link model='goods@flow' action='nopayorderlist'}"+connetor+'iframe=1';/*δ���㶩��*/
var befor_pay_order="{building_link model='goods@flow' action='countgoods'}";/*ȥ���㶩��*/
{foreach from=$lang.js_languages key=key item=item}var {$key} = "{$item}";{/foreach}
</script>
{literal}
<style type="text/css" media="screen">
*{ font-size:12px; margin:0px; padding:0px;}
em{ font-style:normal;}
body,div,body,h1,h2,h3,h4,h5{ font-size:12px; margin:0px; padding:0px;}
.clear{ clear:both;}
a{ font-size:14px; color:#575757; text-decoration:none;}
img{ border:none;}
body{background:#f7f7f7;}
.Pro_Info{text-align:center;padding:10px 0;border-bottom:1px solid #ccc;}
.Pro_Info h1 em{font-size:12px;color:#999;font-weight:normal;}
.Pro_Info h1 a:link,.Pro_Info h1 a:visited{color:#005aa0;}
.Pro_Images{padding-top:10px;}
.Pro_Images img{display:inline;width:130px;height:98px;margin:0 5px;border:1px solid #ccc;filter:alpha(opacity=30);opacity:0.3; cursor:pointer;}
.Pro_Images .active{filter:alpha(opacity=100);opacity:1;border-color:#999;}
.Pro_Pagination{background:#fff;padding:5px 0;text-align:center;font-size:14px;}
.Pro_Pagination em{ font-size:13px;}
.Pro_Pagination a{ font-size:14px;}
.Pro_BigImage{text-align:center;background:#fff;}
.Pro_BigImage img{margin:0 auto;cursor:pointer; width:480px;}
.Pro_Link{border-top:1px solid #ccc;padding:5px 0;text-align:center;font-size:14px;}
.Pro_Buttons{text-align:center;background:#fff; margin-top:5px;}
.Pro_Buttons img{display:inline;}
.Pro_Text{height:0px;overflow:hidden;width:1000px;margin:0 auto;}
/*grd_window*/
.grd_main_windows{ position: fixed; _position:absolute; left:0px; top:0px;background:#FFF;width:; height:350px;border:5px solid #C83E19;}
.grd_bar{ height:25px; border-bottom:1px solid #C83E19; cursor:move; width:100%;}
.grd_bar .grd_title{ float: left; font-size:13px; font-weight:bold; line-height:25px; padding-left:4px; color:#C83E19;}
.grd_bar .grd_status{text-align:right; margin-right:0px; width:100px; height:25px; float:right;}
.grd_bar .g_close{background:url({$template_url}images/goods/close.png) left center no-repeat; position: absolute; right:0px; top:0px;height:25px; width:30px; cursor:pointer;}
.form_submit{ background-color:#C83E19; border-bottom: #ccc solid 2px; border-right:#ccc solid 2px; height:23px; line-height:20px; color:#fff; padding:0px 8px; letter-spacing:1px; cursor:pointer; border:none;}
.grd_main_content{ width:100%; padding:0px; margin:0px; overflow: auto;}
.grd_main_content .grd_loading{ margin:0px auto;text-align:center;}
.empty_input_val{ color:#aa0000;background-color:#FFE59E;}
</style>
<script type="text/javascript">
function copyCode(id){
    var testCode=$("#site_view_link").val();
    if(copy2Clipboard(testCode)!=false){
        alert("���ɵĴ����Ѿ����Ƶ�ճ���壬�����ʹ��Ctrl+V ������Ҫ�ĵط�ȥ��Ŷ�� ");
    }
}
copy2Clipboard=function(txt){
    if(window.clipboardData){
        window.clipboardData.clearData();
        window.clipboardData.setData("Text",txt);
    }
    else if(navigator.userAgent.indexOf("Opera")!=-1){
        window.location=txt;
    }
    else if(window.netscape){
        try{
            netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
        }
        catch(e){
            alert("����firefox��ȫ�������������м�������������'about:config'�� signed.applets.codebase_principal_support'����Ϊtrue'֮�����ԣ����·��Ϊfirefox��Ŀ¼ /greprefs/all.js");
            return false;
        }
        var clip=Components.classes['@mozilla.org/widget/clipboard;1'].createInstance(Components.interfaces.nsIClipboard);
        if(!clip)return;
        var trans=Components.classes['@mozilla.org/widget/transferable;1'].createInstance(Components.interfaces.nsITransferable);
        if(!trans)return;
        trans.addDataFlavor('text/unicode');
        var str=new Object();
        var len=new Object();
        var str=Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);
        var copytext=txt;str.data=copytext;
        trans.setTransferData("text/unicode",str,copytext.length*2);
        var clipid=Components.interfaces.nsIClipboard;
        if(!clip)return false;
        clip.setData(trans,null,clipid.kGlobalClipboard);
    }
} 
var currNum;
var maxNum;
var imgUrl;
function getNum(action){
	currNum=parseInt($(".Pro_BigImage img").get(0).name);
	$(".Pro_Images img").each(function(){
		$(this).removeClass("active");
		this.style.filter="alpha(opacity=30)";
		this.style.opacity="0.3";
	})
	if (action=="prev"){
		if (currNum==0){currNum=maxNum};
		$(".Pro_Images img").get(currNum-1).className="active";
		$(".Pro_Images img").get(currNum-1).style.filter="alpha(opacity=100)";
		$(".Pro_Images img").get(currNum-1).style.opacity="1";
		$(".Pro_BigImage img").hide();
		$(".Pro_BigImage img").get(0).src=imgUrl+$(".Pro_Images img").get(currNum-1).name.split("||")[1];
		$(".Pro_BigImage img").get(0).name=$(".Pro_Images img").get(currNum-1).name.split("||")[0];
		$(".Pro_BigImage img").fadeIn();
		$("#page_1").html(currNum+"/"+maxNum);
		$("#page_2").html(currNum+"/"+maxNum);
	}else{
		if (currNum==maxNum-1){currNum=-1};
		$(".Pro_Images img").get(currNum+1).className="active";
		$(".Pro_Images img").get(currNum+1).style.filter="alpha(opacity=100)";
		$(".Pro_Images img").get(currNum+1).style.opacity="1";
		$(".Pro_BigImage img").hide();
		$(".Pro_BigImage img").get(0).src=imgUrl+$(".Pro_Images img").get(currNum+1).name.split("||")[1];
		$(".Pro_BigImage img").get(0).name=$(".Pro_Images img").get(currNum+1).name.split("||")[0];
		$(".Pro_BigImage img").fadeIn();
		$("#page_1").html(parseInt(currNum+2)+"/"+maxNum);
		$("#page_2").html(parseInt(currNum+2)+"/"+maxNum);
	}
}
function initNum(){
	maxNum=	parseInt($(".Pro_Images img").length);
	imgUrl="";
	$(".Pro_Images img").get(0).className="active";
	$(".Pro_BigImage").append("<img src='"+ imgUrl + $(".Pro_Images img").get(0).name.split("||")[1] +"' name='"+ $(".Pro_Images img").get(0).name.split("||")[0] +"' alt='����鿴��һ��'>");
	$(".Pro_BigImage img").click(function(){
		getNum("next");
	})
	$("#page_1").html("1/"+maxNum);
	$("#page_2").html("1/"+maxNum);
}
$(function(){
	initNum();
	$(".Pro_Images img").mouseover(function(){
		this.style.filter="alpha(opacity=100)";
		this.style.opacity="1";
	}).mouseout(function(){
		if (this.className!="active"){
			this.style.filter="alpha(opacity=30)";
			this.style.opacity="0.3";
		}
	}).click(function(){
		$(".Pro_Images img").each(function(){
			$(this).removeClass("active");
			this.style.filter="alpha(opacity=30)";
			this.style.opacity="0.3";
		})
		this.className="active";
		this.style.filter="alpha(opacity=100)";
		this.style.opacity="1";
		$(".Pro_BigImage img").hide();
		$(".Pro_BigImage img").get(0).src=imgUrl+this.name.split("||")[1];
		$(".Pro_BigImage img").get(0).name=this.name.split("||")[0];
		$(".Pro_BigImage img").fadeIn();
		$("#page_1").html(parseInt(this.name.split("||")[0])+1+"/"+maxNum);
		$("#page_2").html(parseInt(this.name.split("||")[0])+1+"/"+maxNum);
	})
})
	</script>
{/literal}
</head>
<body>
<input type="hidden" value="{$data.view_link}"  id="site_view_link"/>
<input type="hidden" value="{$data.goods_name}"  id="call_goods_names"/>
<input type="hidden" value="1" id="goods_buy_total_num" />
    <div class="Pro_Info"><h1><a href="{$data.view_link}">{$data.goods_name}</a><em>(��ţ�{$data.goods_sn})</em></h1><div class="Pro_Buttons"><a  href="{$data.view_link}" target="_blank"><img  src="{$template_url}images/goods/viewProduct.gif" /></a>
<img src="{$template_url}images/goods/appendToCart.gif"   onclick="php188_goods_tocart(this,'{$data.goods_id}');" style=" cursor:pointer;"/>
    </div>	<div class="Pro_Images">
    {foreach from=$data.goods_albums_data item='list' key='key'}
    <img alt="{$data.goods_name}" src="{$list.album_thumb}" name="{$key}||{$list.ablum_end_detail_big_pic}"/>
    {/foreach}
    </div></div><div class="Pro_Pagination"><a href="javascript:getNum('prev')" >��һ��</a>&nbsp;&nbsp;&nbsp;<em id="page_1"></em>&nbsp;&nbsp;&nbsp;<a href="javascript:getNum('next')" >��һ��</a></div><div class="Pro_BigImage"></div><div class = "Pro_Text">{$data.goods_name}
      

</div><div class="Pro_Pagination"><a href="javascript:getNum('prev')" >��һ��</a>&nbsp;&nbsp;&nbsp;<em id="page_2"></em>&nbsp;&nbsp;&nbsp;<a href="javascript:getNum('next')" >��һ��</a></div><div class="Pro_Link"><a href="{$siteurl}">������ҳ</a>&nbsp;&nbsp;&nbsp;<a href="{$data.view_link}">������Ʒҳ</a>&nbsp;&nbsp;&nbsp;<a href="javascript:;" onclick="copyCode('site_view_link');">�������ӷ�������</a></div>
</body>
</html>

