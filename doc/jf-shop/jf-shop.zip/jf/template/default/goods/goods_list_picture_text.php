<?php exit('die'); ?>
{if $goods_list.total>0}
<table class="table_common" id="display_list_picture" cellpadding="0" cellspacing="1">
  {foreach from = $goods_list.data item=goods name=name}
  <tr>
    <td>
    <a href="{$goods.goods_url}" title="{$goods.goods_name}" class="show_img" target="_blank"> <img src="{$goods.goods_end_thumb_pic}"  alt="{$goods.goods_name}{$goods.goods_alias_name}" title="{$goods.goods_name}"/> </a> 
        <a href="{$goods.goods_url}" title="{$goods.goods_name}" target="_blank" class="show_title">{$goods.goods_name}<span>{$goods.goods_alias_name}</span></a>
        </td>
    <td>
    <span class="salepric yahei red">
    {if  $goods.only_use_point eq '1'}
   	 {$goods.goods_point_fee}��
    {else}
    	  {$goods.goods_shop_price}{if $goods.goods_point_fee>0}+{$goods.goods_point_fee}��{/if}
    {/if}</span>
      <div class="desc"><a href="{$goods.goods_url}" title="{$goods.goods_short_desc|truncate:90}">{$goods.goods_short_desc|truncate:90}</a></div>
      </td>
    <td valign="middle" align="center" nowrap="nowrap"><a href="javascript:;" name="{$goods.goods_collect_url}" onclick="php188_goods_collect(this,'{$goods.goods_id}');">�ղ�</a> &nbsp; <a href="javascript:;"  name="{$goods.goods_buy_url}" onclick="php188_goods_tocart(this,'{$goods.goods_id}');">����</a></td>
  </tr>
{/foreach}
</table>
</div>
{$goods_list.page}
{else}
<div class="notice_msg">{$php188_empty_data}</div>
{/if}