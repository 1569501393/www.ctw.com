<?php exit('die'); ?>
{if $goods_data}
            {foreach from=$goods_data key=key item='goods'}
            <dl class="rxtj">
            	<dt><a title="{$goods.goods_name}" href="{$goods.goods_url}" target="_blank"><img alt="{$goods.goods_name}" title="{$goods.goods_name}" src="{$site_url}picture.php?s={$goods.goods_end_source_pic}&w=58" /></a></dt>
                <dd><a href="{$goods.goods_url}" title="{$goods.goods_name}" target="_blank">{$goods.goods_name|truncate:'12':'...'}</a></dd>
                {if $site_promition eq 'true'}
                <dd>
                <samp class="promotion_show yahei red"  id="promotion_times_{$key}" ></samp>
                <script type="text/javascript">
                function GetRTime_{$key}(){
                var EndTime  = {$goods.goods_promotion_end_time_format};
                var NowTime = new Date();
                var nMS =EndTime - NowTime.getTime();
                var nD =Math.floor(nMS/(1000 * 60 * 60 * 24));
                var nH=Math.floor(nMS/(1000*60*60)) % 24;
                var nM=Math.floor(nMS/(1000*60)) % 60;
                var nS=Math.floor(nMS/1000) % 60;
                var string = 'ʣ��'+nD+'��'+nH+'ʱ'+nM+'��'+nS+'��';
                document.getElementById("promotion_times_{$key}").innerHTML = string;
                 setTimeout("GetRTime_{$key}()",1000);
               }
               $(function(){
				GetRTime_{$key}();
			   });
               </script>	
             </dd>
            {/if}
            <dd>{if $site_promition eq 'true'}�����ۣ�{/if}{$goods.goods_shop_price}</dd>
            <div class="clear"></div>	
            </dl>
            {/foreach} 
{/if}