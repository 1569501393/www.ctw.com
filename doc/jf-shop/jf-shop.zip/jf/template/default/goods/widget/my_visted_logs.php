<?php exit('die'); ?>
{get_my_visted_goods assign='goods_data' limit='5' goods_id=$goods_id}
{if $goods_data}       
	{include file="goods/widget/small/goods_bar_pannel.php"}
{/if}