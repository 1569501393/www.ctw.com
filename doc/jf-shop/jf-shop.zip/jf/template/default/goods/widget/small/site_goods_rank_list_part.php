<?php exit('die'); ?>
{foreach from=$goods_data key=key item='rank'}
<dl class="rxtj">
    <dt><img src="{$siteurl}{$rank.goods_list_small_pic}" width="58" height="59"/></dt>
      <dd><a style="color:#000;" href="{$rank.goods_url}" title="{$rank.goods_name}" target="_blank">{$rank.goods_name|truncate:'12':'...'}</a></dd>
      <div class="clear"></div>	
</dl>
{/foreach}