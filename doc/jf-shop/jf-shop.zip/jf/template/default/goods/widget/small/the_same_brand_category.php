<?php exit('die'); ?>
<div class="small_bar some_text">
<h2>ͬƷ���·���</h2>
<div class="bar_pannel bar_pannel_detail">
 {get_category_form_brand brand_id='$brand_id' name='cat' assign='cates'}
  {if $cates}
  {foreach from=$cates item='item' name='cat'} <a href="{$item.view_category}" target="_blank">{$item.cate_name}</a>
  {/foreach}
  {else}
  <samp class="gray">��������!</samp>
  {/if} 
  </div>
</div>