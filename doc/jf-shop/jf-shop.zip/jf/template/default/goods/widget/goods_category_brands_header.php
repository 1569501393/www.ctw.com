<?php exit('die'); ?>
{include file='header_common.php'}
{include file='widget/site_top.php'}