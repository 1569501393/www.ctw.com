<?php exit('die'); ?>
{include file=$model_part_file}