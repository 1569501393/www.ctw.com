<?php exit('die'); ?>
{get_goods limit='4' assign = 'goods_data' cate_id='$category_id'}
{if $goods_data}
<div class="goods_small_pannel" id="same_category_goods">
  <h3>ͬ��������Ʒ</h3>
  <div class="clear"></div>
    {if $goods_data}
      {include file="widget/site_goods_small_part.php"} 
    {else}
        <samp class="gray">��������!</samp>
    {/if}
    <div class="clear"></div>
    </div>
{/if} 