<?php exit('die'); ?>
<div class="Product">
   <h3 class="title2">���в�Ʒ����</h3>	
   <ul id="root">
   {if $category_data}
    <li class="root_bg"><a href="javascript:;">{$category_data.cate_name}</a></li>
    {foreach from=$curent_category_tree item='cate'}
    <li><label><a href="{$cate.view_category}" title="{$cate.cate_name}" class="bhk">{$cate.cate_name}</a></label>
    {if $cate.childrens}
      <ul class="two" style="display:none;">
       {foreach from=$cate.childrens item='son'}
         <li><a href="{$son.view_category}" title="{$son.cate_name}">{$son.cate_name}</a></li>
       {/foreach}
      </ul>
    {/if}
    </li>
    {/foreach}
    {/if}
  </ul>
</div>