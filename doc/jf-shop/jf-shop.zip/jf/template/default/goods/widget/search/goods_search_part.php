<?php exit('die'); ?>
<div class="spacer"></div>
<script type="text/javascript">
function search_goods(){
	window.location.href=_c('php188_form_search');return false;
}
$(function(){
	$("#php188_form_search").submit(function(){
		search_goods();return false;
	});
	$(".table_goods_search_pannel td:even").addClass('add_fix_table_left');
});
</script>
<div class="clear"></div>
<form action="{building_link model='search' action='searchgoods'}" method="get" id="php188_form_search" autocomplete="off">
  <table class="table_list table_goods_search_pannel">
    <tr>
      <td align="right"  nowrap="nowrap" class="f">���عؼ��֣�</td>
      <td><input type="text" class="form_input" name="searchname" id="search_name"  /></td>
    </tr>
    <tr>
      <td  >��Ʒ���ࣺ</td>
      <td> {get_category assign='goods_category_tree' show_children_tag='true'}
        <select class="form_select" name="goodstype">
          <option value="">��ѡ�����...</option>
          {foreach from=$goods_category_tree item=tree}
          <option value="{$tree.cate_id}">{$tree.spacer}{$tree.cate_name}</option> 
          {/foreach}            
        </select></td>
    </tr>
    {get_region_has_ailas assign='region'}
    {if $region}
    <tr>
      <td >������</td>
      <td> 
        <select name="region" class="form_select">
          <option value="">��ѡ�����..</option>
					{foreach from=$region item='list'}
          <option value="{$list.region_id}">{$list.region_name}</option>
          {/foreach}
                    
        </select></td>
    </tr>
    {/if}
    {get_brands assign='brands_list'}
    {if $brands_list}
    <tr>
      <td >��ƷƷ�ƣ�</td>
      <td><select name="goodsbarnds[]"  class="form_select">
          <option value="">��ѡ��Ʒ��...</option>{foreach from=$brands_list item=brand key=key}
          <label>
          <option value="{$brand.brand_id}">{$brand.brand_name}</option>
          </label>
          {/foreach}        
        </select></td>
    </tr>
    {/if}
    <tr>
      <td >�۸����䣺</td>
      <td><input type="text" class="ln search_price form_input_small"  style="ime-mode: disabled;width:85px" name="goodsprice[0]" maxlength="9" onkeyup="this.value=this.value.replace(/[^0-9.]/g,'')" onafterpaste="this.value=this.value.replace(/[^0-9.]/g,'')" />
        -
        <input type="text" class="ln search_price form_input_small"  style="width:85px" name="goodsprice[1]" maxlength="9" onkeyup="this.value=this.value.replace(/[^0-9.]/g,'')" onafterpaste="this.value=this.value.replace(//[^0-9.]/g,'')" /></td>
    </tr>
    {get_goods_tags assign=tags}{if $tags}
    <tr>
      <td >��Ʒ��ǩ��</td>
      <td> {foreach from=$tags item=tags}
        <label>
          <input type="checkbox" value="{$tags.tag_id}" name="tags[]" />
          {$tags.tag_value}&nbsp;&nbsp;</label>
        {/foreach} </td>
    </tr>
    {/if}
    {if $types}
    <tr>
      <td >��Ʒ���ͣ�</td>
      <td> {foreach from=$types item=v key=k}
        <label>
          <input type="checkbox" value="{$k}"  name="types[]"/>
          {$v}</label>
        {/foreach} </td>
    </tr>
    {/if}
    <tr>
	  <td></td>
      <td><input type="submit" value="�� ��"  class="form_submit" /></td>
    </tr>
  </table>
</form>