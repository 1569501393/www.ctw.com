<?php  exit('die');?>
<div class="sy_pp">
           		<p class="fl">Ʒ�ƣ�</p>
                <div class="box_more fl">
                {if $brand}
                {foreach from=$brand item='brand' key=key}
                {if $key<=9}
                    <a href="" {if $user_self_search_keywords.goodsbarnds.0 eq $brand.brand_id} class="s_selected"  {/if} name="goodsbarnds[0]={$brand.brand_id}">{$brand.brand_name}</a>
                {/if}
                {/foreach}                
                    <div id="panel">
                    {foreach from=$brand item='brand' key=key}
                        {if $key>9}
                        <a href="" {if $user_self_search_keywords.goodsbarnds.0 eq $brand.brand_id} class="s_selected"  {/if} name="goodsbarnds[0]={$brand.brand_id}">{$brand.brand_name}</a>
                        {/if}
                    {/foreach}
                    </div>
                    <div class="slide"><a href="javascript:;" class="btn-slide">����</a></div>
                    {/if}
                </div>
                <div class="clear"></div>
                {foreach from=$category_filter.plate item='plates'}
    	        {if $plates.limiter_temp}
                <p class="fl">{$plates.name}��</p>
                <div class="box_more fl"><a href="{$plates._all_item_.link}" {if $plates._all_item_.selected eq 1}class="curent"{/if}>ȫ��</a>
            {foreach from=$plates.limiter_temp key=k item='val'}<a href="{$val.link}" {if $val.selected eq 1}class="curent" {/if} >{$val.val}</a>{/foreach}</div>
                <div class="clear"></div>
                {/if}
                
                {if $plates.spec_pannel}
        	    {foreach from=$plates.spec_pannel item='spec'}
                <p class="fl">{$spec.spec_name}��</p>
                <div class="box_more fl"><a href="{$spec.link}" {if $spec.selected eq '1'}class="curent"{/if}>ȫ��</a>
                {foreach from=$spec.spec_value_info key=k item='val'}
                	<a href="{$val.link}" {if $val.selected eq '1'}class="curent"{/if}>{$val.spec_value}</a>
                {/foreach}</div>
                <div class="clear"></div>
                {/foreach}
                {/if}
                
                {/foreach}
            </div>
