<?php exit('die'); ?>
{get_goods_vist_rank limit='10' cate_id='$category_id' assign='goods_data' sort='DESC'}
<div class="small_bar">
<h2>�����������</h2>
<div class="bar_pannel bar_pannel_rank_detail bar_goods_category_visted_rank">
{if $goods_data}
	{include file="goods/widget/small/site_goods_rank_list_part.php"}
{else}
	<samp class="gray">��������!</samp>
{/if}
  </div>
</div>