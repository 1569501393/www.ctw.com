<?php exit('die'); ?>
{get_goods_vist_rank limit='10' brand_id='$brand_id' assign='goods_data' sort='DESC'}
<div class="small_bar">
<h2>��Ʒ�Ʒ�������</h2>
<div class="bar_pannel bar_pannel_rank_detai bar_pannel_visted_rank">
{if $goods_data}
	{include file="goods/widget/small/site_goods_rank_list_part.php"}
{else}
	<samp class="gray">��������!</samp>
{/if}
  </div>
</div>