<?php exit('die'); ?>
<script type="text/javascript">
var search_filter_url = "{building_link model='search' action='searchgoods'}"+connetor;
var is_categorys = false;
var curent_cate_id = 0;
{if $is_goods_category}is_categorys = true;curent_cate_id = '{$category_id}';{/if}
	$(function(){
		$(".box_more a").attr({"href":'javascript:;'});
		$(".box_more a").click(function(){
			var string = '';
			var c = '';
			this_tag = $(this).attr('name');
			a = this_tag.split('=').shift();
			$(".s_selected").each(function(){
				var tag = $(this).attr('name');
				var t = tag.split('=').shift();
				if(!empty(tag) && a!=t){
					string+=c+tag;	
					c = '&';
				}
			});
			string+=(!empty(string)?'&':'')+this_tag;
			var u = search_filter_url+string+(is_categorys?'&from=category&curent_from_cid='+curent_cate_id:'');
			$(this).attr({"href":u});
		});
	});
</script>


<div class="sy_Product">
        	<div class="sy_title">
            	<a href="javascript:;">���в�Ʒ</a>
            	<span></span>
                <em>����<strong>{$goods_list.total|default:0}</strong>��������������Ʒ</em>
            </div>
            {if !$is_goods_category}
            <!--ȫ������ ����ҳ��-->
            {get_category assign='category' show_children_tag = 'true'}
            {else}
            <!--����ҳ ��ȡ��ǰ�����һ���ӷ���-->
            {get_goods_category_parent assign='category_all' only_one_son='true' only_load_curent_son='true' cate_id=$category_id}
            {assign var='category' value=$category_all.childrens}
            <!--��û���ӷ����ȡ ��ǰ���ϼ�����  һ��-->
            {if !$category}
            {get_goods_category_parent assign='category_all' only_one_parent='true' cate_id=$category_id}
            {assign var='category' value=$category_all.childrens}
            {/if}
            {/if}
            <div class="sy_pp">
            {if $category}
           		<p class="fl">���ࣺ</p>
                <div class="box_more fl" style="width:890px;">
                    <a href="" name="goodstype=" {if !$user_self_search_keywords.goodstype} class="s_selected" {/if}>ȫ��</a>{foreach from=$category item='cate' name='cates' key=key}{if $smarty.foreach.cates.index<=15} <a href="" {if $user_self_search_keywords.goodstype eq $cate.cate_id} class="s_selected"  {/if} name="goodstype={$cate.cate_id}">{$cate.cate_name}</a> {else}{break}{/if}{/foreach}
                </div>
                <div class="clear"></div>
             {/if}
             
             <!--Ʒ��-->
             {if $brand}
             <p class="fl">Ʒ�ƣ�</p>
                <div class="box_more fl" style="width:890px;">
                    <a name="goodsbarnds[0]=" href="" {if !$user_self_search_keywords.goodsbarnds} class="s_selected" {/if}>ȫ��</a> {foreach from=$brand item='brand' key=key}{if $key <=20} <a href="" {if $user_self_search_keywords.goodsbarnds.0 eq $brand.brand_id} class="s_selected" {/if} name="goodsbarnds[0]={$brand.brand_id}">{$brand.brand_name}</a> {else}{break}{/if}{/foreach}
                </div>
                <div class="clear"></div>
              {/if}
              
              <!--�۸�-->
             <p class="fl">Ʒ�ƣ�</p>
                <div class="box_more fl" style="width:890px;">
                    <a  href="" name="goodsprice[0]=&goodsprice[1]="  {if !$user_self_search_keywords.goodsprice ||  $user_self_search_keywords.goodsprice.1 eq '0' } class="s_selected" {/if}>ȫ��</a> <a href="" {if $user_self_search_keywords.goodsprice.0>0 && $user_self_search_keywords.goodsprice.1<=200}class="s_selected" {/if} name="goodsprice[0]=1&goodsprice[1]=200">1-200</a> <a href="" {if $user_self_search_keywords.goodsprice.0>=201 && $user_self_search_keywords.goodsprice.1<=400}class="s_selected" {/if}  name="goodsprice[0]=201&goodsprice[1]=400">201-400</a> <a href="" {if $user_self_search_keywords.goodsprice.0>=401 && $user_self_search_keywords.goodsprice.1<=800}class="s_selected" {/if}  name="goodsprice[0]=401&goodsprice[1]=800">401-800</a> <a href="" {if $user_self_search_keywords.goodsprice.0>=801 && $user_self_search_keywords.goodsprice.1<1501}class="s_selected" {/if}  name="goodsprice[0]=801&goodsprice[1]=1500">801-1500</a> <a href="" {if $user_self_search_keywords.goodsprice.0>=1500 && $user_self_search_keywords.goodsprice.1<=15000000000}class="s_selected" {/if}  name="goodsprice[0]=1500&goodsprice[1]=15000000000">1500����</a>
                </div>
                <div class="clear"></div>
                
                {get_all_goods_types assign='types'}
                {if $types}
                <p class="fl">���ͣ�</p>
                <div class="box_more fl" style="width:890px;">
                    <a href="" name="types[]=" {if !$user_self_search_keywords.types || !$user_self_search_keywords.types.0} class="s_selected" {/if}>ȫ��</a> {foreach from=$types item=v key=k} <a href="" {if $user_self_search_keywords.types.0 eq $k} class="s_selected"  {/if}   name="types[]={$k}">{$v}</a> {/foreach}
                </div>
                <div class="clear"></div>
                {/if}
                
                {get_goods_tags assign=tags}
                {if $tags}
                <p class="fl">��ǩ��</p>
                <div class="box_more fl" style="width:890px;">
                    <a  href=""  name="tags[]=" {if !$user_self_search_keywords.tags} class="s_selected" {/if}>ȫ��</a> {foreach from=$tags item=tags} <a href="" {if $user_self_search_keywords.tags.0 eq $tags.tag_id} class="s_selected"{/if}  name="tags[]={$tags.tag_id}">{$tags.tag_value}</a> {/foreach}
                </div>
                <div class="clear"></div>
                {/if}
            </div>
            
            
        	<div class="sy_order">
                <div class="sy_1 fl" style="width:128px; line-height:20px; color:#666;">���� Ĭ������</div>
                <div class="sy_1 fl" style="width:210px; line-height:20px; color:#666;">
                <form action="{$post_do_url}"  method="post" id="do_form_search" style="display:inline;" autocomplete="off">
                	�۸�����&nbsp;<input name="moneystart" type="text" maxlength="6" class="sy_bt"  value="{if $pathinfo.moneystart>0}{$pathinfo.moneystart}{/if}"  onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" />&nbsp;-&nbsp;<input name="moneyend" type="text" class="sy_bt" value="{if $pathinfo.moneyend>0}{$pathinfo.moneyend}{/if}" maxlength="6"  onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));"/>&nbsp;&nbsp;<input  type="submit" value="����" style="font-size:12px;border:1px solid #F5F5F5; background:none;color:#333;" id="price_search_filter" /></form>
                </div>
                <div class="sy_1 fr" style=" text-align:right;width:390px; line-height:20px; color:#666; border-right:none;">&nbsp;&nbsp;<img  title="ͼƬģʽ" class="goods_display_model"  {if $filter_data.model eq 'picture'} id="goods_display_model_selected"{/if} onclick="goods_display_model_filter(this);" name="picture" src="{if $filter_data.model eq 'picture'} {$template_url}images/common/display_mode_grid_act_selected.gif{else}{$template_url}images/common/display_mode_grid_act.gif{/if}" />&nbsp;&nbsp;<img  title="�ı��б�ģʽ" class="goods_display_model" {if $filter_data.model eq 'picturetext'}id="goods_display_model_selected"{/if} onclick="goods_display_model_filter(this);" name="picturetext" src="{if $filter_data.model eq 'picturetext'}{$template_url}images/common/display_mode_list_selected.gif{else}{$template_url}images/common/display_mode_list.gif{/if}" />&nbsp;&nbsp;<img title="��Ʒ" class="goods_display_model"{if $filter_data.model eq 'text'}id="goods_display_model_selected"{/if} onclick="goods_display_model_filter(this);" name="text" src="{if $filter_data.model eq 'text'}{$template_url}images/common/display_mode_text_selected.gif{else}{$template_url}images/common/display_mode_text.gif{/if}" />&nbsp;&nbsp;<select id="php188_goods_selector">
            <option value="timedesc" selected="selected">���ϼ�ʱ�� ��->��</option>
            <option value="timeasc" {if $filter_data.sort eq 'timeasc'}selected="selected"{/if}>���ϼ�ʱ�� ��->��</option>
            <option value="pricedesc" {if $filter_data.sort eq 'pricedesc'}selected="selected"{/if}>���۸� ��->��</option>
            <option value="priceasc" {if $filter_data.sort eq 'priceasc'}selected="selected"{/if}>���۸� ��->��</option>
          </select>&nbsp;&nbsp;<select id="goods_show_num" name="goods_show_numbers" style="width:80px;">
            <option selected="selected" value="10">10��</option>
            <option value="20" {if $filter_data.perpage eq '20'} selected="selected"{/if}>20��</option>
            
        {if $total>20}
            <option value="50" {if $filter_data.perpage eq '50'}selected="selected"{/if}>50��</option>
            <option value="80" {if $filter_data.perpage eq '80'}selected="selected"{/if}>80��</option>
            <option value="120" {if $filter_data.perpage eq '120'}selected="selected"{/if}>120��</option>
            {/if}
        
          </select>&nbsp;&nbsp;<input type="button" value="�鿴" onclick="filter_goods_for_user(this);" class="form_submit" /><input type="hidden" value="{$php_user_select_url}" id="php188_cate_filter_goods_url" />&nbsp;&nbsp;</div>		
            	<div class="clear"></div>
            </div>	
        </div>