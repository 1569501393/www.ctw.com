<?php exit('die'); ?>
<div class="site_all_categorys">
  <h2>��Ʒ����<a class="all_categorys" href="{building_link model='category'}" target="_blank">ȫ������</a></h2>
  <div class="site_all_categorys_pannel"> 
  {get_category assign='goods_cate' check_children='true'}
    {foreach from =$goods_cate item=item name=name}
      <h3><a href="{$item.view_category}" target="_blank" title="{$item.cate_name}">{$item.cate_name}</a></h3>
      <p> 
      {foreach from = $item.childrens item=children name=name}
      	<a href="{$children.view_category}" target="_blank" title="{$children.cate_name}">{$children.cate_name}</a> 
        {if $children.childrens}
        	<samp>{foreach from=$children.childrens item='sons'}
        	<a href="{$sons.view_category}" target="_blank" title="{$sons.cate_name}">{$sons.cate_name}</a> 
            {/foreach}</samp>
        {/if}
      {/foreach}
      </p>
    {/foreach} </div>
</div>
