<?php exit('die'); ?>
<div class="Product mt">
{get_brand_form_category cate_id='$category_id' name='brand' assign='brands'}
  <h3 class="title2">ͬ��Ʒ��</h3>	
    <ul class="rxpp">
    {if $brands}
    {foreach from=$brands item='item' name='brand' key=key}
      <li{if $key % 2==0} style="border-right:none"{/if}><a href="{$item.link}" target="_blank"><img src="{$site_url}picture.php?s={$item.brand_logo}&w=106&h=50" /></a></li>
    {/foreach}
    {else}
    <li>������Ϣ</li>
    {/if}
    <div class="clear"></div>
   </ul>
</div>