<?php exit('die');//��Ʒ����ײ���Ϣ ?>
<div class="clear"></div>
<script type="text/javascript">
$(function(){
	var goods_id = '{$goods_id}';
	var obj = $("#scroll_pannel");
	$(obj).find("li").click(function(){
		var _this = $(this);
		$("#scroll_pannel").find('.crennt_fix').removeClass('crennt_fix');_this.addClass('crennt_fix');var a = _this.attr('tag');
		$(".hide_item").hide();
		var d = $("#"+a);
		if(d.is(":visible"))return '';
		d.show();
		var rel = _this.attr('rel');
		if(rel && d.attr('has_load')!='1'){
			$.get(rel,{id:goods_id},function(data){
				d.attr({"has_load":"1"}).html(data);
			});	
		}
	});
	$("#goods_detail_self_prefix p").attr({"style":''});
});
</script>
<div class="qihuan" id="scroll_pannel">
  <ul>
    <li class="crennt_fix" tag='goods_detail_call'><a title="��Ʒ��Ϣ">��Ʒ��Ϣ</a></li>
    <li tag='goods_detail_comment_call' rel="{building_link model='member@comment' param="id=$goods_id"}"><a title="��Ʒ����">��Ʒ����</a></li>
    <li tag="goods_detail_tag_call" rel="{building_link model='goods' action='salelogs'}"><a title="�����¼">�����¼</a></li>
    <li tag='goods_detail_baozhang_call'><a title="���ﱣ��">���ﱣ��</a></li>
  </ul>
</div>
<div id="goods_detail_call" class="hide_item">
  <div id="goods_detail_self_prefix"> {$goods_detail.goods_extend_prefix} </div>
  <div class="clear h10"></div>
  {if $goods_detail.goods_extend_attrs.types_extends_attr}
  <table class="prifix_table">
  <tr>
    {foreach from=$goods_detail.goods_extend_attrs.types_extends_attr item=attr}
	<td class="one">��{$attr.attr_name}����</td>
    <td>{$attr.user_fix_data}</td>
    </tr>
    {/foreach}
    </table>
  {/if}
  <div class="clear h10"></div>
  <div class="goods_detail_desc">
   {if $goods_detail.goods_contents}
    {$goods_detail.goods_contents}
    {/if} 
    </div>
</div>
<!--#end goods_detail_call-->
<div id="goods_detail_comment_call" style="display:none;" class="hide_item"> <img src="{$template_url}images/zoomloader.gif" /> </div>
<div id="goods_detail_tag_call" style="display:none;" class="hide_item"> <img src="{$template_url}images/zoomloader.gif" /> </div>
<!--#goods_detail_tag_call-->
<div id="goods_detail_baozhang_call" style="display:none;" class="hide_item"> ���ﱣ�� </div>
