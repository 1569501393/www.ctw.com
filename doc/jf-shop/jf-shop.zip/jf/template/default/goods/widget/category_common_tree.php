<?php exit('die'); ?>
{if $category_data}
 <div class="cat_bar_pannel"> <strong>��Ʒ����</strong>
 	{foreach from=$category_data item='cate'}
    <span><a href="{$cate.view_category}" title="{$cate.cate_name}">{$cate.cate_name}</a></span>
	    {if $cate.childrens}
        <ul>
        {foreach from=$cate.childrens item='son'}
          <li>
          <a href="{$son.view_category}" title="{$son.cate_name}">{$son.cate_name}</a>
          {if $son.childrens}
          	<samp class="eson">
          	{foreach from=$son.childrens item='son_two' name='son_two'}
            	<a href="{$son_two.view_category}" title="{$son_two.cate_name}">{$son_two.cate_name}</a> {if !$smarty.foreach.son_two.last}|{/if}
            {/foreach}
            </samp>
          {/if}
          </li>
        {/foreach}
        </ul>
       {/if}
	{/foreach}
</div>
{/if}