<?php exit('d');//���ۼ�¼ ?>
{get_goods_sales_log assign='goods_sales' goods_id=$goods_id}
{if $goods_sales}
  <div class="gmjl mt20"> <strong>�����¼</strong>
    <ul>
    {foreach from=$goods_sales item='s'}
      <li><span>{$s.format_user}</span><font> {$s.group_name}</font><i>{$s.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</i></li>
      {/foreach}
    </ul>
  </div>
{else}
<div class="no_data">�����ۼ�¼!</div>
{/if}