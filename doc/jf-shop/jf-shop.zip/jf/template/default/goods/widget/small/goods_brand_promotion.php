<?php exit('die'); ?>
{get_goods limit='2' assign = 'goods_data' type='promotion' brand_id='$brand_id'}
<div class="small_bar promotion_pannels" id="same_brands_promotion">
<h2 class="red">��Ʒ�ƴ���</h2>
<div class="bar_pannel bar_pannel_rank_detail">
{if $goods_data}
  {include file="widget/site_goods_small_part.php"} 
{else}
    <samp class="gray">��������!</samp>
{/if}
  </div>
</div>