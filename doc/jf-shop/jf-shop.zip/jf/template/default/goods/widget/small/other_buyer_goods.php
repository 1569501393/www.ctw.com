<?php exit('die'); ?>
{get_goods_other_buyer_goods goods_id=$goods_id  limit='4' assign='goods_data'}
{if $goods_data}
<div class="goods_small_pannel" id="tlsp_buyer">
<h3>�������Ʒ���˻����</h3>
<div class="clear"></div>
  {include file="widget/site_goods_small_part.php"}
    <div class="clear"></div>
</div><!--#end goods_small_pannel-->
{/if}