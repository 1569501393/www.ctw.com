<?php exit('die'); ?>
{if $goods_list.total>0}
{insert_root_css files='shopdata/js/colorbox/colorbox.css'}
{insert_template_scripts_root files='shopdata/js/colorbox/jquery.colorbox.js'}
<script type="text/javascript">
	$(function(){
		$("a[rel='view_goods_big']").colorbox({width:750, height:550,slideshow:true,transition:"fade",slideshowAuto:false});
	});
</script>
<table class="table_common table_text_list" align="center" cellpadding="0" cellspacing="0"  border="0"  id="display_goods_list_text" style="_width:99%;">
  <thead>
    <tr>
      <th width="340">����</th>
      <th width="80" >�۸�</th>
      <th>��ͼ</th>
      <th>����</th>
    </tr>
  </thead>
  <tbody>
  {foreach from = $goods_list.data item=goods name=name}
  <tr>
    <td><a href="{$goods.goods_url}" title="{$goods.goods_name}" class="text-title" target="_blank">{$goods.goods_name}<span>{$goods.goods_alias_name}</span></a></td>
    <td align="center">{$goods.goods_shop_price}</td>
    <td align="center">{if $goods.goods_source_pic}<a href="{$goods.goods_end_source_pic}" title="" rel="view_goods_big">�鿴��ͼ</a>{/if}</td>
    <td align="center" nowrap="nowrap" ><a href="javascript:;" name="{$goods.goods_collect_url}" onclick="php188_goods_collect(this,'{$goods.goods_id}');">�ղ�</a>&nbsp;<a href="javascript:;"  name="{$goods.goods_buy_url}" onclick="php188_goods_tocart(this,'{$goods.goods_id}');">����</a></td>
  </tr>
  {if $smarty.foreach.name.last}
  <tr>
    <td colspan="4"></td>
  </tr>
  {/if}
  {/foreach}
  </tbody>
  
</table>
<div class="clear"></div>
{$goods_list.page}
{else}
<div class="notice_msg">{$php188_empty_data}</div>
{/if}