<?php exit('die'); ?>
{include file="goods/widget/header.php"}
<div class="middle"><!--����-->
    <div class="middle_left fl"><!--���-->
    	{assign var='c_id' value=$category_data.cate_id}
        {get_category cate_id=$c_id show_children_tag='false' assign='curent_category_tree'}
        {if !$curent_category_tree}
    	{get_goods_category_parent cate_id=$c_id assign='c_data'}
        {assign var='curent_category_tree' value=$c_data.childrens}
        {assign var='category_data' value=$c_data}
        {/if}
        {include file='goods/widget/category_tree.php'}
        <!--�����Ƽ�-->    
        {include file="goods/widget/small/goods_category_sale_rank.php"}
        <!--����Ʒ��-->
        {include file="goods/widget/small/the_same_category_brand.php"}
    </div><!--��� end-->
    <div class="middle_right fr"><!--�Ҳ�-->
   		<div class="sy_Product">
        	<div class="sy_title">
            	<a href="javascript:;">���в�Ʒ</a>
            	<span></span>
                <em>����<strong>{$goods_list.total|default:0}</strong>��������������Ʒ</em>
            </div>
            {get_brands assign='brand' cate_id = $category_id}
        	{include file="goods/widget/search_filter_pannel.php"}
        	<div class="sy_order">
                <div class="sy_1 fl" style="width:128px; line-height:20px; color:#666;">���� Ĭ������</div>
                <div class="sy_1 fl" style="width:210px; line-height:20px; color:#666;">
                <form action="{$post_do_url}"  method="post" id="do_form_search" style="display:inline;" autocomplete="off">
                	�۸�����&nbsp;<input name="moneystart" type="text" maxlength="6" class="sy_bt"  value="{if $pathinfo.moneystart>0}{$pathinfo.moneystart}{/if}"  onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" />&nbsp;-&nbsp;<input name="moneyend" type="text" class="sy_bt" value="{if $pathinfo.moneyend>0}{$pathinfo.moneyend}{/if}" maxlength="6"  onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));"/>&nbsp;&nbsp;<input  type="submit" value="����" style="font-size:12px;border:1px solid #F5F5F5; background:none;color:#333;" id="price_search_filter" /></form>
                </div>
                <div class="sy_1 fl" style="width:90px; line-height:20px; color:#666; border-right:none;"></div>
            	<div class="clear"></div>
            </div>	
        </div>
        <div class="Proshow">
        {include file="goods/widget/goods_list_filter_common.php"}
        </div>
    </div><!--�Ҳ� end-->
    <div class="clear"></div>
</div><!--���� end-->
{include file="goods/widget/footer.php"}