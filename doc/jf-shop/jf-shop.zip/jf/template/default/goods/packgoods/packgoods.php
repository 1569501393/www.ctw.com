<?php exit('die');  // �����װ?>
{include file="header.php"}
{insert_css files="style/goods.css"}
{include file="widget/site_top.php"}
<div class="dh">{include file="nav.php"}</div>
<div class="clear"></div>
<div class="middle">
	{if $data.total>0}
		{foreach from=$data.data item='goods'}
        <div class="pack_goods_info">
        	<h3><a href="{$goods.goods_url}" target="_blank">{$goods.goods_name}{if $goods.goods_alias_name}<samp>{$goods.goods_alias_name}</samp>{/if}</a></h3>
            <div class="pack_goods_container">
            {foreach from=$goods.taozhuang_data  name='taozhuang' item='item'}
            	<p>
                	<span><a href="{$item.goods_url}" target="_blank"><img src="{$site_url}picture.php?s={$item.goods_end_thumb_pic}&w=100&h=90" /></a></span>
                    <samp><a href="{$item.goods_url}" target="_blank">{$item.goods_name}</a></samp>
                    <samp class="price yahei">{$item.goods_shop_price}</samp>
                </p>
                {if !$smarty.foreach.taozhuang.last}
                <p class="add"><img  src="{$template_url}images/goods/plusimg.gif" /></p>
                {/if}
            {/foreach}
            </div>
            <div class="heji">
            <p>��ϼۣ�<span class="yellow yahei">{$goods.goods_shop_price}</span></p>
            <p>ԭ&nbsp;&nbsp; �ۣ�<span class="gray yahei">{$goods.packed_goods_total_money|money_format}</span></p>
            <p>����ʡ��<span class="price yahei">{$goods.packed_goods_save_money|money_format}</span></p>
            <p class="to_cart_pack"><a href="javascript:;" onclick="php188_goods_tocart(this,{$goods.goods_id});"><img src="{$template_url}images/goods/buy_cart.jpg" /></a></p>
             </div>
            <div class="clear"></div>
            </div>
        {/foreach}
        <div class="h10"></div>
        {$data.page}
    {else}
    <div class="notice_msg">�޿�������!</div>
    {/if}
</div>
<div class="h20"></div>
{include file = "widget/page_helper.php"}
{include file="footer.php"}