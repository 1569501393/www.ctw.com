{if $goods_list.total>0}
{assign var='goods_data' value=$goods_list.data}
<ul class="shop_list shop_list1 lindex mt">
{foreach from=$goods_data key=key item='goods'}
      		<li>
            	<p style="margin-bottom:10px;" class="imgcenter"><a title="{$goods.goods_name}"  class="img" href="{$goods.goods_url}" target="_blank"><img alt="{$goods.goods_name}" title="{$goods.goods_name}" src="{$goods.goods_end_thumb_pic}"/></a></p>
                <p>{$goods.goods_name|truncate:'12':'...'}</p>
                <p style="color:#eb008d;">{if $site_promition eq 'true'}�����ۣ�{/if}{if $goods.only_use_point eq '1'}{$goods.goods_point_fee}��{else}{$goods.goods_shop_price}{if $goods.goods_point_fee>0}+{$goods.goods_point_fee}��{/if}
    {/if}</p>
    {if $site_promition eq 'true'}<p>
    <samp id="promotion_times_{$key}" ></samp>
          <script type="text/javascript">
            function GetRTime_{$key}(){
                var EndTime  = {$goods.goods_promotion_end_time_format};
                var NowTime = new Date();
                var nMS =EndTime - NowTime.getTime();
                var nD =Math.floor(nMS/(1000 * 60 * 60 * 24));
                var nH=Math.floor(nMS/(1000*60*60)) % 24;
                var nM=Math.floor(nMS/(1000*60)) % 60;
                var nS=Math.floor(nMS/1000) % 60;
                var string = 'ʣ��'+nD+'��'+nH+'ʱ'+nM+'��'+nS+'��';
                document.getElementById("promotion_times_{$key}").innerHTML = string;
                 setTimeout("GetRTime_{$key}()",1000);
            }
           $(function(){
				GetRTime_{$key}();
			});
        </script>	
    </p>{/if}<a href="{$goods.goods_url}"><img src="{$template_url}images/bt_2.gif" /></a>
            </li>
           {/foreach}
            <div class="clear"></div>	
        </ul>
        <div class="clear"></div>        
        	{$goods_list.page}
        <div class="clear"></div>	
{else}
  <div class="notice_msg">{$php188_empty_data}</div>
{/if} 