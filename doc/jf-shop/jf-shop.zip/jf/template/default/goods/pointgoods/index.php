<?php exit('die');  // ������Ʒ?>
{include file="header.php"}
{include file="widget/site_top.php"}
<div class="dh">{include file="nav.php"}</div>
<div class="clear"></div>
<div class="middle"><!--����-->
   		<div class="sy_Product">
        	<div class="sy_title">
            	<a href="javascript:;">���л�����Ʒ</a>	
            	<span></span>
            </div>
        </div>    	
        {if $data.total>0}
<div class="Proshow">
<ul class="shop_list shop_list1 lindex mt">
{foreach from=$data.data key=key item='goods'}
      		<li>
            	<p style="margin-bottom:10px;" class="imgcenter"><a title="{$goods.goods_name}"  class="img" href="{$goods.goods_url}" target="_blank"><img alt="{$goods.goods_name}" title="{$goods.goods_name}" src="{$goods.goods_end_thumb_pic}"/></a></p>
                <p>{$goods.goods_name|truncate:'12':'...'}</p>
                <p style="color:#eb008d;">{if $goods.only_use_point eq '1'}{$goods.goods_point_fee}��{else}{$goods.goods_shop_price}{if $goods.goods_point_fee>0}+{$goods.goods_point_fee}��{/if}{/if}</p>
    <a href="{$goods.goods_url}"><img src="{$template_url}images/bt_2.gif" /></a>
            </li>
           {/foreach}
            <div class="clear"></div>	
        </ul>
        <div class="clear"></div>
        	{$goods_list.page}
        <div class="clear"></div>	
{else}
  <div class="notice_msg">�޿�������!</div>
{/if}
</div>
    <div class="clear"></div>
</div><!--���� end-->
{include file = "widget/page_helper.php"}
{include file="footer.php"}