<?php exit('die'); ?>
{include file="goods/widget/header.php"}
<div class="middle"><!--����-->
{if $action != 'advanced_search'}<!--��ʾ��Ʒ�б�-->
    {include file="goods/widget/search/goods_search_filter.php"}  
    <div class="Proshow">  
    {include file="goods/widget/goods_list_filter.php"}
    </div>
{else}
<!--�߼�������ʾģʽ-->
  {include file="goods/widget/search/goods_search_part.php"}
{/if}
</div>
{include file="goods/widget/footer.php"}