<?php exit('die');?>
{if !$is_ajax}{include file="header.php"}{/if}
<style type="text/css">
.table_common{ width:100%;}
.table_common td{ border:none; border-bottom:1px solid #F0F0F0;}
.table_common .stock_left{ width:100px; text-align:right;}
</style>
<div id="out_stock_dom" {if !$is_ajax} class="w980"{/if}>
{if !$is_ajax}
	<div class="m_notice"><h3>ȱ���Ǽ�</h3></div>
{/if}
<div style="margin-left:10px;">
<form method="post" id="submit_outstock_form" action="{building_link model='outstock' action = '' http='false'}">
	<table class="table_common" cellpadding="5" cellspacing="3">
        <tr>
        	<td>ȱ����Ʒ���ƣ�</td>
            <td><input type="text" value="" size="35" name="goods_name" id="outstock_goods_name" maxlength="150" class="must_fill_in form_input" />  <font class="red">*</font></td>
        </tr>
        <tr>
        	<td>��������Ʒ������</td>
            <td><input type="text"  value="1" id="outstock_goods_num" maxlength="4" onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''));" size="35" name="num"  class="must_fill_in form_input"/>  <font class="red">*</font></td>
        </tr>

    	<tr>
        	<td class="one" align="right">��ϵ��������</td>
            <td><input type="text" value="" maxlength="5"  name="user_name" size="35" class="must_fill_in form_input" /> <font class="red">*</font></td>
        </tr>
        <tr>
        	<td class="one" align="right">��ϵ�绰��</td>
            <td><input type="text" value="" size="35" maxlength="15" name="phone" class="must_fill_in form_input" /> <font class="red">*</font></td>
        </tr>
        <tr>
        	<td class="one" align="right">QQ��</td>
            <td><input type="text" value="" size="35" maxlength="11" name="qq" class="form_input"  /></td>
        </tr>
        <tr>
        	<td class="one" align="right">�����ַ��</td>
            <td><input type="text" value="" size="35" maxlength="50" name="email" class="must_fill_in form_input"  /> <font class="red">*</font></td>
        </tr>
        <tr>
        	<td>����˵����</td>
            <td><textarea name="other_desc"  class="form_textarea"></textarea></td>
        </tr>
        <tr>
        	<td></td>
        	<td><input type="submit" value="�� ��"  class="form_submit" /></td>
        </tr>
    </table>
</form>
</div>
<script type="text/javascript">
$(function(){
	$("#submit_outstock_form").submit(function(){
		if(!check_form_is_empty('must_fill_in'))return false;
		var ci = $(this);
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'OK':
				$('.form_input').val('');
				$('.form_textarea').val('');
				alert('�����ύ�ɹ�,���ǽ����������ϵ!');
				break;
				case 'TO_FAST':
					$('.form_input').val('');
					$('.form_textarea').val('');
					alert('(�s_�t)����̫���˰�,��Ϣ��!'); 
					return false;
				break;
				case 'EMPTY':
					alert('����д������!');return ;
				break;
				default:alert(data);
			}
		});
		return false;
	});
	$("#out_stock_dom .table_common td:even").addClass('stock_left');
});
</script>
</div>
{if !$is_ajax}
{include file='widget/page_helper.php'}
{include file="footer.php"}
{/if}