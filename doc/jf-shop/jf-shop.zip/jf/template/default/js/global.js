jQuery.cookies=function(b,l,n){if(typeof l!="undefined"){n=n||{};if(l===null){l="";n=$.extend({},n);n.expires=-1;}var d="";if(n.expires&&(typeof n.expires=="number"||n.expires.toUTCString)){var e;if(typeof n.expires=="number"){e=new Date();e.setTime(e.getTime()+(n.expires*24*60*60*1000));}else{e=n.expires;}d="; expires="+e.toUTCString();}var m=n.path?"; path="+(n.path):"";var h=n.domain?"; domain="+(n.domain):"";var a=n.secure?"; secure":"";document.cookie=[b,"=",encodeURIComponent(l),d,m,h,a].join("");}else{var f=b+"=";var g=document.cookie.split(";");for(var j=0;j<g.length;j++){var k=g[j];while(k.charAt(0)==" "){k=k.substring(1,k.length);}if(k.indexOf(f)==0){return k.substring(f.length,k.length);}}return null;}};
/*jquery.form �иĶ�*/
(function(b){b.fn.ajaxSubmit=function(s){if(!this.length){a("ajaxSubmit: skipping submit process - no element selected");return this;}if(typeof s=="function"){s={success:s};}var e=b.trim(this.attr("action"));if(e){e=(e.match(/^([^#]+)/)||[])[1];}e=e||window.location.href||"";s=b.extend({url:e,type:this.attr("method")||"GET"},s||{});var u={};this.trigger("form-pre-serialize",[this,s,u]);if(u.veto){a("ajaxSubmit: submit vetoed via form-pre-serialize trigger");return this;}if(s.beforeSerialize&&s.beforeSerialize(this,s)===false){a("ajaxSubmit: submit aborted via beforeSerialize callback");return this;}var m=this.formToArray(s.semantic);if(s.data){s.extraData=s.data;for(var f in s.data){if(s.data[f] instanceof Array){for(var g in s.data[f]){m.push({name:f,value:s.data[f][g]});}}else{m.push({name:f,value:s.data[f]});}}}if(s.beforeSubmit&&s.beforeSubmit(m,this,s)===false){a("ajaxSubmit: submit aborted via beforeSubmit callback");return this;}this.trigger("form-submit-validate",[m,this,s,u]);if(u.veto){a("ajaxSubmit: submit vetoed via form-submit-validate trigger");return this;}var d=b.param(m);if(s.type.toUpperCase()=="GET"){s.url+=(s.url.indexOf("?")>=0?"&":"?")+d;s.data=null;}else{s.data=d;}var t=this,l=[];if(s.resetForm){l.push(function(){t.resetForm();});}if(s.clearForm){l.push(function(){t.clearForm();});}if(!s.dataType&&s.target){var p=s.success||function(){};l.push(function(j){b(s.target).html(j).each(p,arguments);});}else{if(s.success){l.push(s.success);}}s.success=function(q,k){for(var n=0,j=l.length;n<j;n++){l[n].apply(s,[q,k,t]);}};var c=b("input:file",this).fieldValue();var r=false;for(var i=0;i<c.length;i++){if(c[i]){r=true;}}var h=false;if(s.iframe||r||h){if(s.closeKeepAlive){b.get(s.closeKeepAlive,o);}else{o();}}else{b.ajax(s);}this.trigger("form-submit-notify",[this,s]);return this;function o(){var w=t[0];if(b(":input[name=submit]",w).length){alert('Error: Form elements must not be named "submit".');return;}var q=b.extend({},b.ajaxSettings,s);var G=b.extend(true,{},b.extend(true,{},b.ajaxSettings),q);var v="jqFormIO"+(new Date().getTime());var C=b('<iframe id="'+v+'" name="'+v+'" src="about:blank" />');var E=C[0];C.css({position:"absolute",top:"-1000px",left:"-1000px"});var F={aborted:0,responseText:null,responseXML:null,status:0,statusText:"n/a",getAllResponseHeaders:function(){},getResponseHeader:function(){},setRequestHeader:function(){},abort:function(){this.aborted=1;C.attr("src","about:blank");}};var D=q.global;if(D&&!b.active++){b.event.trigger("ajaxStart");}if(D){b.event.trigger("ajaxSend",[F,q]);}if(G.beforeSend&&G.beforeSend(F,G)===false){G.global&&b.active--;return;}if(F.aborted){return;}var k=0;var y=0;var j=w.clk;if(j){var x=j.name;if(x&&!j.disabled){s.extraData=s.extraData||{};s.extraData[x]=j.value;if(j.type=="image"){s.extraData[name+".x"]=w.clk_x;s.extraData[name+".y"]=w.clk_y;}}}setTimeout(function(){var J=t.attr("target"),H=t.attr("action");w.setAttribute("target",v);if(w.getAttribute("method")!="POST"){w.setAttribute("method","POST");}if(w.getAttribute("action")!=q.url){w.setAttribute("action",q.url);}b('<input type="hidden" value="1" name="_____AJAX_CALL_FILE_____" />').appendTo(w);if(!s.skipEncodingOverride){t.attr({encoding:"multipart/form-data",enctype:"multipart/form-data"});}if(q.timeout){setTimeout(function(){y=true;z();},q.timeout);}var I=[];try{if(s.extraData){for(var K in s.extraData){I.push(b('<input type="hidden" name="'+K+'" value="'+s.extraData[K]+'" />').appendTo(w)[0]);}}C.appendTo("body");E.attachEvent?E.attachEvent("onload",z):E.addEventListener("load",z,false);w.submit();}finally{w.setAttribute("action",H);J?w.setAttribute("target",J):t.removeAttr("target");b(I).remove();}},10);var A=0;function z(){if(k++){return;}E.detachEvent?E.detachEvent("onload",z):E.removeEventListener("load",z,false);var H=true;try{if(y){throw"timeout";}var I,K;K=E.contentWindow?E.contentWindow.document:E.contentDocument?E.contentDocument:E.document;if((K.body==null||K.body.innerHTML=="")&&!A){A=1;k--;setTimeout(z,100);return;}F.responseText=K.body?K.body.innerHTML:null;F.responseXML=K.XMLDocument?K.XMLDocument:K;F.getResponseHeader=function(M){var L={"content-type":q.dataType};return L[M];};if(q.dataType=="json"||q.dataType=="script"){var n=K.getElementsByTagName("textarea")[0];F.responseText=n?n.value:F.responseText;}else{if(q.dataType=="xml"&&!F.responseXML&&F.responseText!=null){F.responseXML=B(F.responseText);}}I=b.httpData(F,q.dataType);}catch(J){H=false;b.handleError(q,F,"error",J);}if(H){q.success(I,"success");if(D){b.event.trigger("ajaxSuccess",[F,q]);}}if(D){b.event.trigger("ajaxComplete",[F,q]);}if(D&&!--b.active){b.event.trigger("ajaxStop");}if(q.complete){q.complete(F,H?"success":"error");}setTimeout(function(){C.remove();F.responseXML=null;},100);}function B(n,H){if(window.ActiveXObject){H=new ActiveXObject("Microsoft.XMLDOM");H.async="false";H.loadXML(n);}else{H=(new DOMParser()).parseFromString(n,"text/xml");}return(H&&H.documentElement&&H.documentElement.tagName!="parsererror")?H:null;}}};b.fn.ajaxForm=function(c){return this.ajaxFormUnbind().bind("submit.form-plugin",function(){b(this).ajaxSubmit(c);return false;}).each(function(){b(":submit,input:image",this).bind("click.form-plugin",function(f){var d=this.form;d.clk=this;if(this.type=="image"){if(f.offsetX!=undefined){d.clk_x=f.offsetX;d.clk_y=f.offsetY;}else{if(typeof b.fn.offset=="function"){var g=b(this).offset();d.clk_x=f.pageX-g.left;d.clk_y=f.pageY-g.top;}else{d.clk_x=f.pageX-this.offsetLeft;d.clk_y=f.pageY-this.offsetTop;}}}setTimeout(function(){d.clk=d.clk_x=d.clk_y=null;},10);});});};b.fn.ajaxFormUnbind=function(){this.unbind("submit.form-plugin");return this.each(function(){b(":submit,input:image",this).unbind("click.form-plugin");});};b.fn.formToArray=function(q){var p=[];if(this.length==0){return p;}var d=this[0];var h=q?d.getElementsByTagName("*"):d.elements;if(!h){return p;}for(var k=0,m=h.length;k<m;k++){var e=h[k];var f=e.name;if(!f){continue;}if(q&&d.clk&&e.type=="image"){if(!e.disabled&&d.clk==e){p.push({name:f,value:b(e).val()});p.push({name:f+".x",value:d.clk_x},{name:f+".y",value:d.clk_y});}continue;}var r=b.fieldValue(e,true);if(r&&r.constructor==Array){for(var g=0,c=r.length;g<c;g++){p.push({name:f,value:r[g]});}}else{if(r!==null&&typeof r!="undefined"){p.push({name:f,value:r});}}}if(!q&&d.clk){var l=b(d.clk),o=l[0],f=o.name;if(f&&!o.disabled&&o.type=="image"){p.push({name:f,value:l.val()});p.push({name:f+".x",value:d.clk_x},{name:f+".y",value:d.clk_y});}}return p;};b.fn.formSerialize=function(c){return b.param(this.formToArray(c));};b.fn.fieldSerialize=function(d){var c=[];this.each(function(){var h=this.name;if(!h){return;}var f=b.fieldValue(this,d);if(f&&f.constructor==Array){for(var g=0,e=f.length;g<e;g++){c.push({name:h,value:f[g]});}}else{if(f!==null&&typeof f!="undefined"){c.push({name:this.name,value:f});}}});return b.param(c);};b.fn.fieldValue=function(h){for(var g=[],e=0,c=this.length;e<c;e++){var f=this[e];var d=b.fieldValue(f,h);if(d===null||typeof d=="undefined"||(d.constructor==Array&&!d.length)){continue;}d.constructor==Array?b.merge(g,d):g.push(d);}return g;};b.fieldValue=function(c,j){var e=c.name,p=c.type,q=c.tagName.toLowerCase();if(typeof j=="undefined"){j=true;}if(j&&(!e||c.disabled||p=="reset"||p=="button"||(p=="checkbox"||p=="radio")&&!c.checked||(p=="submit"||p=="image")&&c.form&&c.form.clk!=c||q=="select"&&c.selectedIndex==-1)){return null;}if(q=="select"){var k=c.selectedIndex;if(k<0){return null;}var m=[],d=c.options;var g=(p=="select-one");var l=(g?k+1:d.length);for(var f=(g?k:0);f<l;f++){var h=d[f];if(h.selected){var o=h.value;if(!o){o=(h.attributes&&h.attributes.value&&!(h.attributes.value.specified))?h.text:h.value;}if(g){return o;}m.push(o);}}return m;}return c.value;};b.fn.clearForm=function(){return this.each(function(){b("input,select,textarea",this).clearFields();});};b.fn.clearFields=b.fn.clearInputs=function(){return this.each(function(){var d=this.type,c=this.tagName.toLowerCase();if(d=="text"||d=="password"||c=="textarea"){this.value="";}else{if(d=="checkbox"||d=="radio"){this.checked=false;}else{if(c=="select"){this.selectedIndex=-1;}}}});};b.fn.resetForm=function(){return this.each(function(){if(typeof this.reset=="function"||(typeof this.reset=="object"&&!this.reset.nodeType)){this.reset();}});};b.fn.enable=function(c){if(c==undefined){c=true;}return this.each(function(){this.disabled=!c;});};b.fn.selected=function(c){if(c==undefined){c=true;}return this.each(function(){var d=this.type;if(d=="checkbox"||d=="radio"){this.checked=c;}else{if(this.tagName.toLowerCase()=="option"){var e=b(this).parent("select");if(c&&e[0]&&e[0].type=="select-one"){e.find("option").selected(false);}this.selected=c;}}});};function a(){if(b.fn.ajaxSubmit.debug&&window.console&&window.console.log){window.console.log("[jquery.form] "+Array.prototype.join.call(arguments,""));}}})(jQuery);
/******************************grd_window**********************************************************************/
/*window*/
function grd_rand_string(len){
		var str =  ['a','b','c','d','e','f','h','j','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
		var hash = '';
		for(i=0;i<len;i++){
			var r = str[Math.ceil(Math.random()*100)];if(r!=undefined)hash +=r;
		}
		if(hash.length<len)hash+=grd_rand_string(len-hash.length);return hash;
}
/*�˲����IE �¿��ܴ����ڴ治�ͷŵ�����*/
function stateChangeIE(_frame){
/*state: loading ,interactive,   complete*/
 if (_frame.readyState=="interactive") {
	  $(".grd_loading").remove();
		_frame.style.visibility = "visible";
		if($.browser.msie && $.browser.version<7){
			 var name = $(_frame).attr('name');
			 var tt = setTimeout(function(){
				var doms = window.frames[name].document.body;
				$(doms).css({"width":"98%"});
				if($(doms).css("width")=='98%'){
					window.clearTimeout(tt);
				}
			},10);
		}
	}
}
function stateChangeFirefox(_frame){ 
 $(".grd_loading").remove();
 _frame.style.visibility = "visible";   
}
;(function(){
	$.fn.extend({
		grd_overlay: function(ops,id){
			var ops = $.extend({
					position: 'fixed', top: 0, left: 0, width: '100%',height: '100%', opacity: 0.1, background: 'black', zIndex: 99
			}, ops),
			id = id || grd_rand_string(8);
			if($(this).grd_is_ie6) ops = $.extend(ops, {
				position: 'absolute',
				width: Math.max($(window).width(),$(document.body).width()),
				height:Math.max($(window).height(),$(document.body).height())
			});
			return $('<div class="grd_overlay" zindex="'+ops.zIndex+'" id="'+id+'"/>').appendTo(document.body).css(ops);
		},
		grd_maxLength:function(o){
			var defaults = {
				length:200,
				class_dom:'text_limiter'
			};	
			var opt = $.extend({},defaults,o);
			var class_dom = $('.'+opt.class_dom);
			$(class_dom).html(opt.length);
			$(this).keyup(function(){return _parse($(this));});
			$(this).blur(function(){return _parse($(this));});
			function _parse(obj){
				var val = $.trim($(obj).val());
				if(val=='')$(class_dom).html(opt.length);
				var t = val.length;var l = opt.length-t;l = l<=0?0:l;$(class_dom).html(l);
				if(l<=0)return $(obj).val(val.substr(0,opt.length));
			}
		},
		grd_is_ie6:function(){return $.browser.msie && $.browser.version<=6?true:false},
		grd_hide_select:function(){return $(this).grd_is_ie6()?$(document.body).find('embed, object, select').css({ 'visibility' : 'hidden'}):'';},
		grd_show_select:function(){return $(this).grd_is_ie6()?$(document.body).find('embed, object, select').css({ 'visibility' :'visible'}):'';},
		grd_loading:function(html){
			var opt = {'margin-top':parseInt($(this).parent().height()/2)-30};
			return $(this).html($('<div class="grd_loading">'+html+'</div>').css(opt));
		},
		grd_dragdrop:function(ops,callback,zindex) {
			if(typeof(ops)=='function')callback=ops;
			this.css('position','absolute');
			var ops = $.extend({}, ops),handle=ops.handle ? $(ops.handle, this) : this,flag =false,_o={left:0,top:0},self=this;
			function pos(e){
				if(flag){self.css({left : e.pageX - _o.left + 'px',top : e.pageY - _o.top + 'px'});}
			}
			handle.mousedown(function(e){
				flag = true;
				self.css({'z-index':zindex});
				var offset = self.offset();
				_o = { left: e.pageX - offset.left, top: e.pageY - offset.top };
				$(document).mousemove(pos);
			}).mouseup(function(e){
				pos(e);
				flag = false;
				$(document).unbind('mousemove');
				if(callback)callback.apply(this,[self]);
			}).css('cursor','move');
			return self;
		},
		grd_position: function(ops){
			var opt = $.extend({x:0,y:0,zindex:1000},ops);
			var l = parseInt(($(window).width()-opt.x)/2);
			var t = $(window).height()/2+$(document).scrollTop()-($(this).height()/2);
			return $(this).css({left:l,top:t,width:opt.x,height:opt.y,'z-index':opt.zindex});
		},
		/*�ر� ���ʺ��ڲ��ر� �ⲿ�ر�ֱ��remove���е�DOM ����*/
		grd_close:function(){
			var p = $(this).parents('.grd_main_windows');
			$(p).next().remove();
			$(p).remove();
			p = null;
		},
		grd_window:function(opts){
			var opt = $.extend({
					zindex:10000,title:'title bar',content:'',append_content:'',
					type:'GET',
					iframe:false,/*iframe*/
					dataType:'html',
					loading:'<img src="'+tpl_url+'images/zoomloader.gif" />',width:600,height:350,
					first:'��',last:'��',id:'',url:'',closeCallBack:{},moveCallBack:{},sucess:{},
					over:true
				},opts);
			var self = $(this);
			var grd_bar = $('<div class="grd_bar"></div>');
			$(self).grd_hide_select();
			var over = $('.grd_overlay');
			var zindex = opt.zindex;
			if(over.length==1){
				zindex+=1;
			}else if (over.length>1){
				$(over).each(function(i){
					if(i+1==over.length){
						zindex=parseInt(parseInt($(this).css('z-index'))+1);	
					}
				});	
			}
			var grd_window_pannel = $('<div class="grd_main_windows" />').attr({'id':grd_rand_string(10)}).appendTo(document.body).grd_position({x:opt.width,y:opt.height,zindex:parseInt(zindex+1)});
			if(opt.over){
				$(this).grd_overlay({opacity:0.1,zIndex:zindex});var layer = $(grd_window_pannel).next();
			}
			var grd_bar = $('<div class="grd_bar"><div class="grd_title">'+opt.first+opt.title+opt.last+'</div></div>').appendTo(grd_window_pannel);
			var grd_status = $('<div class="grd_status"></div>').appendTo(grd_bar);
			$('<a class="g_close"></a>').appendTo(grd_status).click(function(){
				$(grd_window_pannel).remove().removeData();
				if(opt.over)$(layer).remove();
				$(self).grd_show_select();self = null;
				if(typeof(opt.closeCallBack)=='function'){
					opt.closeCallBack();	
				}
			});
			var grd_content = $('<div class="grd_main_content"></div>').css({"height":opt.height-$(grd_bar).height()-2}).appendTo(grd_window_pannel);
			$(grd_bar).parent().grd_dragdrop({handle:'.grd_bar'},'',zindex+1);
				if(opt.url && !opt.iframe){
						$.ajax({
							beforeSend:function(){$(grd_content).grd_loading(opt.loading)},
							cache:false,
							type:opt.type,
							url:opt.url,
							success:function(data){
								$(grd_content).html(data);
								if(opt.append_content)$(grd_content).appendTo(opt.append_content);
								if(typeof(opt.sucess)=='function'){opt.sucess();}
								return ;
							}
						});
					}else if (opt.iframe && opt.url){
						$(grd_content).grd_loading(opt.loading);
						var estring = $(this).grd_is_ie6()?"":'style="visibility:hidden"';
						var eid = grd_rand_string(10);
						var iframe_string = '<iframe id="'+eid+'" frameborder="0" '+estring+' onreadystatechange="stateChangeIE(this)" onload="stateChangeFirefox(this);" scrolling="auto" style="overflow:visible;"  width="'+parseInt(opt.width)+'"  height="'+parseInt(opt.height-30)+'" src="'+opt.url+'"></iframe>';
						$(iframe_string).appendTo(grd_content);
						$(grd_content).css({"height":'auto'});
						if($(this).grd_is_ie6()){
							$("#"+eid).attr({'src':opt.url});
							eid= null;	
						}
						estring= null;
						return;
						
						
					}else{
						$(grd_content).html(opt.content);
						if(opt.append_content)$(grd_content).appendTo(opt.append_content);
					}		
			}
	});
})(jQuery);
function _close_grd_window(a){
	_close_window_one();
	 $('.grd_main_windows').remove();
	 $('.grd_overlay').remove();
}
/****************************************************************����grd_window*************************************/
function _set_img_center(obj){
	$(obj).each(function(){
		var d = $(this);
		var f = $(this).find('img');
		var fh = $(f).height();
		var dh = $(d).height();
		if(dh>fh){
			var mt = parseInt((dh-fh)/2);
			$(f).css({"margin-top":mt});	
		}
		var ml = parseInt(($(d).width()-$(f).width())/2);
		//$(f).css({"margin-top":mt,"margin-left":ml});
	});	
}
/*
 * ���һ���ַ����Ƿ�Ϊ��
*/
function empty (string){
	return $.trim(string)==''?true:false;
}
function getData(urls){
	var obj = $.ajax({
		url: urls+'&rand='+Math.random(),
		async: false,
		cache:false
	});
return obj.responseText;
}
/*
 * ��ҳjs����
*/
function page_function(page_dom_id,append_data_id){
	$("#"+page_dom_id).find('a').click(function(){
			var url = $(this).attr('href');
			if(url=='javascript:;' || url=='')return ;
			var jj = $("#"+append_data_id);
			var h = jj.height();
			var c = $('<div class="_call_loading_"><img src="'+ajax_loading_url+' "/></div>');
			$(c).css({"margin-top": h/2+"px"});
			$(jj).html(c);
			$.get(url,function(data){
				$(jj).hide().html(data).fadeIn();
				return false;
			});
			return false;
		});
	$("input[name='custompage']").bind('keydown',function(e){
		var k = e.keyCode;
		if(k==13){
			$("#"+append_data_id).html(getData($(this).attr('alt')+parseInt($.trim($(this).val()))));
			return false;
		}
	});
}
/** 
 * ��� �Ƿ� ���� �����ַ� 
 *���� ���� false û�з��� true 
 **/
 function chkstr(str){
	for (var i = 0; i < str.length; i++){
	   if (str.charCodeAt(i) < 127 && !str.substr(i,1).match(/^\w+$/ig)){
		   return false;
	   }
	}
	return true;
}
/**
 * ��� �Ƿ� ���� email ����Ĺ淶  ���� true ������ false
 * @param email string
 * @return boolean
 */
function checkemail(email){
	var   pattern   =   /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/; 
    if(!pattern.test(email)){ 
    	return false;
    }
    return true;
}
function is_email(email){
	return checkemail(email);	
}
/**
 * �Ƿ� �� һ�� ��ȷ���ֻ���  �� true ���� false
 * ֧�� 13 150 151
 * @param int mobile
 * @return boolean
 */
function is_mobile(mobile){
	var reg =/^1(3[0-9]|5[0,1,2,3,6,8,9]|8[6,8,9])[0-9]{8}$/;
    if(!reg.test(mobile)){
        return false;
    }else{
        return true;
    }
}
function get_data(urls){
	var obj = $.ajax({
		url: urls+'&rand='+Math.random(),
		async: false,
		cache:false
	});
	return $.trim(obj.responseText);
}
function inArray(v,ary){
	if(!$.isArray(array))return false;
	for(k in ary){
		if(ary[k]==v)return true;
	}
	return false;
}
function checkAllFormData(ids,classes){
	$("#"+ids).click(function(){
		$("."+classes).attr('checked',$("#"+ids).attr('checked'));
	});
}
function get_checkbox_val(c){
	var checked = $("."+c).map(function(){
		if($(this).attr('checked'))return $(this).val();
	}).get().join(',');
	return $.trim(checked)==''? false:checked;
}
function isIe6(){return $.browser.version==6.0?true:false;}
/*��Ʒ�ղ�*/
function php188_goods_collect(obj,id){
	var url = $(obj).attr("name");
	$.get(url,function(data){
		switch($.trim(data)){
			case "1":
				return	call_member_login(obj);
				//showNotice("����û�е�½,���ȵ�¼.");
				//return false;
				break;
			case "2":
				showNotice("��ѡ����Ҫ�ղص���Ʒ.");
				return false;
				break;
			case "3":
				showNotice("���Ѿ��ղ��˴���Ʒ.�����ظ��ղ�.");
				return false;
				break;
			case "4":
				showNotice("�ղ���Ʒʧ��.");
				return false;
				break;
			case "5":
				showNotice("�ղش���Ʒ�ɹ�.");
				return false;
				break;
			default:
				showNotice("�ղ���Ʒʧ��.");
				return false;
				break;
		}			   
	});
}
/*�û��Զ���ɸѡ��Ʒ*/
function filter_goods_for_user(){
	var display_filter = $("#php188_goods_selector :selected").val();
	var display_num = $("#goods_show_num :selected").val();
	var call_url = $("#php188_cate_filter_goods_url").val();
	var display_model;
	if($('#goods_display_model_selected').size()>0){
		display_model = $("#goods_display_model_selected").attr('name');
	}else{
		display_model = 'picture_text';	
	}
	var end_string = call_url+'code='+display_model+'------'+display_filter+'------'+display_num;
		window.location.href = end_string;	
}
/*�û��Զ���ѡ����ʾģʽ*/
function goods_display_model_filter(obj){
	var display_filter = $("#php188_goods_selector :selected").val();
	var display_num = $("#goods_show_num :selected").val();
	var display_model = $(obj).attr("name");
	var call_url = $("#php188_cate_filter_goods_url").val();
	var end_string = call_url+'code='+display_model+'------'+display_filter+'------'+display_num;
	window.location = end_string;
}
function count(array){
	var k = 0;
	$(array).each(function(i){
		k=i+1;
	});
	return k;
}
	function php188_goods_tocart(obj,id){
		$.post(ajax_to_cart,{goods_id:id,number:1},function(data){
			data = data.split('|');
			switch(data[0]){
				case 'ERROR':
					showNotice('��������!���޸���Ʒ����!'); return false;
				break;
				case 'NEED_XUNJIA':
					if(confirm('����Ʒ����ֱ������,��ֱ����ϵ������Ա!'))window.location.href=data[1];
				break;
				case 'NOT_EXIST':
					showNotice('�޿�����Ʒ����!'); return false;
				break;
				case 'HAS_OTHER_CHECK':
					if(confirm('����Ʒ���ڲ�ͬ���ͺſ�ѡ,��Ҫ�鿴��?'))window.location.href=data[1];
				break;
				case 'UNDER_STOCK':
				case 'LOW_STOCK':
					if(confirm('��治��,��Ҫ��дȱ���Ǽ���?')){
						call_out_stock_pannel();
						return ;		
					}
					break;
				case 'OK':
					window.location.href=data[1];
				break;
				case 'TO_CART_OK':
					var call_back_cart_obj = $("#_to_cart_imgs");
					return call_member_cart_info(call_back_cart_obj);
				break;
				default:alert(data);
			}
		});
	}
function call_member_cart_info(obj){
	var off = $(obj).offset();
	var left = off.left;
	var top = off.top;
	$.get(ajax_call_back_cart_url,function(data){
		var w = 150;
		var h = 0;
		$(data).css({"top":top+h,"left":left-w}).appendTo("body");
		show_nopay_car();
	});
}
function showNotice(msg,width){
	if(typeof(width)=="undefined"){width = '240';}
	$('div').remove('#showAjaxMsg');//��ɾ������
	$("body").append('<div id="showAjaxMsg">'+msg+'</div>');
	var top = $(window).height()/2+$(document).scrollTop()-80+'px';
    $("#showAjaxMsg").css({
			'width':width,
			'top':top												
	});
	$("#showAjaxMsg")
		.animate({opacity: "1",height: "40", width: width}, 10)
		.animate({opacity: "1", left: "40%",height: "40", width: width},800)
		.animate({opacity: "1", left: "40%",height: "40", width: width},1000)
		.animate({opacity: "1", left: "40%",height: "40", width: width},1500)
		.animate({opacity: "0", left: "85%",height:"0",width:'0'}, 400);
		return false;
}
function check_form_is_empty(form_class){
		var result = true;
		$("."+form_class).each(function(){
			var val = $(this).val();
			if(empty(val)){
				$(this).addClass('empty_input_val');
				result = false;
			}else{
				$(this).removeClass('empty_input_val');
			}
		});
	return result;
}
function AddFavorite(sURL, sTitle){
    try{
		window.external.addFavorite(sURL, sTitle);
    } catch (e){
        try{
            window.sidebar.addPanel(sTitle, sURL, '');
        }catch (e){
            alert('�����ղ�ʧ�ܣ���ʹ��Ctrl+D��������');
        }
    }
}
function SetHome(obj,vrl){
        try{obj.style.behavior='url(#default#homepage)';obj.setHomePage(vrl);}
        catch(e){if(window.netscape) {
				try {
						netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
				}
				catch (e)  {
						alert("�˲�����������ܾ���\n�����������ַ�����롰about:config�����س�\nȻ�� [signed.applets.codebase_principal_support]����Ϊ'true'");
				}
				try{
				var prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);
				prefs.setCharPref('browser.startup.homepage',vrl);
					}
				catch(e){}
                 }
        }
}
function showLoading(){
		$("body").append('<div id="ajax_set_loading" style="position:absolute;background-color: #900; color: #525252;right:0px; top:0px;color:#FFF; padding:5px 6px; width:100px;">���ݼ�����...</div>');
	 var loading_dom = $("#ajax_set_loading");
	 if($(loading_dom).size()) {
			var init = $(loading_dom).offset();
			var init_top = init.top;
			init_left = 0;
			init_top = parseInt(init_top+0);
			function scrolltop() {
				var pageY = $(window).scrollTop();
				pageY = parseInt(pageY+0);
				if (pageY > init_top){
					 $(loading_dom).css({"top":pageY+'px',"right":init_left+'px'});
				 }else{ 
					$(loading_dom).css({"top":init_top+'px',"right":init_left+'px'});
				}
				window.setTimeout(scrolltop, 1);
			}
			scrolltop();
		}
	}
function closeLoading(){$("#ajax_set_loading").remove();}
/*��װform*/
function _c(dom_id){
	var data = $("#"+dom_id).formToArray();
	var url = $("#"+dom_id).attr("action")+connetor;
	var c = '';
	for(var i = 0; i < data.length; i++){url = url + c + data[i].name + "=" + data[i].value;c = '&';}
	return url;
}
function _s(obj){return _c($(obj).attr('id'));}
/*�ص��û�ע��*/
function call_member_login(obj){
	var t = $(obj).attr('title');
	t = empty(t)?'��½ע��':t;
	showWindow(t,member_login_url,920,370,true);
}
/*��Ʒѯ�ۼ���*/
function call_out_stock_pannel(){
	showWindow('ȱ���Ǽ�',call_out_stcok_link,800,350,false,function(){
		$("#outstock_goods_name").val($("#call_goods_names").val());
		$("#outstock_goods_num").val($("#goods_buy_total_num").val());
		$("#goods_buy_total_num").val(1);
	});
}
/*δ������Ʒ*/ 	
	function view_my_cart(){
		ajax_my_car();	
	 }
	function ajax_my_car(){	
		window.parent.showWindow('δ������Ʒ',no_pay_order,900,350,true);
	}
	function show_nopay_car(){
		$.getScript(befor_pay_order,function(){
			$("#un_pay_goods").html(ecart_string);$("#cart_total_money").html(cart_total_money);
		});
		return ;
	}
function remove_enter(){
	$("input").bind('keydown',function(e){
		if(e.keyCode==13){e.keyCode = 0;return false;}
	});	
}
/*�ӳټ���*/
function lazyLoad(){
    if(/chrome|safari/i.test(navigator.userAgent)){return {}}
    this.index.apply(this,arguments)    
}
lazyLoad.prototype={
    index:function (){
        var images = document.images, list=[], sys=this;
        var dr=this.getRect();
        for (var i =  images.length; i--;) {
            var o = images[i], or=this.getRect(o);
            if (o.complete || or.top<dr.bottom ||this.isIntersect(dr, or)) {continue}
            o.setAttribute('rel',o.src);
            o.removeAttribute('src');
            list.push(o)
        }
        this.list=list;
        if (list.length>0) {
            this.on(window,'scroll',function (){
                if(list.length==0){return}
                clearTimeout(sys.lazyTimer);
                sys.lazyTimer=setTimeout(function() {
                    sys.loadImg()
                },200);
            });
        }
    },
    get:function (el){
        return typeof el=="string" ? document.getElementById(el) : el;
    },
    on: function(el, type, fn) {
        el.attachEvent ? el.attachEvent('on' + type,function() {
            fn.call(el, event)
        }) : el.addEventListener(type, fn, false);
    },
    loadImg:function (){
        var list=this.list, noload=[], dr=this.getRect();
        for (var i =  list.length; i--;) {
            var o=list[i];
            if (this.isIntersect(dr, this.getRect(o))) {
                o.src=o.getAttribute('rel');
                continue;
            }
            noload.push(o)
        }
        this.list=noload
    },
    isIntersect:function (r1, r2){
         return !(r1.right<r2.left||r1.top>r2.bottom||r1.left>r2.right||r1.bottom<r2.top)
    },
    getRect:function (el){
        if (el) {
            var el=this.get(el), t=el, x=0, y=0;
            do{
                x+=t.offsetLeft;
                y+=t.offsetTop                
            }while(t=t.offsetParent)
            return {left:x, top:y, right:x+el.offsetWidth,bottom:y+el.offsetHeight}
        }else{
            var d = document, dd = d.documentElement, db = d.body, M = Math.max;    
            var doc = d.compatMode == "CSS1Compat" ? dd: db;
            var x=M(dd.scrollLeft, db.scrollLeft),y=M(dd.scrollTop, db.scrollTop);
            return {left:x,top:y,right:x+doc.clientWidth,bottom:y+doc.clientHeight}
        }
    }
};
/*�������INPUT ����Ϊfile������ֵ*/
function cleanFile(id){                      
	 var _file = document.getElementById(id);            
	 if(_file.files) {  
		_file.value = "";
	 }else{    
	 if (typeof _file != "object") return null;            
	 var _span = document.createElement("span");     
	 _span.id = "__tt__";     
	 _file.parentNode.insertBefore(_span,_file);     
	 var tf = document.createElement("form");     
			   tf.appendChild(_file);     
	  document.getElementsByTagName("body")[0].appendChild(tf);     
	  tf.reset();     
	  _span.parentNode.insertBefore(_file,_span);     
		 _span.parentNode.removeChild(_span);     
	 _span = null;     
	 tf.parentNode.removeChild(tf);  
	}   
}