function setTab(name,cursel,n){
    for(i=1;i<=n;i++){
    var menu=document.getElementById(name+i);
    var con=document.getElementById("con_"+name+"_"+i);
        menu.className=i==cursel?"hover":"";
        con.style.display=i==cursel?"block":"none";
   }
}
$(document).ready(function(){
	$(".btn-slide").click(function(){
		//ֻ���ϵ�ǰ��html�ṹ
		$(this).toggleClass("active").parent().parent().find("#panel").slideToggle("slow");
		return false;
	});
});
function setimg(EleobjImg,ElemaxWidth,ElemaxHeight){
      var Eleimg=new Image();
           Eleimg.src = EleobjImg.src;
      var hRatio;
      var wRatio;
      var Ratio = 1;
      var w = Eleimg.width;
      var h = Eleimg.height;
          wRatio = ElemaxWidth / w;
          hRatio = ElemaxHeight / h;
       if (ElemaxWidth ==0 && ElemaxHeight==0){
           Ratio = 1;
      }else if (ElemaxWidth==0){//
         if (hRatio<1) Ratio = hRatio;
      }else if (ElemaxHeight==0){
         if (wRatio<1) Ratio = wRatio;
      }else if (wRatio<1 || hRatio<1){
           Ratio = (wRatio<=hRatio?wRatio:hRatio);
      }
         if (Ratio<1){
           w = w * Ratio;
           h = h * Ratio;
}
EleobjImg.height = h;
EleobjImg.width = w;
}  
function addBookmark(title,url) {
        try {
            window.external.addFavorite(url, title);
        }
        catch (e) {
            try {
                window.sidebar.addPanel(title, url, "");
            }
            catch (e) {
                alert("�����ղ�ʧ�ܣ���ʹ��Ctrl+D��������");
            }
        }
    }

function SetHome(obj, vrl) {   
    try {   
        obj.style.behavior = 'url(#default#homepage)';   
        obj.setHomePage(vrl);   
    } catch (e) {   
        if (window.netscape) {   
            try {   
                netscape.security.PrivilegeManager   
                        .enablePrivilege("UniversalXPConnect");   
            } catch (e) {   
                alert("�˲�����������ܾ���\n�����������ַ�����롰about:config�����س�\nȻ�� [signed.applets.codebase_principal_support]��ֵ����Ϊ'true',˫�����ɡ�");   
            }   
            var prefs = Components.classes['@mozilla.org/preferences-service;1']   
                    .getService(Components.interfaces.nsIPrefBranch);   
            prefs.setCharPref('browser.startup.homepage', vrl);   
        }   
    }   
}   
//-->   
