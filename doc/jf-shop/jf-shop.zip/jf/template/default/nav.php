<?php exit('die'); ?>
<div class="curent_crumb"> <span class="crumb_menu">{$middle_nav_url}</span>
  <div class="clear"></div>
</div>
