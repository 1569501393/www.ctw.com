<?php if(!defined('INC_PHP188'))exit('php188'); ?>
{include file="header.php"}
{include file="widget/site_top.php"}
<div class="dh">{include file="nav.php"}</div>
<div class="clear"></div>
<div class="middle"><!--����--> 	
     {include file="widget/goods_category_brand_small.php"}
         {if $brands_data}
          <div class="brands_msg">
               <ul>                 
                 {foreach from=$brands_data.data item=c key=key} 
                 <li>
                 <span><a href="{$c.link}" target="_blank" title="{$c.brand_name}"><img src="{$site_url}picture.php?s={$c.brand_logo}&w=120&h=40" /></a></span>
                 <div class="clear"></div>
                 <span><a href="{$c.link}" target="_blank" title="{$c.brand_name}">{$c.brand_name}</a></span>
                 </li>
                 {/foreach}
             </ul>
             <div class="clear"></div>
         </div>
             <div id="brand_page">{$brands_data.page}</div>
        {else}
        <div class="notice_msg">�޿�������!</div>
      {/if}
<div class="clear"></div>
</div><!--���� end-->
{include file = "widget/page_helper.php"}
{include file="footer.php"}