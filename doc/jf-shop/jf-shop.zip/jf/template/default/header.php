<?php exit('die'); ?>
{include file="header_common.php"}