/*jquery overLayer*/
jQuery.closeLayer=function(){$(".jquery-overlay").remove();if($.browser.msie&&$.browser.version<7){try{$("embed, object, select").css({visibility:"visible"});var d=getIFrameDoc("right_frame");$(d).find("embed, object, select").css({visibility:"visible"})}catch(a){}}};jQuery.overLayer=function(c,d){var c=$.extend({position:"fixed",top:0,left:0,width:"100%",height:"100%",opacity:0.1,background:"black",zIndex:1998},c),d=d||roundString(8);c=$.extend(c,{position:"absolute",width:Math.max($(window).width(),$(document.body).width()),height:Math.max($(window).height(),$(document.body).height())});if($.browser.msie&&$.browser.version<7){try{$("embed, object, select").css({visibility:"hidden"});var a=getIFrameDoc("right_frame");$(a).find("embed, object, select").css({visibility:"hidden"})}catch(b){}}return $('<div class="jquery-overlay" zindex="'+c.zIndex+'" id="'+d+'"/>').appendTo(document.body).css(c)};
/*jquery.form �иĶ�*/
(function(b){b.fn.ajaxSubmit=function(s){if(!this.length){a("ajaxSubmit: skipping submit process - no element selected");return this;}if(typeof s=="function"){s={success:s};}var e=b.trim(this.attr("action"));if(e){e=(e.match(/^([^#]+)/)||[])[1];}e=e||window.location.href||"";s=b.extend({url:e,type:this.attr("method")||"GET"},s||{});var u={};this.trigger("form-pre-serialize",[this,s,u]);if(u.veto){a("ajaxSubmit: submit vetoed via form-pre-serialize trigger");return this;}if(s.beforeSerialize&&s.beforeSerialize(this,s)===false){a("ajaxSubmit: submit aborted via beforeSerialize callback");return this;}var m=this.formToArray(s.semantic);if(s.data){s.extraData=s.data;for(var f in s.data){if(s.data[f] instanceof Array){for(var g in s.data[f]){m.push({name:f,value:s.data[f][g]});}}else{m.push({name:f,value:s.data[f]});}}}if(s.beforeSubmit&&s.beforeSubmit(m,this,s)===false){a("ajaxSubmit: submit aborted via beforeSubmit callback");return this;}this.trigger("form-submit-validate",[m,this,s,u]);if(u.veto){a("ajaxSubmit: submit vetoed via form-submit-validate trigger");return this;}var d=b.param(m);if(s.type.toUpperCase()=="GET"){s.url+=(s.url.indexOf("?")>=0?"&":"?")+d;s.data=null;}else{s.data=d;}var t=this,l=[];if(s.resetForm){l.push(function(){t.resetForm();});}if(s.clearForm){l.push(function(){t.clearForm();});}if(!s.dataType&&s.target){var p=s.success||function(){};l.push(function(j){b(s.target).html(j).each(p,arguments);});}else{if(s.success){l.push(s.success);}}s.success=function(q,k){for(var n=0,j=l.length;n<j;n++){l[n].apply(s,[q,k,t]);}};var c=b("input:file",this).fieldValue();var r=false;for(var i=0;i<c.length;i++){if(c[i]){r=true;}}var h=false;if(s.iframe||r||h){if(s.closeKeepAlive){b.get(s.closeKeepAlive,o);}else{o();}}else{b.ajax(s);}this.trigger("form-submit-notify",[this,s]);return this;function o(){var w=t[0];if(b(":input[name=submit]",w).length){alert('Error: Form elements must not be named "submit".');return;}var q=b.extend({},b.ajaxSettings,s);var G=b.extend(true,{},b.extend(true,{},b.ajaxSettings),q);var v="jqFormIO"+(new Date().getTime());var C=b('<iframe id="'+v+'" name="'+v+'" src="about:blank" />');var E=C[0];C.css({position:"absolute",top:"-1000px",left:"-1000px"});var F={aborted:0,responseText:null,responseXML:null,status:0,statusText:"n/a",getAllResponseHeaders:function(){},getResponseHeader:function(){},setRequestHeader:function(){},abort:function(){this.aborted=1;C.attr("src","about:blank");}};var D=q.global;if(D&&!b.active++){b.event.trigger("ajaxStart");}if(D){b.event.trigger("ajaxSend",[F,q]);}if(G.beforeSend&&G.beforeSend(F,G)===false){G.global&&b.active--;return;}if(F.aborted){return;}var k=0;var y=0;var j=w.clk;if(j){var x=j.name;if(x&&!j.disabled){s.extraData=s.extraData||{};s.extraData[x]=j.value;if(j.type=="image"){s.extraData[name+".x"]=w.clk_x;s.extraData[name+".y"]=w.clk_y;}}}setTimeout(function(){var J=t.attr("target"),H=t.attr("action");w.setAttribute("target",v);if(w.getAttribute("method")!="POST"){w.setAttribute("method","POST");}if(w.getAttribute("action")!=q.url){w.setAttribute("action",q.url);}b('<input type="hidden" value="1" name="_____AJAX_CALL_FILE_____" />').appendTo(w);if(!s.skipEncodingOverride){t.attr({encoding:"multipart/form-data",enctype:"multipart/form-data"});}if(q.timeout){setTimeout(function(){y=true;z();},q.timeout);}var I=[];try{if(s.extraData){for(var K in s.extraData){I.push(b('<input type="hidden" name="'+K+'" value="'+s.extraData[K]+'" />').appendTo(w)[0]);}}C.appendTo("body");E.attachEvent?E.attachEvent("onload",z):E.addEventListener("load",z,false);w.submit();}finally{w.setAttribute("action",H);J?w.setAttribute("target",J):t.removeAttr("target");b(I).remove();}},10);var A=0;function z(){if(k++){return;}E.detachEvent?E.detachEvent("onload",z):E.removeEventListener("load",z,false);var H=true;try{if(y){throw"timeout";}var I,K;K=E.contentWindow?E.contentWindow.document:E.contentDocument?E.contentDocument:E.document;if((K.body==null||K.body.innerHTML=="")&&!A){A=1;k--;setTimeout(z,100);return;}F.responseText=K.body?K.body.innerHTML:null;F.responseXML=K.XMLDocument?K.XMLDocument:K;F.getResponseHeader=function(M){var L={"content-type":q.dataType};return L[M];};if(q.dataType=="json"||q.dataType=="script"){var n=K.getElementsByTagName("textarea")[0];F.responseText=n?n.value:F.responseText;}else{if(q.dataType=="xml"&&!F.responseXML&&F.responseText!=null){F.responseXML=B(F.responseText);}}I=b.httpData(F,q.dataType);}catch(J){H=false;b.handleError(q,F,"error",J);}if(H){q.success(I,"success");if(D){b.event.trigger("ajaxSuccess",[F,q]);}}if(D){b.event.trigger("ajaxComplete",[F,q]);}if(D&&!--b.active){b.event.trigger("ajaxStop");}if(q.complete){q.complete(F,H?"success":"error");}setTimeout(function(){C.remove();F.responseXML=null;},100);}function B(n,H){if(window.ActiveXObject){H=new ActiveXObject("Microsoft.XMLDOM");H.async="false";H.loadXML(n);}else{H=(new DOMParser()).parseFromString(n,"text/xml");}return(H&&H.documentElement&&H.documentElement.tagName!="parsererror")?H:null;}}};b.fn.ajaxForm=function(c){return this.ajaxFormUnbind().bind("submit.form-plugin",function(){b(this).ajaxSubmit(c);return false;}).each(function(){b(":submit,input:image",this).bind("click.form-plugin",function(f){var d=this.form;d.clk=this;if(this.type=="image"){if(f.offsetX!=undefined){d.clk_x=f.offsetX;d.clk_y=f.offsetY;}else{if(typeof b.fn.offset=="function"){var g=b(this).offset();d.clk_x=f.pageX-g.left;d.clk_y=f.pageY-g.top;}else{d.clk_x=f.pageX-this.offsetLeft;d.clk_y=f.pageY-this.offsetTop;}}}setTimeout(function(){d.clk=d.clk_x=d.clk_y=null;},10);});});};b.fn.ajaxFormUnbind=function(){this.unbind("submit.form-plugin");return this.each(function(){b(":submit,input:image",this).unbind("click.form-plugin");});};b.fn.formToArray=function(q){var p=[];if(this.length==0){return p;}var d=this[0];var h=q?d.getElementsByTagName("*"):d.elements;if(!h){return p;}for(var k=0,m=h.length;k<m;k++){var e=h[k];var f=e.name;if(!f){continue;}if(q&&d.clk&&e.type=="image"){if(!e.disabled&&d.clk==e){p.push({name:f,value:b(e).val()});p.push({name:f+".x",value:d.clk_x},{name:f+".y",value:d.clk_y});}continue;}var r=b.fieldValue(e,true);if(r&&r.constructor==Array){for(var g=0,c=r.length;g<c;g++){p.push({name:f,value:r[g]});}}else{if(r!==null&&typeof r!="undefined"){p.push({name:f,value:r});}}}if(!q&&d.clk){var l=b(d.clk),o=l[0],f=o.name;if(f&&!o.disabled&&o.type=="image"){p.push({name:f,value:l.val()});p.push({name:f+".x",value:d.clk_x},{name:f+".y",value:d.clk_y});}}return p;};b.fn.formSerialize=function(c){return b.param(this.formToArray(c));};b.fn.fieldSerialize=function(d){var c=[];this.each(function(){var h=this.name;if(!h){return;}var f=b.fieldValue(this,d);if(f&&f.constructor==Array){for(var g=0,e=f.length;g<e;g++){c.push({name:h,value:f[g]});}}else{if(f!==null&&typeof f!="undefined"){c.push({name:this.name,value:f});}}});return b.param(c);};b.fn.fieldValue=function(h){for(var g=[],e=0,c=this.length;e<c;e++){var f=this[e];var d=b.fieldValue(f,h);if(d===null||typeof d=="undefined"||(d.constructor==Array&&!d.length)){continue;}d.constructor==Array?b.merge(g,d):g.push(d);}return g;};b.fieldValue=function(c,j){var e=c.name,p=c.type,q=c.tagName.toLowerCase();if(typeof j=="undefined"){j=true;}if(j&&(!e||c.disabled||p=="reset"||p=="button"||(p=="checkbox"||p=="radio")&&!c.checked||(p=="submit"||p=="image")&&c.form&&c.form.clk!=c||q=="select"&&c.selectedIndex==-1)){return null;}if(q=="select"){var k=c.selectedIndex;if(k<0){return null;}var m=[],d=c.options;var g=(p=="select-one");var l=(g?k+1:d.length);for(var f=(g?k:0);f<l;f++){var h=d[f];if(h.selected){var o=h.value;if(!o){o=(h.attributes&&h.attributes.value&&!(h.attributes.value.specified))?h.text:h.value;}if(g){return o;}m.push(o);}}return m;}return c.value;};b.fn.clearForm=function(){return this.each(function(){b("input,select,textarea",this).clearFields();});};b.fn.clearFields=b.fn.clearInputs=function(){return this.each(function(){var d=this.type,c=this.tagName.toLowerCase();if(d=="text"||d=="password"||c=="textarea"){this.value="";}else{if(d=="checkbox"||d=="radio"){this.checked=false;}else{if(c=="select"){this.selectedIndex=-1;}}}});};b.fn.resetForm=function(){return this.each(function(){if(typeof this.reset=="function"||(typeof this.reset=="object"&&!this.reset.nodeType)){this.reset();}});};b.fn.enable=function(c){if(c==undefined){c=true;}return this.each(function(){this.disabled=!c;});};b.fn.selected=function(c){if(c==undefined){c=true;}return this.each(function(){var d=this.type;if(d=="checkbox"||d=="radio"){this.checked=c;}else{if(this.tagName.toLowerCase()=="option"){var e=b(this).parent("select");if(c&&e[0]&&e[0].type=="select-one"){e.find("option").selected(false);}this.selected=c;}}});};function a(){if(b.fn.ajaxSubmit.debug&&window.console&&window.console.log){window.console.log("[jquery.form] "+Array.prototype.join.call(arguments,""));}}})(jQuery);/*js�Ƴ� dom*/
 jQuery.fn.removeNode = function(){
	 var d;
	 return function(){
	 if(this[0] && this[0].tagName != 'BODY'){
		 d = d || document.createElement('div');
		 d.appendChild(this[0]);
		 d.innerHTML = '';
		 d.outerHTML = '';
		 }
 	};
 }();
/*for ajax call data*/
function _do(data,url){
	var ems = data.split('|');
	var m = ems[1];
switch(ems[0]){
	case '1'://error
		return window.showNotice(m);
	break;
	case '2'://ok
		window.parent.showNotice(m);
		window.location.href=url;
	break;
	default:alert(data);return false;
	}	
}
/*
 * ���һ���ַ����Ƿ�Ϊ��
*/
function empty (string){
	return $.trim(string)==''?true:false;
}
function load_data_for_get(urls){
	var obj = $.ajax({
		type:'GET',
		url: urls+'&rand='+Math.random(),
		async: false,
		cache:false
	});
return obj.responseText;
}
function getData(urls){
	return load_data_for_get(urls);
}
function load_data_for_post(urls,datas){
	var obj = $.ajax({
		url: urls+'&rand='+Math.random(),
		type:'POST',
		async: false,
		data:datas,
		cache:false
	});
	return obj.responseText;
}
//��ʾ��ʾ��Ϣ
function showNotice(msg,options){
	var defaults = {width:400};
	var options = $.extend({},defaults,options);
	$('#showAjaxMsg').remove();
	$('<div id="showAjaxMsg">'+msg+'</div>').appendTo(document.body).css({
		'border':'2px solid #E1562d',
		'z-index':'99999999',
		'text-align':'center',
		'line-height':'40px',
		'position':'absolute',
		'background-color':'#E1562d',
		'top':'40%','left':'35%',
		'line-height':'30px',
		'width':'0px',
		'height':'0px',
		'font-size':'14px',
		'display':'none',
		'color':'#FFF'
	}).animate({opacity: "1", left: "30%", top:"40%", height: "4", width: "4"}, 10)
		.animate({opacity: "1", left: "30%", top:"40%",height: "40", width: options.width},1000)
		.animate({opacity: "1",left: "30%", top:"40%",height: "40", width: options.width},1000)
		.animate({opacity: "0", left: "0", top:"40%"}, 800)
		.animate({opacity: "0", left: "0", top:"40%"}, 400)
		.animate({opacity: "0", left: "0", top:"0",height:"0",width:'0'}, 200);
		//$("embed, object, select").css({visibility:"visible"});
	return false;
}
/*�ύ������ʱ��Ĵ���*/
function checkFormSelect(formNamees,classes,options){
	var defaults = {showMsg:true};
	var options = $.extend({},defaults,options);
	$("form[name='"+formNamees+"']").submit(function(){
				var checked = $("."+classes).map(function(){
					if($(this).attr('checked'))return $(this).val();
				}).get().join('');
			if($.trim(checked)==''){
					if(options.showMsg){
						showNotice(php_empty_select);
						/*��ѡ��Ҫ�����Ķ���.*/
					}
					return false;
			}
	});
}
function get_checkbox_val(c){
	var checked = $("."+c).map(function(){
		if($(this).attr('checked'))return $(this).val();
	}).get().join(',');
	return $.trim(checked)==''? false:checked;
}
function getIFrameDoc(id) {
    var iframe = document.getElementById(id);
    var doc = (iframe.contentWindow || iframe.contentDocument);
    if (doc.document){doc = doc.document;}
    return doc;
}
/*�رյ������ڵ����ز�*/
function hidenLayer(){
	try{
		var a = $('.window').attr('id');
		unset(a);
		$('.window-shadow').remove();
		$('.window-mask').remove();
		var obj = getIFrameDoc('right_frame');
		$(obj).find('embed, object, select').css({ 'visibility' : 'visible' });
		close_date();/*ǿ�йر�ûѡ��� ����*/
	}catch(e){}
}
function close_window(){return hidenLayer();}
/*���ûس���*/
function removeEnter(){
	$("input").bind('keydown',function(e){
		if(e.keyCode==13){e.keyCode = 0;return false;}
	});	
}
function _set_hover_color(obj){
	obj.css({'background-color':curent_skin_selected}).attr({'fixed':'1'});	
}
function _set_color(obj){
	obj.css({'background-color':curent_skin_selected}).attr({'fixed':'1'});	
}
function _set_color_default(obj){
	obj.css({'background-color':curent_skin_default}).attr({'fixed':'0'});	
}
function fix_table_select(c){
	var cc = $('.'+c).find('tr:gt(0)');
	$(cc).each(function(){
		var _this = $(this);
		var _etag;
		if(_this.find("input[type='checkbox']").size()>0){
			_etag = _this.find('td:gt(0)');
		}else{
			return ;/*��ֱ����ʾѡ��Ķ�����*/
			_etag = _this.find('td');
		}
		_etag.click(function(){
			var o = _this.find("input[type='checkbox']");
			var fix = _this.attr('fixed');
			fix = fix==undefined?0:fix;
			var c = $(o).attr('checked');
			if(fix==1){
				_set_color_default(_this);
				$(o).attr('checked',false);	
			}else{
				_set_color(_this);
				$(o).attr('checked',true);	
			}
		});
	});
	_this =  cc = null;
}
function fix_input(c){
	var a = $('.'+c).find('tr:gt(0)');
	$(a).find("input[type='checkbox']").each(function(){
		$(this).click(function(){
			var _this = $(this);
			var sec  = $(this).attr('checked');
			var oo = $(this).parents('tr');
			if(sec){
				_set_color(oo);
				_this.attr('checked',true);
			}else{
				_this.attr('checked',false);
				_set_color_default(oo);
			}
		});
	});
	a = null;
}
/*����ȫѡ*/
function checkAllFormData(ids,classes){
	$("#"+ids).click(function(){
		 var obj = $("."+classes);
		 var c = $("#"+ids).attr('checked');
		 $(obj).attr('checked',c);
		 if(c){
			_set_hover_color($(obj).parents('tr')); 
		 }else{
			_set_color_default($(obj).parents('tr')); 
		  }
	});
}
function check_all(a,b){return checkAllFormData(a,b)}
function table_color(table_classes,options){
	var defaults = {pointer:'default'};
	var options = $.extend({},defaults,options);
	$("."+table_classes).find('tr:gt(0)').hover(function(){
		 /*�������ȥ��ʱ��*/
		$(this).css({'background-color':curent_skin_hover,'cursor':options.pointer});
	},function(){
		var fix = $(this).attr('fixed');
		if(fix=='0' || fix==undefined){
			/*Ĭ����ɫ*/
			$(this).css({'background-color':curent_skin_default,'cursor':'default'});	
		}else if(fix=='1'){
			/*ѡ�е���ɫ*/
		    $(this).css({'background-color':curent_skin_selected,'cursor':'default'});	
		}
	});
}
/*
 * ��ҳjs����
*/
function page_function(page_dom_id,append_data_id,idtag){
		idtag = !idtag?'#':'.';
		var dom = idtag+append_data_id;
		$("#"+page_dom_id).find('a').each(function(i){
			$(this).click(function(){
				var u = $(this).attr('href');
				if(u=='javascript:;')return ;
				$.get(u,function(data){
					remove($(dom));
					$(dom).empty();
					$(dom).html(data);
					return false;
				});
				return false;
			});
		});
		$("input[name='custompage']").bind('keydown',function(e){
			var k = e.keyCode;
			if(k==13){
				remove($(dom));$(dom).empty();
				$(dom).html(getData($(this).attr('alt')+parseInt($.trim($(this).val()))));
				return false;
			}
		});
	}
/*js�������ַ��� len��Ҫ��õĳ���*/
function roundString (len){
		var str =  ['a','b','c','d','e','f','h','j','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
		var hash = '';
		for(i=0;i<len;i++){
			var r = str[Math.ceil(Math.random()*100)];
			if(r!=undefined)hash +=r;
		}
		if(hash.length<len)hash+=roundString(len-hash.length);
		return hash;
}
/** 
 * ��� �Ƿ� ���� �����ַ� 
 *���� ���� false û�з��� true 
 **/
 function chkstr(str){
	for (var i = 0; i < str.length; i++){
	   if (str.charCodeAt(i) < 127 && !str.substr(i,1).match(/^\w+$/ig)){return false;}
	}
	return true;
}
/**
 * ��� �Ƿ� ���� email ����Ĺ淶  ���� true ������ false
 * @param email string
 * @return boolean
 */
function checkemail(email){
	var   pattern   =   /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/; 
    return !pattern.test(email)?false:true;
}
function is_email(email){
	return checkemail(email);
}
/**
 * �Ƿ� �� һ�� ��ȷ���ֻ���  �� true ���� false
 * ֧�� 13 150 151
 * @param int mobile
 * @return boolean
 */
function is_mobile(mobile){
	var reg =/^1(3[0-9]|5[0,1,2,3,4,5,6,7,8,9]|8[0,1,2,3,4,5,6,7,8,9])[0-9]{8}$/;
	return  !reg.test(mobile)?false:true;
}
/** jq tooggle�¼���չ @click_id �����id show_id ��ʾ������ID
*/
function close_open_helper(click_id,show_id,is_val){
	var is_html = !is_val?true:false;
	$("#"+click_id).toggle(function(){
		$("#"+show_id).slideDown();
		is_html?$(this).html(php_close_help):$(this).val(php_close_help);
	},function(){
		$("#"+show_id).slideUp();
		is_html?$(this).html(php_open_help):$(this).val(php_open_help);
	});
}
function showColor (obj){
		$(obj).hover(function(){
			$(obj).css({"cursor":"pointer", "background-color":"#030", "color":"#FFF"});
		},function(){
			$(obj).css({"cursor":"default", "background-color":"#FFF", "color":"#000"});	
		});//end	
	}
function isIe6(){return $.browser.version==6.0?true:false;}
function check_form_is_empty(form_class){
		var result = true;
		$("."+form_class).each(function(){
			var val = $(this).val();
			if(empty(val)){
				$(this).addClass('empty_input_val');
				result = false;
			}else{
				$(this).removeClass('empty_input_val');
			}
		});
	return result;
}
function inArray(v,ary){
	return $.inArray(v, ary)==-1?false:true;
}
function in_array(value,array){return in_array(value,array);}
function count(array){
	var k = 0;
	$(array).each(function(i){
		k=i+1;
	});
	return k;
}
function url_encode(string){
	return encodeURIComponent(string);	
}
//�޸�input��ֵ
jQuery.editTable = function(obj,options){
		var defaults = {
			attr_item:'item',
			ajaxUrl:'index.php?m=goods/attribute&a=ajaxSetVal&action=change_attr_name'
		};
		var _set = $.extend({},defaults,options);
		$(obj).each(function(){
		showColor($(this));
		var id_item = $(this).parent().attr(_set.attr_item);
		id_item = id_item.split('_');
			$(this).editable({
				onSubmit:function(content){
					removeEnter();
					if(content.current==content.previous)return ;
				var url = _set.ajaxUrl+'&name='+content.current+'&id='+id_item[0]+'&c_id='+id_item[1];
					$.get(url,function(d){
						var call_back = d.split('|');
						var msg = call_back[1];
						switch(call_back[0]){
							case '1':
							showNotice(msg);
								return false;
							break;
							case '2':
								//alert('ok');
							break;
							default:alert(d);return false;
						}
					});
				}
			});
	});	
};
//����Ƶ�ѡ����ʱ����������༭
jQuery.editTableForSelect = function(obj,options){
	var defaults = {
		ajaxUrl:'',
		select_data:{}
	};
	var _set = $.extend({},defaults,options);
	$(obj).each(function(){
		var objs = $(this);
		showColor($(this));
		var t = $(this);
		$(this).editable({
			type:'select',
			options:_set.select_data,/*�������ֵ*/
			onSubmit:function(content){
				if(content.current==content.previous)return true;
				var curent_select = $("#append_selected_value").html();
				var items = $(this).parent().attr('item');
				var val = items.split('_');
				var url = _set.ajaxUrl+'&c_id='+curent_select+'&id='+val[0];
				$.get(url,function(data){
						var c = data.split('|');
						switch(c[0]){
							case '1':
								 alert(c[0]);
							break;
							case '2':
								$(t).html(content.current.split('|-').pop());
							break;
							default:alert(c);
						}
					 $("#append_selected_value").remove();
				});
			}		 
		});
	});
}
function showLoading(){
		//closeLoading();
		php_loading = !php_loading?'loading...':php_loading;
		var defaults = {zIndex:100000000,style:'',width:90,content:php_loading};
		var options = $.extend({},defaults,options);
		$("body").append('<div id="ajax_show_msg" style="background-color:'+loading_show_color+';width:'+options.width+'px;text-align:left; z-index:'+options.zIndex+';">'+options.content+'</div>');
		return ;
	}
function add_loading(obj_id){
$("#"+obj_id).html('<div style="margin:20px auto;text-align:center;border:10px;"><img src="images/windows_loading.gif" /></div>');
}
function closeLoading(){unset('ajax_show_msg');$("#ajax_show_msg").remove();}
$(function(){
	try{
		$(this).ajaxStart(function(){window.parent.showLoading();});
		$(this).ajaxSuccess(function(){window.parent.closeLoading();}); 
	}catch(e){}
	$("a").focus(function(){$(this).blur();});	
});
function $$(id) {return typeof(id)=='string'?document.getElementById(id):id;}   
window.recycler=(function(){ var t=document.createElement('div');t.id="recycler";t.style.display="none";return t;})();
function unset(el){
	el=typeof(el)=='object'?el:$$(el); 
	if (el && window.recycler && $.browser.msie){
		window.recycler.appendChild(el);
		window.recycler.innerHTML='';
	}else{
		if(el && el.parentNode && el.tagName != 'BODY'){      
			el.parentNode.removeChild(el);      
		}  
	}
}
function remove(el){el=typeof(el)=='object'?el:$$(el);if(typeof(el)!='object')return ;$(el).empty();el.innerHTML='';}
/*string to time*/
function strtotime(times){
	if(times=='' || times==null)return false;
	var ary = times.replace(/:/g,'-').replace(/ /g,'-').split('-');
	ary[3] = ary[3]=='undefined'?'00':ary[3];
	ary[4] = ary[4]=='undefined'?'00':ary[4];
	ary[5] = ary[5]=='undefined'?'00':ary[5];
	var datum = new Date(Date.UTC(ary[0],ary[1]-1,ary[2],ary[3],ary[4],ary[5]));
	return datum.getTime()/1000;			
}
function now(){
	var date = new Date();
	return  date.getTime()/1000;
}
function _s(obj){
	var data = $(obj).formToArray();
	var url = $(obj).attr("action");
	var c = '&';
	for(var i = 0; i < data.length; i++){url = url + c + data[i].name + "=" + data[i].value;c = '&';}
	return url;
}
var newWin=null;
function ie_open_window(url,w,h){
	var ww = window.screen.width;
	var hh = window.screen.height;
	var left  = parseInt((ww-w)/2);
	var top  = parseInt((hh-h)/2);
	newWin =window.open(url,'newWin','height='+h+',width='+w+',top='+top+',left='+left+',toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no,status=no');
}
function _focus(){
	 if(newWin){
	 	if(!newWin.closed)  newWin.focus();
	 } 	
}
window.onfocus=function (){  
	_focus();
};
window.document.onfocus=function (){ 
	_focus();
};
window.document.onclick=function (){  
	_focus();
};
window.document.ondblclick=function (){  
	_focus();
};
function showDialog(obj,dialogUrl){	
	if($.browser.msie || $.browser.mozilla || $.browser.safari){
			file_children_obj = obj;
			ie_open_window(dialogUrl,'950','450');
		}else{
		window.parent.show_window_for_editor(obj,dialogUrl);
	}
	return false;
}
function showDialoga_file(obj,dialogUrl){
	if($.browser.msie || $.browser.mozilla){
		var f = "help:off;resizable:off;dialogHeight:450px;dialogWidth:950px;status:off;";
		var call = window.showModalDialog(dialogUrl,obj,f);
			call = $.trim(call);
			if(typeof(call_back_write)!='undefined'){
				var old_val = $(image_dom).attr('src');
				if(call==''){call = old_val;}
				$(image_dom).attr({"src":call});
				$(input_main_dom).val(call);
			}else{
				obj.value=call;	
			}
			obj.focus();call= null;
		}else{			
		window.parent.show_window_for_editor(obj,dialogUrl);
	}
	return false;
}
function call_back_window(data){
	$(file_children_obj).val(data);
	$(file_children_obj).focus();
}
function show_window_pannel(title,url,w,h){
	if($.browser.msie || $.browser.mozilla){
		var ww = window.screen.width;
		//var hh = window.screen.height;
		var left  = parseInt((ww-w)/2);
		//var top  = parseInt((hh-h)/2);
		var sFeathers = "help:off;resizable:on;status:off;center:yes;dialogHide:no;scroll:0;dialogLeft:"+left+"px;dialogHeight:"+h+"px;dialogWidth:"+w+"px";
		var call_back = window.showModalDialog(url,'',sFeathers);	
		if(call_back=='refresh'){
			window.parent.frames["rightFrame"].location.reload();
		}
	}else{
		window.parent.showWindow(title,url,w,h);	
	}
}
$(function(){
	if($.browser.msie){$('.form_submit').focus(function(){ $(this).blur();});}
});
function find_window_class(){
var d = $(".window-content:last").attr('class').split(' ');
return d[1];	
}
function cleanFile(id){                      
		 var _file = document.getElementById(id);            
		 if(_file.files) {  
			_file.value = "";
		 }else{    
		 if (typeof _file != "object") return null;            
		 var _span = document.createElement("span");     
		 _span.id = "__tt__";     
		 _file.parentNode.insertBefore(_span,_file);     
		 var tf = document.createElement("form");     
				   tf.appendChild(_file);     
		  document.getElementsByTagName("body")[0].appendChild(tf);     
		  tf.reset();     
		  _span.parentNode.insertBefore(_file,_span);     
			 _span.parentNode.removeChild(_span);     
		 _span = null;     
		 tf.parentNode.removeChild(tf);  
		}   
  }  
function ddd_click(obj){
	var ab = $(obj).is(":checked");
	if(ab){
		$(obj).next().show();
	}else{
		$(obj).next().hide();
	}
}
function submit_form(a){
	return $("#"+a).submit();
}
jQuery.table_bars = function(tab,show,hide,show_all,current){
	current = !current?'wintable_curent':current;
	show = !show?'cfg_base':show;
	hide = !hide?'table_item':hide;
	show_all = !show_all?'cfg_all':show_all;
	$('.'+hide).hide();
	$("#"+show).show();
	$(tab).click(function(){
		var name = $(this).attr('name');
		if(name==show_all){
			$("."+hide).show();
		}else{
			var c_id = '#'+name;
			$('.'+hide).hide();		
			$(c_id).show();
		}
		$("."+current).removeAttr('class');
		$(this).addClass(current);		
	});
}
function _reload_frame(){
	window.frames['rightFrame'].location.reload();	
}
function reload_frame_url(url){
	window.frames['rightFrame'].location.href=url;
}
function _show_date(obj_id,week,showTime){
  showTime = showTime==undefined?false:showTime;
  week = week==undefined?true:week;
  var cal = Calendar.setup({
	   weekNumbers: true,
	   showTime: showTime,
	   onSelect: function(cal) {
		  cal.hide();
		}
  });
  var timestr = showTime?"%Y-%m-%d %I:%M:%S":"%Y-%m-%d";
  cal.manageFields(obj_id, obj_id, timestr);
}
function show_date(obj,week,showTime){
	var id = obj.id;
	if(!id){
		var id = roundString(12);		
		$(obj).attr({'id':id});	
	}
	_show_date(id,week,showTime);	
}
function HS_setDate(obj,week,showTime){
	return show_date(obj,week,showTime);	
}
jQuery.hoverpic = function(tag){
	function _loading_app(obj){
		var h = $(obj).height() /2 ;
		var l = './images/zoomloader.gif';
		return "<div class='call_loading' style='margin-top:"+h+"px;'><img  src='"+ l +"' /></div>";
	}
	$("."+tag).hover(function(){
			var obj = $(this);
			var m = $("<div class='call_pannel_tag'></div>");
			var f = $(obj).offset();
			var t = f.top;
			var l = f.left;
			var w = $(obj).width();
			var hh = $(obj).height();
			$(m).hide().appendTo("body");
			var mm = $(m).height();
			var jj = parseInt(t-mm/2+hh/2);
			jj = jj<=0?36:jj;
			$(m).css({"left":l+w+2,"top":jj});
			var cc = $("<div class='call_pannel_content'>"+_loading_app(m)+"</div><div class='clear'></div>");
			$(cc).appendTo(m); $(m).fadeIn();
			var img = $(obj).attr('rel');
			$(cc).html('<img src="'+img+'" />');	
		},function(){
			$(".call_pannel_tag").remove();
	});
}