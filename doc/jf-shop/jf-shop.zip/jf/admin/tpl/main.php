<?php exit('a'); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset={$outPutChar}" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<title>{$lang.common.site_admin_title}</title>
{insert_scripts files='js/jquery-1.4.min.js'}
<link href="style/layout.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="style/{$__default_skin__}.css" id="call_css_tag" rel="stylesheet" type="text/css" media="screen"/>
{include file="frame_js.php"}
{include file="skin.php"}
<script  type="text/javascript">
var php_notice_msg_info='{$lang.common.site_admin_title}';
var is_open_notice = '{$is_open_notice}';
var auto_command_time_set = '{$auto_command_time}';
var auto_command_time = auto_command_time_set*1000*60;
call_back_write = null;
</script>
</head>
<body scroll="no" style="overflow:hidden; margin:0px auto;">
<div id="notice_msg_hidden" style="display:none;"></div>
<div id="header_out">
<div id="header">
    <div id="header_left"></div>
<div id="header_right">
        <div id="nav_top_t">
            <div id="r_left">
                ����,<span class="etag_name">{$curent_controler} [{$cgroup_name}]</span> {if $is_orgin} <a href="javascript:;" onClick="recover_orgin_auth(this);"><!--�ָ�Ĭ��ϵͳȨ��-->{$lang.recover_sys_auth}</a> | <a href="javascript:;" onClick="see_online(this);">��˭����</a> {/if} 
                &nbsp;&nbsp;<a href="javascript:;" onClick="show_map();">��̨��ͼ</a> | <a href="index.php?m=default&a=right" target="rightFrame">����</a> | <a href="http://www.php.cm/yingyongzhongxin.html" target="rightFrame">Ӧ������</a>
                <samp id="site_notice_info"></samp>
            </div>
   		  <div class="clear"></div>
    </div>
  <div class="clear"></div>
    <!--�����м䵼����ʼ-->
<div id="top_nav">
{if  $top_menu}
    <div id="top_nav_left">
        <ul>
        {foreach from = $top_menu  key=key item=menu}
        <li onClick="add_class(this);"  model="parent_id_{$menu.id}"><a href="javascript:;" rel="{$menu.link}" name="{$menu.id}" class="vist_tag"  onFocus="this.blur();"><em>{$menu.name}</em></a><span></span></li>
        {/foreach}
        </ul>
    </div>
{/if}
</div>
    <!--#end top_nav-->
        <div id="r_right">
            <samp><a href="javascript:;" onClick="window.parent.showWindow($(this).html(),'index.php?m=system/about',900,450);">{$lang.php_about}</a></samp> 
            <samp><em>|</em><a href="http://www.php.cm/buy.html" target="_blank"><!--������ѯ-->{$lang.buy_info}</a> </samp> 
            <samp><em>|</em><a href="http://help.php.cm/" target="_blank"><!--����-->{$lang.help_info}</a></samp> 
     </div>
     
  <div id="change_tpl">
         <a href="javascript:;" class="{if $__default_skin__ eq 'blue'}blue_curent{else}blue{/if} show_tpl_a" rel='blue'></a>
         <a href="javascript:;" rel='black' class="{if $__default_skin__ eq 'black'}black_curent{else}black{/if} show_tpl_a"></a>
         <a href="javascript:;"  class="{if $__default_skin__ eq 'yellow'}yellow_curent{else}yellow{/if} show_tpl_a" rel="yellow"></a>
         <a href="javascript:;"  class="{if $__default_skin__ eq 'green'}green_curent{else}green{/if} show_tpl_a" rel="green"></a>
          <script type="text/javascript">
        $(function(){
            $("#change_tpl a").click(function(){
                var a = $(this).attr('rel');
                var cc=$(this).attr('class');
                $(".show_tpl_a").each(function(){
                    var r = $(this).attr('rel');
                    $(this).removeClass(r+'_curent');
                    $(this).addClass(r);
                });
                $(this).addClass(a+'_curent');
				$.get('index.php?m=default&a=setskin&type='+a,function(data){
					var append_css = 'style/'+a+'.css'
					$("#call_css_tag").attr({"href":append_css});
					window.frames['rightFrame']._change_skin(a);
				});
            });
        });
     </script>
 </div>
 
</div>
<!--blue_curent-->

</div><!--#header-->
</div><!--#header out-->
<!--#������ʼ-->
<div id="main_content_pannel">


<!--#main_left-->
 <div id="main_left" style="display:none;">
{include file="main_left.php"}
</div><!--#end main_left-->

<!--#�м��۵���ʼ-->
<div id="switch_bar" onClick="_switch_bar();">
	<div id="bar_switch" class="s_right"></div>
</div><!--#�м��۵�����-->


<!--#�ұ������忪ʼ-->
<div id="main_content_right">
    <div id="right_sub_menu">
    <div id="do_pannel">
        	<span class="d_cache"><em></em><a href="index.php?m=login&a=loginOut">{$lang.common.loginout}</a></span>
            <span class="d_outs"><em></em><a href="javascript:;" onClick="delete_cache('all');">ɾȫ������</a></span>
            <span class="d_outs"><em></em><a href="javascript:;" onClick="delete_cache('all_tpl_cache');">ɾģ�建��</a></span>
            <span class="d_outs"><em></em><a href="javascript:;" onClick="delete_cache('static');">ɾ��̬����</a></span>
            <span class="d_index"><em></em><a href="../index.php" target="_blank">��ҳ</a></span>
    </div>
    <span id="curent_nav_pos">��ӭ������ҳ</span>
    </div>
<!--#��ܿ�ʼ-->
  <div id="right_frame_all_pannel">
    <div  class="col-1">
		<div id="right_frame_pannel">
<iframe src="index.php?m=default&a=right" id="right_frame" name="rightFrame" width="100%" height="100%" frameborder="0" scrolling="yes" style="overflow: visible;"></iframe>
		</div>
		<div class="clear"></div>
        </div>
        <div class="clear"></div>
    </div>
    <div id="call_footer"></div>
    <div class="clear"></div>
</div>
<!--#end  main_content_right-->
<div class="clear"></div>
</div>
<!--##�ұ����������-->
<div class="clear"></div>
</div>
<!--#վ���ͼ����-->
<script type="text/javascript">
function load_left_tree(){
	$.get('index.php?m=default&a=leftTree',function(data){
		$("#main_left").html(data);
		add_class($(".top_menu_visited").prev().next());
	});
}
function _call_footer(a){
	$("#call_footer").html(a);	
}
function _load_height(){
	return $("#right_frame_pannel").height();	
}
function _switch_bar(flag){
	var left = $("#main_left");
	var show = left.is(":visible");
	var bar = $("#bar_switch");
	if(flag){
		$(bar).removeClass('s_right').addClass('s_left');
		$(left).show();_set_width();return true;
	}
	if(show){
		$(bar).removeClass('s_left').addClass('s_right'); $(left).hide();
	}else{
		$(bar).removeClass('s_right').addClass('s_left'); $(left).show();
	}
	_set_width();
}
function _set_height(){
	var all_height =  $(window).height();
	var header_height = $("#header").height();
	var bar_height = $("#right_sub_menu").height();
	var footer_height = $("#call_footer").height();
	footer_height = 12;
	var ht= parseInt(all_height-header_height-bar_height-footer_height)
	$("#right_frame_pannel").height(ht);
	var h =  parseFloat(all_height-header_height);
	$("#main_left").height(h);
	$("#switch_bar").height(h);
	$("#bar_switch").css({"margin-top":parseFloat(h/2)+"px"});
}
function _set_width(){
	var window_width = $(window).width();
	var ml = $("#main_left");
	var main_left_w = $(ml).is(":visible")?ml.width():0;
	var switch_bar_w = $("#switch_bar").width();
	var w = window_width-main_left_w-switch_bar_w;
	$("#main_content_right").width(w);
	$("#right_frame_all_pannel").width(w-10);
	$(".col-1").width(w-12);
}
function delete_cache(string){
	$.get('index.php?m=tools&a=clearCache&task='+string,function(data){
		switch(data){
			case 'OK':window.parent.showNotice('ɾ���ɹ�!');
			break;
			default:alert(data);
		}
	});
}
function _set_menu_click(obj){
	var next = $(obj).next();
	var span = $(obj).find('span');
	if(span.hasClass('on')){
		$(next).hide(); $(span).removeClass('on').addClass('off');
	}else{
		$(next).show(); $(span).removeClass('off').addClass('on');
	}	
}
var file_children_obj = null;/*��ܵ���ͼƬ��*/
var append_data_val = false;
/*����*/
function show_window_for_editor(obj,ajaxCallUrl){$(document).newWindow({windowTitle:file_manage,ajaxURL:ajaxCallUrl,showLayer:true,width:930,height:430});return file_children_obj = obj;}
function showWindow(title,links,w,h,showIframe){$(document).newWindow({windowTitle:title,ajaxURL:links,width:w,height:h,resizeable:true,maximizeButton:true,showLayer:true,iframe:showIframe});}
function show_window_content(title,content,w,h){$(document).newWindow({windowTitle:title,content:content,width:w,height:h,resizeable:true,maximizeButton:true,showLayer:true});}
function open_new_window(options){$("body").newWindow(options);}
/*��ʱ����*/
var timeID;
var timer;
function scrollTitle() {
	if(php_notice_msg_info){
		window.document.title=php_notice_msg_info 
		php_notice_msg_info=php_notice_msg_info.substring(1,php_notice_msg_info.length)+php_notice_msg_info.substring(0,1)
		timeID=setTimeout("scrollTitle()",250);	
	}
}
function close_time_id(){
	if(timeID)window.clearTimeout(timeID);
	if(timer)window.clearTimeout(timer);
	auto_command_time_set = 0;
}
function call_do(){
	is_open_notice = 1;
	auto_command_time_set = 3;
	if(!timeID || !timer)check_orders();
}
function alter_site_notice(){
	open_new_window({
		windowTitle:site_msg_notice,/*վ������*/
		content:'<div class="notice_bar_msg">'+$("#notice_msg_hidden").html()+'</div>',
		width:400,
		showLayer:true,
		height:250
	});	
}
function showLoadingPage(obj){
	$(".left_visited").removeClass('left_visited');
	$(obj).parent('li').addClass('left_visited');
	var cc =$(obj).parents('li').attr('etag');
	var is_ajax = $(obj).attr('is_ajax');
	var j = $(obj).parents('.slide_menu').prev();
	//$(".php_ajax_tree ul").css({"border-bottom":"1px solid #D9E4EA"});
	$(".php_ajax_tree ul").addClass('ajax_tree_left_visted');
	if(cc==1){
		$(j).css({"border":'none'});
	}else{
		$(".php_ajax_tree ul").removeAttr('style').addClass('ajax_tree_left_visted');
	}
	if(is_ajax =='1'){
		return _call_ajax_page(obj);
	}
	obj = null;
}
function _call_ajax_page(obj){
	var w = $(obj).attr('w');
		w = !w || w==0?350:w;
		var h = $(obj).attr('h');
		h = !h || h==0?420:h;
		window.parent.showWindow($(obj).attr('rel_name'),$(obj).attr('rel'),w,h);	
}
function check_orders(){
	var ajaxUrl = 'index.php?m=default&a=checkOrder&jsoncallback=?';
	var call_msg = '';
	$.getJSON(ajaxUrl,function(data){
		switch(data.status.toString()){
			case 'OK':
				var notice_msg = '';
				var call_msg = '';
				var o_msg = '';
				/*��������*/
				var num = 0;
				if(data.order_total>0){
					o_msg = '��������:���С�'+data.order_total+'��������δ������';
				call_msg = '<p><a onclick="_close_window_one();" href="index.php?m=order&a=wait_confirmed" target="rightFrame">'+o_msg+'</a></p>';
					notice_msg+=o_msg;
					num+=1;
				}
				/*ȱ���Ǽ�*/
				if(data.quehuo>0){
					o_msg = 'ȱ���Ǽ�:���С�'+data.quehuo+'������';
				call_msg +='<p><a onclick="_close_window_one();" href="index.php?m=order/outstock&a=outstock&type=undo" target="rightFrame">'+o_msg+'</a></p>';	
					notice_msg+=o_msg;
					num+=1;
				}
				/*�˿�*/
				if(data.tuikuan_order>0){
					o_msg = '�����˿�:���С�'+data.tuikuan_order+'������';
				call_msg +='<p><a onclick="_close_window_one();" href="index.php?m=order&a=tuikuan" target="rightFrame">'+o_msg+'</a></p>';	
					notice_msg+=o_msg;
					num+=1;
				}
				/*�˻�*/
				if(data.tuihuo_order>0){
					o_msg = '�����˻�:���С�'+data.tuihuo_order+'����';
				call_msg +='<p><a onclick="_close_window_one();" href="index.php?m=order&a=return" target="rightFrame">'+o_msg+'</a></p>';	
					notice_msg+=o_msg;
					num+=1;
				}
				/*���*/
				if(data.goods_stock_total>0){
					o_msg = '��澯��:���С�'+data.goods_stock_total+'������Ʒ��Ҫ������档';
				call_msg +='<p><a onclick="_close_window_one();" href="index.php?m=goods/products&a=productsList&checkstock=1" target="rightFrame">'+o_msg+'</a></p>';	
					notice_msg+=o_msg;
					num+=1;
				}
				/*�¶���*/
				if(data.new_order>0){
					o_msg = '�¶�������:���С�'+data.new_order+'�����¶�����';
					call_msg +='<p><a onclick="_close_window_one();" href="index.php?m=order&a=newOrder"  target="rightFrame">'+o_msg+'</a></p>';	
					notice_msg+=o_msg;
					num+=1;
				}
				/*�ʼ�*/
				if(data.un_send_mail_total>0){
					o_msg = '�ʼ���������:����'+data.un_send_mail_total+'δ������';
					call_msg +='<p><a onclick="_close_window_one();" href="index.php?m=system/messenger&a=mailqueue" target="rightFrame">'+o_msg+'</a></p>';	
					notice_msg+=o_msg;
					num+=1;
				}
				var new_msg = '<a href="javascript:;" onclick="alter_site_notice();">&nbsp;&nbsp;��������Ϣ<b>('+num+')</b></a>';
				$("#notice_msg_hidden").html(call_msg);
				$("#site_notice_info").html(new_msg);
				window.onload = function(){scrollTitle();};
				php_notice_msg_info = notice_msg;
				window.clearTimeout(timer);
				timer = window.setTimeout(check_orders,auto_command_time);
			break;
			case 'EMPTY':
			break;
		}
	});
}
var ht= 0;
/*��̨��ͼ*/
function bind_map_key(){$("#show_admin_panel_menu").size()>0?close_map():show_map();}
function close_map(){_close_window_one();}
function show_map(){
	window.parent.showWindow('�����˵�','index.php?m=default&a=callMap',970,520);
}
function _set(){
	 _set_width(); _set_height();	
}
function go_page(obj){
	close_map();
	if($(obj).attr('is_ajax')==1){
		return _call_ajax_page(obj);
	}else{
		window.parent.showLoading();		
	}
	
}
$(function(){
	if(is_open_notice==1){check_orders();}
	$(this).keypress(function(e){
		if(e.keyCode==27)bind_map_key();
	});
	_set();
	$('.input_notice').poshytip();
	$(window).resize(function(){
		_set();
	});
});
/*�������� ��ߵ���*/
function add_class(obj){
	$(".top_menu_visited").removeClass('top_menu_visited');
	$(obj).addClass('top_menu_visited');
	$(".default_set_class_menu").hide();
	$(".need_hidden").hide();
	$("#"+$(obj).attr("model")+'_model').show();
	_switch_bar(true);
}
function recover_orgin_auth(){
	if(!confirm("ȷ�ϲ�����?�˲���������ˢ��ҳ��,\r\n���ޱ�����������ȱ���!"))return ;
	$.get('index.php?m=default&a=recover',function(data){
		switch(data){
			case 'ERROR': break;
			case 'OK': window.location.reload();break;
			default:alert(data);
		}
	});	
}
function getPinYin(str){
	if(empty(str))return ;
	var s = load_data_for_post('index.php?m=default&a=getPinyin',{key:str});
	if(s=='ERROR'){alert('empty_string');return ;} return s;
}
function get_pinyin(val,append_obj){
	if(empty(val)){
		window.parent.showNotice('��ȷ��Ҫ��ȡƴ�����ַ�����!');
		return '';	
	}
	$(append_obj).val(getPinYin(val));
}
function see_online(obj){
	$.get('index.php?m=default&a=lookOnline',function(data){
		switch(data){
			case 'OK':
				showWindow($(obj).html(),'index.php?m=default&a=viewOnline',800,350);
			break;
			case 'ONLY_FILE_MODEL':
				window.parent.showNotice("Ŀǰϵͳֻ֧���ļ�ģʽ");
			break;
			case 'NO_AUTH':window.parent.showNotice("����Ȩ����!"); break;
		}
	});
}
function _check_window_is_open(){ return $(document).hasClass('.window') && $(document).hasClass('.window-shadow')?true:false;}
function set_curent_nav(m,a){
	if(!m || !a)return '';
	var nav = $("#curent_nav_pos");
	$.get('index.php?m=default&a=callMenu',{aa:a,mm:m},function(data){
		if(data){
			$(nav).html(data);	
		}
	});
}
$(function(){
	$.getScript('{$call_auto_url}',function(){
		
	});
});
</script>
{insert_scripts files='js/packed.js,js/global.js,js/swfupload.js,js/jquery.poshytip.min.js,js/jscal2.js'}
<!--<link href="{$call_auto_url}" rel="stylesheet" type="text/css" media="screen"/>-->
</body>
</html>