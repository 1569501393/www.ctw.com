<?php  if (! defined ( 'PHP_TEMPLATE' )) exit ();?>
{include file="frame_header.php"}
<script>
 var area_url="{$thispage}";
$(function(){
	$("#menu_change li").click(function(){
		$(".swf_need_show").hide();
		$('#'+$(this).attr('name')).show();
		$('.wintable_curent').removeClass('wintable_curent')
		$(this).addClass('wintable_curent');
	});
});
</script>
<div  class="table_scroll" id="menu_change">
	<div class="menu">
    	<li class="wintable_curent" name="time_spreed"><% _e('ʱ��ֲ�');%></li>
    	<li name="area_spreed"><% _e('�����ֲ�');%></li>        
    </div>
</div>
<div class="clear"></div>
<script type="text/javascript" src="js/swfobject.js"></script>
<div id="php_right_main_content">
<div  id="time_spreed"  class="swf_need_show">
    <div id="7day_data" class="flash_contents">
       <script type="text/javascript">
        var so = new SWFObject("swf/char.swf", "chart", "98%", "280", "9", "#FFFFFF");
        so.addVariable("data", "{$weekmember}");
        so.addParam("allowScriptAccess", "sameDomain");
        so.addParam('wmode','opaque');
        so.write("7day_data");
    </script>
    </div>
<div class="dt_count_info">
<form action="index.php?m=order/finance&a=memspread" method="post">
<input type="hidden" value="month" name="type" />
    <select name="year">
   <option value=""><% _e('��ѡ����');%></option>
    {foreach from=$preyear name=name item=item}
    <option value="{$item}" {if $smarty.session.__g_month_group.y eq $item} selected="selected"{/if}>{$item} <% _e('��');%></option>
    {/foreach}
    </select>
    <select name="month">
    <option value=""><% _e('��ѡ����');%></option>
����{foreach from=$for_month name=name item=item}
       <option value="{$item}" {if $smarty.session.__g_month_group.m eq $item} selected="selected"{/if}>{$item}<% _e('��');%></option>
����{/foreach}
    </select>
    <input type="submit" value="<% _e('��ѯ');%>" class="form_submit" />
</form>    
</div>
<div class="clear"></div>
<div id="flash_month_content" class="flash_contents">
<script type="text/javascript">
	var so = new SWFObject("swf/char.swf", "chart", "98%", "280", "9", "#FFFFFF");
	so.addVariable("data", "{$monthmember}");
	so.addParam("allowScriptAccess", "sameDomain");
	so.addParam('wmode','opaque');
	so.write("flash_month_content");
	</script>
    </div>
<div class="clear"></div>
<div class="dt_count_info">
<form action="index.php?m=order/finance&a=memspread" method="post">
<input type="hidden" value="year" name="type" />
    <select name="year_grounp">
    <option value="">{$lang.php_select}</option>
    {foreach from=$preyear name=name item=item}
    <option value="{$item}" {if $smarty.session.__g_year eq $item} selected="selected"{/if}>{$item}<% _e('��');%></option>
    {/foreach}
    </select>
    <input type="submit" value="<% _e('��ѯ');%>" class="form_submit" />
</form>    
</div>
<div class="clear"></div>
<div id="flash_year_content" class="flash_contents">
<script type="text/javascript">
    var so = new SWFObject("swf/char.swf", "chart", "98%", "280", "9", "#FFFFFF");
    so.addVariable("data", "{$yearmember}");
    so.addParam("allowScriptAccess", "sameDomain");
    so.addParam('wmode','opaque');
    so.write("flash_year_content");
</script>  
</div>
<div class="clear"></div>
</div>
<!-----------�����ֲ�-------------------->
<div id='area_spreed' style="display:none;" class="swf_need_show">
<table class="table_list">
	<tr>
    	<th><% _e('����');%></th>
        <th><% _e('��Ա����');%></th>
        <th><% _e('����');%></th>
    </tr>
    {foreach from=$dataspread.data name=name item=item}
    	<tr>
        	<td>{$item.name}</td>
            <td>{$item.total}</td>
            <td><img src='images/per_bg.png' width="{$item.ratio}"  height="14px;"  />&nbsp;&nbsp;&nbsp;&nbsp;{$item.ratio}%</td>
        </tr>
    {/foreach}
</table>
<div></div>
</div>
{include file="frame_footer.php"}