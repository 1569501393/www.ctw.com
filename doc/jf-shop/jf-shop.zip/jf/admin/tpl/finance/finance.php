<?php exit('die'); ?>
{include file="frame_header.php"}
<!--Ԥ����ͳ�ƿ�ʼ-->
{if $action eq 'total_advance'}
<script type="text/javascript">
	$(function(){
		$("#sub_form_pay").submit(function(){
			window.location.href = _s(this);
			return false;
		});
	});
</script>
<form method="post"  id="sub_form_pay" action="index.php?m=order/finance&a=totalAdvancePay">
  <div id="php_top_bar">
    <div class="tb">{$lang.f.begain_time}:</div>
    <div class="tb">
      <input type="text" class="must_fill date date_input" id="sart_times" style="margin-bottom:3px;" name="first" value="{$get.first}" onfocus="show_date(this)" />
    </div>
    <div class="tb">
      <!--����ʱ��-->
      {$lang.f.end_time}:</div>
    <div class="tb">
      <input type="text" class="must_fill date date_input" style="margin-bottom:3px;"  name="last"  id="end_time" onfocus="show_date(this);" value="{$get.last}" />
    </div>
    <div class="tb">
      �û���
      : </div>
    <div class="tb">
      <input  type="text" value="{$get.user}"  style="margin-bottom:3px;" name="user" />
    </div>
    <div class="tb">
      <input  type="submit" value="{$lang.php_search}" class="form_submit" style="display: none" />
      <a href="javascript:;" onclick="submit_form('sub_form_pay');" class="block_button">����</a></div>
    <div class="tb"><a class="block_button" href="{if $export}{$export}{else}javascript:;{/if}" target="_blank">{$lang.f.export_excel}</a></div>
  </div>
</form>
<div id="php_right_main_content"> {if $finance_data}
  <table class="table_list">
    <th><!--�û�-->
        {$lang.f.user}</th>
      <th><!--����ʱ��-->
        {$lang.f.jiaoyitime}</th>
      <th><!--ҵ��ժҪ-->
        {$lang.f.yewuzhaiyao}</th>
      <th><!--������ע-->
        {$lang.f.guanlibeizhu}</th>
      <th><!--��ʱ���-->
        {$lang.f.curent_moneys}</th>
      <th><!--������-->
        {$lang.f.save_moneys_num}</th>
      <th><!--֧�����-->
        {$lang.f.out_moneys_num}</th>
      <th><!--���-->
        {$lang.f.dangqian_yue}</th>
    </tr>
    {foreach from=$finance_data.data key=k item=f}
    <tr  onclick="window.parent.showWindow($(this).attr('name'),'index.php?m=member/money&a=moneylog&opt=not_show_header&id={$f.mem_id}',980,350);('{$f.mem_id}',this);" style="cursor:pointer;"  name="{$f.mem_username}-������Ϣ">
      <td nowrap="nowrap"  class="center">{$f.mem_name}{if $f.mem_name}( {/if}{$f.mem_username} {if $f.mem_name} ) {/if}</td>
      <td nowrap="nowrap" class="center">{$f.date|date_format:"%Y-%m-%d %H:%M:%S"}</td>
      <td class="center"  nowrap="nowrap"> {if $f.type eq 1}<b>{$f.manager_name}</b> {$lang.f.daikoufei}
        <!--���۷�-->
        {/if}
        {if $f.type eq 2}<b>{$f.manager_name}</b>{$lang.f.daichongzhi}
        <!--����ֵ-->
        {/if}
        {if $f.type eq 3}{$lang.f.yucunchongzhi}
        <!--Ԥ����ֵ-->
        {/if}
        {if $f.type eq 4}{$lang.f.yuchunkuanzhifu}
        <!--Ԥ���֧��-->
        {/if}</td>
      <td>{$f.desc}</td>
      <td class="center">{$f.current_money}</td>
      <td class="center">{$f.add_money|default:'-'}</td>
      <td class="center">{$f.cut_money|default:'-'}</td>
      <td class="center">{$f.result_money}</td>
    </tr>
    {/foreach}
    </tbody>
    
  </table>
  {if $finance_data.page}
  <div id="fi_page">{$finance_data.page}</div>
  {/if}
  <div  style="text-align:right; padding:5px; line-height:180%;">
    <!--��ǰ����-->
    {$lang.f.curent_has} {$other.total}
    <!--��,��ת��-->
    <b>{$lang.f.curent_has_1}</b> {$other.total_add}
    <!--Ԫ-->
    {$lang.php_yuan}
    <!--��ת��-->
    <b>{$lang.f.total_zhuanchu}</b> {$other.total_cut} {$lang.php_yuan}
    <!--Ԫ-->
    <b>{$lang.f.zongjine}</b>
    <!--�����-->
    ��{$other.over_all_total}
    <!--Ԫ-->
    {$lang.php_yuan}</div>
  {else}
  <div class="notice_msg">
    <!--�޿�������-->
    {$lang.php_nodata}</div>
  {/if} </div>
{/if}
<!--Ԥ����ͳ�ƽ���-->
<!--��Ա�������п�ʼ-->
{if $action eq 'member_buy_count'}
<form method="post" action="index.php?m=order/finance&a=memberBuyCount">
  <div id="php_top_bar">
    <div class="tb">��ʼʱ�䣺</div>
    <div class="tb">
      <input type="text" name="first" id="start_time" class="date date_input" value="{$day.first_day}"  onfocus="show_date(this);"/>
    </div>
    <div class="tb">����ʱ�䣺</div>
    <div class="tb">
      <input type="text" name="last" id="end_time" class="date date_input" onfocus="show_date(this);" value="{$day.last_day}" />
    </div>
    <div class="tb">
      <input  type="submit" value="{$lang.php_search}" class="form_submit" />
    </div>
  </div>
</form>
<div class="clear"></div>
<div id="php_right_main_content">
  <div class="clear"></div>
  {if $data}
  <table class="table_list">
    <thead>
      <tr>
        <th>���</th>
        <th>�û�</th>
        <th>������</th>
        <th>�����</th>
        <th>����</th>
      </tr>
    </thead>
    <tbody>
    {foreach from=$data key= k item = d}
    <tr>
      <td class="center">{$k+1}</td>
      <td class="center"><a href="javascript:;" onclick="window.parent.showWindow('��{$d.mem_name}��- ��{$d.mem_username}�����˻���Ϣ','index.php?m=member&a=detail&memid={$d.mem_id}&noborder=true',900,300);" class="blue">{$d.mem_name}</a></td>
      <td class="center">{$d.order_total_num}</td>
      <td class="center">{$d.total_money|money_format}</td>
      <td class="center">
<a href="javascript:;"  class="blue" onclick="_do_window_open('��{$d.mem_name}���Ķ���','index.php?m=order&a=searchOrder&reciver=&order_no=&order_status=has_pay&member_name={$d.mem_username}')">����</a>&nbsp;
<a  href="javascript:;"  class="blue"  onclick="_do_window_open('��{$d.mem_name}�����ʽ���־','index.php?m=member/money&a=moneylog&opt=not_show_header&id={$d.mem_id}');">�ʽ�</a>&nbsp;
<a  href="javascript:;"  class="blue"  onclick="_do_window_open('��{$d.mem_name}���Ļ�����־','index.php?m=member&a=viewPointLogs&id={$d.mem_id}');">����</a>&nbsp;
      </td>
    </tr>
    {/foreach}
    </tbody>
  </table>
<script type="text/javascript">
	function _do_window_open(t,u){
		window.parent.showWindow(t,u,980,450);		
	}
</script>
  {else}
  <div class="notice_msg">
    <!--�޿�������-->
    {$lang.php_nodata}</div>
  {/if} </div>
{/if}
<!--��Ա�������н���-->
<!-- ������Ʒ���п�ʼ-->
{if $action eq 'salesRanks'}
<div id="php_top_bar">
  <form method="post" action="index.php?m=order/finance&a=salesRank">
    &nbsp;
    ��ʼʱ��
    :
    <input type="text" name="first" value="{$day.first_day}"  onfocus="show_date(this);" class="date date_input"  id="do_f_start" style="margin-bottom:4px;" />
    <!--����ʱ��-->
    ����ʱ��
    :
    <input style="margin-bottom:4px;"  type="text"  name="last" class="date date_input" onfocus="show_date(this);" id="do_f_end" value="{$day.last_day}" />
    <input  type="submit" value="{$lang.php_search}" class="form_submit"/>
  </form>
</div>
<div class="clear"></div>
<div id="php_right_main_content"> {if $data}
  <table class="table_list">
    <thead>
      <tr>
        <th><!--����-->
          {$lang.f.xuhao}</th>
        <th><!--��Ʒ����-->
          {$lang.f.goods_name}</th>
        <th><!--����-->
          {$lang.f.numbers}</th>
        <th><!--�ܽ��-->
          {$lang.f.zongjine}</th>
      </tr>
    </thead>
    <tbody>
    
    {foreach from=$data key=k item=d}
    <tr>
      <td class="center">{$k+1}</td>
      <td>{$d.goods_name} <a href="{$d.goods_view_link}" target="_blank" class="blue">
        <!--ǰ̨-->
        {$lang.f.public_view}</a> | <a href="javascript:void(0);" onclick="if(confirm(php_location_notice))this.href='index.php?m=goods/products&a=productsList&s_type=title&search_goods_val={$d.search_key}'" class="blue">
        <!--��̨-->
        {$lang.f.admin_view}</a></td>
      <td class="center">{$d.total_goods_num}</td>
      <td class="center">{$d.total_money}</td>
    </tr>
    {/foreach}
    </tbody>
    
  </table>
  {else}
  <div class="notice_msg">
    <!--�޿�������-->
    {$lang.php_nodata}</div>
  {/if} </div>
{/if}
<!--������Ʒ���н���-->


<!--���۱��� ��������-->
{if $action eq 'salesReports' || $action eq 'salenumber'}
<script type="text/javascript">
function _set_loading(){
	var obj = $("#php_right_main_content");	
	$(obj).html('<div class="call_extend_dom"><img src="images/zoomloader.gif"/></div>');
	var px = parseInt(($(obj).height()/2));
	px= 200;
	$(".call_extend_dom").css({"margin-top":px+"px", "text-align":"center"});
}
function _do_form_action(form_id,do_action){
	$("#do_action_info").val(do_action);
	$("#do_task").val('showChar');
	var url = _s($('#'+form_id));
	_set_loading();
	var obj = $("#php_right_main_content");	
	$.get(url,function(data){
		$(obj).html(data);
	});
}
function export_baobiao(obj,form_id){
	$("#do_task").val('export');
	var url = _s($('#'+form_id));
	$(obj).attr({'href':url});
}
$(function(){
	_do_form_action('submit_form_fin','year');
});
</script>
<form method="post" action="{$do_url_action}" id="submit_form_fin" style="margin-top:150px; text-align:center;">
<input type="hidden" value="showChar" name="task" id="do_task" />
<input type="hidden" value="year" name="date_type" id="do_action_info" />
  <div id="php_top_bar">
    <div class="tb">ѡ��:</div>
    <div class="tb">
      <select name="year">
        {foreach from=$year item=y}
        <option value="{$y}" {if $sec_data.y eq $y} selected="selected"{/if}>{$y}��</option>
        {/foreach}
      </select>
    </div>
    <div class="tb">
      <select name="month">
        {foreach from=$month item=m}
        <option {if $sec_data.m eq $m} selected="selected"{/if} value="{$m}">{$m}��</option>
        {/foreach}
      </select>
    </div>
    <div class="tb"> <a href="javascript:;" onclick="_do_form_action('submit_form_fin','year')"  class="block_button form_btn">�걨��</a> </div> 
    <div class="tb"> <a href="javascript:;" onclick="_do_form_action('submit_form_fin','month')" class="block_button form_btn">�±���</a> </div>
    <div class="tb"> <a href="javascript:;" target="_blank" onclick="export_baobiao(this,'submit_form_fin');" class="block_button form_btn">�����������</a> </div>
    </div>
</form>
<div class="clear"></div>
<div id="php_right_main_content" style=" margin:0px; padding:0px;"><img src="images/zoomloader.gif"/></div>
{/if}


<!--���۱�������-->
<!--//������빺��δ��� �ı���-->
{if $action eq 'clickbuyratio'}
<div id="php_top_bar"> <a href="index.php?m=order/finance&a=clickbuyratio&export=true&type=xls&key={$export}" class="block_button">{$lang.f.export_excel}</a> </div>
<div id="php_right_main_content" > {if $buyclick}
  <table class="table_list">
    <tr>
      <th><!--����-->
        ����</th>
      <th><!--�û���-->
        �����</th>
      <th><!--����-->
        �������</th>
      <th><!--������-->
        ����</th>
    </tr>
    {foreach from=$buyclick item=item name=name}
    <tr>
      <td>{$item.gname}</td>
      <td class="center">{$item.clicknum}</td>
      <td class="center">{$item.c}</td>
      <td class="center">{$item.ratio}%</td>
    </tr>
    {/foreach}
  </table>
  {else}
  <div class="notice_msg">
    �޿�������!
  </div>
  {/if} </div>
{/if}
<!--������빺��δ��� �ı���//-->
<!-----//����ָ��------------>
{if $action eq 'salequota'}
<div id="php_right_main_content" >
  <div class="salequota_pannel">
    <table  width="100%"  border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td  width="50%" valign="top"><div class="salequota">
            <div class="name">
              ƽ��ÿλ�ͻ��������
            </div>
            <div class="data">
              <div class="salequota_title fontcolor" >�������</div>
              <div class="salequota_title fontcolor" >�ܻ�Ա��</div>
              <div class="salequota_title fontcolor" >ƽ��ÿλ�ͻ��������</div>
              <div class="salequota_title" >��{$ordermoney|default:'0'}</div>
              <div class="salequota_title" >{$membernumber}</div>
              <div class="salequota_title" >��{$moneymember|default:'0'}</div>
            </div>
            <div class="clear"></div>
          </div>
          <div class="salequota">
            <div class="name">����ת����</div>
            <div class="data">
              <div class="salequota_title fontcolor" >�ܶ�����</div>
              <div class="salequota_title fontcolor" >�ܷ��ʴ���</div>
              <div class="salequota_title fontcolor" >����ת����</div>
              <div class="salequota_title" >{$ordernumber}</div>
              <div class="salequota_title" >{$visitedsum}</div>
              <div class="salequota_title" >{$ordvisiratio}%</div>
            </div>
            <div class="clear"></div>
          </div>
          <div class="salequota">
            <div class="name">ƽ����Ա������</div>
            <div class="data">
              <div class="salequota_title fontcolor" >�ܶ����� </div>
              <div class="salequota_title fontcolor" >�ܻ�Ա��</div>
              <div class="salequota_title fontcolor" >ƽ����Ա������</div>
              <div class="salequota_title" >{$ordernumber}</div>
              <div class="salequota_title" >{$membernumber}</div>
              <div class="salequota_title" >{ $memordratio}</div>
            </div>
            <div class="clear"></div>
          </div></td>
        <td width="50%" valign="top"><div class="salequota">
            <div class="name">ƽ��ÿ�η��ʶ������</div>
            <div class="data">
              <div class="salequota_title fontcolor" >�������</div>
              <div class="salequota_title fontcolor" >�ܷ��ʴ���</div>
              <div class="salequota_title fontcolor" >ƽ��ÿ�η��ʶ������</div>
              <div class="salequota_title" >��{$ordermoney|default:'0'}</div>
              <div class="salequota_title" >{$visitedsum}</div>
              <div class="salequota_title" >��{ $moneyvisiratio|default:'0'}</div>
            </div>
            <div class="clear"></div>
          </div>
          <div class="salequota">
            <div class="name">ע���Ա������</div>
            <div class="data">
              <div class="salequota_title fontcolor" >�й������Ļ�Ա </div>
              <div class="salequota_title fontcolor" >�ܻ�Ա��</div>
              <div class="salequota_title fontcolor" >ע���Ա������</div>
              <div class="salequota_title" >{$ordermember}</div>
              <div class="salequota_title" >{$membernumber}</div>
              <div class="salequota_title" >{$memberratio}%</div>
            </div>
            <div class="clear"></div>
          </div></td>
      </tr>
    </table>
  </div>
</div>
{/if}
<!--����ָ��//-->
{include file="frame_footer.php"}