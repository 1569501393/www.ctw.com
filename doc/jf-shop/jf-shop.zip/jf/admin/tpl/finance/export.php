<?php  exit('die');?>
<!--#�������۱���-->
{if $action eq 'export_sale_report'}
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<style>
td{vnd.ms-excel.numberformat:@}
</style>
</head>
<table width="100%" border="1">
  <tr>
    <th colspan="3" filter="all" align="center">{$title}</th>
  </tr>
  <tr>
	<th filter="all">ʱ��</th>
    <th filter="all">{if $curent_action eq 'salenumber'}����{else}���{/if}</th>
    <th filter="all">ʱ�䷶Χ</th>
  </tr>
  {foreach from=$data item=list}
  <tr>
    <td align="center">{$list.do_string}</td>
    <td align="center">{if $curent_action eq 'salenumber'}{$list.total}{else}{$list.total}|money_format}{/if}</td>
    <td align="center">{$list.start}��{$list.stop}</td>
  </tr>
  {/foreach}
  <tr>
    <td colspan="3" align="right">
    {if $curent_action eq 'salenumber'}
    	���ƣ�{$total}
    {else}
    �ܶ{$total|money_format}
    {/if}
      
      </td>
  </tr>
</table>
{/if}