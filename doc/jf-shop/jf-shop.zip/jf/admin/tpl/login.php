<?php  exit('diie');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>{$lang.common.login_title}</title>
{if $can_login=='ok'}
<style type="text/css">
*,body{ margin:0px; padding:0px; font-size:12px;}
img,tbody,th,table,td,div,ul,li,p,span,dl,dt,dd,frame,h1,h2,h3,h4,h5{margin:0px; padding:0px; border:0px;font-size:12px;font-family:"����",Arial, Helvetica, sans-serif; line-height:normal; color:#000000;font-weight:normal;}
body{ margin:0px; padding:0px;height:100%; overflow: hidden;background:#367FA5 url(images/login/bg.jpg) right 0px  no-repeat;}
p{line-height:180%; vertical-align:middle; padding:5px 0px;}
img{ border:0px;}a{ color:#FFF; text-decoration:none;}
#login_page{ height:auto; clear:both; width:100%; clear:both; z-index:100;}
#ct_all{ width:550px; height:100px; position: relative; top:250px; left:250px; clear:both; display: block; z-index:1000;}
#bar_left{ width:226px; height:115px; float:left;margin-right:10px;}
#foot{ position:relative; text-align:center; color:#88D2F4; line-height:30px; top:380px;clear:both; display:block; z-index:10;}
#foot a,#foot a:hover{ color:#88D2F4; font-family:Verdana, Geneva, sans-serif; font-size:12px;}
#pannel em{ font-style:normal; color:#FFF;}
.input_set{ border:1px solid #FFF;height:20px; line-height:20px; color:#000; width:127px;}
.read_input{ border:1px solid #369;}
#login_btn{ text-align:center; width:550px; clear:both; position: absolute; top:130px;}
#login_btn input{ background:url(images/login/btn.jpg) left top no-repeat; width:67px; height:26px; border:none; color:#000;}
#login_btn span{ margin-left:20px;}
#ajaxCallMsg{ position: absolute; left:150px;top:150px;color:#FFF;border:1px solid #fff;text-align:center;padding:8px; margin:0px auto;display:none;width:580px;text-align:left;}
#ajaxCallMsg font{ color: #FFF;}
#cap_imgs{ margin-bottom:-8px;cursor:pointer;}
</style>
{insert_scripts files='js/jquery-1.4.min.js'}
<script language="JavaScript">
{foreach from=$lang.login.js_languages key=key item=item}var {$key} = "{$item}";{/foreach}
</script>
<script type="text/javascript">
function checkForm(){
	var result = true;
	$(".must_fill_in").each(function(i){
		var val = $.trim($(this).val());
		if(val ==''){$(this).addClass('read_input');result = false;}else{$(this).removeClass('read_input');}
	});
	return result;
}
function _login(){
	if(!checkForm())return false;
	var n = $("#name").val();var p = $("#pass").val();var c = $("#cap").size();var opt = {};
	opt = $("#cap").size()>0?{cp_name:n,cp_passwords:p,cp_captcha:$("#cap").val()}:{cp_name:n,cp_passwords:p};
	$.post('index.php?m=login&a=do',opt,function(d){
			var e = d.split('|');
			var error = $.trim(e[0]);
			switch(error){
				case '1':window.location.href='index.php?m=login&a=login&rand='+Math.random();break;
				case '3':return window.location.href='index.php?rand='+Math.random();break;
				default:alert(d);
			}
	});
}
function _resize(){
	var d = $("#ajaxCallMsg");
	if($(d).length){
		var left = parseFloat(($(this).width()-$(d).width())/2)
		$(d).css({"left":left+'px'});
	}
	var cal_main = $("#ct_all");
	$(cal_main).css({"left":parseFloat(($(this).width()-$(cal_main).width())/2)+'px'});
	if(!$(".ecap_pannel").length){
		$("#pannel").css({"padding-top":"20px"});	
	}
	if(window.screen.width>1024){
		$("#foot").css({"top":"380px"});	
	}	
}
$(function(){
	$("#cap").focus(function(){_show_code();});
	$("#login_form").submit(function(){
		_login();return false;	
	});
	_resize();
	$(this).resize(function(){
		_resize();
	});
});
function _show_code(){$("#cap_imgs").attr({"src":"../captcha.php?w=86&h=25&num=4&hash=0&rand="+Math.random()});}
  function correctPNG(){
		for(var i=0; i<document.images.length; i++)
		{
		var img = document.images[i];
		var imgName = img.src.toUpperCase();
			if (imgName.substring(imgName.length-3, imgName.length) == "PNG")
			{
				var imgID = (img.id) ? "id='" + img.id + "' " : "";
				var imgClass = (img.className) ? "class='" + img.className + "' " : "";
				var imgTitle = (img.title) ? "title='" + img.title + "' " : "title='" + img.alt + "' ";
				var imgStyle = "display:inline-block;" + img.style.cssText;
				if (img.align == "left") imgStyle = "float:left;" + imgStyle;
				if (img.align == "right") imgStyle = "float:right;" + imgStyle;
				if (img.parentElement.href) imgStyle = "cursor:hand;" + imgStyle;
				var strNewHTML = "<span "+ imgID + imgClass + imgTitle + "style=\"" + "width:" + img.width + "px; height:" + img.height + "px;" + imgStyle + ";" 
				+ "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader" + "(src='" + img.src + "', sizingMethod='scale');\"></span>";
				img.outerHTML = strNewHTML;
				i = i-1;
			}
		}
    }
	var isIE=!!window.ActiveXObject; 
	var isIE6=isIE&&!window.XMLHttpRequest;
	if(isIE6){window.attachEvent("onload", correctPNG);} 	
</script>
</head>
<body scroll="no">
<form method="post" action="" id="login_form" autocomplete="off">
<div id="login_page">
{if $notice_msg || $e_msg}
<div id="ajaxCallMsg" style="{if $notice_msg}display:block;{/if}">{$notice_msg}<br /><br />{if $e_msg}<b>{$lang.login.error_notice}</b><font>{$e_msg}</font>{/if}</div>
{/if}
<div id="ct_all">
	<div id="bar_left"><img src="images/login/bar1.png" /></div>
	<div id="pannel">
		<p><em>{$lang.login.username}��</em><span><input class="input_set must_fill_in" type="text" value="" id="name"  name="cp_name" maxlength="30"/></span></p>
		<p><em>{$lang.login.userpass}��</em><span><input class="input_set must_fill_in" type="password" id="pass" value="" name="cp_passwords" maxlength="40" /></span></p>
		{if $login_times>0}<p class="ecap_pannel"><em>{$lang.login.captcha}��</em><span><input type="text" class="input_set must_fill_in" name="cp_captcha" value="" id="cap" maxlength="4" /></span><span id="cap_img">
        <img src="../captcha.php?w=86&h=25&num=4&hash=0"  width="80" id="cap_imgs" onclick="_show_code();"/></span></p>{/if}
    </div>
     <div id="login_btn" class="btn"><span><input type="submit"  onfocus="this.blur();" class="btn" value="{$lang.login.submit}" /></span><span><input type="reset"  class="btn" value="{$lang.login.cache}"  onfocus="this.blur();" /></span></div>
<div class="clear"></div>
</div>
<div class="bar" id="foot"><a href="http://www.php.cm" target="_blank">PHP&copy;2011-2021 �������������缼�����޹�˾,����������Ȩ��</a></div>
<div class="clear"></div>
</div>
{else}
<div style=" font-size:14px; color: #F00; line-height:18px; text-align:center; margin:40px auto; border:3px solid #F00; width:300px; line-height:20px; padding:8px;">{$not_login_msg}</div>
{/if}
</form>
</body>
</html>