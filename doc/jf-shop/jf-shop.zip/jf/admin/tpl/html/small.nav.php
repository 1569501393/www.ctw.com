<?php exit('die'); ?>
<div id="php_top_bar" style="background:#FFF; border:none;">
  <div class="table_scroll">
    <ul class="menu" id="show_bar_menus" style="padding-left:4px;">
      <li class="wintable_curent" id="make_all_htmls"><a href="index.php?m=html&a=createhtml">��ݲ���</a></li>
      <li id="do_category"><a href="index.php?m=html&a=do_category" >��Ʒ����</a></li>
      <li id="do_region"><a href="index.php?m=html&a=do_region" >��������</a></li>
      <li id="do_gooods_detail"><a href="index.php?m=html&a=do_gooods_detail">������Ʒ����</a></li>
      <li id="do_brands"><a href="index.php?m=html&a=do_brands">����Ʒ��</a></li>
      <li id="article_category"><a href="index.php?m=html&a=article_category" >���·���</a></li>
      <li id="do_article"><a href="index.php?m=html&a=do_article" >��������</a></li>
    </ul>
  </div>
</div>
<script type="text/javascript">
	function make_all_data(obj){
		if(!confirm("ȷ��Ҫ������?\r\n�������ཫ�ķѱȽϴ��ϵͳ��Դ!"))return false;
		window.open($(obj).attr('rel'));
	}
	$(function(){
		var u = window.location.href;
		var end = u.split('a=').pop();
		end = end.split('&page').shift();
		$('.wintable_curent').removeClass('wintable_curent');
		$("#"+end).addClass('wintable_curent');
		if($('.wintable_curent').size()<=0){
			$("#make_all_htmls").addClass('wintable_curent');
		}
		var has = $('.wintable_curent');
		$("#show_bar_menus li").hover(function(){
			$(this).addClass('wintable_curent');
		}, function(){
			$(this).removeClass('wintable_curent');
			$(has).addClass('wintable_curent');
		});
	});
</script>
<div class="clear"></div>
