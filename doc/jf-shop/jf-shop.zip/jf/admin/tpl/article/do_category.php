<?php  if(!defined('PHP_TEMPLATE'))exit();?>
{if !$is_ajax_call}
{include file="frame_header.php"}
<form method="post" action="{if $action eq 'add'}index.php?m=article&a=addarticlecategory{else}index.php?m=article&a=editarticlecategory{/if}" id="category_save_form" autocomplete="off">
<div id="php_top_bar" class="php_bot_bar">
	<div class="tb"><a href="javascript:;" onclick="window.location.reload();" class="block_button">ˢ��</a></div>
	<div class="tb"><a href="javascript:;" onclick="submit_form('category_save_form');" class="block_button form_btn">����</a></div>
</div>
<div id="php_right_main_content">
{/if}
<script language="JavaScript">
	{foreach from=$lang.article.js_html key=key item=item}
		var {$key} = "{$item}";
	{/foreach}
$(function(){
	$("#category_save_form").submit(function(){
		if(!check_form_is_empty('must_fill_in_tags')){
			window.parent.showNotice('�����������!');
			return false;
		}
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'EMPTY_CATE_NAME':
					window.parent.showNotice(EMPTY_CATE_NAME);<!--'�������������!'-->
				break;
				case 'HAS_EXIST_CATE':
					window.parent.showNotice(HAS_EXIST_CATE);<!--'������ͬ�ķ�������!'-->
				break;
				case 'NOT_EXIST_PARENT_CATE':
					window.parent.showNotice(NOT_EXIST_PARENT_CATE);<!--'�����ڸø�����'-->
				break;
				case 'ERROR':
					window.parent.showNotice(ERROR);<!--'��������!'-->
				break;
				case 'HAS_EXIST_CATE_SIGN':
					return window.parent.showNotice(HAS_EXIST_CATE_SIGN);<!--'�Ѵ�����ͬ�ķ����־λ'-->
				break;
				case 'DO_ERROR':
					window.parent.showNotice(please_re_select_cate);<!--'������ѡ�񸸷���!'-->
				break;
				case 'OK':
				case 'F':
					{if $action eq 'add'}
					window.parent.showNotice(do_ok_and_can_add);<!--�����ɹ�-->	
					$("#cat_names").val('');
						
					{else}
					window.parent.showNotice(do_ok);<!--�����ɹ�-->
					_close_window_one();
						{/if}
					_reload_frame();
				break;
				default:alert(data);
			}
		});
		return false;
	});
	$.table_bars($("#do_article_category li"));
});
</script>
<div id="do_article_category" class="table_scroll">
    <ul class="menu" id="show_menus">
        <li name="cfg_all">ȫ��</li>
        <li name="cfg_base" class="wintable_curent">������Ϣ</li>
        <li name="cfg_seo">SEO��Ϣ</li>
        <li name="cfg_html">��̬����</li>
    </ul>
</div>
{if $is_ajax_call}
<form method="post" action="{if $action eq 'add'}index.php?m=article&a=addarticlecategory{else}index.php?m=article&a=editarticlecategory{/if}" id="category_save_form" autocomplete="off">
{/if}
<div class="table_item_base">
    <div class="table_item" id="cfg_base">
        <h1 class="c_bar">������Ϣ</h1>
            <div class="c_content">
            <table class="table_common">
             <tr>
                <td class='one'>{$lang.article.category_name}</td>
                <td><input type="text" name="category_name" value="{$cat.category_name}" id="cat_names" class="must_fill_in_tags  category_all_val bg_input w300"/><span class="blue">*</span></td>
            </tr>
            <tr>
                <td class='one'>{$lang.article.up_category}</td>
                <td><select  name="parent_id"  id="cat_parent_tree"  class="w300">
                    <option value="0" selected="selected">{$lang.article.top_category}</option>
                    {foreach from = $tree_list item = list}
                    <option value="{$list.category_id}" {if $cat.parent_id eq $list.category_id}selected{/if}>{$list.spacer}{$list.category_name}</option>
                    {/foreach}
                  </select></td>
              </tr>
           <tr>
                <td class="one">��ʶλ</td><!-- ��ʶλ -->
                <td>
                    <input type="text" maxlength="50" name="category_sign" value="{$cat.category_sign}"  class="form_text category_all_val bg_input w300"/>
                    <input type="button" value="<% _e('��ȡƴ��');%>" onclick="window.parent.get_pinyin($('#cat_names').val(),$(this).prev());" class="form_submit"/>
                </td>
            </tr> 
           <tr>
                <td class="one">ÿҳ��ʾ����</td><!-- ��ʶλ -->
                <td>
                   <input type="text"  name="seo[perpage_number]"  value="{$cat.category_seo.perpage_number}" class="w300 form_input" />
                </td>
            </tr> 
            {if $cat.category_have neq '1'}
            <tr>
            	<td class="one">�ӷ���ģ��</td>
                <td><input  type="checkbox" value="1" {if $cat.focus_son_use_tpl eq '1'} checked="checked" {/if} name="focus_son_use_tpl" />
                <p class="notice_desc blue" style="padding-top:5px;">����ѡ�����������ӷ��඼��ʹ�ô˵�ǰ����ģ��</p>
                </td>
            </tr>
            <tr>
            	<td class="one">����ģ��</td>
                <td><input type="text" value="{$cat.son_cate_tpl}" name="son_cate_tpl"  class="form_text w300"/>
                <p class="notice_desc blue" style="padding-top:5px;">������������ģ��,��÷��༰���������ӷ����µ����½�ʹ�ô�����(���ȼ�С�����µ��������ģ��)</p>
                </td>
            </tr>
            {/if}
            <tr>
            	<td class="one">����ʽ</td>
                <td><select name="extend_data[sort_type]" class="w300">
                	<option value="">ʹ��ȫ������</option>
                	<option value="pub_desc" {if $extend_data.sort_type eq 'pub_desc'} selected="selected"{/if}>����ʱ�併��</option>
                	<option value="pub_asc" {if $extend_data.sort_type eq 'pub_asc'} selected="selected"{/if}>����ʱ������</option>
                	<option value="sort_desc" {if $extend_data.sort_type eq 'sort_desc'} selected="selected"{/if}>����������</option>
                	<option value="sort_asc" {if $extend_data.sort_type eq 'sort_asc'} selected="selected"{/if}>������������</option>
                	<option value="click_desc" {if $extend_data.sort_type eq 'click_desc'} selected="selected"{/if}>�������</option>
                	<option value="click_asc" {if $extend_data.sort_type eq 'click_asc'} selected="selected"{/if}>�������</option>
                </select></td>
            </tr>
            <tr>
            	<td class="one">�ӷ���̳и���������</td>
                <td><input type="checkbox" value="1" {if $extend_data.son_category_fix_parent_set} checked="checked"{/if} name="extend_data[son_category_fix_parent_set]" />
                <p>���������ӷ����µ������б���ʾ����������������</p>
                </td>
            </tr>
            <tr>
                <td class="one">{$lang.article.templete_file}</td>
                <td><input type="text" maxlength="255"  name="templete_file" value="{$cat.templete_file}"  class="form_text category_all_val bg_input w300" /></td>
            </tr> 
             <tr>
            <td class="one">{$lang.article.categroy_sort}</td>
            <td><input type="text" maxlength="5"  name="category_sort" value="{$cat.category_sort|default:'0'}" class="form_text category_all_val bg_input w300" /></td>
        </tr> 
             </table>
        </div>
    </div><!--#������Ϣ����-->
    
    <div class="table_item" id="cfg_seo">
        <h1 class="c_bar">SEO����</h1>
            <div class="c_content">
			<table class="table_common">
                <tr>
                <td class='one'> meta->title</td>
                <td><textarea name="seo[category_meta_title]" class="category_all_val seo_set">{$cat.category_seo.category_meta_title}</textarea></td>
                </tr>
                 <tr>
                    <td class='one'>{$lang.article.category_seo_title}(seo):</td>
                    <td><textarea name="seo[category_title]" class="category_all_val seo_set">{$cat.category_seo.category_title}</textarea></td>
                </tr> 
                <tr>
                  <td class='one' >{$lang.article.category_desc}(seo):</td>
                  <td><textarea name="seo[category_desc]"  class="category_all_val seo_set">{$cat.category_seo.category_desc}</textarea></td>
                </tr>
                 <tr>
                    <td class='one'>{$lang.article.category_keyword}(seo):</td>
                    <td><textarea name="seo[category_keyword]"  class="category_all_val seo_set">{$cat.category_seo.category_keyword}</textarea></td>
                </tr>
            </table>
       	 </div>
        </div><!--#����SEO����-->
    <div class="table_item" id="cfg_html">
        <h1 class="c_bar">��̬����</h1>
            <div class="c_content">
            <table class="table_common">
                <tr>
                <td class="no_border">
                    {include file="widget/set_html.php"}
                </td>
                </tr>
            </table>
        </div>
        </div><!--#��̬����-->
</div>
<input  type="submit" value="{$lang.article.save}"  class="form_submit" id='close_editsubmit'  style="display:none"/>
<input type="hidden" name="category_id" value="{$cat.category_id}" />
<input type="hidden" name="category_old_name" value="{$cat.category_name}"/>
{if $is_ajax_call}
	<div class="clear"></div>
    <div style="margin-top:-20px;">
    <table class="table_common">
        <tr>
            <td style="border:none;"></td>
            <td class="no_border">
                <a href="javascript:;" onclick="submit_form('category_save_form');" class="block_button form_btn">����</a>
            </td>
        </tr>
    </table>
    </div>
 </form>
{/if}
{if !$is_ajax_call}
</div>
 </form>
{include file="frame_footer.php"}
{/if}