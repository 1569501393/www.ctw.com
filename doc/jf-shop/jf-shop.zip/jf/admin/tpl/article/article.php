<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{include file="frame_header.php"}
<script language="JavaScript">
	{foreach from=$lang.article.js_html key=key item=item} var {$key} = "{$item}"; {/foreach}
</script>
{literal}
<script type="text/javascript">
$(document).ready(function(){
close_open_helper('article_helper','article_info_msg');
checkAllFormData('chkall','article_id');
 $("#sub_articel_form").submit(function(){
	$(this).ajaxSubmit({success:function(data){
		var c = data.split('|');
		switch(c[0]){
			case '1':
				window.parent.showNotice(c[1]);
				return ;
			break;
			case '2':
				window.parent.showNotice(c[1]);
				window.location.reload();
			break;
			default:alert(data);
		}
	}});
	return false;
});
 $("#search_form").submit(function(){
		window.location.href=_s(this);return false;
 });
});
function _submit_form(tag){
	$("#opt_action_id").val(tag);
	$("#sub_articel_form").submit();
}
function delArticle(){
	$("#opt_action_id").val('delete');
	var d = get_checkbox_val('article_id');
	if(empty(d))return window.parent.showNotice(php_empty_select);
	if(!confirm('ȷ��ɾ����?�˲������ɻָ�!'))return false;
	//if(confirm("�Ƿ�ͬʱɾ�����ɵľ�̬ҳ��?"))
	$("#delete_type").val('delete_html');
	$("#sub_articel_form").submit();
}
function butch_article(){
	var d = get_checkbox_val('article_id');
	if(!d)return window.parent.showNotice(php_empty_select);
	window.parent.showWindow("<% _e('����ת������');%>",'index.php?m=article&a=butcharticle&ids='+d,600,400);
}
$(function(){
   $("#cate").change(function(){
       if($(this).val()==''){
	   }else{
	    return window.location.href='index.php?m=article&a=listarticle&category_id='+$(this).val();
	   }	   
   });	
});
 </script>
 {/literal}
<!--�����б�--if--start-->
<form method="get" id="search_form" action="index.php?m=article&a=listarticle">
<div id="php_top_bar" style="padding:0 0 0 10px">
<div class="tb">
{if !$art_cate}{else}
<select id="cate">
 <option value="">�������������</option>
 {foreach from = $art_cate item = list}
 {if $list.parent_id eq 0}
 <option value="{$list.category_id}" {if $list.category_id eq $category_id}selected{/if}>{$list.spacer}{$list.category_name}</option>
 {/if}
 {/foreach}
</select>
{/if}
<input type="hidden" value="search" name="search" class="form_submit"/>
<input type='text' maxlength='20' value="{$search_str}" name="key" />
<input type="submit" value="{$lang.article.search}" class="form_submit" style="display:none"/>
</div>
<div class="tb"><a href="javascript:;" onclick="submit_form('search_form');" class="block_button form_btn">����</a></div>
{if $article.total>0}
{if $can_delete}<div class="tb"><a  href="javascript:;"  class="block_button" onclick="delArticle();">{$lang.article.delArticle}</a></div>{/if}
<div class="tb"><a  href="javascript:;"  class="block_button" onclick="_submit_form('permit')">{$lang.article.batch_permit}</a></div>
<div class="tb"><a  href="javascript:;"  class="block_button" onclick="_submit_form('reject')">{$lang.article.batch_reject}</a></div>
<div class="tb"><a  href="javascript:;"  class="block_button" onclick="butch_article(this);"><% _e('����ת������');%></a></div>
{/if}
</div>
</form>
<div id="php_right_main_content">
{if $article.total>0}
<form method="post" id="sub_articel_form" action="">
<input type="hidden" value=""  name="delete_type"   id="delete_type"/>
<input type="hidden" value="" id="opt_action_id" name="opt_action"/>
<table class="table_list table_list_hover" style="*margin-left:-10px;">
    <tr>
        <th nowrap="nowrap">{if $can_delete}<input name='chkall' type='checkbox' id='chkall'>{else}<% _e('���');%>{/if}</th>
        <th nowrap="nowrap">{$lang.article.operation}</th>
        <th nowrap="nowrap">{$lang.article.article_title}</th>
        <th nowrap="nowrap">{$lang.article.hit}</th>
        <th nowrap="nowrap">����</th>
        <th nowrap="nowrap">{$lang.article.public}</th>
        <th nowrap="nowrap">{$lang.article.article_date}</th>
        <th nowrap="nowrap">{$lang.article.article_category}</th>
        <th nowrap="nowrap">��������</th>
<tbody>
{foreach from=$article.data item=art key=k}
<tr align="center" id="row{$k}" name='show{if $art.article_public==0}1{else}{$art.article_public}{/if}' class='cat'>
  <td width="30"> {if $can_delete} <input type="checkbox" name="cid[]"   class="article_id" id="{$art.article_id}" value="{$art.article_id}">{else}{$art.article_id}{/if}</td>
    <td>{if $art.html_link}<a href="{$art.html_link}" target="_blank">��</a>{/if} {if $can_edit}<a href="index.php?m=article&a=editarticle&article_id={$art.article_id}">��</a>{/if} <a href="{$art.view_link}" target="_blank">��</a></td>
    <td title="{$art.article_long_title}" style='text-align:left'><a href="{$art.view_link}" target="_blank">{$art.article_long_title|truncate:35:""}</a></td>
    <td>{$art.article_hit|default:0}</td>
    <td>{$art.article_seq}</td>
    <td>{if $art.article_public eq 2}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
    <td>{if $art.edit_time}{$art.edit_time|date_format:"%Y-%m-%d %H:%M:%S"}{else}{$art.article_date|date_format:"%Y-%m-%d %H:%M:%S"}{/if}</td>
    <td nowrap="nowrap"><a href="index.php?m=article&a=listarticle&category_id={$art.category_id}">{$art.category_name}</a></td>
    <td nowrap="nowrap">{if $art.allow_comment neq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
</tr>
{/foreach}
</tbody>
</table>
<div id="pagelist">{$article.page}</div>
</form>
{else}
<div class="notice_msg"><a href='index.php?m=article&a=addarticle'>{$lang.article.no_article_please_add}</a></div>
{/if}<!--û������������-end-->

</div>
<!--�����б�--if--end-->
{include file="frame_footer.php"}