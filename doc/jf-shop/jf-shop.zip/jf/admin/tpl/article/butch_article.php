<?php exit('die'); ?>
{if $action eq 'butch_article'}
<div class="butch_article_pannel">
	<ul>
    {foreach from=$article_list item='list'}
    	<li>{$list.article_long_title}</li>
        {/foreach}
    </ul>
    <div class="clear"></div>
<script type="text/javascript">
	$(function(){
		$("#do_article_butch").submit(function(){
			if(!check_form_is_empty('must_in_check')){
				window.parent.showNotice(php_empty_select);	
				return false;
			}
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						_close_window_one();
						window.frames['rightFrame'].location.reload();
						window.parent.showNotice(php_do_ok);
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
<form method="post" action="index.php?m=article&a=butcharticle" id="do_article_butch">
<div class="bcatsss">
<% _e('����������ת����->');%>
 {if !$tree_list}<font class="blue">{$lang.article.no_article_category}</font>{else}
<select  name="category_id"  class='form_option must_in_check' style="width:200px;">
<option value="">{$lang.article.empty_select_categroy}</option>
        {foreach from = $tree_list item = list}
            <option value="{$list.category_id}" {if $list.category_id eq $art.category_id}selected{/if}>{$list.spacer}{$list.category_name}</option>
        {/foreach}
    {/if}
</select>
<input type="submit" class="form_submit" value="<% _e('�� ��');%>" />
</div>
</form>
</div>
{/if}