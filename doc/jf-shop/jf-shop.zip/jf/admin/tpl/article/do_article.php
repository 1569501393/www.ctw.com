<?php if(!defined('PHP_TEMPLATE'))exit();?>
{if $action eq 'edit' || $action eq 'add'}{include file="frame_header.php"}{/if}
<script language="JavaScript">
{foreach from=$lang.article.js_html key=key item=item} var {$key} = "{$item}";{/foreach}
var not_attrs= '{$lang.article.this_group_no_attr}';
</script>
{if $action eq 'edit' || $action eq 'add'}
<form method="post" action="" id="ajax_submit_form">
<input type="submit" style="display:none;" value="����" />
<div id="php_top_bar" class="php_bot_bar">
    <div class="top_bar_pannel">
        <div class="tb"> <a class="block_button" onclick="window.location.reload();">ˢ��</a></div>
        <div class="tb"><a class="block_button form_btn" onclick="submitGeneralForm();">����</a></div>
    </div>
</div>
<div id="php_right_main_content">
	<div id="add_goods_products" class="table_scroll">
		<ul class="menu" id="show_menus">
        	<li name="cfg_all">ȫ��</li>
            <li name="cfg_base" class="wintable_curent">����</li>
            <li name="cfg_seo">SEO</li>
            <li name="cfg_extend">��չ����</li>
		</ul>
	</div>
<div class="table_item_base">
<div class="table_item" id="cfg_base">
	<h1 class="c_bar">������Ϣ</h1>
    <div class="c_content">
    
<script type="text/javascript">
    function getRegionChild(obj){
		var val = $(obj).val();
		var parent = $(obj).attr("parent");
		if(val != ''){
			$.get('index.php?m=default&a=getRegion',{'parentid':val},function(callback){
				$(obj).parent().nextAll().remove();
				$(obj).nextAll().remove();
				$(obj).parent().append(callback);
			});
		}
  }
</script>
<table class="table_common">
  <tr>
    <td valign="top" style="border-right:1px solid #EEE;">
     <!--a-->
     <table class="table_common">
      <tr>
         <td style="width:60px;" class="one">����</td>
         <td><input type="text" value="{$art.article_long_title}" name="article_long_title" maxlength="255" id="art_bg" class="must_in"/> <span class="blue">*</span></td>
      </tr>
      <tr>
         <td class="one">��Դ</td>
         <td><input type="text" class="w300" maxlength="50" value="{$art.article_source}" name="article_source"/> <span class="blue">*</span></td>
      </tr>
      <tr>
         <td class="one">��Դ��ַ</td>
         <td><input type="text" maxlength="255" class="w300" value="{$art.article_surl}" name="article_surl"/></td>
      </tr>
      <tr>
         <td class="one">��ת��ַ</td>
         <td><input type="text" class="input_notice w300" title="{$lang.article.extUrlLike}" value="{$art.article_exturl}" name="article_exturl"/></td>
      </tr>
      <tr>
         <td class="one">�Զ���ģ���ļ���</td>
         <td><input type="text" name="template_file" maxlength="255" class="w300" value="{$art.template_file}"/></td>
      </tr>
      <tr>
        <td class="one">����ժҪ</td>
        <td><textarea name="article_short_content" style="width:450px; height:70px;">{$art.article_short_content}</textarea></td>
      </tr>
      <tr>
        <td colspan="2">��������(ʹ�� [--page--] ��ҳ)</td>
        </tr>
      <tr>
        <td colspan="2" style="background:#F7F7F7;border:1px solid #EFEFEF;width:100px;">{$FCK}</td>
      </tr>
     </table>
     <!--a-->
    </td>
    <td valign="top" style="width:180px;">
     <!--b-->
     <table border="0" cellpadding="0" cellspacing="0" style="180px;">
      <tr>
         <td colspan="2" align="center"><div class="thumb_pic"><img  src="../picture.php?s={$art.article_icon}&w=120&h=140" />
                      </div>
                    <div class="thumb_upload"><input id='article_icon' name="article_icon" value="{$art.article_icon}" type="text" class="w100" />&nbsp;<input type="button" class="form_submit" onclick="showDialog(document.getElementById('article_icon'),'index.php?m=file&type=default')" value="{$lang.article.select_pic}" /></div></td>
         </tr>
      <tr>
         <td>����</td>
         <td>{if !$tree_list}<font class="blue">{$lang.article.no_article_category}</font>{else}
					<select  name="category_id" style="width:100px;" class='form_option must_in'>
                    <option value="">{$lang.article.empty_select_categroy}</option>
								{foreach from = $tree_list item = list}
				        			<option value="{$list.category_id}" {if $list.category_id eq $art.category_id}selected{/if}>{$list.spacer}{$list.category_name}</option>
				        		{/foreach}
							{/if}
				 		</select> <font class="blue">*</font></td>
      </tr>
      <tr>
        <td>����</td>
        <td><input type="checkbox" value="2" {if $art.allow_comment neq '1'} checked="checked"{/if}  name="allow_comment" />
          ����/�ر�</td>
      </tr>
      <tr>
        <td>����</td>
        <td><input type="text" value="{$art.article_seq|default:0}"  name="article_seq" maxlength="10" class="w100" /></td>
      </tr>
      <tr>
        <td>���</td>
        <td><input type="text" value="{$art.article_hit|default:0}"  name="article_hit" maxlength="10" class="w100" /></td>
      </tr>
     </table>
     <!--b-->
    </td>
  </tr>
</table>
    </div><!--������ʼ-->
</div>
<!--seo��ʼ-->
<div class="table_item" id="cfg_seo">
	<h1 class="c_bar">SEO����</h1>
    <div class="c_content">
	<table class="table_common">
<tr >
	<td class="one"><!--����-->{$lang.php_title}</td>
    <td><textarea name="article_seo[seo_title]" class="seo_set">{$art.article_seo.seo_title}</textarea></td>
</tr>
<tr >
	<td class="one">meta->title</td>
    <td><textarea name="article_seo[meta_title]" class="seo_set">{$art.article_seo.meta_title}</textarea></td>
</tr>
<tr >
	<td class="one">�ؼ���</td>
    <td><textarea name="article_seo[keywords]" class="seo_set">{$art.article_seo.keywords}</textarea></td>
</tr>
<tr >
	<td class="one">ҳ������</td>
    <td><textarea name="article_seo[description]" class="seo_set">{$art.article_seo.description}</textarea></td>
</tr>
    </table>
    </div>
</div>
<div class="table_item" id="cfg_extend">
	<h1 class="c_bar">��չ����</h1>
    <div class="c_content">
<input type="hidden" value="{$art.defined_id}" name="old_extend_id" />
{if !$extend}
	<div class="notice_msg"><!--�޿�����չ��������!������!-->{$lang.article.no_extend_data}</div>
{else}
    <script type="text/javascript">
	var aid = "{$art.article_id}";
	function load_extend_info(obj){
		var val = $(obj).val();
		if(val!=0){
			var u = 'index.php?m=article&a=ajax_call_extend&eid='+val+'&aid='+aid;
			$.get(u,function(data){
				remove('ajax_call_extend_info');
				$("#ajax_call_extend_info").empty().html(data);
			});
		}
	}
</script>
   <table class="table_common">
		<tr>
       	<td class="one">ѡ�����Է���</td>
    	<td>    	<select name="defined_id" onchange="load_extend_info(this);" style="width:300px;">
        	<option value="0">{$lang.php_select}</option>
            {foreach from = $extend item="extend"}
            	<option value="{$extend.define_id}" {if $art.defined_id eq $extend.define_id} selected="selected"{/if}>{$extend.define_name}</option>
            {/foreach}
        </select></td>
        </tr>
   </table>
{/if}
    <div id="ajax_call_extend_info">
{if $type_data}
<table class="table_common" id="table_common_tag">
{foreach from=$type_data item=type}
	<tr>
    	<td class="one" width="150">{$type.attribute_name}</td>
        <td>
        	{if $type.attribute_inputtype eq '1'}
            	<input type="text" value="{$type.attribute_fix_val}" name="article_attr_extend_value[{$type.attribute_id}]" style="width:300px;" />
            {/if}
			{if $type.attribute_inputtype eq '2'}
                <select name="article_attr_extend_value[{$type.attribute_id}]" style="width:300px;">
                	<option value=""><!--��ѡ��...-->{$lang.php_select}</option>
                	{foreach from=$type.attr_extend_val item=a_v}
			<option value="{$a_v}"{if $type.attribute_fix_val eq $a_v} selected="selected"{/if}>{$a_v}</option>
                    {/foreach}
                </select>
            {/if}
        </td>
    </tr>
 {/foreach}
</table>
        {/if}
        </div>
    </div>
</div>
		<!--û��������������-end-->
		<input type="hidden" name="article_id" value="{$art.article_id}"/>
		<input type="hidden" name="old_category_id" value="{$art.category_id}"/>

</div>
</div>
	</form>
<script type="text/javascript">
		$(document).ready(function(){
			$.table_bars($("#show_menus li"));
			$("#ajax_submit_form").submit(function(){
				if(!check_form_is_empty('must_in'))return window.parent.showNotice(must_fill_input);
				var cc = KE.html('article_content_editor');
				if(empty(cc)){
					window.parent.showNotice(empty_article_content);<!--����д����-->
					return false;
				}
				ct = null;
			});
		});
		function submitGeneralForm(){return $("#ajax_submit_form").submit();}
	</script>
</div>
{include file="frame_footer.php"}
{/if}
<!--�༭���º��������½���-->
{if $action eq 'extend_type'}
{if $type_data}
<table class="table_common" id="table_common_tag">
{foreach from=$type_data item=type}
	<tr>
    	<td class="one" width="150">{$type.attribute_name}</td>
        <td>
        	{if $type.attribute_inputtype eq '1'}
            	<input type="text" value="{$type.attribute_fix_val}" name="article_attr_extend_value[{$type.attribute_id}]" style="width:300px;" />
            {/if}
			{if $type.attribute_inputtype eq '2'}
                <select name="article_attr_extend_value[{$type.attribute_id}]" style="width:300px;">
                	<option value=""><!--��ѡ��...-->{$lang.php_select}</option>
                	{foreach from=$type.attr_extend_val item=a_v}
			<option value="{$a_v}"{if $type.attribute_fix_val eq $a_v} selected="selected"{/if}>{$a_v}</option>
                    {/foreach}
                </select>
            {/if}
        </td>
    </tr>
 {/foreach}
</table>
{else}
<div class="notice_msg"><!--�뵽���Թ������ø�������Ĳ���-->�뵽���Թ������ø�������Ĳ���</div>
{/if}
{/if}