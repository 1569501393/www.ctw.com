<?php  if(!defined('PHP_TEMPLATE'))exit();?>
{if !$is_ajax_call}{include file="frame_header.php"}{/if}
<script language="JavaScript">
{foreach from=$lang.article.js_html key=key item=item}var {$key} = "{$item}";{/foreach}
var comm_url = "index.php?m=article/comment&a=oper&action={$action}";
var comm_type = "{$action}";
</script>
	<div class="clear"></div>
{if $action == 'list'}
<div id="php_right_main_content">
	{if $data.data eq null}
		<div class="notice_msg">{$lang.article.no_comment}</div>
	{else}<!--û������-->
			<table class="table_list table_list_common">
			  <tr>
				<th>{$lang.article.th_comm_article_title}</th><!-- ���±��� -->
			    <th>{$lang.article.th_comm_count}</th><!-- �������� -->
				<th>{$lang.article.th_comm_assess_number}</th><!-- ����˸��� -->
				<th>{$lang.article.th_comm_unaudited_number}</th><!-- δ��˸��� -->
				<th>{$lang.article.operation}</th><!-- ���� -->
			  </tr>
			{foreach from=$data.data item=cm key=k}
				<tr>
				    <td>{$cm.article_title}</td>
				    <td  align="center">{$cm.count}</td>
				    <td class="updatepermit_{$cm.article_id} opertion_class_{$cm.article_id} center">{$cm.permit}</td>
				    <td class="updatewait_{$cm.article_id} opertion_class_{$cm.article_id} center">{$cm.wait}</td>
				    <td style="text-align:center;">
				    	<a href="index.php?m=article/comment&a=lockcomment&curpage={$curpage}&id={$cm.article_id}">{$lang.article.td_a_comm_details}</a> 
				    	 &nbsp;
				    	<a target="_blank" href="{$cm.lockurl}">{$lang.article.td_a_com_orgcontent}</a><!-- �鿴ԭ�� -->
				    </td>
				</tr>
			{/foreach}
				{if $data.page}
					<tr>
						<td colspan="8"><div id='pagelist' style="text-algin:right;float:right;" >{$data.page}</div></td>
					</tr>
				{/if}
			</table>
		</form>
	{/if}<!--û������-->
	<div class="clear"></div>
    </div>
   {/if}
{if $action == 'comment'}
	<div id="php_top_bar">
		<li class="block_button" onclick="operComment('delete')">����ɾ��</li>
		<li class="block_button" onclick="operComment('permit')">���ͨ��</li>
		<li class="block_button" onclick="operComment('reject')">�������</li>
		<li class="block_button" onclick="operComment('wait')">����ʾ����</li>
		<li class="block_button" onclick="window.location.reload();">ˢ��</li>
    <li onclick="window.location.href='index.php?m=article/comment&a=listcomment'" class="block_button loading">����</li><!-- ���� -->
	</div>
	<div class="clear"></div>
<input type="hidden" id="php_comm_article_id" value="{$articleid}" />
<input type="hidden" id="php_comm_curpage" value="{$data.curpage}" />

	<script type="text/javascript">
		$(function(){
			checkAllFormData('checked_all','form_checked');
		});
		function show_replay_comment(obj,comm_id){
			window.parent.showWindow('�ظ�����','index.php?m=article/comment&a=backcomm&id='+comm_id,700,250);	
		}
		function operComment(type){
			var che = get_checkbox_val('form_checked');
			if(!che)return window.parent.showNotice(selectObject);
			$("#php_form_comment").attr("action", comm_url + "&type=" + type);
			$("#php_form_comment").ajaxSubmit(function(data){
				switch($.trim(data)){
					case "updatepermit":
					case "updatereject":
					case "updatewait":
						window.parent.showNotice(option_success);
						window.location.reload();
						break;
					case "deletesuccess":
						window.parent.showNotice(option_success);
						window.location.href='index.php?m=article/comment&a=listcomment';
						break;
					case "notdata":
						window.parent.showNotice(selectObject);
						break;
					default:
					alert(data);
				}
			});
			return false;
		}
	</script>
<div id="php_right_main_content">
	<form action="" method="post" id="php_form_comment">
		<table class="table_common" cellpadding="0" cellspacing="0">
			<tr>
				<td colspan="2" style="text-align:center;font-size:15px; font-weight:bold;">{$lang.article.td_a_com_article_title}{$title}</td>
			</tr>
			{foreach from=$data.data item=comm}
				<tr>
					<td class="one">
						<input type="checkbox" value="{$comm.comment_id}" name="cid[]" class="form_checked" />
						{$lang.article.td_com_user_comments}<!--�û�����-->
					</td>
					<td>
						<div style="float: left">
							<span>{$lang.article.td_com_user_name}{$comm.user_name}</span>
							<span style="padding-left:15px;">{$lang.article.td_com_post_data}{$comm.comment_post_time|date_format:"%Y-%m-%d"}</span>
						</div>
						<div style="float:right;width:100px;">
							<span class="red" onclick="show_replay_comment(this,'{$comm.comment_id}')" style="cursor:pointer;float:right;padding-right:10px;">�ظ�</span>
							<span id="updatereject_{$comm.comment_id}" class="php_comm_pub_{$comm.comment_id}" {if $comm.comment_public != '1'}style="float:left;display:none"{/if}><font class="blue">{$lang.article.td_com_unaudited}</font></span>
							<span id="updatepermit_{$comm.comment_id}" class="php_comm_pub_{$comm.comment_id}" {if $comm.comment_public != '2'}style="float:left;display:none"{/if}>{$lang.article.td_com_examine}</span>
							<span id="updatewait_{$comm.comment_id}" class="php_comm_pub_{$comm.comment_id}" {if $comm.comment_public != '3'}style="float:left;display:none"{/if}>{$lang.article.td_com_refused}</span><!-- �ܾ���ʾ -->
						</div>
					</td>
				</tr>
				<tr>
					<td class="one">{$lang.article.td_com_comm_content}</td><!-- �������� -->
					<td style="color: #666666; ">
						{$comm.comment_content|nl2br}
					</td>
				</tr>
				{if $comm.comment_admin}
					<tr>
						<td class="one">{$lang.article.td_com_administrator_reply}</td><!-- ����Ա�ظ� -->
						<td>
							<span>{$lang.article.td_com_manager_name}{$comm.comment_admin}</span><!-- ����Ա���ƣ� -->
							<span style="padding-left:15px;">{$lang.article.td_com_reply_time}{$comm.comment_admin_post_time|date_format:"%Y-%m-%d"}</span><!-- �ظ�ʱ�䣺 -->
						</td>
					</tr>
					<tr>
						<td class="one">{$lang.article.td_com_reply_content}</td><!-- �ظ����� -->
						<td class="admin_back_comment_{$comm.comment_id}" style="color:#AA0000">
							{$comm.comment_admin_content|nl2br}
						</td>
					</tr>
				{/if}
			{/foreach}
		</table>
<div class="clear"></div>
        <div>
    <span style="float:left; background:none; color:#000;" class="block_button"><label><input id="checked_all" type='checkbox' >ȫѡ</label></span>
    <span style="float:right;">{$data.page}</span>
    </div>
	</form>
</div>
{/if}
{if $action eq 'replay_comment'}
<div class="admin_artice_comment">
    <form id="form_back_comment_dom" action='index.php?m=article/comment&a=backcomm' method='post'>
    <input type='hidden' value="{$comm_id}" name='cid' />
    <table class='table_common'>
        <tr>
            <td class='one'>{$lang.article.td_com_pleas_enter_reply_contents}</td><!-- ������ظ������� -->
            <td>
<textarea name='adminbacktext' id="php_adminbacktext" class="form_textarea seo_set must_fill_data">{$data.comment_admin_content}</textarea>
            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type='button' class="form_submit" value="{$lang.article.td_btn_back}" onclick="submit_form('form_back_comment_dom')">
            </td>
        </tr>
    </table>
</form>
</div>
<script type="text/javascript">
	{foreach from=$lang.article.js_tan key=key item=item} var {$key} = "{$item}"; {/foreach}
$(function(){
	$("#form_back_comment_dom").submit(function(){
		if(!check_form_is_empty('must_fill_data')){
			window.parent.showNotice(com_please_fill_reply_content); 
			return false;
		}
		$(this).ajaxSubmit(function(data){
			switch(data){
				case "notid":
					window.parent.showNotice(com_missing_data);
					break;
				case "notdata":
					window.parent.showNotice(com_please_fill_reply_content);
					break;
				case "updatesuccess":
					window.parent.showNotice(com_reply_successfully);
					break;
				default:alert(data);
			}
			_reload_frame();
			_close_window_one();
		});
		return false;
	});
});
</script>
{/if}

{if !$is_ajax_call}
	{include file="frame_footer.php"}
{/if}