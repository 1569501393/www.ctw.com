<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{include file="frame_header.php"}
<script language="JavaScript">
	{foreach from=$lang.article.js_html key=key item=item}
		var {$key} = "{$item}";
	{/foreach}
</script>
{if $action eq "showall"}
{$window_script}
<script type="text/javascript">
var delete_ok = "{$lang.article.error_delSuccess}";
var delete_error = "{$lang.article.error_articleRelationCategory}";
var sys_default= "{$lang.article.system_defined_cat}";
var has_son = "{$lang.article.error_haveSonCategory}";
$(document).ready(function(){
	$(".delete_articles").click(function(){
		if(confirm(okDeleteArticleCategory)){
			var id = $(this).attr('name');
			$.get('index.php?m=article&a=delarticlecategory&category_id='+id,function(data){
				switch(data){
					case 'OK':window.parent.showNotice(delete_ok);window.location.reload();break;
					case 'ERROR':window.parent.showNotice(delete_error);break;
					case 'SYS_DEFAULT':window.parent.showNotice(sys_default);break;
					case 'HAS_SON':window.parent.showNotice(has_son);break;
					default:alert(data);
				}
			});	
		}
	});
	$(".open_close").toggle(function(){
			 var tree_id = $(this).attr('id');
			 var tree_name = $(this).attr('name');
			 if(!empty(tree_name)){
				 class_tree = tree_name.split(',');
				 class_id = class_tree;
				 $(class_tree).each(function(i){
						$('.'+class_tree[i]).hide();
					});
			$("#"+tree_id).attr({'src':'images/sitemapclosed.gif'});
		 }
	},function(){
		if(class_id!=null){
			var tree_name = $(this).attr('name');
			var tree_id = $(this).attr('id');
			var class_tree = tree_name.split(',');
			$(class_tree).each(function(i){
				$('.'+class_tree[i]).show();
			})
			$("#"+tree_id).attr({'src':'images/sitemapopened.gif'});
		}
	});
});
</script>
<div id="php_top_bar">
{if $can_add}
<a class="block_button form_btn"  href="javascript:;" onclick="window.parent.showWindow('{$lang.article.addroot}','index.php?m=article&a=addarticlecategory',970,450);">{$lang.article.addroot}</a>
{/if}
</div>
<div id="php_right_main_content">
{if $tree_list}
<table class="table_list table_list_common" id="cate_edit_table" cellpadding="0" cellspacing="0">
<tr>
    <th>���</th>
	<th>����</th>
    <th>ID</th>
	<th>ʱ��</th>
	<th>��־</th>
	<th>����</th>

    <th>����ģ��</th>
	<th style="width:100px;">����</th>
</tr>
	<tbody id="tbody">
		{foreach from =$tree_list item=tree}
			<tr class="{$tree.category_id}" id="cates">
                <td align='center'>{if $tree.level+1 eq 1}1{/if}</td>
				<td style="padding-left:10px;" class="tr">
					<span style="padding-left:{$tree.level*25}px;" class='menuspan' id='{$tree.category_id}'>
						({$tree.level+1})<img {if $tree.children}style="cursor:pointer;" class="open_close"{/if} src="images/sitemapopened.gif" name="{$tree.children}" id="img{$tree.category_id}"/>&nbsp;<a href="index.php?m=article&a=listarticle&category_id={$tree.category_id}">{$tree.category_name}</a>
					</span>
                    <span class="blue">({$tree.category_have})</span>
				</td>
                <td align='center'>{$tree.category_id}</td>
				<td align='center'>{$tree.category_date|date_format:"%Y-%m-%d %H:%M:%S"}</td>
				<td align="center">{$tree.category_sign|default:'-'}</td>
                <td align="center">{$tree.category_sort|default:0}</td>
                <td align="center">{if $tree.son_cate_tpl}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
				<td align="center" valign="bottom" class="noborder" >
{if $can_edit}<a href='javascript:;'  onclick="return window.parent.showWindow('{$lang.article.edit}','index.php?m=article&a=editarticlecategory&category_id={$tree.category_id}',850,400)">��</a>
 {/if} {if $can_delete}{if $tree.category_type != 1}<a href='javascript:;' name="{$tree.category_id}" class="delete_articles">ɾ</a> {/if} {/if}
				</td>
			</tr>
		{/foreach}
</tbody>
</table>
{else}
<div class="notice_msg">{$lang.article.no_article_category}</div>
{/if}
</div>
{/if}
{include file="frame_footer.php"}