<?php if(!defined('PHP_TEMPLATE'))exit();?>
{include file="frame_header.php"}
<script language="JavaScript">
	{foreach from=$lang.article.js_html key=key item=item} var {$key} = "{$item}"; {/foreach}
</script>
<div id="php_top_bar" class="php_bot_bar">
<div class="top_bar_pannel"><a href="javascript:;" class="block_button form_btn" onclick="saveForm1(this);">{$lang.article.save}</a></div>
</div>
<div class="clear"></div>
<div id="php_right_main_content">
<script type="text/javascript">
function saveForm1(){
	$('#artConfigForm').ajaxSubmit({type:'POST',url:'index.php?m=article/artconfig&a=listartconfig',dataType:'json',success:function(data){
		switch(data.error.toString()){
			case '1':window.parent.showNotice(data.msg);break;
			case '2':window.parent.showNotice(data.msg);break;
		}
	}});
}
$(function(){
	$.table_bars($("#article_base_config .menu li"));
});
</script>
<div id="article_base_config" class="table_scroll">
    <div class="menu" style="padding-left:20px;">
        <ul>
        	<li name="cfg_all">ȫ��</li>
            <li name="cfg_base" id="g_base_item" class="wintable_curent">��������</li>
	        <li name="cfg_comment">��������</li>
        </ul>
    </div>
</div>
<div class="table_item_base">
<form id='artConfigForm' method='post'>
    <div class="table_item" id="cfg_base">
        <h1 class="c_bar">��������</h1>
            <div class="c_content">
        <table  class="table_common">
        <tr>
            <td class="one">�����б�ҳ��������</td>
            <td>
            <input type='radio' name='articlesort' value=1 {if $data.articlesort eq 1}checked{/if} />{$lang.article.articleConfig_public}<!--����ʱ��-->
            &nbsp;
            <input type='radio' name='articlesort' value=2 {if $data.articlesort eq 2}checked{/if} />{$lang.article.articleConfig_hit}<!--�������-->
            &nbsp;
            <input type='radio' name='articlesort' value=5 {if $data.articlesort eq 5}checked{/if} />{$lang.article.articleConfig_sortbyhand}<!--�ֶ�����-->
            </td>
            </tr>
            <tr>
            	<td class="one">����������ҳ����</td>
                <td>
                	<input  type="checkbox" value="1" {if $data.article_nav_hide_index} checked="checked" {/if} name="article_nav_hide_index" />
                    <samp class="blue">Ĭ�ϲ�����</samp>
                </td>
            </tr>
        <tr>
            <td class="one" nowrap="nowrap">{$lang.article.articleConfig_maxpage}<!--�����б�ҳÿҳ������--></td>
            <td><input type='text' name='maxpage' style='width:150px;' value='{$data.maxpage}'/></td>
        </tr>
        </table>
        </div>
    </div>

    <div class="table_item" id="cfg_comment">
        <h1 class="c_bar">��������</h1>
           <div class="c_content">
            <table  class="table_common">
            <tr>
            <td  class="one">�����οͷ�������</td>
            <td>
            <input type='radio' name='comment' value=1 {if $data.comment eq 1}checked{/if}>{$lang.article.articleConfig_yes}<!--��--></input>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type='radio' name='comment' value=2 {if $data.comment eq 2}checked{/if}>{$lang.article.articleConfig_no}<!--��--></input>
            </td>
            </tr>
            
            <tr>
            <td class="one" >{$lang.article.articleConfig_comcheck}<!--�����Ƿ���Ҫ���--></td>
            <td>
            <input type='radio' name='checkcomment' value=1 {if $data.checkcomment eq 1}checked{/if}>{$lang.article.articleConfig_yes}<!--��--></input>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type='radio' name='checkcomment' value=2 {if $data.checkcomment eq 2}checked{/if}>{$lang.article.articleConfig_no}<!--��--></input>
            </td>
            </tr>
            
            <tr>
            <td class="one" >�ύ���ۿ�����֤��<!--�ύ�����Ƿ�����֤��--></td>
            <td>
            <input type='radio' name='validate' value=1 {if $data.validate eq 1}checked{/if}>{$lang.article.articleConfig_yes}<!--��--></input>&nbsp;&nbsp;&nbsp;&nbsp;
            <input type='radio' name='validate' value=2 {if $data.validate eq 2}checked{/if}>{$lang.article.articleConfig_no}<!--��--></input>
            </td>
            </tr>
            
                <tr>
                <td class="one" >{$lang.article.articleConfig_commaxpage}<!--ÿҳ���������--></td>
                <td><input type='text' name='maxcomment' style='width:150px;' value='{$data.maxcomment}'/></td>
                </tr>
            </table>
            </div>
    </div>
</form>
</div>

{include file="frame_footer.php"}