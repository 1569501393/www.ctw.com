<?php //exit('die'); ?>
{if $action eq 'edit_art_attr' || $action eq 'add_art_attr'}
<script type="text/javascript">
$(function(){
	$("#submit_article_attr").submit(function(){
		if(!check_form_is_empty('define_name_item'))return false;
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'EMPTY':
					alert("����д��������!");
				break;
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					_reload_frame();
					_close_window_one();
				break;
				case 'HAS_EXIST':
				   $(".define_name_item").val('');
					window.parent.showNotice("������ͬ������������!");
				break;
				default:alert(data);
			}
		});return false;
	});
});
</script>
<form method="post" action="index.php?m=article&a=articleAttr" id="submit_article_attr">
<input type="hidden" value="{$data.define_id}"  name="id"/>
<table class="table_common">
	<tr>
    	<td class="one">����</td>
        <td><input  type="text" value="{$data.define_name}" name="attr_name" class="w300 define_name_item"/></td>
    </tr>
    <tr>
    	<td class="one"></td>
        <td>
		<input type="submit" value="" style="display:none;" />
        <a href="javascript:;" onclick="submit_form('submit_article_attr');" class="block_button form_btn">����</a></td>
    </tr>
</table>
</form>
{/if}
{if $action eq "list_article_attr"}
{include file="frame_header.php"}
<script type="text/javascript">
$(function(){
	close_open_helper('article_helper','article_info_msg');
});
function delDefine(id){
	if(!confirm("ȷ��ɾ����?�˲�����ɾ�����µ���������ֵ!"))return false;
	$.get('index.php?m=article&a=articleAttr&action=delete&id='+id,function(data){
		 switch(data){
		 	case 'OK':
				$("#row_"+id).remove();
				//window.parent.showNotice(php_do_ok);
				if($(".e__tags").size()<=0)window.location.reload();
			break;
			default:alert(data);
		 }
	});
}
</script>
<div id="php_top_bar">
 <a href="javascript:;" class="block_button form_btn" onclick="window.parent.showWindow($(this).html(),'index.php?m=article&a=articleAttr&action=add',600,200);">����������</a> 
{if $data}
<a href="javascript:;" class="block_button form_btn" onclick="window.parent.showWindow($(this).html(),'index.php?m=article&a=manageAttribute&action=addAttribute',600,300);">��������</a>
{/if} 
</div>
<div id="php_right_main_content">
{if $data}
  <table class="table_list">
    <tr>
      <th>����</th>
      <th>����</th>
      <th>����</th>
    </tr>
    {foreach from=$data item=de key=k}
    <tr align="center" id="row_{$de.define_id}" class="e__tags">
      <td>{$de.define_name}</td>
      <td>{$de.attribute_count|default:'0'}</td>
      <td>
<a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=article&a=articleAttr&action=edit&id={$de.define_id}',600,200);"> �༭</a>
&nbsp;
<a href="javascript:;" onclick="delDefine({$de.define_id});">ɾ��</a>
&nbsp;<a href="index.php?m=article&a=articleattribute&define_id={$de.define_id}">����ֵ</a>
</td>
    </tr>
    {/foreach}
  </table>
  {else}
  	<div class="notice_msg">�޿�������!</div>
  {/if}
</div>
{include file="frame_footer.php"}
{/if}


<!--�������б�--end----if-->
{if $action eq "viewdefineattribute"}
<!--�����б�--start--if-->
{include file="frame_header.php"}
<script type="text/javascript">
$(function(){
	close_open_helper('article_helper','article_info_msg');
});
function delAttribute(attr_id,define_id){
	if(!confirm("��ȷ��Ҫɾ����?��ɾ��,�������󶨵��������ݽ�ͬʱ��ɾ��!"))return  false;
	var ename = $.trim($("#ename_"+attr_id).html());
	$.get('index.php?m=article&a=manageAttribute&action=delAttribute',{attribute_id:attr_id,define_id:define_id,name:ename},function(data){
		switch(data){
			case 'OK':
				$("#row_"+attr_id).remove();
				window.parent.showNotice(php_do_ok);
				if($(".etag_attr_id").length<=0)window.location.reload();
			break;
		}
	});
}
function show_list(obj){
	var v = $(obj).val();
	if(v!=''){
		var href='index.php?m=article&a=articleattribute&define_id='+v;
		window.location.href=href;	
	}
}
</script>
<div id="php_top_bar">
    <div class="tb">������</div>
    <div class="tb">
    <select onchange="show_list(this);">
    	<option value=""> ��ѡ��</option>
    {foreach from=$cat item='c'}
    	 <option value="{$c.define_id}" {if $c.define_id eq $define_id} selected="selected"{/if}>{$c.define_name}</option>
    {/foreach}
    </select>
    </div>
    <div class="tb"><a href="javascript:;" class="block_button form_btn" onclick="window.parent.showWindow($(this).html(),'index.php?m=article&a=manageAttribute&action=addAttribute',600,300);">��������</a></div>
</div>
<div id="php_right_main_content">
  {if $attribute}
  <table class="table_list">
    <tr>
      <th>{$lang.article.attribute_name}</th>
      <th>����</th>
      <th>{$lang.article.entryway}</th>
      <th>{$lang.article.entryvalue}</th>
      <th>{$lang.article.operation}</th>
    </tr>
    {foreach from=$attribute item=att key=k}
    <tr align="center" id="row_{$att.attribute_id}" class="etag_attr_id">
      <td class="ename_{$att.attribute_id}">{$att.attribute_name}</td>
      <td><a href="index.php?m=article&a=articleattribute&define_id={$att.define_id}">{$att.define_name}</a></td>
      <td>{if $att.attribute_inputtype==1}{$lang.article.manualentry}{/if}{if $att.attribute_inputtype==2}{$lang.article.selectentry}{/if}</td>
      <td>{$att.attribute_value}</td>
      <td><a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=article&a=manageAttribute&action=editAttribute&attribute_id={$att.attribute_id}',600,300);">{$lang.article.edit}</a>&nbsp; <a href="javascript:;" onclick="delAttribute({$att.attribute_id},{$define_id})">{$lang.article.delete}</a></td>
    </tr>
    {/foreach}
  </table>
  {else}
  <div class="notice_msg">�޿�������!</div>
  {/if}
 </div>
{include file="frame_footer.php"}
{/if}
<!--�����б�--end--if-->
{if $action eq "editAttribute" ||  $action eq 'addAttribute'}
<script type="text/javascript">
$(function(){
	$("#sub_com").submit(function(){
		if(!check_form_is_empty('must_fill_in'))return false;
		var e = get_checkbox_val('eee_box');
		$(this).ajaxSubmit(function(data){
			var id = $("#user_defined_id").val();
			if(empty(id)){ alert('crack die');return false;}
			var url = "index.php?m=article&a=articleattribute&define_id="+id;
			switch(data){
				case 'EMPTY':
					window.parent.showNotice("�����ϱ�����!");
				break;
				case 'ADD_OK':
					window.parent.showNotice("���ӳɹ�,�������Լ�������!");
					$("#right_frame").attr({"src":url});
					$(".must_fill_in").val('');
					break;
				case 'EDIT_OK':
					window.parent.showNotice(php_do_ok);
					$("#right_frame").attr({"src":url});
					close_window();
				break;
				case 'HAS_EXIST':
					window.parent.showNotice("������ͬ����������!");$("#attribute_name").val('');
				break;
				default:alert(data);
			}
		});
		return false;
	});
});
</script>
<div class="main_content" style="padding:0px;">
  <form  method="post" action="index.php?m=article&a=manageAttribute" id="sub_com" autocomplete="off">
    <input type="hidden" value="{$action}"  name="action" />
    <table class="table_common">
      <tr>
        <td class='one'>{$lang.article.attributeName}</td>
        <td><input type="text" name="attribute_name" id="attribute_name"  class="must_fill_in bg_input" value="{$att.attribute_name}" style="width:150px" /></td>
      </tr>
      <tr>
        <td  class='one'>{$lang.article.defineName}</td>
        <td><select name="define_id" id="user_defined_id" style="width:150px">
            
    {foreach from=$cat item=c}
            <option value='{$c.define_id}' {if $c.define_id eq $att.define_id}selected{/if}>{$c.define_name}</option>
            {/foreach}
    
          </select></td>
      </tr>
      <tr>
        <td   class='one'>{$lang.article.attributeInputtype1}
          <p>{$lang.article.attributeInputtype2}</td>
        <td nowrap><input type="radio" value="1" onclick="$('#attr_vals').removeClass('must_fill_in');" class="eee_box" {if $att.attribute_inputtype neq '2'}  checked="checked" {/if} name="attribute_inputtype" />
          {$lang.article.attributeHand}
          <input type="radio" value="2"  onclick="$('#attr_vals').addClass('must_fill_in');" class="eee_box" {if $att.attribute_inputtype eq '2'}  checked="checked" {/if} name="attribute_inputtype" />
          {$lang.article.attributeSelect} </td>
      </tr>
      <tr>
        <td class='one'>{$lang.article.attributeValue}
          <p>{$lang.article.attributeList}</td>
        <td><textarea id="attr_vals" name="attribute_value" {if $att.attribute_inputtype eq '2'} class="must_fill_in"{/if} style="width:250px;height:80px;">{$att.attribute_value}</textarea></td>
      </tr>
      <tr>
        <td class="one no_border">&nbsp;</td>
        <td class="no_border">&nbsp;
          <input type="submit" value="{$lang.article.save}" class="form_submit form_btn"/></td>
      </tr>
      {if $cat eq null}
      <tr>
        <th>{$lang.article.noAttributePleaseAdd}</th>
      </tr>
      {/if}
    </table>
  </form>
</div>
{/if}