<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{include file="header_common.php"}
<body style="overflow-x:hidden;" scroll="off">
<div id="all_page_content">
<div id="php_content">
