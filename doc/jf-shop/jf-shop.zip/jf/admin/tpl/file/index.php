<?php  exit('die');?>
{if $action eq 'default'}
{if $html}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�ļ�������</title>
</head>
<link href="style/layout.css" rel="stylesheet" type="text/css"/>
{include file='skin.php'}
{insert_scripts files='js/jquery-1.4.min.js,js/global.js,js/swfupload.js,js/jscal2.js'}
{/if}
{include file='frame_js.php'}
<script type="text/javascript">var syscfg = new Array({$jsb});var sysy_config = '{$jsa}';</script>
<style type="text/css">
h2{font-size:13px;}
.spacer{ display:block; clear:both;}
.hidden{display:none;}
.clear{ display:block; clear:both; line-height:0px; height:0px;}
#file_main_content{ margin:0px auto; height:100%;}
#file_main_content p{ padding:4px; line-height:20px;}
.file_pic_list{height:150px; margin:5px 9px; overflow:hidden; float:left;}
.file_pic_list p{ text-align:center;}
.file_pic_list a.img{display:block;width:130px; height:120px; overflow: hidden;}
.red{ color:#C00;}
.hoho{width:130px; height:120px; cursor:pointer; overflow:hidden;}
#upload_ok{ display: none; border:1px solid  #D2F0FF; margin:10px;padding:3px; line-height:180%; text-align: left; background-color:#F7FCFF;}
input[type=button]{ height:25px; line-height:25px;}
.all_fix_input{ height:16px; width:40px;}
#top_set_menus{ margin:5px; padding:4px;}
#file_search_pannels{ float:right; margin-right:10px; margin-top:-3px;}
.table_common_list{ width:auto;}
.table_common_list td{ padding:4px; text-align:left;}
.upload_pannel_dom{ border-bottom:1px solid #D7D7D7;}
</style>
<script type="text/javascript">
/*�رյ������ڵ����ز�*/
function hidens(){
	try{
		var a = $('.window').attr('id');
		unset(a);
		$('.window-shadow').remove();
		$('.window-mask').remove();
		var obj = getIFrameDoc('right_frame');
		$(obj).find('embed, object, select').css({ 'visibility' : 'visible' });
		close_date();/*ǿ�йر�ûѡ��� ����*/
	}catch(e){}
}
<!--׷�����ݵ��༭����ȥ-->
function addData(obj){	
	if($.browser.msie || $.browser.mozilla || $.browser.safari){		
		/*window.returnValue=$(obj).attr('name');*/
		opener.call_back_window(obj.name);
		window.parent.top.close();return false;
	}else{
		$(file_children_obj).val(obj.name);
		hidens();
		//hidenLayer();
		$(file_children_obj).focus();
		return false;	
	}
}
<!--ɾ���ļ�-->
function deleteFile(obj){
	if(!confirm("ȷ��ɾ��?"))return false;
	var id = $(obj).attr('name');
	var type = $(obj).attr('type');
	$.get('index.php?m=file&a=delete&fid='+id+'&rand='+Math.random(),function(data){
		$("#remove_doms_"+id).remove();if(!$(".remove_doms_"+type).length){$(".wintable_curent").click();	
			}
		});
	}
var curent_type = 'default';
function _get_type(){
	$("#ajax_call_pic_pannel_bar li").each(function(e){
		if($(this).hasClass('wintable_curent')){
			curent_type =  $(this).attr('id');
			curent_type = curent_type.replace(/gf_/g,'')
		}
	})
	return curent_type;
}
$(function(){
	var swf_upload = $("#file_upload_plugin").upload({
		filetype       : sysy_config,
		file_size_limit:1024*20,/*20M*/
		filename:'upload_files_self',
		post_params:{'sid':session_id},
		url:'index.php?m=file&a=ajaxUpload&call_type='+_get_type(),
		loading_dom:$('#upload_ok_doms'),
		sucess:function(file,response){
				try{
					$("#file_loading").empty().html('');var ee = response.split('|');var e = ee[0];var m = ee[1];
					switch(e){
						case '1':
							return false;
						break;
						case '2':
							var end = m.split('+');var file = end[0];var size = end[1];var file_type = $.trim(end[2]);
							//$("#upload_ok").show().html(file_upload_ok+'<br />'+file+'<br />'+file_size+size);
							uri = "index.php?m=file&a=ajaxPic&type="+file_type;
							$.get(uri,function(data){
								$("#file_main_content").empty().html(data);
								$(".wintable_curent").removeClass('wintable_curent');
								$("#gf_"+file_type).addClass('wintable_curent');
							});	
							return true;
						break;
						default:alert(response);return false;
				   }
			}catch(e){alert(e);}
		}
	});
	$(".click_fix_box").click(function(){
		swf_upload.setPostParams({
			'sid':session_id,
			'create_watermark':$("#create_watermark_id").attr("checked")?'true':'',
			'create_thumb':$("#create_thumb_id").attr("checked")?'true':'',
			'c_h':$("#c_h").val(),
			'c_w':$("#c_w").val()
		});
	});
	$(".click_fix_box_blur").blur(function(){
		swf_upload.setPostParams({
			'sid':session_id,
			'create_watermark':$("#create_watermark_id").attr("checked")?'true':'',
			'create_thumb':$("#create_thumb_id").attr("checked")?'true':'',
			'c_h':$("#c_h").val(),
			'c_w':$("#c_w").val()
		});
	});
	close_open_helper('upload_file_plugin','show_helpers');
});

</script>
<div id="file_contents">
{if $can_upload}
<div class="upload_pannel_dom">
<table class="table_common_list">
	<tr>
    	<td>����ͼ    	  <input type="checkbox" class="all_fix check_box_info click_fix_box"  value="true" id="create_thumb_id" name="create_thumb" /></td>
    	<td>��ˮӡ    	  <input class="all_fix click_fix_box" type="checkbox" value="true"   name="create_watermark"  id="create_watermark_id"/></td>
        <td>�߶�          <input class="all_fix_input click_fix_box_blur" type="text" name="c_h" value="0" id="c_h" /></td>
        <td>����          <input class="all_fix_input click_fix_box_blur" type="text" value="0" name="c_w" id="c_w" /></td>
        <td><span id="file_upload_plugin"></span></td>
    </tr>
</table>
<div id="upload_ok"> </div>
<div id="upload_ok_doms"></div>
</div>
{/if}
<!--�����ϴ����-->
<div class="spacer"></div>
{if $can_view}
<script type="text/javascript">
	$(function(){
		$("#ajax_call_pic li").click(function(){
			var rel = $(this).attr('rel');
			$(".wintable_curent").removeClass('wintable_curent');
			$(this).addClass('wintable_curent');
			$.get(rel,function(data){
				$("#file_main_content").empty().html(data);
			});
		});
		page_function('file_page','file_main_content');
		$("#ajax_search_files").submit(function(){
			var a = $("#all_select_item");
			if(empty($(a).val())){
				$(a).addClass('empty_select_val');return false;
			}else{
				$(a).removeClass('empty_select_val');	
			}
			if(!check_form_is_empty('must_file_in'))return false;
			var type  = $(a).val();
			$.get(_s(this),function(data){
				switch(data){
					case 'TYPE_ERROR':
					case 'DATE_ERROR':
					alert(data);return false;
					break;
					default:
						$(".wintable_curent").removeClass('wintable_curent');
						$("#gf_"+type).addClass('wintable_curent');
						$("#file_main_content").empty().html(data);
				}
			});
			a=null;
			return false;
		});
	});
</script>
<div class="table_scroll">
	<ul class="menu" id="ajax_call_pic">
    <div style="float:left;" id="ajax_call_pic_pannel_bar">
    	<li {if $type eq 'default'}class="wintable_curent"{/if} rel="index.php?m=file&a=ajaxPic&type=default" id="gf_default">ͼƬԭ�ļ�</li>
        <li {if $type eq 'thumb'}class="wintable_curent"{/if} rel="index.php?m=file&a=ajaxPic&type=thumb" id="gf_thumb">����ͼ</li>
        <li  {if $type eq 'water'}class="wintable_curent"{/if} rel="index.php?m=file&a=ajaxPic&type=water" id="gf_water">ˮӡͼ</li>
		<li  {if $type eq 'tuan'}class="wintable_curent"{/if} rel="index.php?m=file&a=ajaxPic&type=tuan" id="gf_tuan">�Ź�ͼ</li>
        <li  {if $type eq 'flash'}class="wintable_curent"{/if} rel="index.php?m=file&a=ajaxPic&type=flash" id="gf_flash">Flash</li>
		 <li {if $type eq 'flv'}class="wintable_curent"{/if}  rel="index.php?m=file&a=ajaxPic&type=flv" id="gf_flv">Flv��Ƶ</li>
		 <li  {if $type eq 'other'}class="wintable_curent"{/if} rel="index.php?m=file&a=ajaxPic&type=other" id="gf_other">�����ļ�</li>
         </div>
 <div id="file_search_pannels">
    <form method="get" action="index.php?m=file&a=search" id="ajax_search_files" autocomplete='off'>
    <select name="type" id="all_select_item">
    <option value="">��ѡ��...</option>
    <option value="default">ͼƬԭ�ļ�</option>
    <option value="tuan">�Ź�</option>
    <option value="thumb">����ͼ</option>
    <option value="water">ˮӡͼ</option>
    <option value="flash">Flash</option>
    <option value="flv">FLV��Ƶ</option>
    <option value="other">�����ļ�</option>
    </select>
    <input type="text" value="" size="14" name="time_start" class="must_file_in date date_input"  onfocus="show_date(this);" />
    ��  <input type="text" value="" size="14" name="time_end" class="must_file_in date date_input"  onfocus="show_date(this);" />
        <input  type="submit" class="form_submit" value="{$lang.php_search}" />
    </form>
</div>
    </ul>

        <div class="clear"></div>

<div id="file_main_content">
<!--Ĭ�����-->
{if $data.total>0}
	{foreach from=$data.data item=file}
<div class="file_pic_list remove_doms_{$data.type}" id="remove_doms_{$file.fid}">
<a href="{$file.part}"  class="img" title="{$lang.file.file_name}:{$file.file_name} SIZE:{$file.file_size}">
<img src="../picture.php?s={$file.part}&w=130&h=120" class="hoho file_img" onclick="addData(this);return false;" name="{$file.part}"/>
</a>
<p align="center">
{if $file.system neq 'yes'}
{if $can_delete}<a href="javascript:;" name="{$file.fid}" type="{$data.type}"  onclick="deleteFile(this);">ɾ��</a> {/if} {/if} <a target="_blank" href="{$file.part}">Ԥ��</a></p>
        </div>
    {/foreach}
    <div class="clear"></div>
    <div id="file_page">{$data.page}</div>
	{else}
    <div class="notice_msg">�޿�������!</div>
{/if}
</div><!--#enbd file_main_content-->
<div class="clear"></div>
    {else}
    <div class="notice_msg">{$msg}</div>
    {/if}<!--�����鿴Ȩ��-->
</div>
{/if}<!--����DEFAULT action-->
<!--action -->
{if $action eq 'ajaxPic'}
<!--����ͼƬ-->
{if $type eq 'default' || $type eq 'water' || $type eq 'thumb' || $type eq 'tuan'}
	{if $data.total>0}
	{foreach from=$data.data item=file}
    	<div class="file_pic_list remove_doms_{$data.type}" id="remove_doms_{$file.fid}">
<a href="{$file.part}" class="img"  title="����:{$file.file_name}��С:{$file.file_size}">
<img src="../picture.php?s={$file.part}&w=130&h=120" class="hoho file_img" onclick="addData(this);return false;" name="{$file.part}"/>
</a>
<p align="center">
{if $file.system neq 'yes'}
{if $can_delete}<a href="javascript:;" name="{$file.fid}" type="{$data.type}"  onclick="deleteFile(this);return false;">ɾ��</a> {/if}
{/if}<a target="_blank" href="{$file.part}">Ԥ��</a></p>
        </div>
    {/foreach}
<div class="clear"></div>
    <div id="file_page">{$data.page}</div>
	{else}
    <div class="notice_msg">{$lang.php_nodata}</div>
{/if}
{/if}<!--type == default water thumb end -->

{if $type eq 'flash'}
{if $data.total>0}
{foreach from=$data.data item=file}
<div  class="file_pic_list remove_doms_{$data.type}" id="remove_doms_{$file.fid}">
<embed src="{$file.part}" title="����:{$file.file_name}��С:{$file.file_size}" width="150" height="130" type="application/x-shockwave-flash"></embed>
<p align="center">
{if $can_delete}
<a href="javascript:;" name="{$file.fid}" type="{$data.type}" onclick="deleteFile(this);return false;">ɾ��</a>{/if}<a href="javascript:;" name="{$file.part}"   onclick="addData(this);return false;">����</a></p>
        </div>
    {/foreach}
<div class="clear"></div>
    <div id="file_page">{$data.page}</div>
    {else}
    <div class="notice_msg">�޿�������!</div>
{/if}
{/if}<!--#end fla-->

{if $type  eq 'flv'}
{if $data.total>0}
{foreach from=$data.data item=file}
<p style="text-align:left;"  class="remove_doms_{$data.type}" id="remove_doms_{$file.fid}"><b class="blue">����:</b>{$file.file_name} <b class="blue">��С:</b>{$file.file_size} 
{if $can_delete}&nbsp;&nbsp;
<a href="javascript:;" name="{$file.fid}" type="{$data.type}" onclick="deleteFile(this);return false;">ɾ��</a> {/if}<a href="javascript:;" name="{$file.part}" onclick="addData(this);return false;">����</a>&nbsp;<a class="flv_review" title="{$file.file_name}" target="_blank"  href="index.php?m=file&a=view&file={$file.part_base}">Ԥ��</a></p>
{/foreach}
<div class="clear"></div>
    <div id="file_page">{$data.page}</div>
    {else}
    <div class="notice_msg">�޿�������!</div>
{/if}
{/if}<!--end flv-->
 
{if $type eq 'other'}
{if $data.total>0}
{foreach from=$data.data item=file}
<p style="text-align:left;" class="remove_doms_{$data.type}" id="remove_doms_{$file.fid}"><b class="blue">����</b>{$file.file_name} <b class="blue">��С:</b>{$file.file_size}  
{if $can_delete}
&nbsp;&nbsp;<a href="javascript:;" name="{$file.fid}" type="{$data.type}" onclick="deleteFile(this);return false;">ɾ��</a>{/if} <a href="javascript:;" name="{$file.part}" onclick="addData(this);return false;">����</a></p>
{/foreach}
<div class="clear"></div>
    <div id="file_page">{$data.page}</div>
    {else}
    <div class="notice_msg">�޿�������!</div>
{/if}
{/if}
 <script type="text/javascript">$(function(){page_function('file_page','file_main_content');});</script>
{/if}
