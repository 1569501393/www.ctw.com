<?php if(!defined('PHP_TEMPLATE'))exit('php'); ?>
{if $action eq 'default_data'}
{if !$is_ajax}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>File Manager</title>
</head>
<link href="style/layout.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="js/jquery-1.4.min.js"></script>
{include file='skin.php'}
<script type="text/javascript" src="js/global.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
{include file="frame_js.php"}
<body>
{/if}
<div class="notice_msg"><!--ע��:ͼƬ��Ҫ����̫��,���򽫻�Ƚ���,���鲻Ҫ����1000��.ʹ�õ���ֱ�Ӷ�ȡ��վĿ¼�µ�ͼƬ�б�����.-->{$lang.u.file_notice_help}</div>
{literal}
<style type="text/css">
	#upload_extend_file{ padding:5px;}
	#dir_pic_list{ padding:5px 8px; color:#666;}
	.pic_list{ float:left; padding:3px; text-align:center; margin:5px; width:70px;}
	.pic_list img{margin:5px; width:48px; height:48px; border:1px solid #C60;}
	.pic_list a.pic_link{ display:block; text-align: center; padding:5px; border:1px solid #CDCDCD;}
	.pic_list .title{ margin:0px; padding:0px; text-align:center;}
</style>
<script type="text/javascript">
	var empty_up_file = '{$lang.u.empty_delete_file}';
	var upload_ok = '{$lang.u.upload_ok}';
	var empty_delete_file = '{$lang.u.empty_delete_file}';
	var delete_file_ok = '{$lang.u.delete_file_ok}';
	$(document).ready(function(){
		function _empty_val(){
			var d = $("#upload_val_i");
			d.empty().val('');
			d.value='';
		}
		page_function('ajax_call_page','dir_pic_list');
		$("#ajax_upload_pic").submit(function(){
			var v = $('#upload_val_i').val();
			if(empty(v)){
				_empty_val();
				alert("<% _e('��ѡ��Ҫ�ϴ����ļ�!');%>");return false;
			}
			var ext = v.split('.').pop();
			ext  = $.trim(ext);
			var jj = $.inArray(ext, new Array('jpg','gif','png'));
			if(jj=='-1'){
				_empty_val();
				alert("<% _e('ϵͳֻ����jpg,gif,png�ļ���ʽ!');%>");
				return false;	
			}
			$(this).ajaxSubmit(function(response){
				var ems = response.split('|');
				var m = ems[1];
				switch(ems[0]){
					case '1'://error
						window.showNotice(m);
						return false;
					break;
					case '2'://ok
						window.parent.showNotice(upload_ok);
						_empty_val();
						loadDefault();
					break;
					default:alert(response);return false;
				}
			});
			return false;
		});
	});
	function loadDefault(){
		window.parent.showLoading();
		$.get('index.php?m=file/defaultfile&a=ajaxCall&rand='+Math.random(),function(data){
			$("#dir_pic_list").empty().html(data);			
			window.parent.closeLoading();
		});
	}
	function delete_file(file){
		if(!confirm("<% _e('ȷ��ɾ��?');%>"))return false;
		if(empty(file)){
			window.parent.showNotice(empty_delete_file);return false;
		}
		$.get('index.php?m=file/defaultfile&a=delete&file='+file,function(data){
				var ems = data.split('|');
				var m = ems[1];
				switch(ems[0]){
					case '1'://error
						window.showNotice(m);
						return false;
					break;
					case '2'://ok
						window.parent.showNotice(delete_file_ok);
						loadDefault();
					break;
					default:alert(data);return false;
				}		
		})
	}
	function select_data(obj){
		if($.browser.msie || $.browser.mozilla){
			window.returnValue=obj.name; window.parent.top.close();return false;
		}else{
			var son_dom = window.frames["rightFrame"];
			var call_back_write = son_dom.call_back_write;
			if(call_back_write){
				var image_dom = son_dom.image_dom;
				$(image_dom).attr({"src":obj.name});
			}
			$(file_children_obj).val(obj.name);
			$(file_children_obj).focus();
			hidenLayer();
		}
		return false;
	}
</script>
<div id="upload_extend_file">
<form method="post" action="index.php?m=file/defaultFile&a=upload" id="ajax_upload_pic" enctype="multipart/form-data">
	<input type="file" value=""  name="files" id="upload_val_i" /> <input type="submit" value="<% _e('����');%>" class="form_submit" />
</form>
</div>
<div class="clear"></div>
{if $data.total>0}
<div id="dir_pic_list">
{foreach from=$data.data item=pic}
	<div class="pic_list">
		<a href="javascript:;" class="pic_link" onclick="select_data(this);return false;" name="{$pic.http_url}"><img src="{$pic.http_url}" /></a>
       <p class="title"><a href="javascript:;" onclick="delete_file('{$pic.realname}');return false;"><!--ɾ��-->{$lang.u.delete}</a> | <a href="{$pic.http_url}" target="_blank"><!--Ԥ��-->{$lang.u.privew}</a></p>
    </div>
    {/foreach}
    <div class="clear"></div>
    <div id="ajax_call_page">{$data.page}</div>
</div>
<div class="clear"></div>
{else}
<div class="notice_msg"><!--�޿�������!-->{$lang.u.nodata}</div>
{/if}
{if !$is_ajax}
	</body>
    </html>
{/if}
{/if}
<!--AJAX �ص�����-->
{if $action eq 'ajax_call_pic_data'}
{if $data.total>0}
    {foreach from=$data.data item=pic}
        <div class="pic_list">
            <a href="javascript:;" class="pic_link" onclick="select_data(this);return false;" name="{$pic.http_url}"><img src="{$pic.http_url}" /></a>
           <p class="title"><a href="javascript:;" onclick="delete_file('{$pic.realname}');return false;"><!--ɾ��-->{$lang.u.delete}</a> | <a href="{$pic.http_url}" target="_blank"><!--Ԥ��-->{$lang.u.privew}</a></p>
        </div>
        {/foreach}
    {if $data.page}
    <div class="clear"></div>
        <div id="ajax_call_page">{$data.page}</div>
        <script type="text/javascript">
        	$(function(){
				page_function('ajax_call_page','dir_pic_list');
			});
        </script>
    {/if}
    {else}
    <div class="notice_msg"><!--�޿�������!-->{$lang.u.nodata}</div>
    {/if}
{/if}