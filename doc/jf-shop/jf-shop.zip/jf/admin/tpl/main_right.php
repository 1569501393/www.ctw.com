<?php  if(!defined('PHP_TEMPLATE'))exit();?>
<!--��̨Ĭ����ҳ�ұ�-->
{if $action eq 'main_right'}
{include file="frame_header.php"}
<div id="php_right_main_content">
	{if $exist_install}
    	<div class="notice_msg">
            <!--ϵͳ���installĿ¼����,Ϊ��ϵͳ��ȫ��ʹ��ftp����ɾ����Ŀ¼.-->
            {$lang.w.has_install_folder}
        </div>
    {/if}
    <div class="clear"></div>
    <div id="show_update_panel" style="display:none;">
    	<h1 class="title">{$lang.w.has_new_version}</h1>
    <div id="load_server_json_data" class="notice_msg content" style="text-indent:0px;"></div>
    </div>
    <div class="clear"></div>
    {if $is_ie6}
    	<div class="notice_msg">
        <a href="ie6.html" target="_blank" style="color:#F00">ϵͳ�������������汾̫��,���ܻᵼ�²���ҳ����ʾ�쳣,������������!</a>
        </div>
    {/if}
    <!--���������-->
<div id="right_main_pannel">
    	<div class="main_scr_tab">
        	<ul id="aaa">
            	<li class="curent_li" name="first_tag">����������</li>
                <li name="site_tongji">ͳ����Ϣ</li>
                <li id="update" name="update_pannel">ϵͳ����</li>
<!--                <li id="sys_about" onclick="window.parent.showWindow($(this).html(),'index.php?m=system/about',900,450);">����ϵͳ</li>
-->
            </ul>
            <div class="ccc_pannel">
<!--����������-->
            	<div class="need_show" id="first_tag" style="height:220px; overflow:hidden;overflow-y:scroll;">
                <table cellpadding="2" cellspacing="0" class="e_table">
                    <tr>
                        <td>�������</td>
                        <td >{if $un_pay_order}<a href="index.php?m=order&a=wait_pay">{$un_pay_order}</a>{else}0{/if} ��</td>
                        <td>�Ѹ������������</td>
                        <td><a href="index.php?m=order&a=wait_ship">{$has_pay_un_send_order|default:'0'}</a> ��</td>
                    </tr>
                    <tr>
						<td>δ��������</td>
                        <td >{if $un_do_order}<a href="index.php?m=order&a=wait_confirmed">{$un_do_order}</a>{else}0{/if} ��</td>
                        <td>δ������ȱ���Ǽ�</td>
                        <td>{if $un_do_order_stock}<a href="index.php?m=order/outstock&a=outstock&type=undo">{$un_do_order_stock}</a>{else}0{/if} ��</td>
                    </tr>
                    <tr>
                        <td>δ�������Ź�����</td>
                        <td>{if $un_do_tuangou_msg}<a href="index.php?m=other&a=messageBoard&task=purchase&do_tag=un_do">{$un_do_tuangou_msg|default:'0'}</a>{else}0{/if} ��</td>
                        <td>δ��������������</td>
                        <td>{if $try_goods_list}<a href="index.php?m=promotion/try&a=trylist&do_tag=un_do">{$try_goods_list}</a>{else}0{/if} ��</td>
                    </tr>
                    <tr>
                        <td>��Ʒ��汨��</td>
                        <td>{if $out_stock_goods}<a href="index.php?m=goods/products&a=productsList&goods_type=out_stock" style=" color:#F00;">{$out_stock_goods}</a>{else}0{/if} ��</td>
                        <td>δ��������Ʒ����</td>
                        <td>{if $un_do_goods_comment}<a href="index.php?m=goods/goodscomment&a=comment">{$un_do_goods_comment}</a>{else}0{/if} ��</td>
                    </tr>
                    <tr>
                        <td>δ��������������</td>
                        <td >{if $un_do_article_comment}<a href="index.php?m=article/comment&a=listcomment">{$un_do_article_comment}</a>{else}0{/if} ��</td>
                        <td>δ�������ʼ�����</td>
                        <td>{if $un_do_mail_log}<a href="index.php?m=system/messenger&a=mailqueue">{$un_do_mail_log}</a>{else}0{/if} ��</td>
                    </tr>
                     <tr>
                        <td>���ն�����</td>
                        <td>{if $today_order}<a href="index.php?m=order&a=orderList&order_status=today">{$today_order|default:0}</a>{else}0{/if} ��</td>
                        <td>����˻�Ա</td>
                        <td>{if $need_check_member}<a href="index.php?m=member&a=memberList&memstate=2">{$need_check_member|default:'0'}</a>{else}0{/if} ��</td>
                    </tr>
                    <tr>
                    	<td>���ն����ܶ�</td>
                        <td>{if $today_order_total_money}<a href="index.php?m=order&a=orderList&order_status=today">{$today_order_total_money|default:'0'}</a>{else}0{/if} Ԫ</td>
                        <td>�˻�����</td>
                        <td>{if $all_tuihuo_order>0}<a href="index.php?m=order&a=orderList&order_status=return">{$all_tuihuo_order}</a> {else} 0{/if}��</td>
                    </tr>
                    <tr>
                    	<td>�˿�����</td>
                        <td>{if $total_tuikuan_order}<a href="index.php?m=order&a=orderList&order_status=tuikuan">{$total_tuikuan_order}</a>{else}0{/if} ��</td>
                        <td>δ�������û�����</td>
                        <td>{if $undo_member_message_number}<a href="index.php?m=member/feedback&a=feedbacklist">{$undo_member_message_number}</a>{else}0{/if} ��</td>
                    </tr>
                    <tr>
                    	<td>���ڵĹ��</td>
                        <td>{if $has_expired_ad}<a href="index.php?m=promotion/place&a=placeShow&tag=has_expired">{$has_expired_ad}</a>{else}0{/if} ��</td>
                        <td>��Ҫ���ڵĹ��</td>
                        <td>{if $will_expired_ad}<a href="index.php?m=promotion/place&a=placeShow&tag=will_expired">{$will_expired_ad}</a>{else}0{/if} ��</td>
                    </tr>
                </table>
                     <div class="clear"></div>
                </div>
<!--վ��ͳ����Ϣ-->
            <div class="need_show" style="display:none;" id="site_tongji">
            	<table class="e_table" cellspacing="2"  cellpadding="2">
                		<tr>
                        	<td>��Ʒ����</td>
                            <td><a href="index.php?m=goods/products&a=productsList">{$total_goods_number|default:'0'}</a> ��</td>
                            <td>���¼���Ʒ��</td>
                            <td><a href="index.php?m=goods/products&a=productsList&is_sale=0">{$total_un_sale_goods|default:'0'}</a> ��</td>
                        </tr>
                		<tr>
                        	<td>����������</td>
                            <td><a href="index.php?m=goods&a=suppliers">{$total_supperies|default:'0'}</a> ��</td>
							<td>Ʒ������</td>
                            <td><a href="index.php?m=goods/brands&a=brandList">{$total_brand_number|default:'0'}</a> ��</td>
                        </tr>
                		<tr>
                        	<td>��Ʒ��������</td>
                            <td><a href="index.php?m=goods/goodsCategory&a=goodsCategoryList">{$goods_category_total|default:'0'}</a> ��</td>
							<td>���������ܶ�</td>
                            <td>{$total_money|default:'0'}Ԫ</td>
                        </tr>
                        <tr>
                        	<td>��������</td>
                            <td><a href="index.php?m=order&a=orderList">{$total_order}</a> ��</td>
                            <td>��Ա����</td>
                            <td><a href="index.php?m=member&a=memberList">{$total_member_num}</a> ��</td>
                        </tr>
                        <tr>
                        	<td>��������</td>
                            <td><a href="index.php?m=article&a=listarticle">{$artictel_total}</a> ��</td>
                            <td>���·�������</td>
                            <td><a href="index.php?m=article&a=articleCategroyList">{$total_article_cate_num}</a> ��</td>
                        </tr>
                </table>
            </div>
            <!--������Ϣ-->
            <div id="update_pannel" style="display:none;" class="need_show">
    <div style="padding:10px;"><input type="button"  onclick="update_system();" value="����°汾" style="color:#000;" /> ��ǰϵͳ�汾: {$php_version} 
    	<div id="update_call_back_data" style="display:none;"></div>
    </div>
            </div>
            </div>
        <div class="clear"></div>            
        </div><!--��һ������-->
        
        <!--�ڶ�����ʼ-->
         <div class="main_scr_tab bar_right_call">
        	<ul id="bbb">
               <li name="r_2" class="curent_li" dtype='dongtai'>�ٷ���̬</li>
                <li name="r_3" dtype='moban'>����ģ��</li>
            </ul>
<div class="ccc_pannel">

            <div class="rrr_ct" id="r_2">
<!--<img src="images/zoomloader.gif"/>-->
            </div>
            <div class="rrr_ct" id="r_3" style="display:none">
<!--<img src="images/zoomloader.gif"/>-->
            </div>
            <div class="rrr_ct" id="r_4" style="display:none">
<!--<img src="images/zoomloader.gif"/>-->
            </div>
           <div class="clear"></div>
           </div> 
            </div><!--�ڶ�������-->
        <div class="clear"></div>
        <!--����-->
    <div class="main_scr_tab">
        <ul id="ccc">
            <li class="curent_li" name="show_7day">7������ͳ��</li>
            <li name="show_month" rel='index.php?m=chart&a=chart&type=month'><% echo date("m",time());%>������ͳ��</li>
        </ul>
        <div class="ccc_pannel" style="border:none;">
<div class="rrr_ct_4" align="center" id="show_7day">
<img src="images/zoomloader.gif"/>
</div>
            <!--#end show_7day-->
            <div id="show_month" class="rrr_ct_4" style="display:none;"> </div>
            </div>
    </div><!--����������-->
<!--���ĸ���ʼ-->

<div class="main_scr_tab bar_right_call">
<ul id="ddd">
    <li class="curent_li" name="t_1">�ٷ���վ</li>
    <li name="t_2"><a href="http://moban.php188.com" target="_blank">�ٷ�ģ��</a></li>
    <li name="t_3"><a href="http://bbs.php.cm/forumdisplay.php?fid=7" target="_blank">BUG����</a></li>
</ul>
<div class="ccc_pannel" style="height:180px;">
    <div class="aaa">
        <table cellpadding="1" cellspacing="1">
            <tr>
                <td width="50" align="center"><img src="images/1.jpg"  /></td>
                <td>
                <b>�ٷ���վ��</b> <a href="http://www.php.cm" target="_blank">http://www.php.cm</a>
                <br />
                <b>������̳��</b> <a href="http://bbs.php.cm" target="_blank">http://bbs.php.cm</a></td>
            </tr>
        </table>
    </div>
    <div class="bbb">
        <table cellpadding="1" cellspacing="1">
            <tr>
                <td width="50" align="center"><img src="images/2.jpg" /></td>
                <td>
            <table cellpadding="1" cellspacing="1">
                <tr>
                    <td><b>�������ߣ�</b>400-999-0518  </td>
                    <td><b>&nbsp;�������䣺</b>xie@php.cm</td>
                </tr>

                <tr>
                    <td colspan="2"><b>�������ߣ�</b>010-87875088 </td>
                </tr>
                <tr>
                 <td colspan="2"><b>��˾��ַ��</b>��������������·70�����ش���D��7��</td>
                </tr>
            </table>
           </td>
            </tr>
        </table>
    </div>
    </div>
    </div>  
    </div>
<div class="clear"></div>
</div>
<script type="text/javascript">
	$(function(){
		$("#first_tag table td:odd").addClass('gray');
		$("#site_tongji table td:odd").addClass('gray');
		__t($("#aaa li"),'need_show','curent_li');
		__t($("#bbb li"),'rrr_ct','curent_li');
		__t($("#ccc li"),'rrr_ct_4','curent_li');
		$("#bbb li").click(function(data){
			var type = $(this).attr('dtype');
			var url = 'http://api.php.cm/?a=call&model=article&type='+type;
			var _this = $(this);
			$.getScript(url,function(){
				$("#"+_this.attr('name')).empty().html(e_call_string);
			});
		});
		$.getScript('http://api.php.cm/?a=call&model=article&type=use',function(){
			$("#r_1").empty().html(e_call_string);
		});
		$.get('index.php?m=chart&a=chart&type=7day',function(data){
			$("#show_7day").html(data);data = null;
		});
	});
function __t(a,hide,b){
	$(a).click(function(){
		var id = $(this).attr('id');
		if(id!='sys_about'){
			$(a).parent().find("."+b).removeClass(b);
			$(this).addClass(b);
			$("."+hide).hide();
			$("#"+$(this).attr('name')).show();
		}
		var rel = $(this).attr('rel');
		var name= $(this).attr('name');
		if(rel){
			$.ajax({beforSend:function(){
				$("#"+name).html('<img src="images/zoomloader.gif" />');		
			},type:'GET',url:rel,success:function(data){
				$("#"+name).html(data);
			}});
		 }
	});
}
/*�������*/
function update_system(){
	$.getScript('http://api.php.cm/?a=call&model=update&type=check&pubtime='+'{$pub_time}',function(){
		if(update_string){
			$("#update_call_back_data").show().html(update_string).attr({'class':'notice_msg'});
		}
	});
}
function auto_check_update_system(){
	$.getScript('http://api.php.cm/?a=call&model=update&type=check&callback=yes&pubtime='+'{$pub_time}',function(){
		if(update_jstring_string!=''){
			$("#show_update_panel").show();
			$("#load_server_json_data").show().html(update_jstring_string).attr({'class':'notice_msg'});
		}
	});
}
auto_check_update_system();
function ResumeError() { return true; }
window.onerror = ResumeError; 
bar_right = false;
</script>
 {include file="frame_footer.php"}
{/if}