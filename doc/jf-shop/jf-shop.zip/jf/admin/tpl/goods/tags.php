{if !$is_ajax}
{include file="frame_header.php"}
{/if}
{if $action eq 'tags_manage'}
	<div style="padding:8px">
    <form method="post" id="dddd_tags"  action="index.php?m=goods/products&a=tagsManage" autocomplete='off'>
    <input type="hidden" value="add"  name="action" id="do_action" />
    <input type="hidden" value=""  name="id"  id="do_id"/>
    <div class="tb">
    <input type="text" value="" id="tags_add_value"  name="name" class="is_empty_check w150"  />
    </div>
    <div class="tb">
    	  <input type="submit" class="form_submit"  value="{$lang.php_save}"  style="display:none;"/>
          <a href="javascript:;" onclick="submit_form('dddd_tags');" class="block_button">�� ��</a>
    </div>
    </form>
    </div>
    <div class="clear"></div>
    <script type="text/javascript">
	$(function(){
		$("#tags_add_value").blur(function(){
			if($(this).val()){
				$("#do_action").val('add');
			};
		});
		$("#dddd_tags").submit(function(){
			if(!check_form_is_empty('is_empty_check'))return false;
			$(this).ajaxSubmit(function(data){
				 switch(data){
					case 'OK':
						$.get('index.php?m=goods/products&a=tagsManage',function(data){
							$('.'+find_window_class()).html(data);
						});
						window.parent.showNotice(php_do_ok);
						return false;
					break;
					case 'EMPTY':
						window.parent.showNotice('�����ϱ�������!');
					break;
					case 'HAS_EXIST':
						window.parent.showNotice('������ͬ�ı�ǩ!');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
	function delete_tags(obj){
		var tag_id = $(obj).attr('tag_id');
		$.post('index.php?m=goods/products&a=tagsManage',{action:'delete',id:tag_id,name:$(obj).attr('tag_name')},function(data){
			switch(data){
				case 'OK':
				var o = $(".tags_tr_"+tag_id);
				!o.size()?$(".window-content").html(getData('index.php?m=goods/products&a=tagsManage')):$(o).remove();
				//window.parent.showNotice('�����ɹ�!');
				break;
				default:alert(data);
			}
		});
	}
	function edit_tags(obj){
		var a = $("#tags_add_value");
		$(a).val($(obj).attr('tag_name'));
		$("#do_action").val('edit');
		$("#do_id").val($(obj).attr('tag_id'));
	}
	function load_tag_url(id){
		var url = 'index.php?m=goods/products&a=productsList&tag_id='+id;
		reload_frame_url(url);
		_close_window_one();
		return ;
	}
    </script>
    <div>
    <table class="table_list" id="tag_table_list_tag" style="display:{if !$tags_data}none{/if}; margin:0px auto;">
    <thead>
    	<tr>
        <th width="80"><!--��ǩ��-->{$lang.goods.tag_name}</th>
        <th width="80" align="left"><!--����-->{$lang.goods.php_do_action}</th>
        </tr>
    </thead>
    <tbody id="tags_list">
    	{foreach from =$tags_data item=tag}
        <tr class="tags_tr_{$tag.tag_id}">
        	<td style="padding-left:15px;" ><a href="javascript:;" onclick="load_tag_url('{$tag.tag_id}');"><span class="tag_name">{$tag.tag_value}</span>({$tag.total|default:'0'})</a></td>
            <td  style="text-align:center; padding-left:10px;"><a href="javascript:;" onclick="delete_tags(this);" tag_name="{$tag.tag_value}" tag_id="{$tag.tag_id}">ɾ</a>&nbsp;<a href="javascript:;" onclick="edit_tags(this);" tag_id="{$tag.tag_id}" tag_name="{$tag.tag_value}">��</a></td>
        </tr>
        {/foreach}
        </tbody>
    </table>
    </div>
{/if}

<!--������Ʒ��ǩ-->
<!--��ʼ��Ʒ��λ-->
{if $action eq 'unit'}
<script type="text/javascript">
	function edit_unit(id){
		$("#unit_name").val($('#u_n_'+id).html());$("#do_en_name_id").val($('#u_e_'+id).html());$("#unit_do_id").val(id);
		$("#unit_do_action").val('edit');
	}
	function delete_unit(id){
		if($('#unit_do_id').val()==id)$(".need_clear_unit").val('');
		$.get('index.php?m=goods/products&a=unit',{task:'delete',id:id},function(data){
			switch(data){
				case 'ERROR':
					alert('system error!');
				break;
				case 'OK':
					$("#unit_tag_"+id).remove();
					if(!$(".unit_all_tag").length)$("#all_unit_items").remove();
				break;
				default:alert(data);
			}
		});
	}
	$(function(){
		$("#ajax_submit_unit").submit(function(){
			if(!check_form_is_empty('must_fill_unit_input'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						$.get('index.php?m=goods/products&a=unit',function(d){
							$(".window-content").html(d);
						});
						window.parent.showNotice(php_do_ok);return ;
					break;
					case 'ERROR':
						alert('system error!');return false;
					break;
					default:alert(data);
				}
			});return false;
		});
	});
</script>
<div id="do_goods_unite">
<form method="post" action="index.php?m=goods/products&a=unit" id="ajax_submit_unit" autocomplete='off'>
<div class="tb"><% _e('����');%>��</div>
<div class="tb"><input type="text" value=""  class="must_fill_unit_input need_clear_unit" size="8" id="unit_name" name="do_name"/></div>
<div class="tb"><% _e('Ӣ��');%>��</div>
<div class="tb"><input type="text" class="need_clear_unit"  name="do_en_name"  id="do_en_name_id" size="8" /> </div>
<input type="submit" value="<% _e('����');%>"  class="form_submit"  style="display:none;" />
<div class="tb"><a href="javascript:;" onclick="submit_form('ajax_submit_unit');" class="block_button">����</a></div>
<input type="hidden" class="need_clear_unit" value="add" id="unit_do_action"  name="do_action" /> 
<input type="hidden" class="need_clear_unit" value="" name="do_id" id="unit_do_id"/>
</form>
</div>
<div class="clear"></div>
{if $data.total>0}
<table class="table_list" id="all_unit_items">
	<tr>
    	<th width="40"><% _e('���');%></th>
        <th><% _e('����');%></th>
        <th><% _e('Ӣ��');%></th>
        <th width="100"><% _e('����');%></th>
    </tr>
    {foreach from=$data.data item=list key=key}
	<tr id="unit_tag_{$list.id}" class="unit_all_tag">
    	<td align="center">{$list.id}</td>
        <td align="center" id="u_n_{$list.id}">{$list.name}</td>
        <td align="center" id="u_e_{$list.id}">{$list.en_name}</td>
        <td align="center"><a href="javascript:;" onclick="edit_unit('{$list.id}');"><% _e('��');%></a> <a href="javascript:;" onclick="delete_unit('{$list.id}');"><% _e('ɾ');%></a></td>
    </tr>
    {/foreach}
</table>
    {if $is_ajax}
    <script type="text/javascript">
        $(function(){
            page_function('unit_page','window-content','.');
        });
    </script>
    {/if}
    <div id="unit_page">{$data.page}</div>
    {else}
    <div class="notice_msg"><% _e('�޿�������!');%></div>
    {/if}
{/if}
{if !$is_ajax}
	{include file="frame_footer.php"}
{/if}