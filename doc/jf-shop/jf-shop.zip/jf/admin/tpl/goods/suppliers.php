<?php exit('��Ӧ�̹���'); ?>
{if $action eq 'list'}
{include file="frame_header.php"}
<div id="php_top_bar">
    <div class="top_bar_pannel">
    <a  class="block_button form_btn" rel="���ӹ�����" onclick="window.parent.showWindow($(this).attr('rel'),'index.php?m=goods&a=suppliers&task=add',700,270);" ><% _e('�� ��');%></a>
    {if $data.total>0}<a class="block_button"   onclick="butch_pinyin(this);">��������ƴ��</a>{/if}
    </div>
</div>
<div id="php_right_main_content">
{if $data.total>0}
<script type="text/javascript">
var sup_delete_info = "<% _e('ȷ��Ҫɾ����?�˲������ɻָ�!');%>";
var has_goods_data  = "<% _e('������Ʒ����,����ɾ��!');%>";
	function delete_sup(obj,id){
		if(!confirm(sup_delete_info))return false;
		$.get('index.php?m=goods&a=suppliers&task=delete',{id:id},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
					$(obj).parents('tr').remove();
					if($('.need_remove').length<=0)window.location.reload();
				break;
				case 'HAS_GOODS':
					window.parent.showNotice(has_goods_data);return false;
				break;
				default:alert(data);
			}
		});
	}
	function butch_pinyin(){
		if(!confirm('�˲����ȽϺķ���Դ.\nĬ����ȡǰ3��������ƴ��\r\nȷ��Ҫ������?'))return false;
		$.get('index.php?m=goods&a=butchSuppliers',function(data){
			window.parent.showNotice(php_do_ok);
			window.location.reload();
		});
	}
</script>
<table class="table_list">
	<tr>
        <th><% _e('����');%></th>
        <th><% _e('����');%></th>
        <th><% _e('ƴ��');%></th>
        <th><% _e('�������');%></th>
    </tr>
    {foreach from=$data.data item='list'}
	<tr class="sup_{$list.id} need_remove">
        <td width="75" align="center"><a href="javascript:;" rel="<% _e('�༭������');%>->{$list.name}" onclick="window.parent.showWindow($(this).attr('rel'),'index.php?m=goods&a=suppliers&task=edit&id={$list.id}',700,270)">��</a>  <a href="javascript:;" onclick="delete_sup(this,'{$list.id}');">ɾ</a> <a href="index.php?m=goods/products&a=productsList&supplier_id={$list.id}">��</a></td></td>
        <td align="center" class="left" width="300">{$list.name} <font class="blue">({$list.total})</font></td>
        <td width="50" class="center">{$list.pinyin}</td>
        <td>{$list.desc|truncate:'30'}</td>
    </tr>
{/foreach}
</table>
<div class="spacer"></div>
<div class="center">{$data.page}</div>
{else}
<div class="notice_msg"><% _e('�޿�������!');%></div>
{/if}
</div>
{include file="frame_footer.php"}
{/if}
{if $action  eq 'add' || $action eq 'edit'}
<script type="text/javascript">
	$(function(){
		$("#ajax_post_sup").submit(function(){
			if(!check_form_is_empty('must_fill_in'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'EMPTY':
						window.parent.showNotice("<% _e('����д����������!');%>");
					break;
					case 'HAS_EXIST': window.parent.showNotice("<% _e('������ͬ�Ĺ�����!');%>");$("#delete_d").val('');break;
					case 'ERROR':
						window.parent.showNotice("<% _e('��������!');%>");
					break;
					case 'EDIT_OK':
						window.parent.showNotice("<% _e('�����ɹ�!');%>");
						$("#right_frame").attr({"src":"index.php?m=goods&a=suppliers&rand="+Math.random()});
						close_window();
						return ;
					break;
					case 'ADD_OK':
						$(".clear_info").val('');
						window.parent.showNotice("<% _e('�����ɹ�,�������Լ�������!');%>");
						$("#right_frame").attr({"src":"index.php?m=goods&a=suppliers&rand="+Math.random()});
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
<form method="post" action="index.php?m=goods&a=suppliers" id="ajax_post_sup" autocomplete="off">
<input type="hidden" value="{$action}"  name="action"/>
<input type="hidden" value="{$data.name}"  name="old_name"/>
	<table class="table_common">
    	<tr>
        	<td class="one"><% _e('����');%></td>
            <td><input type="text" value="{$data.name}" name="name"  id="delete_d" class="must_fill_in clear_info form_input w350"/></td>
        </tr>
        <tr>
        	<td class="one"><% _e('ƴ��');%></td>
            <td><input type="text" value="{$data.pinyin}" name="pinyin"  class="form_input w350" /></td>
        </tr>
        <tr>
        	<td class="one"><% _e('����');%></td>
            <td><textarea name="desc" class="clear_info common_textarea">{$data.desc}</textarea></td>
        </tr>
        <tr>
        	<td class="one"></td>
        	<td><input type="submit"  class="form_submit" value="<% _e('�� ��');%>" /></td>
        </tr>
    </table>
</form>
{/if}