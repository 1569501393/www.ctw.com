<?php if (! defined ( 'PHP_TEMPLATE' ))exit (); ?>
{if !$is_ajax}
{include file='frame_header.php'}
{/if}
	<script type="text/javascript" >
		{foreach from=$lang.goodscomment.js_html key=key item=item}
			var {$key} = "{$item}";
		{/foreach}
			var qurl = "index.php?m=goods/goodscomment";
			function refurbish(){
				var url = qurl + "&a=comment&page=" + $("#curpage").val();
				location.href=url;
			}
			$(document).ready(function(){
				$("#refubbish_btn").click(function(){
					refurbish();
				});
				<!-- ���ͨ�� -->
				$(".comment_pass").click(function(){
					var url = qurl + "&a=comm_pass&id=" + $(this).attr("name");
					obj = $(this).parent();
					$.get(url,function(data){
						switch($.trim(data)){
							case "1":
								showNotice(vetted_approved);<!-- ���ͨ�� -->
								obj.remove();
								break;
							case "2":
								showNotice(not_choose_examine_goods_message);<!-- ��û��ѡ��Ҫ��˵���Ʒ���� -->
								break;
							default:
								showNotice(audit_failure);<!-- ���ʧ�� -->
								break;
						}
					});
				});
				<!-- ����ɾ�� -->
				$("#batch_delete").click(function(){
					var fix_val = get_checkbox_val("form_checkbox_val");
					if(!fix_val){
						window.parent.showNotice(php_empty_select);
						return false;	
					}
					var url = qurl + "&a=delete_comment";
/*					var formname = "#formcomment";
					if($("#php_gmp_back_gmp").val() == "php"){
						formname = "#php_frm_gmp";
					}
					*/
					$.post(url,{commentids:fix_val},function(data){
						switch($.trim(data)){
							case "1":
								window.location.reload();
								window.parent.showNotice(delete_success);<!-- ɾ���ɹ� -->
								break;
							case "2":
								showNotice(not_choose_delete_item);<!-- ��û��ѡ��Ҫɾ������ -->
								break;
							case "3":
								showNotice(delete_fail);<!-- ɾ��ʧ�� -->
								break;
							default:alert(data);
						}
					});
				});
				var checkflg = true;
				$("#checked_all").click(function(){
					$(".form_checkbox_val").attr("checked",checkflg);
					checkflg = !checkflg;
				});
			});

	</script>
	<input type="hidden" value="{$curpage}" id="curpage"/>
	<div id="php_top_bar" {if $action == 'goodscomment'} class="php_bot_bar"{/if}>
					{if $action == 'goodscomment'}
                   	<a href="javascript:;" id="checked_all" class="block_button">ȫѡ/ȫ��ѡ</a>
                    <a href="javascript:;" id="batch_delete" class="block_button">����ɾ��</a>
                    <a href="javascript:;"  onclick="refurbish()" id="back_buton" class="block_button">{$lang.goodscomment.html_go_back}</a>
                    <a href="javascript:;"  onclick="window.location.reload();" class="block_button">ˢ��</a>
                    {/if}
        <div class="blue tb">
       ��ǰ״̬:{if $auditingcomment eq 'yes'}<!--����˺����ʾ-->{$lang.goodscomment.need_check_can_show}{else}{$lang.goodscomment.not_check_then_show}{/if}
       </div>
       
	</div>
	<div class="clear"></div>
	<div id="php_right_main_content" >
		<div id="comment_list">
{if $action == ''}
		<script type="text/javascript">
			$(document).ready(function(){
				$(".look_comment").click(function(){
					if($(this).attr("id") <= 0){
						showNotice(not_message_product);<!-- ���ڴ���Ʒû������ -->
						return false;
					}
					var url = qurl + "&a=lookcomment&id=" + $(this).attr("name") + "&curpage=" + $("#curpage").val();
					location.href=url;
					return false;
				});
				table_color("table_list");
			});
		</script>
	{if $comments}
			<table class="table_list">
				<tr>
					<th>{$lang.goodscomment.th_message_trade_names}</th><!-- �����Ե���Ʒ���� -->
					<th>{$lang.goodscomment.th_comm_count_total}</th><!-- ������ -->
					<th>{$lang.goodscomment.th_number_unprocessed_commodities_message}</th><!-- ��Ʒ����δ�������� -->
					<th>{$lang.goodscomment.th_opertion}</th><!-- ���� -->
				</tr>
				{foreach from = $comments item = comment}
					<tr>
						<td>{$comment.goods_name}</td>
						<td align="center">{$comment.count}</td>
						<td align="center">{$comment.weichuli}</td>
						<td style="text-align: center">
							<a href="{$comment.goods_detail}" target="_blank" title="{$lang.goodscomment.html_view_product_details}">{$lang.goodscomment.html_view_product_details}</a> &nbsp; <!--�鿴��Ʒ����  -->
							<a id="{$comment.math}" class="look_comment" style="cursor:pointer" name="{$comment.com_goods_id}" title="{$lang.goodscomment.html_view_message}">{$lang.goodscomment.html_view_message}</a><!-- �鿴���� -->
						</td>
					</tr>
				{/foreach}
				{if $pageurl}
					<tr>
						<td colspan="6" align="right" style="text-algin:righr"><div id="div_pageurl">{$pageurl}</div></td>
					</tr>
				{/if}
			</table>
	{else}
		<div class="notice_msg" style="text-algin:center" align="center">{$lang.goodscomment.html_not_data}</div><!-- û����Ʒ���� -->
	{/if}
{/if}

{if $action == 'goodscomment'}
	<div id="goods_commment" style="padding-top:10px;">
        <div class="clear"></div>
				<span class="blue">{$lang.goodscomment.html_goods_name}<strong id="php_goods_name_comment">{$goods_name}</strong></span>
				<hr /><!-- ��Ʒ���� -->
                <script type="text/javascript">
                	function show_call_pannel(obj){
						var id = $(obj).attr('name');
						window.parent.showWindow('�ظ�','index.php?m=goods/goodscomment&a=back_comment&id='+id,750,300);
					}
                </script>
				{foreach from=$comments item=comment}
					<div class="Message_one"  style="margin:0px auto; padding:8px;">
						<span class="Message_title" style="font-weight:normal;color:#000; padding-top:15px">					<!-- ͨ�� �ظ� ɾ��-->
							<div style="float:right;padding-right:20px">{$comment.com_time|date_format:"%Y-%m-%d %H:%M:%S"} 
                                <span id="compass">
                                {if $comment.com_state == '2'}<a style="cursor:pointer" name="{$comment.com_id}" class="comment_pass red" title="{$lang.goodscomment.html_pass}">{$lang.goodscomment.html_pass}</a> {/if}</span>
                                <a name="{$comment.com_id}" class="comment_back" onclick="show_call_pannel(this);" style="cursor:pointer" title="{$lang.goodscomment.html_back}">�ظ�</a>
                                </div>
							<input type="checkbox" class="form_checkbox form_checkbox_val" name="commentids[]" value="{$comment.com_id}" />
                            {$lang.goodscomment.html_member} <strong>{$comment.com_mem_username}</strong> {$lang.goodscomment.html_said}</span><!-- �û� ˵��-->
						<div class="Reply" id="php_member_comm_content_{$comment.com_id}" >{$comment.com_content|nl2br}</div>
                        
						{if $comment.com_back_content}
							<span class="Message_title" style="color:#aa0000;padding-top:15px">
							<div style="float:right; padding-right:20px">{$comment.com_back_time|date_format:"%Y-%m-%d %H:%M:%S"}</div>
							{$lang.goodscomment.html_admin} <strong>{$comment.com_admin}</strong> {$lang.goodscomment.html_admin_back}</span><!-- ����Ա      �ظ��� -->
							<div id="php_admin_comm_content_{$comment.com_id}" class="admin_replay Reply" >{$comment.com_back_content|nl2br}</div>
						{/if}
                        
					</div>
					<hr class="clear" style="padding-top:10px; ">
				{/foreach}
                <div class="clear"></div>
				<div style="float:right" id="commment_pageurl">{$pageurl}</div>
	</div>
	
	</div>
{/if}

	</div>
</div>
{include file='frame_footer.php'}
