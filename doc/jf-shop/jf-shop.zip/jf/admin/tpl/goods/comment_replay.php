<?php exit('die'); ?>
{if $action eq 'back_comment'}
<input type="hidden" id="goods_id" value="{$comment.com_goods_id}"/>
<input type="hidden" value="{$compage}" id="compage"  />
<input type="hidden" value="{$curpage}" id="hidcurpage"/>
    <script type="text/javascript">
        {foreach from=$lang.goodscomment.js_html key=key item=item}
            var {$key} = "{$item}";
        {/foreach}
            $(function(){
                $("#form_back_comment_replay").submit(function(){
                    if(!check_form_is_empty('must_fill_data')){
                        window.parent.showNotice('����������!');
                        return false;
                    }
                    $(this).ajaxSubmit(function(data){
                        switch($.trim(data)){
                            case "1":
                                window.parent.showNotice(reply_success);
								_close_window_one();
                                break;
                            case "2":
                                showNotice(reply_content_must_not_empty);
                                break;
                            case "3":
                                showNotice(please_respecify_reply_message);
                                
                                break;
                            default :
                                window.parent.showNotice(reply_fail);
                                break;
                        }
						_reload_frame();
                    });
                  return false;
            });
        });
    </script>
    <form action="index.php?m=goods/goodscomment&a=back_comment" method="post" id="form_back_comment_replay">
        <table class="table_common">
            <tr>
                <td class="one">{$lang.goodscomment.html_admin_comments}</td><!-- ����Ա�ظ� -->
                <td>
                    <textarea class="form_textarea php_admin_back_comm seo_set must_fill_data"  id="php_admin_back_comm" name="content" style=" width:450px; height:100px;"></textarea>
                </td>
            </tr>
            <tr>
            	<td class="one"></td>
                <td>
                    <input id="btncomm" style="display:none;" type="submit" value="{$lang.goodscomment.html_btn_save}" class="form_submit" /><!-- �ύ -->
                    <a href="javascript:;" onclick="submit_form('form_back_comment_replay');" class="block_button form_btn">�� ��</a>
                </td>
            </tr>
        </table>
        <input type="hidden" value="{$comment.com_id}" id="admin_back_com_id" name="com_id" />
    </form>
{/if}