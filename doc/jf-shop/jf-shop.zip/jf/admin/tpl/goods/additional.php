<?php exit('extend_goods.php'); ?>
{if $action eq 'list'}
{include file="frame_header.php"}
<div id="php_top_bar">
    <div class="top_bar_pannel">
        <div class="tb"><a class="block_button form_btn" href="javascript:;" onclick="add_ext();">{$lang.php_add}</a></div>
        {if $data}<div class="tb"><a class="block_button" href="javascript:;" onclick="delete_select();"><!--ɾ����ѡ-->{$lang.goods.delete_select}</a></div>{/if}
        <div class="tb"><a href="javascript:;" class="block_button" id="open_helper"><!--�򿪰���-->{$lang.goods.open_help}</a></div>
    </div>
</div>
<div id="php_right_main_content">
<div class="notice_msg" id="helpers" style="display:none;">�յ�����ֱ�ӹ���!ֻ���ڹ��ﳵ������!������һ������,��Ҫ����Ĳ���!</div>
<div id="add_pannel" style="display:none;"></div>
<script type="text/javascript">
	function add_ext(){
		window.parent.showWindow('���Ӵյ���Ʒ','index.php?m=goods&a=additional&task=add',900,400);
	}
	$(function(){
		close_open_helper('open_helper','helpers');
		checkAllFormData('check_box','check_box');
	});
</script>
{if $data}
<script type="text/javascript">
	function edit_ext(obj){
		window.parent.showWindow('�༭�յ���Ʒ','index.php?m=goods&a=additional&task=edit&id='+obj.rel,900,400);
	}
	function delete_select(){
		var a = get_checkbox_val('check_box');
		if(!a)return window.parent.showNotice('{$lang.goods.empty_select_data}');
		if(!confirm(php_delete_confirm))return false;
		$.get('index.php?m=goods&a=additional&task=delete',{id:a},function(data){
				switch(data){
					case 'OK':
						var j = a.split(',');
						$(j).each(function(i){
							$('#'+j[i]).remove();
						});
						if(!$(".ext_all").length)window.location.reload();
					break;
					default:alert(data);
				}
		});
	}
</script>
	<table class="table_list table_list_hover">
    	<tr>
        	<th width="30"><input type="checkbox" value=""  id="check_box"/></th>
            <th><!--����-->{$lang.goods.opts}</th>
            <th><!--����-->{$lang.goods.name}</th>
            <th><!--����-->{$lang.goods.danjia}</th>            
            <th><!--ͼƬ-->{$lang.goods.pictures}</th>
            <th>{$lang.goods.goods_stock}</th>
        </tr>
        {foreach from=$data item=list key=key}
    	<tr  class="ext_all" id="{$list.goods_id}">
        	<td class="center"><input type="checkbox" value="{$list.goods_id}"  name="sec[]"  class="check_box"/></td>
            <td class="center" width="50"><a href="javascript:;" onclick="edit_ext(this);" rel="{$list.goods_id}">��</a> </td>
            <td>{$list.goods_name}</td>
            <td class="center">{$list.goods_shop_price}</td>
            <td class="center"  valign="middle">
            	<a href="{$list.goods_source_pic}" target="_blank"><img src="../picture.php?s={$list.goods_source_pic}&w=30&h=60" /></a>
            </td>
            <td class="center">{$list.goods_stock}</td>
        </tr>
        {/foreach}
    </table>
    {else}
    <div class="notice_msg">{$lang.php_nodata}</div>
    {/if}
</div>
{include file="frame_footer.php"}
{/if}
{if $action eq 'load'}
	<form method="post" action="index.php?m=goods&a=additional" id="do_extend_data" autocomplete="off">
	<input type="hidden" value="{$do_action|default:'add'}" id="do_action" name="action" />
	<table class="table_common">
		<tr>
        	<td class="one"><!--����-->{$lang.goods.name}</td>
            <td><input type="text" value="{$data.goods_name}" name="name" class="must_fill_val reset_ext w300"  maxlength="220" /> <font class="blue">*</font></td>
        </tr>
        <tr>
        	<td class="one"><!--����-->{$lang.goods.danjia}</td>
            <td><input type="text" value="{$data.goods_shop_price}"  name="price" class="must_fill_val reset_ext w300" maxlength="30" /> <font class="blue">*</font></td>
        </tr>
        <tr>
        	<td class="one"><!--ͼƬ-->{$lang.goods.pictures}</td>
            <td valign="middle">
           <div style="line-height:100px; float: left;"><input type="text" value="{$data.goods_source_pic}"  name="pic" id="ext_pic" class="reset_ext w300" /> <input type="button" value="{$lang.goods.select_pic}" class="form_submit" onclick="showDialog($('#ext_pic'),'index.php?m=file')" />
           </div>
           <div style="height:100px; float:left;">
			{if $data.goods_source_pic}
            	<img src="../picture.php?s={$data.goods_source_pic}&w=120&h=100" />
            {/if}
            </div>
            </td>
        </tr>
        <tr>
        	<td class="one"><!--���-->{$lang.goods.goods_stock}</td>
            <td>
            <input type="text" value="{$data.goods_stock|default:'500'}"  name="goods_stock" id="ext_pic" class="reset_ext w300 w300" />
            </td>
        </tr>
        <tr>
        	<td class="one"><!--����-->{$lang.goods.details}</td>
            <td><textarea name="other[detail]" rows="5" cols="47" class="w300">{$data.goods_contents.detail}</textarea></td>
        </tr>
        <tr>
        	<td class="one"></td>
            <td><input  type="submit" value="{$lang.php_save}"  style="display:none;" class="form_submit"/>
            	<a href="javascript:;" onclick="submit_form('do_extend_data');" class="block_button form_btn">�� ��</a>
            </td>
        </tr>
    </table>
    </form>
<script type="text/javascript">
		$(function(){
		$("#do_extend_data").submit(function(){
			if(!check_form_is_empty('must_fill_val'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'ERROR':
						return window.parent.showNotice('{$lang.goods.error}');
					break;
					case 'EMPTY_NAME':
						return window.parent.shwoNotice('{$lang.goods.empty_name}');
					break;
					case 'OK':
						window.parent.showNotice(php_do_ok);
						_close_window_one();
						_reload_frame();
					break;
					default:
						alert(data);
				}
			});
			return false;
		});
	});
</script>
{/if}