<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{if $action eq 'categoryList'}
{include file="frame_header.php"}
<form action="index.php?m=goods/goodsCategory&a=saveSort" id="save_sort" method="post" autocomplete="off">      
<div id="php_top_bar" class="php_bot_bar">
<a href="javascript:;"  onclick="opt_category(this);" rel="index.php?m=goods/goodsCategory&a=addGoodsCategory" ename="������Ʒ����" class="block_button">{$lang.category.add_category}</a>
{if $can_edit && $tree_list}
<a href="javascript:;" class="block_button form_btn" onclick="update_cates_count();"><% _e('���·�����Ʒͳ��');%></a>
<a href="javascript:;" class="block_button form_btn"  onclick="update_cate_sign();">��ƴ�����·����־λ</a>
{/if}
<a href="javascript:;"  onclick="window.parent.showWindow($(this).html(),'index.php?m=goods/goodsCategory&a=catExtend',780,320);" class="block_button form_btn">������չ</a>
<a href="javascript:;" onclick="window.parent.showWindow('������Ʒ�������','index.php?m=goods&a=specialgoods',880,400);" class="block_button form_btn" ><% _e('������Ʒ����');%></a>

{if $can_sort && $tree_list}
<input type="submit" value="{$lang.category.save_category}" class="form_submit" style="display:none" />
<a onclick="submit_form('save_sort');" class="block_button">{$lang.category.save_category}</a>
{/if}<!--end sort-->
</div>
<div class="clear"></div>
{if $can_edit}{insert_scripts files='js/jquery.editable.js'}{/if}
<script type="text/javascript">
function opt_category(obj){
	window.parent.showWindow($(obj).attr('ename'),$(obj).attr('rel'),975,530);	
}
function update_cates_count(){
	$.get('index.php?m=goods/goodsCategory&a=updateCatsCount',function(data){
		switch(data){
			case 'OK':window.parent.showNotice(php_do_ok);window.location.reload();break;
			default:alert(data);
		}
	});	
}
var up_cate_sign_notice = "<% _e('ע��:�˲������������еķ����־λ,����������ͬ���ཨ�鲻Ҫ��������!\n���ܻᵼ��ǰ̨������ȡ������!ȷ��Ҫ����������?');%>"; 
function update_cate_sign(){
	if(confirm(up_cate_sign_notice)){
		$.get('index.php?m=goods/goodsCategory&a=updateCatesSign',function(data){
			switch(data){
				case 'OK':window.parent.showNotice(php_do_ok);window.location.reload();break;
				default:alert(data);	
			}
		});
	}		
}
$(document).ready(function(){
	var class_id = null;
	var tree_id;		
	$(".open_close").toggle(function(){
		 var tree_id = $(this).attr('id'); 
		 var tree_name = $(this).attr('name');
		 if(!empty(tree_name)){
			 class_tree = tree_name.split(',');
			 class_id = class_tree;
			 $(class_tree).each(function(i){
					if(i>0)$('.'+class_tree[i]).hide();
				});
			 $("#"+tree_id).attr({'src':'images/sitemapclosed.gif'});
		 }
	},function(){
		if(class_id!=null){
			$(class_id).each(function(i){
				$('.'+class_id[i]).show();
			});
			$(this).attr({'src':'images/sitemapopened.gif'})
			$("#"+tree_id).attr({'src':'images/sitemapopened.gif'});
		}
	});
	$("#save_sort").submit(function(){
		$(this).ajaxSubmit(function(data){
			window.parent.showNotice(php_save_ok);
			window.location.href='index.php?m=goods/goodsCategory&a=goodsCategoryList';
		});
		return false;
	})
	$.editTable($(".edit_category_ajax").find('span'),{ajaxUrl:'index.php?m=goods/goodsCategory&a=ajaxEditName'});

 });
<!--�ر��۵�-->
{if $can_delete}
<!--delete tree-->
function delete_tree(obj){
	if(!confirm(ok_delete))return false;
		var url = 'index.php?m=goods/goodsCategory&a=deleteGoodsCategory&id='+obj.id+'&cate_name='+encodeURIComponent($(obj).attr('name'));
		$.get(url,function(data){
			switch(data){
				case 'NO_AUTH':
					window.parent.showNotice("<% _e('��Ȩ��������');%>");
				break;
				case 'EMPTY':
					window.parent.showNotice("<% _e('�޿�������');%>");
				break;
				case 'HAS_SON':
					window.parent.showNotice("<% _e('�����ӷ���');%>");
				break;
				case 'HAS_GOODS':
					window.parent.showNotice("<% _e('������Ʒ');%>");
				break;
				case 'OK':
					window.parent.showNotice(php_do_ok);window.location.reload();
				break;
				default:
					alert(data);
			}		
		});   
}
{/if}
function clear_cate_caches(){
	$.get('index.php?m=goods/goodsCategory&a=clearCateCache');	
}
</script>
<div id="php_right_main_content">
{if $tree_list}
        	<table class="table_list table_list_common" id="cate_edit_table" cellpadding="0" cellspacing="0" width="110%">
                    <th>���</th>
                    <th>{$lang.category.goods_category_name}</th>
                    <th>ID</th>
                     <th nowrap="nowrap" align="center">{$lang.ads_space}</th>
                  <!--  <th style="width:70px;">��������</th> -->
                 <!-- <th>��Ʒ����</th>-->
                    <th nowrap="nowrap">{$lang.php_sort}</th>
                    <th nowrap="nowrap">{$lang.php_display_in_public}</th>
                    <th nowrap="nowrap">{$lang.category.cate_signs}</th>
                    <th nowrap="nowrap"><!--��Ʒ��-->{$lang.category.bind_brand}</th>
                    <th nowrap="nowrap">{$lang.category.operate}</th>
                 <!--   <th nowrap="nowrap">{$lang.category.review}</th>-->
                <tbody id="tbody">
	                {foreach from =$tree_list item=tree key=key}
                	<tr class="{$tree.cate_id}" id="cates">
                        <td align="center">{if $tree.level+1 eq 1}1{/if}</td>
                        <td style="padding-left:2px;" class="tr"><div item="{$tree.cate_id}_{$tree.parent_id}" style="padding-left:{$tree.level*10}px;" class="edit_category_ajax">
                        ({$tree.level+1})<img {if $tree.children} style="cursor:pointer;" class="open_close" {/if} src="images/sitemapopened.gif" name="{$tree.children}" id = "{$tree.cate_id}"/>
                      <span>{$tree.cate_name}</span><samp class="blue">({$tree.total})</samp></div></td>
                  <td align="center">{$tree.cate_id}</td>
                 <td align="center" style="cursor:help" title="{$lang.ads_space}">{if $tree.ads_space}<samp class="blue">{$lang.have}</samp>{else}<samp>{$lang.not}</samp>{/if}<!--������--></td>
                       <!--<td></td>-->
                      <!-- <td align="center">[��Ʒ����]</td> -->
                        <td align="center"><input type="text"  {if !$can_sort} disabled="disabled" {/if} value="{$tree.cate_sort}" class="cat_sort"  name="cat_sort[]"  style="text-align:center; height:18px;" size="3" maxlength="3"/>
                       {if $can_sort} <input type="hidden" value="{$tree.cate_id}" name="cate_id[]" /> {/if}
                        </td>
                        <td align="center" style="cursor:help" title="{$lang.php_display_in_public}">{if $tree.show_in_nav}<samp class="blue">{$lang.yes}</samp>{else}{$lang.no}{/if}</td>
                        <td align="center">{$tree.cate_sign|default:'-'}</td>
                        <td  align="center" style="cursor:help" title="{$lang.category.bind_brand}">
                        	{if $tree.cate_brands}<samp class="blue">{$lang.yes}</samp>{else}{$lang.no}{/if}
                        </td>
                        <td class="noborder" align="center" valign="bottom" nowrap="nowrap">
                        {if $can_edit}<a href="javascript:;" ename="�༭��Ʒ����->{$tree.cate_name}" rel="index.php?m=goods/goodsCategory&a=editGoodsCategory&id={$tree.cate_id}" onclick="opt_category(this);">��</a>{/if}{if $can_delete} <a href="javascript:;" id="{$tree.cate_id}" name="{$tree.cate_name}" onclick="delete_tree(this);"><% _e('ɾ');%></a>{/if} <a href="{$tree.view_category}" target="_blank" style="color:#F00">{$lang.category.view_public}</a> <a  href="index.php?m=goods/products&a=productsList&cid={$tree.cate_id}">{$lang.category.view}</a></td>
                    	<!--<td align="center"><a href="{$tree.view_category}" target="_blank">{$lang.category.view_public}</a></td>-->
                    </tr>
                    {/foreach}
                </tbody>
            </table>

    {else}
    <div class="notice_msg">{$lang.category.not_exist_categories}</div>
    {/if}
 </div>
 </form>
{include file="frame_footer.php"}
{/if}<!--���������б�-->

{if $action eq 'addGoodsCategory' || $action eq 'editGoodsCategory'}
{if !$is_ajax_call}
<!--��ʼ���ӱ༭����-->
{include file="frame_header.php"}
{/if}
<script type="text/javascript">
$(document).ready(function(){
	$("#do_category_data").submit(function(){
		if(!check_form_is_empty('must_fill_dats')){
			window.parent.showNotice('����д������!');return false;	
		}
		$(this).ajaxSubmit(function(data){
			data = data.split('|');
			switch(data[0]){
				case 'HAS_SAME_SIGN':
					window.parent.showNotice('������ͬ��־λ!');
				break;
				case 'EMPTY_CATEGORY_NAME':
					window.parent.showNotice('��������Ϊ��!');
				break;
				case 'exist_cate_name':
					window.parent.showNotice('ͬ��������ͬ��������!');
				break;
				case 'not_exist_parent_category':
					window.parent.showNotice('�����ڸø�����!');
				break;
				case 'parent_can_not_to_children':
					window.parent.showNotice('�����಻�ܷ����ӷ�����');
				break;
				case 'php_param_error':
					window.parent.showNotice('�����಻�ܷ����ӷ�����');
				break;
				case 'ADD_OK':
					window.parent.showNotice('���ӳɹ�,�������Լ�������!');
					var c = find_window_class();
					var parent_id = $("#cat_parent_tree").val();
					$.get('index.php?m=goods/goodsCategory&a=addGoodsCategory&from_parent_id='+parent_id+'&rand='+Math.random(),function(data){
						$('.'+c).html(data);
					});
					_reload_frame();
				break;
				case 'EDIT_OK':
					window.parent.showNotice('�����ɹ�!');
					{if $is_ajax_call}
						_close_window_one();
						_reload_frame();
					{else}
						window.location.href='index.php?m=goods/goodsCategory&a=goodsCategoryList';		
					{/if}
				break;
				default:alert(data);
			}
		});
		return false;
	});
	$.table_bars($("#site_category_config .menu li"));
});
</script>
<form id="do_category_data"  action="{if $action eq 'editGoodsCategory'}index.php?m=goods/goodsCategory&a=editGoodsCategory{else}index.php?m=goods/goodsCategory&a=addGoodsCategory{/if}" method="post" autocomplete="off">
<input type="submit"  style="display:none;" value="����" />
{if !$is_ajax_call}
<div id="php_top_bar" class="php_bot_bar">
<div>
    <a href="index.php?m=goods/goodsCategory&a=goodsCategoryList"  class="block_button form_btn">�����б�</a>
    <a href="javascript:;"  class="block_button " onclick="submit_form('do_category_data');">�� ��</a>
    <a href="javascript:;" class="block_button form_btn" onclick="window.location.reload();">ˢ��</a>
    </div>    
</div>
<div id="php_right_main_content">
{/if}
<div id="site_category_config" class="table_scroll">
    <div class="menu" style="padding-left:20px;">
    	<li name="cfg_all">ȫ��</li>
        <li name="cfg_base" id="g_base_item" class="wintable_curent">������Ϣ</li>
        <li name="cfg_seo">SEO�Ż�</li>
        <li name="cfg_bind">���ݰ�</li>
        <li name="cfg_html">��̬����</li>
    </div>
</div>
<div class="table_item_base" {if $is_ajax_call} style="width:96%; margin:0px auto; margin-bottom:20px;"{/if}>
 <div class="table_item" id="cfg_base">
    <h1 class="c_bar">������Ϣ</h1>
        <div class="c_content">
            <table class="table_common">
            {if $cate.cate_brands}
            <tr>
                <td colspan="4"><span class="blue">�Ѿ���Ʒ��</span> </td>
            </tr>
            {/if}
            <tr>
                <td class="one">��������</td>
                <td ><input type="text" value="{$cate.cate_name}" name="cate_name"  class="empty_val bg_input must_fill_dats" id="curent_cate_name" style="width:250px;"/> <span class="blue">*</span></td>
            </tr>
            <tr>
                <td class="one">�� ־ λ</td>
                <td><input type="text" value="{$cate.cate_sign}" id="cat_signs" style="width:250px;" class="bg_input" name="cate_sign"/> 
                <input type="button" value="<% _e('��ȡƴ��');%>" title="��������д�������ƺ�ſ��Զ���ö�Ӧ����" onclick="window.parent.get_pinyin($('#curent_cate_name').val(),$('#cat_signs'));"  class="form_submit"/>
                </td>
            </tr>
            <tr>
                <td class="one">�������</td>
                <td><input type="text" value="{$cate.cate_extension}"  name="cate_extension" class="empty_val_bg_input" style="width:250px;"/></td>
            </tr>
            <tr>
                <td class="one">�ϼ�����</td>
                <td>
                {assign var='from_parent_id' value=$smarty.get.from_parent_id}
                <select  name="parent_id"  id="cat_parent_tree" style="width:260px;">
                    <option value="0" selected="selected">{$lang.category.top_category}</option>
                    {foreach from = $tree_list item = list}
                    <option value="{$list.cate_id}" {if $list.cate_id==$cate.parent_id} selected="selected" {/if} {if $from_parent_id eq $list.cate_id} selected="selected"{/if} >{$list.spacer}{$list.cate_name}</option>
                    {/foreach}
                </select>
                </td>
            </tr>
            {*}
              <tr>
                <td class="one" nowrap="nowrap">��ʾģʽ</td>
                <td class="input_notice" title="ע��:���ܲ���ģ�岻֧��">
                <select name="show_in_category" style="width:260px;">
                    <option value="0" {if $cate.show_in_category neq '1'} selected="selected"{/if}>{$lang.category.display_model_type_default}</option><!--Ĭ��ģʽ-->
                    <option value="1" {if $cate.show_in_category eq '1'} selected="selected"{/if}>{$lang.category.display_model_type_list}</option>
                </select>
                </td>
              </tr>
              {*}
            <tr >
                <td class="one">�ⲿ����</td>
                <td><input type="text" name="other[cate_outlink]" style="width:250px;"  class="bg_input" value="{$cate.cate_outlink}" /></td>
            </tr>
            <tr>
                <td class="one">��������</td>
                <td><input type="text" name="other[cate_sort]" value="{if $action eq 'addGoodsCategory'}0{else}{$cate.cate_sort}{/if}" style="width:250px;" class="bg_input" maxlength="5" /></td>
            </tr>
                <tr>
                <td class="one">������ʾ</td>
                <td>  <input type="checkbox" name="show_in_nav" {if $cate.show_in_nav eq '1'} checked="checked" {/if} value="1" />
                </td>
              </tr>
            <tr>
                <td class="one">�Զ���ģ��</td>
                <td><input type="text" name="template_file"  style="width:250px;"  class="bg_input" value="{$cate.template_file}"/></td>
            </tr>
            <tr >
                <td class="one">�������</td>
                <td><textarea name="other[cate_desc]" style="height:60px; width:250px;">{$cate.cate_desc}</textarea></td>
            </tr>
            </table>
        </div>
    </div>
<!--#�������ý���-->
    <!--#SEO-->
    <div class="table_item" id="cfg_seo">
        <h1 class="c_bar">SEO����</h1>
        <div class="c_content">
        <table class="table_common">
        <tr>
            <td class="one"><!--����-->{$lang.php_title}</td>
            <td><textarea name="seo[cate_title]" class="seo_set">{$cate.seo.cate_title}</textarea></td>
        </tr>
        <tr>
            <td class="one">meta->title</td>
            <td><textarea name="seo[meta_title]" class="seo_set">{$cate.seo.meta_title}</textarea></td>
        </tr>
        <tr>
            <td class="one">�ؼ���</td>
            <td><textarea name="seo[cate_keywords]" class="seo_set">{$cate.seo.cate_keywords}</textarea></td>
        </tr>
        <tr>
            <td class="one">������Ϣ</td>
            <td><textarea name="seo[cate_description]" class="seo_set">{$cate.seo.cate_description}</textarea></td>
        </tr>
        </table>
    </div>
</div>

    <div class="table_item" id="cfg_bind">
        <h1 class="c_bar">��Ʒ��</h1>
            <div class="c_content">
            <table class="table_common">
            <tr>
                <td class="no_border">
                <div id="bind_brands" class="bind_data_lable">
                {if $brands_list}
                {foreach from=$brands_list item="brands"}
            <label><input type="checkbox"  {if $brands.selected eq '1'} checked="checked"{/if}  name="cate_brands[]" value="{$brands.brand_id}" />{$brands.brand_name}</label>
                {/foreach}
                {else}
                <div class="blue"><% _e('��Ʒ��');%></div>
                {/if}
                </div>
                </td>
            </tr>
            </table>
            </div>
            <h1 class="c_bar">�󶨹��</h1>
            <div class="c_content">
            <table class="table_common">
                <tr>
                    <td class="no_border">
                <div id="bind_ads" class="bind_data_lable">
                        {if $ads_place}
                            {foreach from=$ads_place item=ads}
                    <label><input type="checkbox" {if $ads.selected eq '1'} checked="checked"{/if} name="ads_place[]" value="{$ads.place_id}" />{$ads.place_name} </label>
                            {/foreach}
                        {else}
                        <div class="blue"><% _e('�޹��λ!');%></div>
                        {/if}
                    </div>
                    </td>
                </tr>
            </table>
        </div>
</div>
    
    <div class="table_item" id="cfg_html">
        <h1 class="c_bar">HTML����</h1>
        <div class="c_content">
        <table class="table_common">	
            <tr>
            <td colspan="2" class="no_border">
            {include file="widget/set_html.php"}
            </td>
            </tr>
        </table>
    	</div>
	</div>
</div>
{if !$is_ajax_call}
</div>
{else}
<div style="width:100px; margin:0px auto; height:auto; margin-top:-18px; display:block;"><a href="javascript:;" class="block_button  form_btn" onclick="submit_form('do_category_data');">�� ��</a></div>
{/if}
</form>
    {if !$is_ajax_call}
    {include file="frame_footer.php"}
    {/if}
{/if}
<!--������չ��ʼ-->
{if $action eq 'cateextend'}
<script type="text/javascript">
	function delete_extend(obj,id){
		if(confirm(ok_delete)){
			$.get('index.php?m=goods/goodsCategory&a=catExtend&task=delete&id='+id,function(){
				$(obj).parents('tr').remove();
				if(!$(".all_extend_tr").length) $("#all_list_tag").remove();	
			});
		}
	}
	function edit_extend(obj,id){
		$("#cat_extend_pannel").slideDown();
		$("#cat_extend_pannel").html(getData('index.php?m=goods/goodsCategory&a=catExtend&task=edit&id='+id));
	}
	function add_cat_extend_info(){
		$("#cat_extend_pannel").slideDown();
		$("#cat_extend_pannel").html(getData('index.php?m=goods/goodsCategory&a=catExtend&task=add'));
	}
</script>
<div id="cat_extend_pannel"></div>
{if $data}
<table class="table_list table_list_common" id="all_list_tag">
	<tr>
    	<th><% _e('����');%></th>
    	<th><% _e('��־');%></th>
	    <th><% _e('����');%></th>
    </tr>
    <tr>
{foreach from=$data item='list'}
	<tr class="all_extend_tr">
    	<td align="center">{$list.name}</td>
        <td align="center">{$list.sign}</td>
        <td align="center"><a href="javascript:;" onclick="edit_extend(this,'{$list.id}');"><% _e('�༭');%></a> <a href="javascript:;" onclick="delete_extend(this,'{$list.id}');"><% _e('ɾ��');%></a></td>
    </tr>
{/foreach}
    </tr>
</table>
<div class="spacer"></div>
<a onclick="add_cat_extend_info(this);" class="block_button form_btn">���ӷ�����չ</a>
{else}
<div id="cat_extend_pannel">{$fetch_data}</div>
{/if}
{/if}
{if $action eq 'exend_call'}
	<form method="post" action="index.php?m=goods/goodsCategory&a=catExtend" id="cate_extend_do" autocomplete="off">
    <input type="hidden" value="{$task|default:'add'}"  name="task"/>
		<table class="table_common">
        	<tr>
            	<td class="one"><% _e('��չ��������');%></td>
                <td><input   type="text" value="{$data.name}" class="extend_must w300 form_input" name="name" id="extend_name" /> <font class="blue">*</font></td>
            </tr>
            <tr>
            	<td class="one"><% _e('��չ�����־λ');%></td>
                <td><input type="text" value="{$data.sign}"  class="w300 form_input" name="sign"/>
                <a href="javascript:;" class="block_button"  onclick="window.parent.get_pinyin($('#extend_name').val(),$(this).prev());"><% _e('��ȡƴ��');%></a>
               </td>
            </tr>
		<tr>
        	<td class="one"><% _e('��Ӧ����ķ���');%></td>
            <td>
            	<select name="extend[]" multiple="multiple" size="10" style="width:350px; height:100px;">
                	{foreach from=$cat_data item='cat'}
                    	<option {if $cat.used eq '1'} selected="selected"{/if} value="{$cat.cate_id}">{$cat.spacer}{$cat.cate_name}</option>
                    {/foreach}
                </select>
            </td>
        </tr>
            <tr>
            	<td class="one"></td>
                <td>
                <input type="submit" class="block_button" value="<% _e('����');%>"  style="display:none"/>
                <a href="javascript:;"  class="block_button form_btn" onclick="submit_form('cate_extend_do');">�� ��</a>
                 {if $task eq 'edit' || $task eq 'add'} <a onclick="$('#cat_extend_pannel').slideUp();" class="block_button">�� ��</a>{/if}</td>
            </tr>
        </table>
    </form>

<script type="text/javascript">
var has_same_sign = "<% _e('������ͬ�ı�־λ!');%>";
	$(function(){
		$("#cate_extend_do").submit(function(){
			if(!check_form_is_empty('extend_must'))return false;
			$(this).ajaxSubmit(function(data){
				 switch(data){
					case 'OK':
						$(".window-content").html(getData('index.php?m=goods/goodsCategory&a=catExtend'));
						return ;
					break;
					case 'HAS_EXIST_SIGN':
						window.parent.showNotice(has_same_sign);
						return ;
					break;
					default:alert(data);
				 }
			});
			return false;
		});
	});
</script>
{/if}
<!--������չ����-->