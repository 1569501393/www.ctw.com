<?php  if(!defined('PHP_TEMPLATE'))exit('php');?>
{if  $action eq 'product_list'}<!--�б�+����-->
{include file="frame_header.php"}
<script type="text/javascript">
function butch_goods_all(obj){
	var data = get_checkbox_val('goods_checkbox');if(!data)return window.parent.showNotice(php_empty_select);
	var newstr = new Array();
	    newstr = data.split(",");
	if(!data||newstr.length>12)return window.parent.showNotice('���һ�β���12�����ݣ�');
	window.parent.show_window_pannel($(obj).html(),'index.php?m=goods/products&a=call&task=butch&tag='+data,980,500);
}
$(function(){
	checkAllFormData('goods_checkbox_id','goods_checkbox');	
	$("#sreach_goods").submit(function(){
		window.location.href=_s(this); return false;
	});
	$("#addvace_search").click(function(){
		var d = $("#subsearch");
		var is_hide = $(d).css('display').toLowerCase()=='none'?true:false;
		if(is_hide){
			var offset = $(this).offset();
			var h = $(this).height() + $(d).height();
			var tt = offset.top+$(this).height()+10;
			$(d).css({"top":tt+'px','left':parseInt(offset.left-($(d).width()/2)+100)+'px'});
			$(d).fadeIn();d=offset = null;		
		}else{
			$("#subsearch").fadeOut();	
		}
	});
	/*�߼�����*/
	$("#addvace_search_form").submit(function(){
		window.location.href=_s(this);$("#subsearch").fadeOut();return false;
	});
	$(".call_list").toggle(function(){
		var id=$(this).attr('rel_id');
		var d = $("#tr_"+id);
		//$(".tr_all_hide").hide();
		if(d.length){
			$(d).show();	
		}else{
			$.get('index.php?m=goods/products&a=call&task=detail&id='+id,function(data){$("#insert_"+id).after(data);});	
		}
	},function(){
		//$(".tr_all_hide").hide();
		$("#tr_"+$(this).attr('rel_id')).hide();
	});
});
function close_t(id){ $("#tr_"+id).hide();}
function export_goods(){
	var url = _s($("#addvace_search_form"))+'&do_task=export&type=xls';
	$.get(url,{fixed_ids:get_checkbox_val('goods_checkbox')},function(data){
		switch(data){
			case 'CAN_CALL':
				window.parent.showWindow("��Ʒ����ѡ��",'index.php?m=goods/products&a=export',850,350);
			break;
			default:alert(data);
		}
	});
}
function delete_goods(){
	var data = get_checkbox_val('goods_checkbox');
	if(!data)return window.parent.showNotice(php_empty_select);
	if(!confirm("ȷ��Ҫɾ����?�˲������ɻָ�!"))return false;
	var opt = {do_options:'delete',delete_ids:data,delete_file:'true'};
	$.post('index.php?m=goods/products&a=call',opt,function(et){
		et = $.trim(et);
		switch(et){
			case 'ERROR':
				window.parent.showNotice("��������!");
			break;
			case 'EMPTY':
				window.parent.showNotice("��ѡ��Ҫɾ��������!");
			break;
			case 'OK':
			var e = data.split(',');
			$(e).each(function(i){
				var id = e[i];
				$("#insert_"+id).remove();
				$("#tr_"+id).remove();
				id = null;
				window.parent.showNotice(php_do_ok);
				if(!$(".goods_list_tag_items").length)window.location.reload();
			});
			data = null;
			break;
			default:alert(et);
		}
	});
}
function butch_edit_stock(obj){
	window.parent.showWindow($(obj).html(),'index.php?m=goods/products&a=call&task=butch_change_stock',600,250);
}
</script>
<form  method="get" id="sreach_goods" action="index.php?m=goods/products&a=productsList" autocomplete="off">
<div id="php_top_bar" style=" top:0px;">
<div class="tb"><input type="text" value="{$search_data.search_goods_val}" name="search_goods_val"  style="width:100px;" id="search_key_words"/></div>
<div class="tb"><a href="javascript:;" onclick="$('#sreach_goods').submit();" class="block_button form_btn">����</a></div>
<div class="tb"><a id="addvace_search" onfocus="this.blur();" class="block_button form_btn">�߼�����</a></div>
<div class="tb"><a class="block_button" onclick="export_goods(this);">��������</a></div>
{if $can_edit && $goods_list.total>0}
<div class="tb"><a class="block_button" href="javascript:;" onclick="butch_goods_all(this);">��������</a></div>
{/if}
{if $action eq 'search_product_list'}
<div class="tb"><a class="block_button loading"  href="index.php?m=goods/products&a=productsList'">{$lang.goods.goods_list}<!--��Ʒ�б�--></a></div>
{/if}
{if  $can_delete && $goods_list.total>0}
<div class="tb"><a href="javascript:;" onclick="delete_goods();" class="block_button">ɾ����ѡ</a></div>
{/if}
{if  $can_edit && $goods_list.total>0}
<div class="tb"><a href="javascript:;" onclick="butch_edit_stock(this);" class="block_button">�����޸Ŀ��</a></div>
{/if}

<div style="float:right; margin-right:10px;" onclick="window.parent.showWindow($(this).html(),'index.php?m=goods/products&a=setMenu',850,300);" class="block_button form_btn">�б�������</div>

</div><!--#end bar-->
</form>
<div id="subsearch" style="display:none; width:450px;">
<form method="get"  action="index.php?m=goods/products&a=productsList" id="addvace_search_form" autocomplete="off">
  <table>
    <tr>
    	<td nowrap="nowrap" align="center"><!--�۸�����-->{$lang.goods.price_betwen}��</td>
        <td><input type="text" value="{$search_data.price_start}"  size="8" onkeyup="value=value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" name="price_start" />-<input size="8" type="text" value="{$search_data.price_end}" onkeyup="value=value.replace(/[^\d]/g,'')"onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" name="price_end" /></td>
        <td nowrap="nowrap" align="center"><!--�������-->{$lang.goods.stock_betwen}��</td>
        <td><input type="text" value="{$search_data.stock_start}"  size="8" onkeyup="value=value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" name="stock_start" />-<input size="8" onkeyup="value=value.replace(/[^\d]/g,'')"onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" type="text" value="{$search_data.stock_end}"  name="stock_end" /></td>
    </tr>
<tr>
	<td><!--��ʼʱ��-->{$lang.goods.time_start}��</td>
    <td><input type="text" value="{$search_data.time_start}"  name="time_start" style="width:130px;"  onfocus="show_date(this);" class="date date_input" id="s_date_start"/></td>
    <td><!--����ʱ��-->{$lang.goods.time_end}��</td>
    <td><input type="text" value="{$search_data.time_end}"  name="time_end" style="width:130px;"  onfocus="show_date(this);"  class="date date_input" id="s_date_end"/></td>
</tr>
    <tr>
      <td align="right"><!--��&nbsp;&nbsp;��-->��&nbsp;&nbsp;&nbsp;&nbsp;�ͣ�</td>
      <td><select name="goods_type" style="width:140px;">
        <option value="">{$lang.goods.g_select_spec}</option>
{foreach from=$goods_type item='type' key="key"}
 <option value="{$key}" {if $search_data.goods_type eq $key} selected="selected"{/if}>{$type}</option>
{/foreach}
 <option value="specfication" {if $search_data.goods_type eq 'specfication'} selected="selected"{/if}>��Ʒ���</option>
      </select></td>
      <td align="right"><!--��&nbsp;&nbsp;&nbsp;&nbsp;��-->{$lang.goods.cat_sea}��</td>
      <td><label>
        <select  name="cid" style="width:140px;">
<option value="">{$lang.goods.g_select_goods_cate}</option>
{foreach from=$category_data item='list'} <option value="{$list.cate_id}" {if $list.cate_id eq $search_data.cid} selected="selected"{/if} >{$list.spacer}{$list.cate_name}</option>{/foreach}
        </select>
      </label></td>
    </tr>
    <tr>
      <td align="right"><!--Ʒ&nbsp;&nbsp;��-->Ʒ&nbsp;&nbsp;&nbsp;&nbsp;�ƣ�</td>
      <td><select name="bid" style="width:140px;">
        <option value="">{$lang.goods.g_select_goods_brand}</option>
    {foreach from=$brand_data item='list'} <option value="{$list.brand_id}" {if $list.brand_id eq $search_data.bid} selected="selected"{/if}>{if $list.pin}{$list.pin}-{/if}{$list.brand_name}</option>
    {/foreach}</select></td>
      <td  nowrap="nowrap" align="right"><!--���Ʒ�ʽ-->{$lang.goods.name_types}��</td>
      <td><select name="s_type2" style="width:140px;">
      <option value="title" {if $search_data.s_type eq 'title'}selected="selected"{/if}>{$lang.goods.goods_title}</option>
        <option value="sn" {if $search_data.s_type eq 'sn'}selected="selected"{/if}>{$lang.goods.goods_sn}</option>
      </select></td>
    </tr>
    <tr>
      <td align="right"><!--�ؼ���-->��&nbsp;��&nbsp;�֣�</td>
      <td><input type="text" value="{$search_data.search_goods_val}" name="search_goods_val"   style="width:130px;" /></td>
      <td>{$lang.goods.shangjia_sea}��</td>
      <td><select name="is_sale" style="width:140px;">
      	<option value="">{$lang.php_select}</option>
        <option value="1"  {if $search_data.is_sale eq '1'}selected="selected"{/if}>{$lang.goods.shangjia_a_sea}</option>
       <option value="0"  {if $search_data.is_sale eq '0'}selected="selected"{/if}>{$lang.goods.xiajia_a_sea}</option>
      </select></td>
    </tr>
<tr>
	<td>��&nbsp;&nbsp;&nbsp;&nbsp;����</td>
    <td>
	 {get_locate assign='region'}
         <select name="region_id" style="width:140px;">
                <option value="">{$lang.php_select}</option>
                    {foreach from=$region item='list'}
{foreach from=$list.son_temp item='son'}<option value="{$son.region_id}" {if $son.region_id eq $search_data.region_id} selected="selected"{/if}>{if $son.p}{$son.p}-{/if}{$list.region_main_name}=>{$son.alias_name}</option>{/foreach}
                {/foreach}
                </select>
    </td>
    <td>�� �� �̣�</td>
    <td>{get_goods_suppliers assign = 'supplies'}
    <select name="supplier_id" style="width:140px;">
        <option value="">��ѡ��...</option>{foreach from=$supplies item='list'}<option value="{$list.id}" {if $list.id eq $search_data.supplier_id} selected="selected" {/if}>{if $list.pin}=>{$list.pin}{/if}{$list.name}</option> {/foreach}
    </select></td>
</tr>
<tr>
	<td>��Ʒ��ţ�</td>
    <td><input type="text" name="goods_sn" value="{$search_data.goods_sn}"  /></td>
	<td>������ࣺ</td>
    <td>
{get_specail_goods_tag assign='special_data'}
<select  name="goods_special_tags" style="width:140px;">
    <option value="">{$lang.php_select}</option>
    {foreach from=$special_data item='list'}
        <option value="{$list.id}" {if $list.id eq  $search_data.goods_special_tags} selected="selected"{/if}>{$list.name}</option>
    {/foreach}
</select>
    </td>
</tr>
<tr>
{if $is_orgin}
	<td>����Ա��</td>
    <td><select name="manager_id" style="width:140px;">
    	<option value="0">��ѡ��...</option>
    	{foreach from=$managers item='m'}
        	<option {if $m.manager_id eq $search_data.manager_id}{/if} value="{$m.manager_id}">{$m.manager_name}</option>
        {/foreach}	
    </select>
    </td>
    {/if}
    <td>��Ʒ��ǩ��</td>
    <td>
    {get_goods_tags assign='tags'}
    <select name="tag_id"  style="width:140px;">
    	<option value="">��ѡ��...</option>	
        {foreach from=$tags item='tag'}
        	<option value="{$tag.tag_id}" {if $search_data.tag_id eq $tag.tag_id} selected="selected"{/if}>{$tag.tag_value}</option>
        {/foreach}
    </select>
    </td>
</tr>
    <tr>
      <td colspan="4" align="center">
      <input type="submit" value="{$lang.goods.goods_search}" class="form_submit" style="display:none" />
      	<a href="javascript:;" onclick="submit_form('addvace_search_form');" class="form_btn block_button">����</a>
        <a href="javascript:;" onclick="$('#subsearch').hide();try{close_date();}catch(e){}" class="block_button form_btn">�ر�</a></td>
    </tr>
  </table>
  </form>
</div>
<div class="clear"></div>
<div id="php_right_main_content" style="margin-top:40px;">
<div class="clear"></div>
{if $goods_list.total>0}
<div id="php_product_list">
	<table cellpadding="0" cellspacing="0"  class="table_list table_list_hover">
     <tr>
        <th align="center" style="text-align:center;" width="30"><input type="checkbox" id="goods_checkbox_id" /></th>
          <th  align="center" style="text-align:center"><!--����-->{$lang.goods.goods_operation}</th>
          
          {foreach from=$default item='set'}
				<th>{$set.name}</th>
          {/foreach}
        </tr>
        {foreach from=$goods_list.data  key=k item=list}
        <tr  id="insert_{$list.goods_id}"  class="goods_list_tag_items" fixed='0'>
        	<td  width="30" style="text-align:center;"><input type="checkbox"  value="{$list.goods_id}" class="goods_checkbox" /></td>
<td  align="center" nowrap="nowrap">
  {if $list.mk_html}<a href="{$list.mk_html}" target="_blank"  title="��̬��">��</a>{/if}{if $can_edit} <a href="index.php?m=goods/products&a=editProducts&id={$list.goods_id}" class="loading show_link_a" title="�༭��Ʒ">��</a>{/if} <a href="javascript:;"  rel_id="{$list.goods_id}" class="call_list show_link_a" title="�鿴��Ʒ����">��</a>
</td>
 
	{foreach from=$default item='set'}
    	<td align="center">
        {foreach from=$list item='li' key=key}
        	{if $key eq $set.key}
            {if $key eq 'goods_name'}
            <div class="goods_name_tag tt_item" item="{$list.goods_id}_{$list.goods_name}"><span style="color:#000;">{$list.goods_name|truncate:25:''}</span></div>
            
                {elseif $key eq 'goods_category_id'}
                <a href="{$list.category_view_link}" class="loading show_link_a">{$list.cate_name}</a>
                {elseif $key eq 'goods_brands_id'}
                
                {if $list.brand_name}<a href="{$list.brand_view_link}" class="loading show_link_a">{$list.brand_name}</a>{else} - {/if}
                
                {elseif $key eq 'goods_is_promotion'}

                	{if $list.goods_is_promotion eq '1'}<a href="index.php?m=goods/products&a=productsList&goods_type=promotion" title="����鿴�����Ѵ�����Ʒ"><span class="green">��</span></a>{else}<a href="index.php?m=goods/products&a=productsList&goods_type=unpromotion" title="����鿴����δ������Ʒ"><span class="red">��</span></a>{/if}

                   {elseif $key eq  'goods_is_sale'}
                    {if $list.goods_is_sale eq '1'}<a href="index.php?m=goods/products&a=productsList&is_sale=1" title="����鿴ȫ�����ϼ���Ʒ"><span class="green">��</span></a>{else}<a href="index.php?m=goods/products&a=productsList&is_sale=0" title="����鿴ȫ��δ�ϼ���Ʒ"><span class="red">��</span></a>{/if}
                   {elseif $key eq  'goods_is_new'}
	                    {if $list.goods_is_new eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                   {elseif $key eq  'goods_is_hot'}
						{if $list.goods_is_hot eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                   {elseif $key eq  'goods_is_competitive'}
					 {if $list.goods_is_competitive eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                    {elseif $key eq 'only_use_point'}
                     {if $list.only_use_point eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                   {elseif $key eq  'goods_is_recomand'}
					 {if $list.goods_is_recomand eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                   {elseif $key eq  'taozhuang'}
					 {if $list.taozhuang eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                   {elseif $key eq  'zengpin'}
					 {if $list.zengpin eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                   {elseif $key eq  'goods_is_special'}
					 {if $list.goods_is_special eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                     {elseif $key eq 'region_id'}
                     {if $list.alias_name}<a href="index.php?m=goods/products&a=productsList&region_id={$list.region_id}">{$list.alias_name}</a>{else} - {/if}
                      {elseif $key eq 'goods_special_tags'}
                      {$list.spcial_goods_tags_name}
                      {elseif $key eq 'supplier_id'}
                     	{$list.supplier_name}
				{elseif $key eq 'goods_chandi_id'}
                		{$list.region_ename}
                {elseif $key eq 'who_add'}
                  {if $list.who_add_name}<a href="index.php?m=goods/products&a=productsList&manager_id={$list.who_add}">{$list.who_add_name}</a>{else} - {/if}
                {else}
               		{$li}
                    {/if}
            {/if}
            
        {/foreach}
        </td>
    {/foreach}
        </tr>
        {/foreach}
    </table>
    {if $goods_list.page}
<div id="products_page">
    	{$goods_list.page}
    </div>
    {/if}
</div>
{else}
<div class="notice_msg">{$lang.php_nodata}</div>
    {/if}
</div>
{include file="frame_footer.php"}
{/if}<!--�����б�+���ؽ���Ĵ���-->
<!--ajax������Ʒ������չ����-->
{if $action eq 'extend_type'}
<script type="text/javascript">
	var open_tag = '{$lang.goods.open_tag}';
	var close_tag = '{$lang.goods.close_tag}';
</script>
{literal}
<script type="text/javascript">
	function open_close_attr(click_id,hiden_id){
		$("#"+click_id).toggle(function(){
			$("#"+hiden_id).slideUp(function(){
				$("#"+click_id).html(open_tag);
			});
		},function(){
			$("#"+hiden_id).slideDown(function(){
				$("#"+click_id).html(close_tag)
			});
		})	
	}
	open_close_attr('open_close','table_common_tag');
	open_close_attr('extend_param','extend_param_table');
</script>
{/literal}
{if $type_data.types_extends_attr}
<div style="background-color:#FAFAFA;">
<table class="table_common" id="table_common_tag">
{foreach from=$type_data.types_extends_attr item=type}
	<tr>
    	<td class="one" width="150">{$type.attr_name}</td>
        <td>
        	{if $type.input_mode eq 'input'}
          <input type="text" value="{$type.user_fix_data}" name="goods_attr_extend_value[{$type.attr_id}]" style="width:300px;" />
            {/if}
			{if $type.input_mode eq 'select'}
                <select name="goods_attr_extend_value[{$type.attr_id}]" style="width:310px;">
                	<option value=""><!--��ѡ��...-->{$lang.php_select}</option>
                	{foreach from=$type.attr_value item=a_v}
			<option value="{$a_v}"{if $type.user_fix_data eq $a_v} selected="selected"{/if}>{$a_v}</option>
                    {/foreach}
                </select>
            {/if}
                {if $type.input_mode eq 'text'}
            	<textarea name="goods_attr_extend_value[{$type.attr_id}]" style="width:300px;">{$type.user_fix_data}</textarea>
            {/if}
             {if $type.bind_in_param eq '1'}<font class="blue">{$lang.goods.has_bind_parame}</font>{/if}
        </td>
    </tr>
 {/foreach}
</table>
<div>
{/if}
<!--end types_extends_attr check-->
{/if}
<!--������Ʒ������չ���ݴ���-->