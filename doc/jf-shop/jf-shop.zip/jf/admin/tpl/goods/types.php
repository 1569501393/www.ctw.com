<?php if(!defined('PHP_TEMPLATE'))exit('php');/*��Ʒ����*/?>
{if $action eq 'type_list'}
{include file="frame_header.php"}
<div id="php_top_bar">
    <div class="top_bar_pannel">
        {if $can_add_type}
        <div class="tb"><a class="block_button form_btn" href="javascript:;" id="add_type" onclick="add_types('index.php?m=goods/types&a=addType','{$lang.goods.types.add_type}');">��������</a></div>{/if}
        {if $can_add_attr}
        <div class="tb"><a class="block_button form_btn" href="javascript:;" onclick="add_attrs('index.php?m=goods/attribute&a=addAttr','{$lang.goods.types.add_attr}');">{$lang.goods.types.add_attr}</a></div>{/if}
    </div>
</div>
<div id="php_right_main_content">
<script type="text/javascript">
$(document).ready(function(){
	close_open_helper('open_helpers','open_helpers_id');
});
<!--������Ʒ����-->
function add_types(url,title){
	window.parent.showWindow(title,url,500,170);
}
function add_attrs(url,title){
	window.parent.showWindow(title,url,750,350);
}
/*ɾ����Ʒ����*/
function delete_type_info(obj){
	if(confirm(delete_this_group_confirm)){<!--��ȷ��Ҫɾ����������?��������������������������ص�����.-->
		var url = 'index.php?m=goods/types&a=deleteType&id='+$(obj).attr('name');
		$.get(url,function(d){
			var call = d.split('|');
			switch(call[0]){
				case '1':
					alert(call[1]);
				break;
				case '2':
				window.parent.showNotice(call[1]);
				window.location.reload();
				break;
				default:alert(d);
			}
		});
	}
}
</script>
    <div id="type_contents">
     {if $type_list}
     <div class="notice_msg" style="display:none;" id="open_helpers_id">
     	{$lang.goods.types.type_list_helper}
     </div>
<div class="clear"></div>
    <form action="index.php?m=goods/types&a=deleteType" method="post" id="type_delete_form">
    <input  type="hidden" value="deleteType" name="action" id="set_action"/>
    <table class="table_list table_list_common">
        <tr>
        	<th   align="center" width="100">{$lang.php_do_action}</th>
            <th width="70" align="center"><!--��������-->{$lang.goods.types.type_name}</th>
            <th  nowrap="nowrap"><!--������-->{$lang.goods.types.attr_num}</th>
            <th nowrap="nowrap" style="display:none;"><!--���-->{$lang.goods.types.type_specs}</th>
             
            </tr>
        {foreach from=$type_list item=type}
        <tr>
            <td align="center">
            {if $can_list_attr}<a href="index.php?m=goods/attribute&a=list&id={$type.type_id}" class="loading">�����б�</a>{/if}
            {if $can_edit_type}<a href="javascript:;" onfocus="this.blur;" name="{$type.type_id}" onclick="add_types('index.php?m=goods/types&a=editType&id={$type.type_id}','{$lang.goods.types.edit_types_data}');" class="loading">��</a>{/if}
           {if $can_delete_type} <a href="javascript:;" onclick="delete_type_info(this);" name="{$type.type_id}">ɾ</a>{/if}
            </td>
       <td nowrap="nowrap"><b>{$type.type_name}</b>{if $type.type_alias}&nbsp;[{$type.type_alias}]{/if}</td>
            <td align="center">{$type.attr_total}</td>
            <td align="center" style="display:none;">
            	{if $type.types_specification}<font class="blue">{$lang.yes}</font>{else}{$lang.no}{/if}
            </td>

        </tr>
        {/foreach}
        </table>
        </form>
        {if $page}
        <div id="cycle_page">{$page}</div>
        {/if}
        {else}
       <div class="notice_msg">{$lang.php_nodata}<!--���޿�������.--></div>
        {/if}
        </div>
    </div>
{include file="frame_footer.php"}
{/if}
{if $action eq 'add_types' || $action eq 'edit_types'}
{include file="frame_js.php"}
<script type="text/javascript">
$(function(){
<!--������������-->
$("#save_types").click(function(){
	var val = $("#type_names").val();
	if(!check_form_is_empty('must_fill_in'))return false;
	$("#save_type_forms").submit();
});
$("#save_type_forms").submit(function(){
	$(this).ajaxSubmit({
		success:function(data){
			var call = $.trim(data).split('|');
			var e = call[0];
			var m = call[1];
			switch(e){
				case '1':
					window.parent.showNotice(m);
					return false;
				break;
				case '2':
					window.parent.showNotice(m);
					$("#right_frame").attr({"src":'index.php?m=goods/types&a=typeList'});
					hidenLayer();
				break;
				case '3':
					showNotice(m);
					$("#goods_prefix_group").empty();
					$("#add_spec_view_info").empty();
					$("#add_spec_view_info_table").hide();
					$("#type_names").val('');
					$("#right_frame").attr({"src":'index.php?m=goods/types&a=typeList'});
				break;
				default:alert(data);return false;
			}
		}
	});
	return false;
	});
})
</script>
<input type="hidden" value="" id="spec_val_info" />
<form method="post" action="{if $action eq 'add_types'}index.php?m=goods/types&a=addType{else}index.php?m=goods/types&a=editType{/if}" id="save_type_forms">
        <!--��ͨ����-->
            	<table class="table_common">
                	<tr>
                    	<td class="one">{$lang.goods.types.type_name}</td>
                        <td><input type="text" class="must_fill_in  bg_input" value="{$type_data.type_name}"  name="type_name" id="type_names"/><span class="blue">*</span></td>
                    </tr>
                    <tr>
                    	<td class="one"><!--����-->{$lang.goods.types.type_alias}</td>
                        <td><input type="text" value="{$type_data.type_alias}" name="type_alias"  class="bg_input"/></td>
                    </tr>
                </table>
                <div style="text-align:center; padding:3px;"><a class="block_button form_btn" id="save_types" href="javascript:;">{$lang.php_save}</a></div>
           <!--#������Ʒ���ݹ����-->
    {if $action eq 'edit_types'}
    	<input type="hidden" value="{$type_data.type_id}" name="type_id" />
    {/if}
    </form>
{/if}
<!--����ajaxload��Ʒ���� index.php?m=goods/types&a=loadSpeDetail-->
{if $action eq 'specdetail'}
	<div id="spec_detail">
    	<h2>{$spec_data.spec_name}</h2>
<div class="spec_detail_view">{$spec_data.spec_remark}&nbsp;[{$lang.goods.types.display_type}<!--��ʾ��ʽ-->:{if $spec_data.spec_display eq 'flat'}{$lang.goods.types.flat_display}{else}{$lang.goods.types.select_display}{/if}]</div>
<div class="clear"></div>
<div>{if $spec_data.spec_value_info}
            	{foreach from=$spec_data.spec_value_info item=spc}
                 {if $spec_data.spec_type eq 'text'}
                	<div class="text_view">{$spc.spec_value}</div>
                    {else}
                    <div class="pic_view"><img src="{$siteurl}{$spc.spec_image}"  width="30" height="30"/></div>
                    {/if}
                {/foreach}
       	 {/if}
     </div>
    </div>
    <div class="clear"></div>
{/if}
