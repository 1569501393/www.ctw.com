<?php exit('die'); ?>
{if $action eq 'add_spec'}
	<form method="post" action="index.php?m=goods&a=goods_spec" id="submit_spec_form" autocomplete="off">
    <input type="hidden" name="action" value="{$action}" />
    <input type="hidden" value="{$spec_id}"  name="spec_id"/>
    	<table class="table_common">
        	<tr>
            	<td class="one">�������</td>
                <td><input type="text" value="{$data.spec_name}" class="must_fill_in w300" maxlength="250" id="vtags" name="spec_main_fix" /><samp class="red">*</samp></td>
            </tr>
        	<tr>
            	<td class="one">��ʾ��ʽ</td>
                <td>
                	<select name="spec_display" class="w300">
                    	<option value="flat" {if $data.spec_typespec_display neq 'select' && $data.display_type neq 'radio'} selected="selected"{/if}>ƽ��</option>
                    	<option value="select"  {if $data.spec_display eq 'select'} selected="selected"{/if}>����</option>
                    	<option value="radio"  {if $data.spec_display eq 'radio'} selected="selected"{/if}>��ѡ</option>
                    </select>
                </td>
            </tr>
        	<tr>
            	<td class="one">��ע</td>
                <td><input type="text" value="{$data.spec_remark}"  class="w300"name="remark" /></td>
            </tr>
            <tr>
            	<td class="one"></td>
                <td><input type="submit" value="����" style="display:none" />
                <a href="javascript:;" onclick="submit_form('submit_spec_form');" class="form_btn block_button">�� ��</a>
                </td>
            </tr>
        </table>
    </form>
<script type="text/javascript">
	$(function(){
		$("#submit_spec_form").submit(function(){
			if(!check_form_is_empty('must_fill_in'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						_close_window_one();
						window.parent.showNotice('�����ɹ�!');
						window.frames['rightFrame'].reload_data_spec_data();
					break;
					case 'HAS_EXIST':
						window.parent.showNotice('������ͬ����!');
						$("#vtags").val('');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
{/if}

<!--#ajax�ص��������-->
{if $call_action eq 'ajax_call_spec_goods'}
<script type="text/javascript">
	function delete_spec_goods(id){
		if(!confirm('ȷ��ɾ��?�˲������ɻָ�!'))return false;
		$.get('index.php?m=goods&a=goods_spec&action=delete_spec_goods',{id:id},function(data){
			switch(data){
				case 'OK':
					$(".espce_goods_temp_"+id).remove();
				break;
				default:alert(data);
			}
		});
	}
	function edit_spec_goods(id){
		window.parent.showWindow('�༭��չ����','index.php?m=goods&a=goods_spec&action=edit_extend_name&id='+id,600,250);
	}
</script>
	<div class="ajax_called_spec_goods">
    	<h2><samp>��{$spec_data.spec_name}��</samp>�µ���Ʒ</h2>
        {if $goods_spec_data}
        {foreach from=$goods_spec_data item='list'}
        	<p class="espec_goods espce_goods_temp_{$list.goods_id}">
            	<a href="{$list.goods_url}" class="img" title="{$list.goods_name}" target="_blank"><img src="../picture.php?s={$list.goods_end_source_pic}&w=50" /></a>
                <span>
                    <samp class="title">{$list.goods_name}</samp>
                    <samp class="price">{$list.goods_shop_price}</samp>
                    <samp class="extend_name">
                    {$list.goods_spec_extend_name}
                    </samp>
                </span>
                
                <em>{if $list.goods_id neq $goods_data.goods_id}
                <a href="javascript:delete_spec_goods('{$list.goods_id}');">ɾ��</a>
                &nbsp;
                <a href="javascript:edit_spec_goods('{$list.goods_id}');">�༭</a>
                {/if}</em>
                
            </p>
        {/foreach}
        {else}
        <div class="notice_msg">��������,������!</div>
        {/if}
    </div>
{/if}

{if $action eq 'call_edit_extend_name'}
<script type="text/javascript">
	$(function(){
		$("#do_extend_name_append").submit(function(){
			if(!check_form_is_empty('must_fill_in_all'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						window.parent.showNotice('�����ɹ�!');
						_close_window_one();
						window.frames['rightFrame'].__call_extend_data('{$data.goods_spec_main_id}');
					break;
					case 'HAS_EXIST':
						$("#replace_goods_spec_extend_name").val('');
						window.parent.showNotice('������ͬ����,��������д!');						
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
<form method="post" action="index.php?m=goods&a=goods_spec" id="do_extend_name_append" autocomplete="off">
<input type="hidden" value="edit_goods_spec_extend_name"  name="action" />
<input type="hidden" value="{$data.goods_id}" name="goods_id"  />
<input type="hidden" value="{$data.goods_spec_main_id}" name="old_spec_id"  />
<table class="table_common">
<tr>
	<td class="one">������</td>
    <td> <select class="w250 form_option" name="goods_spec_main_id" id="goods_specification_val" style="margin-top:6px;">
            <option value="">��ѡ��...</option>	
            {foreach from=$goods_specfication item='spec'}
                <option {if $data.goods_spec_main_id eq $spec.spec_id} selected="selected"{/if} value="{$spec.spec_id}">{$spec.spec_name}{if $spec.spec_remark}��{$spec.spec_remark}��{/if} ({$spec.total})</option>
            {/foreach}
        </select></td>
</tr>
<tr>
	<td class="one">����</td>
    <td><input type="text" value="{$data.goods_spec_extend_name}" id="replace_goods_spec_extend_name" class="must_fill_in_all w250" name="goods_spec_extend_name" /></td>
</tr>
<tr>
	<td class="one"></td>
    <td><a href="javascript:;" onclick="submit_form('do_extend_name_append');" class="block_button form_btn">����</a>
    <input type="submit" value="����" style="display:none;" /></td>
</tr>
</table>
</form>

{/if}