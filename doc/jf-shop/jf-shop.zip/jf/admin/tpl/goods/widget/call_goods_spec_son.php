 <tr>
    <td class="one">��ĸ</td>
    <td><input type="text" value="" title="���磺XXL" name="append_prefix[{$rand_str}][prefix][]"  maxlength="150" class="w100 form_input must_fill_in_spec_data " /> </td>
    <td class="one">����</td>
    <td><input type="text" value="" title="���磺180" name="append_prefix[{$rand_str}][prefix_alias][]" maxlength="150" class="w100 form_input  " /> </td>
    <td class="one">���</td>
    <td><input type="text" value="50" title="��Ӧ��ǰ����µĿ������" name="append_prefix[{$rand_str}][stock][]"  class="w100 form_input  must_fill_in_spec_data" /> </td>
    <td class="one">����</td>
    <td><input type="text" title="��Ӧ���Ļ���(�Զ���)" name="append_prefix[{$rand_str}][sn][]"   onblur="check_spec_goods_sn(this);" value=""  class="w200 form_input must_fill_in_spec_data goods_spec_sn" /> </td>
    <td><a href="javascript:;" onclick="delete_spec(this);"><img src="images/delete.png" /></a></td>
</tr>