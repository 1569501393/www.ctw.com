<?php exit('die'); ?>
{if $do_spec_action eq 'call_spec_append'}
<!--#��ͨAJAX����-->
<div class="append_spec">
<fieldset>
<legend><samp>������</samp><samp><img onclick="delete_main_index(this);" src="images/delete.png" /></samp></legend>
<input  type="hidden" value="" class="w350 form_input" maxlength="40"  name="append_prefix[{$rand_str}][curent_id]"/>
<table class="table_common_fix">
	<tr>
    	<td>����������</td>
        <td><input type="text" title="�������(���ݲ�Ʒ��ͬ����Ӧ����Ҳ��ͬ��)" value="" class="w350 form_input must_fill_in_spec_data" maxlength="40"  name="append_prefix[{$rand_str}][index]"/><samp class="blue"> ���� ���� </samp></td>
        <td>����</td>
        <td colspan="10"><input type="text" value="0" name="append_prefix[{$rand_str}][sort]" class="w50 form_input" /></td>
    </tr>
</table>
    <fieldset>
    <legend><samp>��չֵ</samp><samp class="add_prefix"><img onclick="call_extend_value(this,'{$rand_str}');" src="images/add.png" /></samp></legend>
    <table class="table_common_fix">
        <tr>
            <td class="one">��ĸ</td>
            <td><input type="text" value="" title="���磺XXL" name="append_prefix[{$rand_str}][prefix][]" maxlength="150" class="w100 form_input must_fill_in_spec_data" /> </td>
            <td class="one">����</td>
            <td><input type="text" value="" title="���磺180" name="append_prefix[{$rand_str}][prefix_alias][]" maxlength="150" class="w100 form_input " /> </td>
            <td class="one">���</td>
            <td><input type="text" value="50" title="��Ӧ��ǰ����µĿ������" name="append_prefix[{$rand_str}][stock][]"  class="w100 form_input must_fill_in_spec_data" /> </td>
            <td class="one">����</td>
            <td><input type="text" title="��Ӧ���Ļ���(�Զ���)" name="append_prefix[{$rand_str}][sn][]" onblur="check_spec_goods_sn(this);" value=""  class="w150 form_input must_fill_in_spec_data goods_spec_sn" /> </td>
            <td><a href="javascript:;" onclick="delete_spec(this);"><img src="images/delete.png" /></a></td>
        </tr>
    </table>
    </fieldset>
</fieldset>
</div>
{/if}

{if $action eq 'edit_product'}
{foreach from=$goods_spec_extend_data item='spec'}
<div class="append_spec">
<fieldset>
<legend><samp>������</samp><samp><img onclick="delete_main_index(this,'{$goods_data.goods_id}','{$spec.id}');" src="images/delete.png" /></samp></legend>
<input  type="hidden" value="{$spec.id}" class="w350 form_input" maxlength="40"  name="append_prefix[{$spec.id}][curent_id]"/>
<table class="table_common_fix">
	<tr>
    	<td>����������</td>
        <td><input type="text" title="�������(���ݲ�Ʒ��ͬ����Ӧ����Ҳ��ͬ��)" value="{$spec.index_name}" class="w350 form_input must_fill_in_spec_data" maxlength="40"  name="append_prefix[{$spec.id}][index]"/><samp class="blue"> ���� ���� </samp></td>
        <td>����</td>
        <td colspan="10"><input type="text" value="{$spec.sort|default:'0'}" name="append_prefix[{$spec.id}][sort]" class="w50 form_input" /></td>
    </tr>
</table>
    <fieldset>
    <legend><samp>��չֵ</samp><samp class="add_prefix"><img onclick="call_extend_value(this,'{$spec.id}');" src="images/add.png" /></samp></legend>
    <table class="table_common_fix">
    {foreach from=$spec.son_data item='son'}
        <tr>
            <td class="one">��ĸ</td>
            <td>
			<input  type="hidden" value="{$son.id}" name="append_prefix[{$spec.id}][son_index][]"  class="w100 form_input" /> 
            <input type="text" title="���磺XXL" value="{$son.prefix_name}" name="append_prefix[{$spec.id}][prefix][]" maxlength="150" class="w100 form_input must_fill_in_spec_data" /> </td>
            <td class="one">����</td>
            <td><input type="text" title="���磺180" value="{$son.prefix_alias_name}" name="append_prefix[{$spec.id}][prefix_alias][]" maxlength="150" class="w100 form_input " /> </td>
            <td class="one">���</td>
            <td><input type="text" title="��Ӧ��ǰ����µĿ������" value="{$son.goods_stock}" name="append_prefix[{$spec.id}][stock][]"  class="w100 form_input must_fill_in_spec_data" /> </td>
            <td class="one">����</td>
            <td><input type="text" title="��Ӧ���Ļ���(�Զ���)" value="{$son.goods_sn}" name="append_prefix[{$spec.id}][sn][]" onblur="check_spec_goods_sn(this);"class="w150 form_input must_fill_in_spec_data goods_spec_sn" /> </td>
            <td><a href="javascript:;" onclick="delete_spec(this,'{$goods_data.goods_id}','{$spec.id}','{$son.id}');"><img src="images/delete.png" /></a></td>
        </tr>
       {/foreach}
    </table>
    </fieldset>
</fieldset>
</div>
{/foreach}
{/if}
