<?php  if(!defined('PHP_TEMPLATE'))exit('php');?>
{if $action eq 'brand_list'}
{include file="frame_header.php"}
<script type="text/javascript">
$(document).ready(function(){
checkAllFormData('check_brand','brand_sec');
<!--������ʾ�༭����  ���JS�е�Сbug�����ݱȽ��ٵ�ʱ��-->
	$("#delete_brand").submit(function(){
			var selected = get_checkbox_val('delete_brand_ids');
			if(!selected){
				window.parent.showNotice('��ѡ��Ҫɾ��������!');
				return false;
			}
			removeEnter();
			if(confirm(php_delete_confirm)){
				$(this).ajaxSubmit({success:function(data){
						var e = data.split('|');
						var error = e[0];
						var msg = e[1];
						switch(error){
							case '1':
								showNotice(msg);
								return false;
							break;
							case '2':
								var delete_tag = selected.split(',');
								$(delete_tag).each(function(i){
									$("#all_tag_"+delete_tag[i]).remove();
									if($(".tr_all_tag").size()<=0)window.location.href.reload();
								});
								window.parent.showNotice(msg);
							break;
							default:alert(data);
						}
				}});
			}
			return false;
	});
	$("#search_brands").submit(function(){
		window.location.href=_s(this);
		return false;
	});
});
function update_brands(obj){
	$.get($(obj).attr('rel'),function(data){
		switch(data){
			case 'OK':
				window.parent.showNotice(php_do_ok);
				window.location.reload();
			break;
			default:alert(data);
		}
	});	
}
</script>
<form method="get" id="search_brands" action="index.php?m=goods/brands&a=brandList" autocomplete="off">
<div id="php_top_bar">
<div class="tb"><% _e('Ʒ����');%></div>
<div class="tb"><input type="text" value="{$search_brand_keys.name}" name="name" /></div>
<div class="tb"><input type="submit" value="<% _e('����');%>" class="form_submit"  style="display:none;"/><a href="javascript:;" class="form_btn block_button" onclick="submit_form('search_brands');">����</a></div>
{if $can_add}
<div class="tb"><a class="block_button form_btn"  href="index.php?m=goods/brands&a=addBrand">����Ʒ��</a></div>
{/if}
{if $can_delete && $brand_list.total>0}
<div class="tb">  <a onclick="submit_form('delete_brand');" class="block_button">{$lang.brand.delete_select}</a></div>
{/if}
<div class="tb"><a onclick="update_brands(this);" rel='index.php?m=goods/brands&a=pinyin' class="block_button"><% _e('��������ƴ��');%></a></div>
<div class="tb"><a onclick="update_brands(this);" rel="index.php?m=goods/brands&a=totals" class="block_button"><% _e('��������������Ʒ����');%></a></div>
</div>
</form>
<div id="php_right_main_content">
<div id="brand_item_info">
{if $brand_list.total>0}
<form method="post" id="delete_brand" action="index.php?m=goods/brands&a=deleteBrand">
<table class="table_list table_list_hover">
        <tr> 
        	<th align="center" width="30"><input type="checkbox" value="" name="" id="check_brand" /></th>
            <th align="center" width="30"></th>
            <th nowrap="nowrap"><% _e('����');%></th>
             <th width="40" align="center">{$lang.php_sort}</th>
            <th width="100" nowrap="nowrap"><% _e('����');%></th>
             <th nowrap="nowrap"><% _e('ƴ��');%></th>
             <th nowrap="nowrap"><% _e('��־');%></th>
            <th width="100" nowrap="nowrap"><% _e('��ַ');%></th>
             <th nowrap="nowrap"><% _e('���');%></th>
            
             <th nowrap="nowrap" align="center"><% _e('���');%></th> 
            <th nowrap="nowrap" align="center"><% _e('����');%></th>
			<th nowrap="nowrap" align="center"><% _e('�Ƽ�');%></th>
            <th nowrap="nowrap"><% _e('��ҳ');%></th>
           <th width="150">LOGO</th>
            </tr>
        {foreach from=$brand_list.data item = brand}
        	<tr id="all_tag_{$brand.brand_id}" class="tr_all_tag" >
            	<td align="center" class="trb_tag">
<input type="hidden" alt="index.php?m=goods/brands&a=editBrand&id={$brand.brand_id}" name="edit_brand" /><input  class="delete_brand_ids brand_sec" {if !$can_delete} disabled="disabled"  {/if} type="checkbox"  value="{$brand.brand_id}" name="brand_ids[]"/></td>
			<td>{$brand.brand_id}</td>
           <td nowrap="nowrap" align="center" width="50"><a href="{$brand.public_view_link}" target="_blank"><% _e('��');%></a> <a href="index.php?m=goods/brands&a=editBrand&id={$brand.brand_id}"><% _e('��');%></a></td>
            <td align="center" class="td">{$brand.sort|default:0}</td>
               <td class="td" nowrap="nowrap"><a href="{$brand.brand_view_link}"  title="{$lang.brand.view_brand_goods}">{$brand.brand_name}</a><font class="blue">({$brand.total|default:'0'})</font></td>
               <td align="center">{$brand.pinyin}</td>
               <td align="center">{$brand.brand_sign}</td>
               <td align="left" class="td">{$brand.brand_url}</td>
               <td align="left" class="td" nowrap="nowrap">{$brand.brand_short_desc|truncate:15}</td>
               <td align="center" class="td">{if $brand.ads_space}<span class="green">��</span>{else}<span class="red">��</span></font>{/if}</td>
               
                <td align="center" class="td">{if $brand.show_in_nav eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
                <td align="center" class="td">{if $brand.is_recomend eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
                 <td align="center"><font class="blue">{if $brand.show_index eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</font></td>
                
                <td align="center" class="td">{if $brand.brand_logo}<img src="../picture.php?s={$brand.brand_logo}&w=120&h=30" />{/if}</td>
          
            </tr>
         {/foreach}
</table>
 <input type="hidden" value="delete" id="do_action" name="action" />
</form>
    <div id="pages">
     {$brand_list.page}
    </div>
{else}
<div class="notice_msg">{$lang.php_nodata}</div>
{/if}
</div>
</div>
{include file="frame_footer.php"}
{/if}<!--end action of brand_list-->
{if $action eq 'add_brand' || $action eq 'edit_brand' }
{include file="frame_header.php"}
<form method="post" id="ajax_submit_form" action="" autocomplete="off">
<input  type="submit" class="form_submit" value=""  style="display:none;"/>
<div id="php_top_bar" class="php_bot_bar">
    <a class="block_button" onclick="window.location.reload();"><% _e('ˢ��');%></a>
    <a href="javascript:;" class="block_button" onclick="submit_form('ajax_submit_form');">����</a>
</div>
{include file="part.js.php"}
<script type="text/javascript">
$(function(){
	$("#brand_logo").upload({
		filename:'brand_logo_file',
		post_params:{'sid':session_id},
		loading_dom:$("#load_doms"),
		url:'index.php?m=goods/brands&a=ajaxUpload',
		sucess:function(file,response){
			try{
					var e = response.split('|');
					var error = $.trim(e[0]);
					var msg = e[1];
					window.parent.closeLoading();
					switch(error){
						case '1':
							window.parent.show(msg);
							return false;
						break;
						case '2':
							$("#show_brand_logo").html('<img src="../picture.php?s='+msg+'&w=120&h=30&rand='+Math.random()+'"  />');
							$("#brand_logo_hidden").val(msg);
						break;
					 default:alert(!empty(response)?response:System_overtime);return false;
				}	
			}catch(e){alert(e);}
		}//end function
	});
	$("#ajax_submit_form").submit(function(){
		if(!check_form_is_empty('must_fill_in')){
			window.parent.showNotice('����д������!');
			return  false;
		}
	});
	$.table_bars($("#site_brand_config .menu li"));
});
</script>
<div id="php_right_main_content">
<div id="site_brand_config" class="table_scroll">
    <ul class="menu" style="padding-left:20px;">
	    <li name="cfg_all">ȫ��</li>
        <li name="cfg_base" id="g_base_item" class="wintable_curent">������Ϣ</li>
        <li name="cfg_seo">SEO�Ż�</li>
        <li name="cfg_detail">����</li>
        <li name="cfg_ads">����</li>
        <li name="cfg_html">��̬����</li>
    </ul>
</div>
<div class="table_item_base">
<!--#��������-->
<div class="table_item" id="cfg_base">
    <h1 class="c_bar">������Ϣ</h1>
        <div class="c_content">
<table class="table_common">
<tr>
    <td class="one">{$lang.brand.brand_name}</td>
    <td ><input type="text" value="{$brand.brand_name}" id="add_brand_name"  size="30" class="must_fill_in" name="brand_name" /> <span class="blue">*</span></td>
</tr>
<tr>
    <td class="one"><% _e('ƴ &nbsp;&nbsp;&nbsp;��');%></td>
    <td><input type="text" value="{$brand.pinyin}"   size="30" name="pinyin" >
    <input type="button" value="��ȡƴ��" class="form_submit input_notice"  title="����дƷ�����ƺ����˰�ť���Զ���ȡ��Ӧƴ��" onclick="window.parent.get_pinyin($('#add_brand_name').val(),$(this).prev());" />
    </td>
</tr>
<tr>
    <td class="one"> {$lang.brand.brand_url}</td>
    <td><input type="text" id="add_brand_url" size="30"  value="{if $brand.brand_url}{$brand.brand_url}{/if}" name="brand_url" /></td>
</tr>
<tr>
<td class="one">�� ־ λ</td>
<td><input type="text" value="{$brand.brand_sign}"   size="30" name="brand_sign"/></td>
</tr>
<tr>
	<td class="one">ģ&nbsp;&nbsp;&nbsp; ��</td>
	<td><input type="text"   name="template_file" size="30"   value="{$brand.template_file}"/></td>
</tr>
<tr>
<td class="one">��&nbsp;&nbsp;&nbsp; ��</td>
<td><input type="text" value="{if $brand.sort}{$brand.sort}{else}0{/if}" name="sort"  size="30" /></td>
</tr>
<tr>
<td class="one"><% _e('������ʾ');%></td>
<td><input  type="checkbox" name="show_in_nav" {if $brand.show_in_nav eq '1'} checked="checked"{/if} value="1" /></td>
</tr>
<tr>
<td class="one">{$lang.brand.brand_show_index}</td>
<td>
<input  type="checkbox" name="show_index" {if $brand.show_index eq '1'} checked="checked"{/if} value="1" />
</td>
</tr>
<tr>
<td class="one"><% _e('��Ϊ�Ƽ�');%></td>
<td><input  type="checkbox" name="is_recomend" {if $brand.is_recomend eq '1'} checked="checked"{/if} value="1" /></td>
</tr>
    <tr>
        <td class="one">Ʒ��LOGO</td>
        <td valign="middle">
        <div id="show_brand_logo">
        <img src="../picture.php?s={$brand.brand_logo}&w=120&h=30" />
        </div>
        </td>
    </tr>
    <tr>
        <td class="one">�ϴ�Ʒ��LOGO</td>
        <td valign="middle">
       <input  id="brand_logo" type="file" >
        <div id="load_doms"></div>
        <input  type="hidden" value="{$brand.brand_logo}" name="brand_logo" id="brand_logo_hidden" /> 
        </td>
    </tr>
</table>
</div>
</div>

<!--#�Ż�-->

<div class="table_item" id="cfg_seo">
    <h1 class="c_bar">SEO����</h1>
        <div class="c_content">
<table class="table_common">
<tr>
	<td class="one"><!--����-->{$lang.php_title}</td>
    <td><textarea name="seo[brand_title]" class="seo_set">{$brand.seo.brand_title}</textarea></td>
</tr>
<tr>
	<td class="one">meta->title</td>
    <td><textarea name="seo[meta_title]" class="seo_set">{$brand.seo.meta_title}</textarea></td>
</tr>
<tr>
    <td class="one" valign="middle">�ؼ���</td>
    <td ><textarea name="seo[brand_keywords]" class="seo_set">{$brand.seo.brand_keywords}</textarea></td>
</tr>
<tr>
    <td class="one" valign="middle">ҳ������</td>
    <td ><textarea name="seo[brand_description]" class="seo_set">{$brand.seo.brand_description}</textarea></td>
</tr>

</table>
</div>
</div>
<!--#���-->
    <div class="table_item" id="cfg_ads">
        <h1 class="c_bar">�󶨹��</h1>
        <div class="c_content">
    <table class="table_common">
        <tr>
        <td class="no_border">
        <div class="ads_pannel_label">
         {foreach from=$ads_place item=ads}
            <label><input type="checkbox" name="ads_place[]" value="{$ads.place_id}"  {if $ads.selected eq '1'} checked="checked" {/if}/>{$ads.place_name} {$ads.place_width} * {$ads.place_height}</label>
         {/foreach}
         </div>
        </td>
        </tr>
    </table>
    </div>
</div>
<!--����-->
<div class="table_item" id="cfg_detail">
    <h1 class="c_bar">��̽���</h1>
        <div class="c_content">
   <table class="table_common">
    <tr>
        <td class="no_border"><textarea name="brand_short_desc" style="width:450px; height:80px;">{$brand.brand_short_desc}</textarea></td>
    </tr>
    </table>
</div>
<h1 class="c_bar">��ϸ����</h1>
    <div class="c_content c_no_border">
<table class="table_common">
     <tr>
        <td class="no_border">{$editor} </td>
    </tr>
</table>
</div>
</div>
<!--#HTML����-->
    <div class="table_item" id="cfg_html">
        <h1 class="c_bar">��̬����</h1>
            <div class="c_content">
                <table class="table_common">
                <tr>
                    <td class="no_border">
                    {include file="widget/set_html.php"}
                     </td>
                  </tr>
                </table>
            </div>
    </div>
</div>
</div>
		<input type="hidden" value="{$brand.brand_id}"  name="brand_id"/>    
    </form>
{include file="frame_footer.php"}
{/if}