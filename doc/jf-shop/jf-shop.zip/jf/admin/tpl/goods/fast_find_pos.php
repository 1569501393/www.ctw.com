<?php exit('die') ?>
{if $action eq 'find_data_action' }
<script type="text/javascript">
	function _s(obj){$(obj).next().show();	}
	function _h(obj){$(obj).next().hide();}
	$(function(){
		var obj = $("#find_datas");
		$(obj).keyup(function(){
			var val = $(this).val();
			if(val.length>=1){
				_s(obj);
				$.get('index.php?m=goods&m=goods&a=callBack',{name:val,type:$("#etype").val()},function(data){
					$("#call_back_data").html(data);
					_h(obj);
					return false;
				});	
			}
		});
	});
	function set_values(obj){
			var rel = $(obj).attr('rel');
			var tag = $("#etype").val()=='cate'?true:false;
			window.frames['rightFrame']._set_value(rel,tag);
			close_window();
	}
</script>
<div style="padding:8px;">
<!--<div class="notice_msg" style="margin:3px;">���������Ľ��˫��ѡ��!</div>-->
<div>
<input  type="hidden" value="{$type}" id="etype" />
<span class="blue" style="font-size:14px;"><% _e('������Ҫ������');%>
<b>{if $type eq 'brand'}<% _e('Ʒ��');%>{elseif $type  eq 'supp'}<% _e('������');%>{elseif $type eq 'cate'}<% _e('��Ʒ����');%>{elseif $type eq 'region'}<% _e('����');%>{/if}</b>��</span><input type="text" value=""  id="find_datas" /><img src="images/loader.gif" style="display:none" />
</div>
<div id="call_back_data"></div>
</div>
{/if}