<?php  exit('die');?>
<!--����-->
{if $action eq 'export_xls'}
<head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" /><style>td{vnd.ms-excel.numberformat:@}</style></head>
<table width="100%" border="1">
<tr>
{foreach from=$default item='menu'}
<th filter=all>{$menu.name}</th>
{/foreach}
</tr>
{foreach from=$goods_list item=list}
	<tr>
	{foreach from=$default item='set'}
    	<td align="left">
        {foreach from=$list item='li' key=key}
        	{if $key eq $set.key}
				{if $key eq 'goods_name'}
					{$list.goods_name|truncate:25:''}
                {elseif $key eq 'goods_category_id'}
					{$list.cate_name}
                {elseif $key eq 'goods_brands_id'}
					{$list.brand_name}
                {elseif $key eq 'goods_is_promotion'}
                	{if $list.goods_is_promotion eq '1'}��{else}��{/if}
                    {elseif $key eq  'goods_is_sale'}
                    	{if $list.goods_is_sale eq '1'}��{else}��{/if}
                    {elseif $key eq  'goods_is_new'}
	                   	 {if $list.goods_is_new eq '1'}��{else}��{/if}
                    {elseif $key eq  'goods_is_hot'}
						{if $list.goods_is_hot eq '1'}��{else}��{/if}
                   {elseif $key eq  'goods_is_competitive'}
						 {if $list.goods_is_competitive eq '1'}��{else}��{/if}
                   {elseif $key eq  'goods_is_recomand'}
						 {if $list.goods_is_recomand eq '1'}��{else}��{/if}
                   {elseif $key eq  'goods_is_special'}
						 {if $list.goods_is_special eq '1'}��{else}��{/if}
                   {elseif $key eq 'region_id'}
						{$list.alias_name}
                   {elseif $key eq 'supplier_id'}
                     	{$list.supplier_name}
				   {elseif $key eq 'goods_special_tags'}
                      {$list.spcial_goods_tags_name}
				   {elseif $key eq 'goods_chandi_id'}
                		{$list.region_ename}
              	  {else}
               		{$li}
                    {/if}
            {/if}
        {/foreach}
        </td>
    {/foreach}
        </tr>
 {/foreach}
</table>
{/if}
<!--������ʾ-->
{if $action eq 'export_goods'}
<script type="text/javascript">
	function set_export(v){
		$("#export_type").val(v);
		$("#submit_menu_form").submit();
	}
</script>

<form method="post" action="index.php?m=goods/products&a=export" id="submit_menu_form"  target="_blank">
<input type="hidden" value="" name="export_type" id="export_type" />
<div class="table_item_base">
	<h1 class="c_bar">��Ʒ����ѡ��</h1>
    <div class="c_content">
	<div class="set_menu_main">
    	<div class="set_menus">
        <ul>
        {foreach from=$data item='item'}
        	<li><label><input  type="checkbox" value="{$item.key}__{$item.name}" class="check_box_call" {if $item.sec eq '1'} checked="checked"{/if} name="set[]" /> 
            {$item.name}</label></li>
        {/foreach}
        <div class="clear"></div>
        </ul>
<div class="set_sub">
<input type="button" onclick="set_export('');" value="�����������"  class="form_submit" style="display:none;"/> 
<a  href="javascript:;" onclick="set_export('');" class="block_button form_btn" >�����������</a>
<a  href="javascript:;" onclick="set_export('1');" class="block_button form_btn" >ֻ������ѡ��Ʒ</a>
<input type="checkbox" value="" id="check_box_call" />ȫѡ
		<script type="text/javascript">
            $(function(){
                check_all('check_box_call','check_box_call');
            });
        </script>
<input type="button" class="form_submit" onclick="set_export('1');" value="ֻ������ѡ��Ʒ" style="display:none;" /></div>
        </div>
    </div>
</div>
</div>
</form>
{/if}