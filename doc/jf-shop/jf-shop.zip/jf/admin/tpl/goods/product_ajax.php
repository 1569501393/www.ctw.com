<?php exit('php'); ?>
{if $action eq 'butch_change_stock'}
<div class="notice_msg">
ֻ֧��txt�����ļ�,�ϴ����ļ����ᱣ��,�����б���,һ��һ��,ֻ�޸���Ʒ��� <a href="./stock.txt" target="_blank"><strong class="blue">����</strong></a>
</div>
	<form method="post" enctype="multipart/form-data" action="index.php?m=goods/products&a=call" id="upload_submit_outstock">
    <input type="hidden" value="butch_change_stock"  name="do_options"/>
    	<table class="table_common">
        	<tr>
            	<td class="one">ѡ���ļ�</td>
                <td><input type="file" id='butch_change_stock_file'  name="butch_change_stock_file" /></td>
            </tr>
            <tr>
            	<td class="one"></td>
                <td><input type="submit" value="�� ��"  class="form_submit" style="display:none"/>
                <a href="javascript:;" onClick="submit_form('upload_submit_outstock');" class="form_btn block_button">�ϴ�</a>
                </td>
            </tr>
        </table>
    </form>
    
<div id="show_not_has_do_log" class="notice_msg" style="display:none"></div>
<script type="text/javascript">
	$(function(){
		$("#upload_submit_outstock").submit(function(){
			$(this).ajaxSubmit(function(data){
				data = data.split('|');
				switch(data[0]){
					case 'OK':
						window.parent.showNotice('�����ɹ���');
						_reload_frame();
						cleanFile('butch_change_stock_file');
						$("#show_not_has_do_log").hide();
					break;
					case 'HAS_ERROR':
						window.parent.showNotice('����û�����ɹ�������!');
						var str = '<a href="../'+data[1]+'" target="_blank"><strong class="red">�鿴ʧ����־</strong></a>';
						cleanFile('butch_change_stock_file');
						$("#show_not_has_do_log").show().html(str);
					break;
					case 'EMPTY':
						window.parent.showNotice('��ѡ��Ҫ�ϴ����ļ�!');
					break;
					case 'NO_DATA':
						window.parent.showNotice('��ȷ���ı��ļ���������!');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
{/if}

{if $action eq 'detail'}
  <tr id="tr_{$data.goods_id}" class="tr_all_hide">
        	<td  colspan="30">
                <table class="tttt">
                	<tr>
                    	<td width="173"><img src="../picture.php?s={$data.goods_detail_pic}&w=170&h=120" class="detail_pic" /></td>
                        <td valign="top" align="left">
		<div class="detail_main_left">
<p class="detail_view_all tag_p"><!--ǰ̨���ʵ�ַ-->{$lang.goods.public_view_link}:<input type="text" value="{$data.preview_link}" />   <a href="{$data.preview_link}" class="viewbut" target="_blank"><!--����ǰ̨-->{$lang.goods.view_public}</a><a href="javascript:void(0);" onClick="close_t('{$data.goods_id}');"  class="viewbut"><!--�ر�-->{$lang.goods.close_but}</a></p> 
                        <p class="tag_p">
                           <span>SN:{$data.goods_sn}</span>
                           <br />
                            {if $data.goods_is_new eq '1'}<span class="blue b">{$lang.goods.goods_new_goods}</span>{/if}
                            {if $data.goods_is_competitive eq '1'}<span class="blue b">{$lang.goods.goods_comptive_goods}</span>{/if}
                           {if $data.goods_is_hot eq '1'}<span class="blue b">{$lang.goods.goods_hot_goods}</span>{/if}
                            {if $data.goods_is_recomand eq '1'}<span class="blue b">{$lang.goods.remomend}</span>{/if}
                           {if $data.goods_is_chufang eq '1'}<span class="blue b">����</span>{/if}
                           {if $data.supplier_name}<span class="blue b">�����̣�</span><em style="font-style:normal;">{$data.supplier_name}</em>{/if}
							<span class="b blue"><!--�г���-->{$lang.goods.goods_market_price}��{$data.goods_market_price}</span>
                            <span class="b blue"><!--�����-->{$lang.goods.shop_price_c}��{$data.goods_shop_price}</span>
                     		<span class="b blue"><!--����-->{$lang.goods.pub_view_all}:{$data.goods_visted|default:0}</span>
                     <br />
                          <span class="b blue">    
                           {if $data.goods_is_promotion eq '1'} 
                         {$lang.goods.promotion_end_times}��{$data.goods_promotion_end_time|date_format:"%Y-%m-%d %H:%M:%S"}
                           &nbsp;{$lang.goods.promotion_price}��{$data.goods_promotion_price}
                           {/if}
                           </span>
                           </p> </div>
<div class="clear"></div>

<!--����ͼ-->
<div class="tag_p">
{*}
<img src="http://chart.apis.google.com/chart?chs=300x100&chd=t:2,0,5,1,20,0,0,0,0,0,0,0,3,0,8&chxt=x,y,x,r&chco=224499&chxl=0:|25|26|27|28|29|30|31|01|02|03|04|05|06|07|08|1:|0|5|10|2:|2010.08|2010.09|3:|0|5|10&cht=lc&chds=0,10&chxp=2,0,46&chxs=2,000099,13&chm=B,76A4FB,0,0,0|V,000099,0,7,1&chg=5,25,1" />

<img src="http://chart.apis.google.com/chart?chs=300x100&chd=t:2,0,5,1,20,0,0,0,0,0,0,0,3,0,8&chxt=x,y,x,r&chco=224499&chxl=0:|25|26|27|28|29|30|31|01|02|03|04|05|06|07|08|1:|0|5|10|2:|2010.08|2010.09|3:|0|5|10&cht=lc&chds=0,10&chxp=2,0,46&chxs=2,000099,13&chm=B,76A4FB,0,0,0|V,000099,0,7,1&chg=5,25,1" />
<!--��������ͼ-->
{*}
</div>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
{/if}<!--end action detail-->

{if $action eq 'butch'}<!--��Ʒ��������-->
{if !$is_ajax}
	{include file="header_common.php"}
<body style="margin:0px; overflow:hidden;"  scroll="no">
{/if}
{if $data}
<form method="post" action="index.php?m=goods/products&a=call"  id="ajax_butch_all">
<input type="hidden" value="" id="do_task" />
<style type="text/css">
.table_list td{ padding:4px 1px; text-align:center;}
</style>
	<table class="table_list">
    	<tr>
			<th><input type="checkbox" id="ajax_butch"  checked="checked"/></th>
        	<th>{$lang.goods.goods_name}</th>
            <th>{$lang.goods.goods_brands}</th>
            <th>{$lang.goods.goods_category}</th>
            <th>����</th>
            <th>����</th>
            <th>{$lang.goods.pub_view_all}</th>
            <th>����</th>
            <th>{$lang.goods.goods_kuchun}</th>
            <th>��Ʒ</th>
            <th>��Ʒ</th>
            <th>�Ƽ�</th>
            <th>����</th>
            <th>�ؼ�</th>
           {if $can_shangjia} <th>�ϼ�</th>{/if}
        </tr>
        {foreach from=$data item='list'}
        	<tr>
            <td align="center"><input class="ajax_butch" type="checkbox"  checked="checked" name="delete_ids[]" value="{$list.goods_id}"/></td>
            	<td>
                <input  type="text"  name="temp_all[{$list.goods_id}][goods_name]" value="{$list.goods_name}" style="width:100px;"  maxlength="200"/>
                </td>
                <td>
                <select  style="width:100px;" name="temp_all[{$list.goods_id}][brands]">
					<option value="">{$lang.php_select}</option>
                    {foreach from=$brands item='brand'}
                    	<option value="{$brand.brand_id}" {if $list.goods_brands_id eq $brand.brand_id} selected="selected"{/if}>{$brand.brand_name}</option>
                    {/foreach}
                </select>
                </td>
                <td>
      	  <select style="width:100px;" name="temp_all[{$list.goods_id}][category]">
					<option value="">{$lang.php_select}</option>
                    {foreach from=$categorys item='cate'}
                    	<option value="{$cate.cate_id}" {if $list.goods_category_id eq $cate.cate_id} selected="selected"{/if}>{$cate.spacer}{$cate.cate_name}</option>
                    {/foreach}
                </select>
                </td>
                <td align="center">
                {get_locate assign='region'}
            	<select  name="temp_all[{$list.goods_id}][region_id]"  style="width:120px;">
                <option>{$lang.php_select}</option>
                    {foreach from=$region item='region_list'}
                    {foreach from=$region_list.son_temp item='son'}
<option value="{$son.region_id}" {if $son.region_id eq $list.region_id} selected="selected"{/if}>{$son.p}->{$region_list.region_main_name}=>{$son.alias_name}</option>
                    {/foreach}
                {/foreach}
                </select>
                </td>
                <td align="center"><input type="text"  style="width:30px;" value="{$list.goods_weight|default:'0'}" name="temp_all[{$list.goods_id}][goods_weight]" /></td>
                <td align="center"><input type="text" style="width:20px;" name="temp_all[{$list.goods_id}][goods_visted]" value="{$list.goods_visted}" /></td>
                <td align="center">
                <input  type="text" value="{$list.goods_points}" name="temp_all[{$list.goods_id}][goods_points]"  style="width:20px;"/>
                </td>
                <td>
                	<input type="text" name="temp_all[{$list.goods_id}][stock]" style="width:20px;" value="{$list.goods_stock}" />
                </td>
                <td>
                <select  name="temp_all[{$list.goods_id}][goods_is_new]">
                <option value="1" {if $list.goods_is_new eq '1'} selected{/if}>{$lang.yes}</option>
                <option value="0" {if $list.goods_is_new eq '0'} selected{/if} >{$lang.no}</option>
                </select>
                </td>
                <td>
              <select  name="temp_all[{$list.goods_id}][goods_is_competitive]">
                <option value="1" {if $list.goods_is_competitive eq '1'} selected{/if}>{$lang.yes}</option>
                <option value="0" {if $list.goods_is_competitive eq '0'} selected{/if} >{$lang.no}</option>
                </select>
                </td>
                <td>
              <select  name="temp_all[{$list.goods_id}][goods_is_recomand]">
                <option value="1" {if $list.goods_is_recomand eq '1'} selected{/if}>{$lang.yes}</option>
                <option value="0" {if $list.goods_is_recomand eq '0'} selected{/if} >{$lang.no}</option>
                </select>
                </td>
                <td>
                <select  name="temp_all[{$list.goods_id}][goods_is_hot]">
                <option value="1" {if $list.goods_is_hot eq '1'} selected{/if}>{$lang.yes}</option>
                <option value="0" {if $list.goods_is_hot eq '0'} selected{/if} >{$lang.no}</option>
                </select>
</td>
                 <td>
                   <select  name="temp_all[{$list.goods_id}][goods_is_special]">
                <option value="1" {if $list.goods_is_special eq '1'} selected{/if}>{$lang.yes}</option>
                <option value="0" {if $list.goods_is_special neq '1'} selected{/if} >{$lang.no}</option>
                </select>
                </td>
              {if $can_shangjia}   <td>
                 <select  name="temp_all[{$list.goods_id}][goods_is_sale]">
                <option value="1" {if $list.goods_is_sale eq '1'} selected{/if}>{$lang.yes}</option>
                <option value="0" {if $list.goods_is_sale neq '1'} selected{/if} >{$lang.no}</option>
                </select>
                {/if}
                </td>
            </tr>
            </tr>
        {/foreach}
    </table>
    <div class="clear"></div>
    <div style="padding:5px; padding-left:25px;">
  <select name="do_options" id="do_options">
   	<option value="default">�������в���</option>
    <option value="move_to_category">����ת��������</option>
    <option value="move_to_chandi">����ת��������</option>
    <option value="move_to_brand">����ת����Ʒ��</option>
    <option value="move_to_region">����ת��������</option>
    <option value="move_to_special_tag">����ת�����������</option>
    <option value="butch_to_new">��Ϊ��Ʒ</option>
    <option value="butch_un_new">ȡ����Ʒ</option>
    <option value="butch_to_hot">��Ϊ����</option>
    <option value="butch_un_hot">ȡ������</option>
    <option value="butch_to_com">��Ϊ��Ʒ</option>
    <option value="butch_un_com">ȡ����Ʒ</option>
    <option value="butch_to_recomend">��Ϊ�Ƽ�</option>
    <option value="butch_un_recomend">ȡ���Ƽ�</option>
    <option value="butch_to_special">��Ϊ�ؼ�</option>
    <option value="butch_un_special">ȡ���ؼ�</option>
    {if $can_shangjia}
    <option value="butch_to_sale">�����ϼ�</option>
    <option value="butch_un_sale">�����¼�</option>
    {/if}
   </select>
   <!--����-->
		<span id="move_to_category" style="display:none;" class="need_show_all">
		=> <select name="to_categorys" id="show_remove_datas" style="width:200px;">
        <option value="">{$lang.php_select}</option>
        {foreach from=$categorys item='cate'}
            <option value="{$cate.cate_id}">{$cate.spacer}{$cate.cate_name}</option>
        {/foreach}
    </select>
    </span>
    <!--Ʒ��-->
	<span id="move_to_brand" style="display:none;" class="need_show_all">
		=> <select name="to_brand" id="show_remove_datas_brand" style="width:200px;">
        <option value="">{$lang.php_select}</option>
        {foreach from=$brands item='brand'}
            <option value="{$brand.brand_id}">{if $brand.pin}{$brand.pin}=>{/if}{$brand.brand_name}</option>
        {/foreach}
    </select>
    </span>
<!--����-->
		<span id="move_to_chandi" style="display:none;" class="need_show_all">
		=>      {get_chandi assign='chandi'}
            	<select name="goods_chandi_id" style="width:200px;" class="form_option" id="show_remove_datas_chandi">
                <option>{$lang.php_select}</option>
                    {foreach from=$chandi item='list'}
                    <option value="{$list.region_id}">{if $list.p}{$list.p}=>{/if}{$list.region_ename}</option>
                    {if $list.childrens}
                    {foreach from=$list.childrens item='son'}
<option value="{$son.region_id}" {if $son.region_id eq $goods_data.goods_chandi_id} selected="selected"{/if}>&nbsp;&nbsp;|-{$son.region_ename}</option>
               		{if $son.childrens}
                    {foreach from=$son.childrens item='sons'}
                    <option value="{$sons.region_id}" {if $sons.region_id eq $goods_data.goods_chandi_id} selected="selected"{/if}>&nbsp;&nbsp;&nbsp;|--{$sons.region_ename}</option>
                    {/foreach}
                   {/if}
                    {/foreach}
                    {/if}
                {/foreach}
                </select>
    </span>
    <!--����-->
		<span id="move_to_region" style="display:none;" class="need_show_all">
		=> <select name="region_id" style="width:200px;" id="show_remove_datas_region">
                <option>{$lang.php_select}</option>
                    {foreach from=$region item='list'}
                    {foreach from=$list.son_temp item='son'}
<option value="{$son.region_id}" {if $son.region_id eq $goods_data.region_id} selected="selected"{/if}>{if $son.p}{$son.p}=>{/if}{$list.region_main_name}=>{$son.alias_name}</option>
                    {/foreach}
                {/foreach}
                </select>
    </span>

    <!--�������-->
		<span id="move_to_special_tag" style="display:none;" class="need_show_all">
		=>{get_specail_goods_tag assign='special_data'}<select name="special_goods_tags" style="width:200px;" id="show_remove_datas_speicla_tag">
                	<option value="">{$lang.php_select}</option>
                    {foreach from=$special_data item='list'}
                    	<option value="{$list.id}">{$list.name}</option>
                    {/foreach}
                </select>
    </span>

                
                
    <input  type="submit" value="{$lang.php_save}" class="form_submit" />
</div>
     </div>
    </form>
<script type="text/javascript">
var php_do_ok = '{$lang.php_do_ok}';
var select_move_to_category = "��ѡ��Ҫת�Ƶ�Ŀ��!";
var php_empty_select_goods = "��ѡ��Ҫ��������Ʒ!";
	$(function(){
		checkAllFormData('ajax_butch','ajax_butch');
			var opt_dom = $("#do_options");
			$(opt_dom).change(function(){
				var s = $(".need_show_all");
				 $(".need_show_all").hide();
				 $(s).hide();
				 switch($(this).val()){
					case 'move_to_category':
						$("#move_to_category").show();
					break;
					case 'move_to_chandi':
						$("#move_to_chandi").show();
					break;
					case 'move_to_brand':
						$("#move_to_brand").show();
					break;
					case 'move_to_region':
						$("#move_to_region").show();					
					break;
					case 'move_to_special_tag':
						$("#move_to_special_tag").show();
					case 'default':
						$(d).hide();
					break;
				 }
			});
	
		$("#ajax_butch_all").submit(function(){
			 switch($(opt_dom).val()){
				case 'move_to_category':
					if(empty(get_checkbox_val('ajax_butch')))return window.parent.showNotice(php_empty_select_goods);
					var a = $("#show_remove_datas").val();
					if(empty(a))return window.parent.showNotice(select_move_to_category);
				break;
				case 'move_to_chandi':
					if(empty(get_checkbox_val('ajax_butch')))return window.parent.showNotice(php_empty_select_goods);
					var a = $("#show_remove_datas_chandi").val();
					if(empty(a))return window.parent.showNotice(select_move_to_category);
				break;
				case 'move_to_brand':
					if(empty(get_checkbox_val('ajax_butch')))return window.parent.showNotice(php_empty_select_goods);
					var a = $("#show_remove_datas_brand").val();
					if(empty(a))return window.parent.showNotice(select_move_to_category);
				break;
				case 'move_to_region':
					if(empty(get_checkbox_val('ajax_butch')))return window.parent.showNotice(php_empty_select_goods);
					var a = $("#show_remove_datas_region").val();
					if(empty(a))return window.parent.showNotice(select_move_to_category);
				break;
				/*
				case 'move_to_special_tag':
					if(empty(get_checkbox_val('ajax_butch')))return window.parent.showNotice(php_empty_select_goods);
					var a = $("#show_remove_datas_speicla_tag").val();
					if(empty(a))return window.parent.showNotice(select_move_to_category);
				break;
				*/
			 }
			 opt_dom=d=a=null;
			 $(this).ajaxSubmit(function(data){
				 switch(data){
				 	case 'ERROR':
						alert('ERROR');
					break;
					case 'EMPTY':return window.parent.showNotice(php_empty_select_goods);break;
					case 'EMPTY_MOVE_CATE':return window.parent.showNotice(select_move_to_category);
					break;
					case 'OK':
						window.parent.showNotice(php_do_ok);
						if($.browser.msie || $.browser.mozilla){
							window.parent.top.close();
							window.returnValue='refresh';
						}else{
							close_window();
							window.parent.frames["rightFrame"].location.reload();
						}
						
					break;
					default:alert(data);
				 }
			});
			 return false;
		});
	});
</script>
    {else}
    <div class="notice_msg">{$lang.php_nodata}</div>
    {/if}
{if !$is_ajax}	{include file="footer_common.php"}{/if}
{/if}