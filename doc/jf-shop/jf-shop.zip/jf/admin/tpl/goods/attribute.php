<?php if(!defined('PHP_TEMPLATE'))exit('php'); ?>
{if $action eq 'attr_list'}<!--��Ʒ�����б�-->
{include file="frame_header.php"}
<script type="text/javascript">
	$(function(){ checkAllFormData('select_attr','type_attr_val'); });
	function show_type_list(obj){ window.location.href = 'index.php?m=goods/attribute&a=listAttr&id='+$(obj).val(); }
	function doAction(url,title){ window.parent.showWindow(title,url,750,380); }
	function butch_goods_attr(obj){
		var val = get_checkbox_val('type_attr_val');
		if(!val){window.parent.showNotice('��ѡ��Ҫ����������!');return false;}
		window.parent.showWindow('�����༭��Ʒ����','index.php?m=goods/attribute&a=butch&ids='+val,800,400);
	}
</script>
<div id="php_top_bar">
<div class="tb">���Է��� </div>
<div class="tb">
<select name="type_list" id="type_list_info" class="w150" onchange="show_type_list(this);">
	<option value="0">�鿴����</option>
	{foreach from = $type_list item=type}
	<option value="{$type.type_id}" {if $type.type_id eq $get_data.id} selected="selected"{/if}>{$type.type_name}({$type.attr_total|default:'0'})</option>
    {/foreach}
</select>
</div>
<div class="tb"><a href="javascript:;"  onclick="doAction('index.php?m=goods/attribute&a=addAttr',$(this).html());" class="block_button form_btn">��������</a></div>
<div class="tb"><a href="javascript:;" onclick="butch_goods_attr(this);" class="block_button form_btn">��������</a></div>
<a href="javascript:;" onclick="window.location.reload();" class="form_btn block_button">ˢ��</a>
</div>

<div id="php_right_main_content">
{if $data.total>0}
	<table class="table_list table_list_hover">
        	<thead>
          	  <tr>
            	<th><input type="checkbox" id="select_attr" /></th>
                <th nowrap="nowrap">��</th>
                <th>����</th>
                <th>����</th>
                <th>��̨¼�뷽ʽ</th>
                <th>��ѡֵ</th>
                <th>������</th>
                     </tr>
            </thead>
        	<tbody>
            {foreach from=$data.data item=attr}
            	<tr>
	  <td  align="center" width="20"><input type="checkbox" value="{$attr.attr_id}"   class="type_attr_val" /></td>
<td align="center"  width="25"><a href="javascript:;"  onclick="doAction('index.php?m=goods/attribute&a=editAttr&id={$attr.attr_id}','{$lang.attr.edit_attr}');">��</a></td>
      <td class="attr_name" item="{$attr.attr_id}_{$attr.type_id}"><span>{$attr.attr_name}</span></td>
                    <td align="center" class="attr_type_name">{$attr.type_name}</td>
                    <td align="center">
                    	{if $attr.input_mode eq 'input'}{$lang.attr.input_attr_entry}{elseif $attr.input_mode eq 'select'}<!--����ѡ��-->{$lang.attr.select_choose}{else}<!--�����ı���-->{$lang.attr.attr_choose_textarea}{/if}
                    </td>
                    <td {if $attr.attr_value} style="max-width:350px;_width:350px;*width:350px;"{/if}>
                    	{if $attr.attr_value}
                        	{$attr.attr_value|escape:"html"}
                        {/if}
                    </td>
                    <td align="center">{if $attr.bind_in_param eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
                    	
                </tr>
             {/foreach}
            </tbody>
    </table>
	<div class="clear"></div>
    {$data.page}
    {else}
    <div class="notice_msg">{$lang.php_nodata}</div>
    {/if}
    </div>
    {include file="frame_footer.php"}
{/if}
<!--�������Կ�ʼ-->
{if $action eq 'add_attr' || $action eq 'edit_attr'}
<script type="text/javascript">
$(function(){
	//����������ʾ
	$("#attr_do_action").ajaxForm({
		success:function(data){
			var call = data.split('|');
			var msg = call[1];
			switch($.trim(call[0])){
				case '1':
					window.parent.showNotice(msg);
				break;
				case '2':<!--ִ�гɹ�ҳ�浯���ر�-->
					window.parent.showNotice(msg);
					var id = $("#attr_hidden_id").val();
					var o ='index.php?m=goods/attribute&a=listAttr&id='+id;
					$("#right_frame").attr({"src":'index.php?m=goods/attribute&a=listAttr&id='+id});
					window.parent.hidenLayer();
					return ;
				break;
				case '3':<!--ִ�гɹ���������-->
					showNotice(msg);
					$("#attr_name").val('');
					$("#text_val").val('');
					$("#text_val").text('');
					$("#rignt_frame").attr({"src":'index.php?m=goods/attribute&a=listAttr'});
					return ;
				break;
				default:alert(data);return false;
			}
		}
	 })
	$("input[name='input_mod']").each(function(){
		var t = $(this).val();
		var checked  =  $(this).attr('checked');
		if(t =='select' && checked)$("#text_val").attr("disabled",false);
		$(this).click(function(){
			switch(t){
				case 'input':
				case 'text':
					$("#text_val").attr("disabled",true);
				break;
				case 'select':
				$("#text_val").attr("disabled",false);
				break;
			}
		})
	});
});
</script>
<p style="display:none;"><input type="button" value="{$lang.attr.return_attr_list}" onclick="view_attr_list(this);" class="form_submit"/></p>
<div>
<form method="post"  autocomplete="off"  action="{if $action eq 'add_attr'}index.php?m=goods/attribute&a=addAttr{else}index.php?m=goods/attribute&a=editAttr{/if}" id="attr_do_action">
	<table class="table_common">
    	<tr>
        	<td class="one" width="150">{$lang.attr.attr_name}:</td>
            <td><input type="text " value="{$attr.attr_name}" name="attr_name" id="attr_name" class="bg_input"  style="width:200px;"> <span class="blue">*</span></td>
        </tr>
        <tr>
        	<td class="one">{$lang.attr.attr_list_owner}:</td>
            <td>
            <select name="attr_types" style="width:200px;">
            	<option value="0"><!--��ѡ��-->{$lang.php_please_select}</option>
                {foreach from = $type_data item=type}
    <option value="{$type.type_id}" {if $attr.type_id eq $type.type_id}selected="selected"{/if}>{$type.type_name}</option>
                {/foreach}
            </select> <span class="blue">*</span>
            </td>
        </tr>
        <tr style="display:none;">
        	<td class="one">{$lang.attr.public_display_type}:</td>
            <td>
            <select name="display_mode" style="width:200px;">
            <option value="flat" selected="selected">{$lang.attr.attr_flat}</option>	
            <option value="select" {if $attr.display_mode eq 'select'} selected="selected"{/if}>{$lang.attr.attr_select}</option>	
            </select></td>
        </tr>
        <tr>
        	<td class="one"><!--�󶨵���Ʒ������-->{$lang.attr.bind_to_prames}:</td>
            <td title="{$lang.attr.bind_to_parems_help}" class="input_notice"> 
            	<input type="checkbox" value="1" {if $attr.bind_in_param eq '1'} checked="checked"{/if} name="bind_in_param"  /> 
            </td>
        </tr>
        <tr>
        	<td class="one"><!--������ֵ��¼�뷽ʽ-->{$lang.attr.attr_val_type_input}:</td>
            <td>
            	<input type="radio" value="input"  name="input_mod" {if $attr.input_mode neq  'select'} checked="checked" {/if}/><!--�ֹ�¼��-->{$lang.attr.input_attr_entry}
            	<input name="input_mod" type="radio" value="select" {if $attr.input_mode eq 'select'} checked="checked"{/if} /><!--��������б���ѡ��һ�д���һ����ѡֵ��-->{$lang.attr.choose_attr_input}  
            	<input type="radio" value="text" {if $attr.input_mode eq 'text'} checked="checked"{/if} name="input_mod"/>{$lang.attr.text_area}
            </td>
        </tr>
        <tr>
        <td class="one">
        {$lang.attr.can_select_list}:
        </td>
        <td>
        	<textarea style="width:400px; height:150px; padding:3px;" id="text_val"  disabled="disabled" name="attr_values" >{$attr.attr_value}</textarea>{$lang.attr.one_line_one}
        </td>
        </tr>
    </table>
    {if $action eq 'edit_attr'}
    	<input type="hidden" value="{$attr.attr_id}"   name="attr_id" />
        <input type="hidden" value="{$attr.type_id}"  id="attr_hidden_id" />
    {/if}
    <div align="center" style="padding:5px; text-align:center"><input type="submit" value="{$lang.php_save}" class="form_submit"/></div>
    </form>
</div>
{/if}

{if $action eq 'butch_goods_attr_data'}
<script type="text/javascript">
	$(function(){
		checkAllFormData('butch_select','butch_select_val');
		if($('.table_list_hover')){
			table_color('table_list_hover');fix_table_select('table_list_hover');
		}
		$("#butch_goods_pannel").submit(function(){
			$(this).ajaxSubmit(function(call){
				call = call.split('|');
				switch(call[0]){
					case 'OK':
						window.parent.showNotice('�����ɹ�!');
						_reload_frame();
						_close_window_one();
					break;
					case 'HAS_EXIST':
						window.parent.showNotice('������ͬ��������! '+call[1]);
						return false;
					break;
					case 'EMPTY':
						window.parent.showNotice('����дҪ����������!');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
	function do_submit_form(val){
		$("#butch_form_action").val(val);
		if(val=='delete' && !confirm('ȷ��ɾ����?�˲������ɻָ�!')){
			return false;	
		}
		if(val!='delete' && !check_form_is_empty('butch_must_fill_val')){
			window.parent.showNotice('����д������!');return false;
		}
		$("#butch_goods_pannel").submit();
	}
</script>
<form method="post" action="index.php?m=goods/attribute&a=butch" id="butch_goods_pannel">
<input type="hidden" value=""  name="do_action" id="butch_form_action"/>
<!--table_list_hover-->
<table class="table_list">
	<tr>
    	<!--<th><input type="checkbox" value=""  id="butch_select"/></th>-->
		<th>����</th>
        <th>����</th>
        <th>������</th>
    </tr>
    {foreach from=$data item='list'}
    	<tr>
        	<!--<td width="40" align="center"><input type="checkbox" value="butch[{$list.attr_id}][ids]" class="butch_select_val" checked="checked" /></td>-->
            <td align="center"><input type="text"  value="{$list.attr_name}" name="butch[{$list.attr_id}][name]" class="w200 butch_must_fill_val" /> <samp class="blue"> * </samp></td>
            <td align="center">
            	<select name="butch[{$list.attr_id}][type_id]" class="w200">
                  {foreach from=$type_list item='type'}
                	<option value="{$type.type_id}"  {if $type.type_id eq $list.type_id} selected="selected"{/if}>{$type.type_name}</option>
                  {/foreach}
                </select>
            </td>
            <td align="center">
            	<input type="checkbox" value="1"  name="butch[{$list.attr_id}][bind_in_param]" {if $list.bind_in_param eq '1'} checked="checked"{/if} />
            </td>
        </tr>
    {/foreach}
    <tr>
    	<td colspan="5" align="center">
	       {if $can_delete} <a href="javascript:;" onclick="do_submit_form('delete');" class="block_button form_btn">ɾ��</a>{/if}
        {if $can_edit}	<a href="javascript:;" onclick="do_submit_form('save');" class="block_button form_btn">�� ��</a>{/if}
        </td>
    </tr>
</table>
</form>
{/if}