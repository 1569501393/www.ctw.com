<?php exit('die'); ?>
{if $action eq 'special_goods_list'}
<div id="special_goods_tag">
<div style="padding:4px; height: auto;">
	<a onclick="do_tags(this);" rel="index.php?m=goods&a=specialgoods&tag=add" class="block_button form_btn">����</a>
<div class="clear"></div>
</div>
<div class="clear"></div>
<script  type="text/javascript">
	function do_tags(obj){
		var url = $(obj).attr('rel');
		$.get(url,function(data){
			$("#call_tags_back").show().html(data);
		});
	}
	var class_tags = $("#special_goods_tag").parent().attr('class').split(' ');
	var etags = '.'+class_tags[1];
</script>
<div id="call_tags_back">
	
</div>
<div class="clear"></div>
{if $data}
<script  type="text/javascript">
	function delete_tag(obj){
		if(!confirm('ȷ��ɾ����?�˲������ɻָ�!'))return false;
		var u = $(obj).attr('rel');
		var id = $(obj).attr('tag_id');
			$.get(u,function(data){
			 switch(data){
				case 'OK':
				$(".asd"+id).remove();
				if($(".tt_tafgs").size()<=0){
					$("#ttt_call_tag").empty();	
				}
				break;
				default:
					alert(data);
			 }
		});
	}
	$(function(){
		page_function('etag_page',class_tags[1],'.');
	});
</script>
<div id="ttt_call_tag">
<table class="table_list">
	<tr>
    	<th>���</th>
        <th>����</th>
        <th>Ӣ��</th>
        <th>�������</th>
        <th>���</th>
        <th>����</th>
    </tr>
    {foreach from=$data.data item='list'}
    	<tr class="tt_tafgs asd{$list.id}">
        <td align="center" width="30">{$list.id}</td>
        <td align="center">{$list.name}<span class="blue">({$list.total|default:'0'})</span></td>
        <td align="center">{$list.en_name}</td>
        <td align="center">{$list.extend.extend_price|default:'0'}</td>
        <td align="center">{$list.extend.delivery_data.delivery_name}</td>
        <td align="center"><a href="javascript:;" onclick="delete_tag(this);" tag_id="{$list.id}" rel="index.php?m=goods&a=specialgoods&tag=delete&id={$list.id}">ɾ</a> <a href="javascript:;"  onclick="do_tags(this);" rel="index.php?m=goods&a=specialgoods&tag=edit&id={$list.id}">��</a></td>
        </tr>
    {/foreach}
</table>
<div id="etag_page">{$data.page}</div>
	{else}
    <div class="notice_msg">�޿�������!</div>
{/if}
</div>	
{/if}
{if $action eq 'add' || $action eq 'edit'}
<form method="post" action="index.php?m=goods&a=specialgoods" autocomplete="off" id="do_tags_post_form">
<input type="hidden" value="{$action}"  name="action"/>
	<table class="table_common">
    	<tr>
        	<td class="one">����</td>
            <td><input type="text" value="{$data.name}" name="name" id="sssss_tags" maxlength="20" class="form_input must_fill_tag_input" /></td>
        </tr>
    	<tr>
        	<td class="one">ƴ��</td>
            <td><input type="text" value="{$data.en_name}" name="enmame"   maxlength="50" class="form_input" />
            <input type="button" value="��ȡƴ��" onclick="window.parent.get_pinyin($('#sssss_tags').val(),$(this).prev());" class="form_submit" />
            </td>
        </tr>
    	<tr>
        	<td class="one">���Ᵽ�۷�</td>
            <td><input type="text" value="{$data.extend.extend_price|default:'0'}" onkeyup="value=value.replace(/[^\d]/g,'')" onbeforepaste="clipboarddata.setdata('text',clipboarddata.getdata('text').replace(/[^\d]/g,''));" name="extend[extend_price]" class="form_input" />
            <span class="blue">����д����д����ʱ��ǿ�����Ӵ˷���</span>
            </td>
        </tr>
    	<tr>
        	<td class="one" nowrap="nowrap">��Ӧ����ϵͳ</td>
            <td>
            	<select name="extend[wuliu_system]" style="width:135px;" class="must_fill_tag_input">
                	<option value="">��ѡ��</option>
                    {foreach from=$delivery item='list'}
                    	<option value="{$list.id}" {if $list.id eq $data.extend.wuliu_system} selected="selected"{/if}>{$list.delivery_name}</option>
                    {/foreach}
                </select>
                <span class="blue">����ѡ���û�����Ʒʱ���ͷ�ʽ��ǿ��ʹ�ö�Ӧѡ������ͷ�ʽ</span>
            </td>
        </tr>
    	<tr>
        	<td colspan="4">
            <input type="submit" value="����" class="form_submit"  style="display:none;"/>
            <a href="javascript:;" class="form_btn block_button" onclick="submit_form('do_tags_post_form');">����</a>
             <a href="javascript:;" onclick="$('#call_tags_back').slideUp(function(){ $(this).empty();});" class="block_button">�ر�</a></td>
        </tr>
    </table>
</form>
<script type="text/javascript">
	$(function(){
		$("#do_tags_post_form").submit(function(){
			if(!check_form_is_empty('must_fill_tag_input'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						window.parent.showNotice(php_do_ok);
						var edata =  getData('index.php?m=goods&a=specialgoods');
						$(etags).html(edata);
					break;
					case 'EMPTY':
						window.parent.showNotice('����д������!');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
</form>
{/if}