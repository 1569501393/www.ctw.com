<?php exit('die'); ?>
{if $action eq 'spec_list'}
{include file="frame_header.php"}
<div id="php_top_bar"> {if $can_delete &&  $speclist.total>0}
  <div class="tb"><a href="javascript:;" onclick="delete_spec();" class="block_button form_btn">{$lang.spec.delete_select}</a></div>
  {/if}
  {if $can_add}
  <div class="tb"><a href="javascript:;"  onclick="window.parent.showWindow('���ӹ��','index.php?m=goods/specification&a=addSpec',650,250);" class="block_button form_btn">{$lang.spec.add_spec}</a></div>
  {/if} </div>
<script type="text/javascript">
	function delete_spec(){
		var v = get_checkbox_val('spec_all_sleect_val');
		if(empty(v)){
			window.parent.showNotice('��ѡ��Ҫ����������');
			return false;
		}
		if(!confirm('ȷ��ɾ����?�˲������ɻָ�!'))return false;
		$.post('index.php?m=goods/specification&a=deleteSpec',{ids:v},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					window.location.reload();
				break;
				case 'EMPTY':
					window.parent.showNotice('��ѡ��Ҫ����������!');
				break;
				default:
				alert(data);
			}
		});		
	}
$(function(){
	checkAllFormData('seletc_spec','spce_v');
});
function edit_goods_spec_data(id){
	window.parent.showWindow('�༭���','index.php?m=goods/specification&a=editSpec&id='+id,650,250);	
}
</script>
<div id="php_right_main_content"> {if $speclist.total>0}
  <form method="post" action="" id="spec_list" name="form_names_select">
    <table class="table_list {if $can_delete}table_list_hover{else}table_list_common{/if}">
      <thead>
        <tr> {if $can_delete}
          <th width="30"><input type="checkbox"  class="select_spec_value" id="seletc_spec" value=""/></th>
          {/if}
          {if $can_edit}
          <th width="30" align="center">����</th>
          {/if}
          <th >����</th>
          <th>��ʾ��ʽ</th>

          <th>������Ʒ����</th>
        </tr>
      </thead>
      <tbody>
      
      {foreach from=$speclist.data item=spec}
      <tr> {if $can_delete}
        <td class="center"><input type="checkbox" name="spce_id[]" value="{$spec.spec_id}" class="spce_v spec_all_sleect_val" /></td>
        {/if}
        {if $can_edit}
        <td class="center" nowrap="nowrap"><a href="javascript:;"  onclick="edit_goods_spec_data('{$spec.spec_id}');" >�༭</a></td>
        {/if}
        <td class="center">{$spec.spec_name}{if $spec.spec_remark}��{$spec.spec_remark}��{/if}</td>
        <td align="center"> {if $spec.spec_display eq 'select'}
          ����
          {elseif $spec.spec_display eq 'radio'}
          ѡ��
          {else}
          ƽ��
          {/if} </td>
 
        <td> {foreach from=$spec.spec_value_info name=n item=v}
          &nbsp;<a href="{$v.url}" target="_blank">{$v.goods_spec_extend_name}</a> {/foreach} </td>
      </tr>
      {/foreach}
      </tbody>
      
    </table>
  </form>
  {$speclist.page}
  {else}
  <div class="notice_msg">{$lang.php_nodata}.</div>
  {/if} </div>
<!--#/php_right_main_content-->
{include file="frame_footer.php"}
{/if}
<!--����spec_list���ݴ���-->

{if $action eq 'add_spec' || $action eq 'edit_spec'}
	<form method="post" action="index.php?m=goods/specification&a={$do_action}" id="do_submit_form_action_spec">
    <input type="hidden" value="{$data.spec_id}" name="spec_id" />
    	<table class="table_common">
        	<tr>
            	<td class="one">�������</td>
                <td><input type="text" value="{$data.spec_name}" name="spec_name" id="need_replace_val" class="w250 must_fill_in_data" /><samp class="red">*</samp></td>
            </tr>
        	<tr>
            	<td class="one">��ʾ��ʽ</td>
                <td>
                	<select name="spec_display" class="w250">
                    	<option value="flat" {if $data.spec_typespec_display neq 'select' && $data.display_type neq 'radio'} selected="selected"{/if}>ƽ��</option>
                    	<option value="select"  {if $data.spec_display eq 'select'} selected="selected"{/if}>����</option>
                    	<option value="radio"  {if $data.spec_display eq 'radio'} selected="selected"{/if}>��ѡ</option>
                    </select>
                </td>
            </tr>
        	<tr style="display:none">
            	<td class="one">�Ƿ�������</td>
                <td>
                	<select name="spec_index" class="w250">
                    	<option value="0"  {if $data.spec_index neq '1'} selected="selected"{/if}>��</option>
                    	<option value="1" {if $data.spec_index eq '1'} selected="selected"{/if}>��</option>                    	
                    </select>
                </td>
            </tr>
            <tr>
            	<td class="one">��ע</td>
                <td><input type="text" value="{$data.spec_remark}" class="w250" name="spec_remark" /></td>
            </tr>
            <tr>
            	<td class="one"></td>
                <td>
                	<input type="submit" value="����" style="display:none;" />
					<a href="javascript:;" class="block_button form_btn" onclick="submit_form('do_submit_form_action_spec');">����</a>
                </td>
            </tr>
        </table>
    </form>
<script type="text/javascript">
	$(function(){
		$("#do_submit_form_action_spec").submit(function(){
			if(!check_form_is_empty('must_fill_in_data'))return false;
			$(this).ajaxSubmit(function(data){
				 switch(data){
					case 'OK':
						_reload_frame();
						{if $action neq 'add_spec'}
							window.parent.showNotice('�����ɹ�!');
							_close_window_one();
						{else}
							window.parent.showNotice('�����ɹ�!,�������Լ�������!');
							$(".must_fill_in_data").val('');
						{/if}
					break;
					case 'EMPTY':
						window.parent.showNotice('����д��������!');
					break;
					case 'HAS_EXIST':
						window.parent.showNotice('������ͬ�Ĺ������!!');
						$("#need_replace_val").val('');
					break;
					default:alert(data);
				 }
			});
			return false;
		});
	});
</script>
{/if}
