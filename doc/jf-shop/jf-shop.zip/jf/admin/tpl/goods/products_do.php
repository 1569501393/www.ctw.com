{if $action eq 'add_product' || $action eq 'edit_product'}<!--������Ʒ�����Ӻͱ༭-->
{include file="frame_header.php"}
{include file="part.js.php"}
<script type="text/javascript">
var system_filed_must_fill ='{$lang.goods.must_fill_input}';<!--'ϵͳҪ��ı�����δ��д,��鿴��ɫ����!';-->
var empty_category_select = "��ѡ����Ʒ����!";
var do_confirm_check = "��ȷ����Ʒ�༶�ۺ���Ʒ��������һ��������!\n��ͬʱ����ϵͳ��ȫ��ɾ������������!";
function ajax_load_extend_data(obj){
		var vc = $(obj).val();
		if(vc==0)return remove('goods_extend_apped_area');
		var c = vc.split('|');
		var v = c[0];
		var g = c[1];
		if(v!=0){
			var url = 'index.php?m=goods/products&a=getTypeData&id='+v+'&goods_id='+g;
			$.get(url,function(data){
				remove('goods_extend_apped_area');
				var e = '<h1 class="c_bar">��չ����</h1><div class="c_content">'+data+'</div>';
				$("#goods_extend_apped_area").empty().html(e);		
			})
	  }	
}
/*����������*/

function check_products_form(){
	var result = true;
	$(".not_empty_val").each(function(){
		if(empty($(this).val())){
			$(this).addClass('empty_input_val');
			var i = $(".wintable_curent").attr('name');
			$("#"+i).hide();
			$(".wintable_curent").removeClass('wintable_curent')
			$("#g_base_item").addClass('wintable_curent');
			$("#g_base").show();
			result = false;
		}else{
			$(this).removeClass('empty_input_val');
			result = true;
		}
	});
	if(!result)_show();
	return result;
}
function _show(){window.parent.showNotice(system_filed_must_fill);}
$(function(){
/*��Ʒѯ�۴���*/
	var d = $("#is_use_xunjia_info");
	$(d).click(function(){
		var attr = $(this).attr("checked");	
		var j = $(".is_use_xunjia");attr?$(j).hide():$(j).show();
		/*���ֶһ�����*/
		var points = $("#fixed_use_goods_point_only").attr("checked");
		if(points)$(".only_use_points").hide();	
		d = j = null;
	});
/*ѯ�۽���*/
/*�۵��˵�*/
	$.table_bars($("#add_goods_products .menu li"),'g_base','table_item','cfg_all','wintable_curent');
/*������Ʒ*/
	$("#product_form").submit(function(){
		/*ѯ�۴���*/
		var xunjia = $(".check_xunjia");
		$("#is_use_xunjia_info").attr("checked")?$(xunjia).removeClass('not_empty_val'):$(xunjia).addClass('not_empty_val');
		/*���ִ���*/
		var point_check = $("#fixed_use_goods_point_only").attr("checked");
		point_check?$(xunjia).removeClass('not_empty_val'):$(xunjia).addClass('not_empty_val');
		var f = $("#goods_point_fee");
		if(point_check){
			//goods_point_fee
			var v = f.val();
			if(empty(v)){
				window.parent.showNotice('��������Ʒ�һ��Ļ���!');
				$(f).addClass('empty_input_val');	
				return false;
			}
			var fix = parseFloat(v);
			if(fix<=0 || fix==NaN){
				window.parent.showNotice('��Ʒ�һ��Ļ��ֱ������0!');
				$(f).addClass('empty_input_val');
				return false;
			}
		}
		$(f).removeClass('empty_input_val');
		/*��Ʒ������չ����*/
		var spec = $(".must_fill_in_spec_data");
		var size = spec.size();
		var sn = $("#site_goods_sn");
		spec?$(sn).removeClass('not_empty_val'):$(sn).addClass('not_empty_val');
		if(size){
			if(!check_form_is_empty('must_fill_in_spec_data')){
				window.parent.showNotice('����д������!');
				return false;
			}
		}
		var res = check_products_form();
		if(!res)return false;
		var cat = $("#ajax_call_brands_data").val();
		if(empty(cat)){
			$(".opt_select").css({"border":"2px solid #FF0000","background-color":"#FFFFD5" });	
			window.parent.showNotice(empty_category_select);
			return false;
		}else{
			$(".opt_select").css({"border":"2px solid #767676","background-color":"#FFF" });	
		}
/*�����չ�۸�������Ƿ񶼴���*/
	  var extend_price_data = $("#goods_kuadu_price input").map(function(){return $.trim($(this).val());}).get().join('');
	  var pifa_data = $("#append_buy input").map(function(){return $.trim($(this).val());}).get().join('');
	  if(!empty(extend_price_data) && !empty(pifa_data)){
			alert(do_confirm_check);
		  return false;
	  }
/*������*/
		var flag = true;
		if($("#is_promotion").attr('checked')){
			var b = $("#promotion_begain_time");
			var b_v = $(b).val();
			var e = $("#promotion_end_time");
			var e_v = $(e).val();
			var p  = $("#promotion_price").val();
			if(!flag){ _show();return false;}
			if(!empty(b_v)&& !empty(e_v)){
				if(strtotime(e_v)<strtotime(b_v)){
					/*'������ʼʱ�����С�ڽ���ʱ��!'*/
					$("#g_others_b").click();
					window.parent.showNotice(promotion_time_is_error);
					return false;
				}
			}else{
				$(e).addClass('empty_input_val');$(b).addClass('empty_input_val');flag = false;	
			}
			if(empty($("#promotion_price").val())){
				/*�����۸�Ϊ��*/
				window.parent.showNotice(promotion_price_is_empty);$("#g_others_b").click();
				return false;
			}
			b = b_v = e=e_v = p = null;
			if(!flag){ _show();return false;}
		}
	});//end 
	close_open_helper('good_helper_optration','goods_info_msg_list',true);
	//��������
	if($("#is_promotion").attr("checked")){
		$("#show_promotion_time").show();
		$(".select_date_time").attr("disabled",false);
		$(".promotion_price_all").attr("disabled",false);
	}
	function _set_loading(){$("#show_upload_file_temp").html('<img src="images/windows_loading.gif" />');}
/*��ƷͼƬ�ϴ�*/
	$("#upload_goods_detail_pic").upload({
		loading_dom:$('.show_upload_loading'),
		filename:'goods_detail_pic_upload',
		show_img_dom:$("#show_upload_file_temp"),
		post_params:{'sid':session_id,action:'goods_detail_pic_upload',create_thumb:$("#auto_create_thumb").val()},
		url:'index.php?m=goods/products&a=ajaxUpload',
		sucess:function(file,response){
			try{
				var call = response.split('|');var m = call[1];
				switch(call[0]){
					case '1':return window.parent.showNotice(m);break;
					case '2':
					var auto_create = $("#auto_create_thumb").val();
					if(auto_create=='create'){
						var thumb = '<img src="'+call[2]+"?rands="+Math.random()+'"  width="140" height="105"/>';
						$("#goods_thumb_small_pic_input").val(call[2]);
						$("#show_goods_thumb").html(thumb);//.show();
					}
var detail = '<a href="'+call[1]+'?rand='+Math.random()+'" target="_blank"><img src="../picture.php?s='+call[1]+"&w=270&h=220&rands="+Math.random()+'"  width="270" height="300"/></a>';
					$("#goods_detail_pic_input").val(call[1]);
					$("#show_upload_file_temp").html(detail);
					break;
					default:alert(!empty(response)?response:System_overtime);return false;
				}
			}catch(et){alert(et);}
		}//end function
	});
/*����ͼƬ�ϴ�*/

/*��Ʒ���Сͼ*/
	$("#auto_create_thumb").click(function(){$("#auto_create_thumb").val(($(this).attr("checked")?'create':'uncreate'));});
	$("#upload_goods_thumb_upload").upload({
		filename:'goods_thumb_list_pic',
		loading_dom:$('.show_upload_loading_thumb'),
		post_params:{'sid':session_id,'action':'goods_list_thumb'},
		url:'index.php?m=goods/products&a=ajaxUpload',
		sucess:function(file,response){
				try{
					var call = response.split('|');
					var m = call[1];
					switch(call[0]){
						case '1':
							alert(call[1]);return false; break;
						case '2':
							$("#goods_thumb_small_pic_input").val(call[1]);
							$("#show_goods_thumb").html('<a target="_blank" href="'+m+'?rands='+Math.random()+'"><img src="'+m+'?rands='+Math.random()+'" width="140" height="105"/></a>');
						break;
						default:alert(response);
					}
			}catch(e){alert(e);}
		}
	});	/*Сͼ����*/
});
/*end doucment ready function*/

/*���ɾ��js*/
	var delete_lang = '{$lang.php_delete}';
	function remove_album_self(obj){
		$.get('index.php?m=goods/products&a=deltealbumfile&string='+$(obj).attr('name'),function(d){
		$(obj).parent('div').remove();
	 });
	}
/*����ɾ��*/

/*��Ʒ���ͼ�ϴ�����*/
 $(function(){
	var swf_upload = $("#album_uploader").upload({
		filename:'goods_album_pic',
		loading_dom:$("#show_thumb_loading"),
		post_params:{'sid':session_id,'action':'goods_album'},
		url:'index.php?m=goods/products&a=ajaxUpload',
		sucess:function(file,response){
			try{
				window.parent.closeLoading();
				<!--ɾ�����ֲ�-->
					$('.jquery-overlay').fadeOut(function() { $(this).remove(); });
					$('embed, object, select').css({ 'visibility' : 'visible' });
					var call_back_data = response.split('|');
					var m = call_back_data[1];
					switch(call_back_data[0]){
						case '1':
							window.parent.showNotice(call[1]);
							return false;
						break;
						case '2':
					var small_album_pic = call_back_data[2];
					var big_album_water = call_back_data[3];
					var all_album_pic = '';
					var a = call_back_data[1];
					var b = call_back_data[2];
					var c = call_back_data[3];
					var d = call_back_data[4];
					var e = call_back_data[5];
					var f = call_back_data[6];
					var g = call_back_data[7];
					var aaa = new Array(a,b,c,d,f,g);
					var all_album_pic = aaa.join('|');
					var rand_string = call_back_data[4];
					$("#no_goods_thumb_pic").hide();
var content = ' <div class="js_alumb"><a href="'+big_album_water+'" target="_blank" rel="colorbox_thumb" class="al_small_img"><img src="../picture.php?s='+small_album_pic+'&w=40&h=60" /></a><span name="'+rand_string+'" onclick="remove_album_self(this);" class="del_alumb"><a href="javascript:;">'+delete_lang+'</a></span><input type="hidden" value="'+all_album_pic+'" name="goods_albums[]" /><input type="text" style="display:none" name="goods_album_desc[]" value="'+call_back_data[5]+'" /></div>';
							$("#album_td").append(content);
							$("#album_pic_desc").val('');
						break;
						default:alert(!empty(response)?response:System_overtime);return false;
					}	
			}catch(e){alert(e);}
		}//end function
	});
	$("#album_pic_desc").blur(function(){
		var  set = {'sid':session_id,action:'goods_album',album_title:$(this).val()}; swf_upload.setPostParams(set);
	});
});
/*��ʼ���ϴ�ģ��*/
$(function(){
    $("#auto_create_thumb").attr("checked","checked");
	$("#upalumb").attr("checked","");
    $("#auto_create_thumb").change(function(){
	  if($(this).attr("checked")){
         $("#upalumb").attr("checked","");//�ر�����ϴ����ư�ť
		 $("#album_set").css("display","none");//�ر�����ϴ���ť
		 $("#detail_set").css("display","block");//������ͼ�ϴ�
		 $("#show_upload_file_temp").css("display","block");//������ͼ
	     $("#thumb_set").css("display","none");//�ر������ϴ�
		 $("#show_goods_thumb").css("display","none");//�ر�����ͼ
      }else{
         $("#upalumb").attr("checked","");//�ر�����ϴ����ư�ť
		 $("#album_set").css("display","none");//�ر�����ϴ���ť
		 $("#detail_set").css("display","none");//�رմ�ͼ�ϴ�
		 $("#show_upload_file_temp").css("display","none");//�رմ�ͼ
	     $("#thumb_set").css("display","block");//���������ϴ�
		 $("#show_goods_thumb").css("display","block");//��������ͼ
       }
    });
	$("#upalumb").change(function(){
	  if($(this).attr("checked")){
         $("#auto_create_thumb").attr("checked","");//�رմ�ͼ
		 $("#album_set").css("display","block");
		 $("#detail_set").css("display","none");
		 $("#thumb_set").css("display","none");
      }else{
         $("#auto_create_thumb").attr("checked","checked");
		 $("#album_set").css("display","none");
		 $("#detail_set").css("display","block");
	     $("#thumb_set").css("display","none");//���������ϴ�
       }
	});
});
/*��ʼ��ģ�����*/
{if $action eq 'edit_product'}
	var type_id = '{$goods_data.goods_types_id}';
	var edit_goods_id = '{$goods_data.goods_id}';
{/if}
    </script>
<form method="post" id="product_form" action="{if $action eq 'add_product'}index.php?m=goods/products&a=addProducts{else}index.php?m=goods/products&a=editProducts{/if}">
{if $action eq 'edit_produtc'}<input type="hidden" value="{$products_data.goods_id}" name="product_id"/>{/if}
<div id="php_top_bar" class="php_bot_bar">
<div class="top_bar_pannel">
    <input type="submit"  style="display:none" value="{$lang.php_save}"  ><!--����-->
    <!--<div class="tb"><a href="javascript:;"  class="block_button" onclick="window.parent.showWindow($(this).html(),'index.php?m=goods/products&a=tagsManage',270,450);">{$lang.goods.tags_manage}</a></div>-->
    <div class="tb"><a href="javascript:;" class="block_button" id="good_helper_optration">�򿪰���</a><!--�򿪰���--></div>
    <div class="tb"><a onclick="window.location.reload();" class="block_button">ˢ��</a></div>
    <div class="tb"><a href="javascript:;" onclick="submit_form('product_form');" class="block_button">�� ��</a></div>
    </div>
</div><!--#end php_top_bar-->

<div id="php_right_main_content">
    <div class="notice_msg" id="goods_info_msg_list" style="display:none;">
    1��GIF����������������ͼ��<b>�޶���Ч��</b>; <br />2���ϴ���Ʒ���ͼƬ���ϴ���Ʒͼʱ������4��ͼ����ԭʼͼ��5��,�ֱ�Ϊԭʼͼ,����ͼ(Сͼ)��С����(�б�ҳ����ͼ)����,ˮӡͼ(��ԭʼͼ�����ϴ�ˮӡͼ����Ʒ����ͼ�ϴ�ˮӡ,ǰ��Ϊ����ϵͳˮӡͼ����)��δ����ˮӡ���ܽ���ԭͼ��������һ�ŷ�ˮӡ�ļ�;<br/>3����������ƷΪ����ʱ,������Ʒ�۸���������,ȫ��ʹ�ô����۴���,ͬʱ������.(������)<br />
    3�����ڴ�������ѡ��������д�����ۻ���ʱ�䷶Χ��Ϊ���ϣ���������ʱ��С�ڿ�ʼʱ����Ϊ����,������,��Ʒ�༶��ͬʱ����ʹ�ô�������
    
    </div>
<div id="add_goods_products" class="table_scroll">
    <div class="menu">
    	<ul>
         	<li name="cfg_all" id="g_base_all">ȫ��</li>
            <li name="g_base" id="g_base_item" class="wintable_curent">������Ϣ</li>
            <li name="g_others" id="g_others_b">����</li>
            <li name="g_extend" id="g_extend_a">��չ����</li>
            <li name="g_specfication">��չ���</li>
            <li name="g_tags">��Ʒ��ǩ</li>
            <li name="g_cross_goods">������Ʒ</li>
            <li name="g_relative_article">��������</li>
            <li name="g_seo">���������Ż�</li>
            <li name="g_goods_pack">��װ��Ϣ</li>
            <li name="g_goods_service">�ۺ����</li>
        </ul>
    </div>
</div>
<div class="table_item_base">
<input  type="hidden" value="{$goods_data.goods_id}"  name="goods_id" />
<input type="hidden" value="{$curent_page}"  name="curent_page"/>
<div class="table_item" id="g_base">
	<h1 class="c_bar">��������</h1>
    <div class="c_content">
    {if $in_taozhuang}
    	<div class="notice_msg" id="taozhuang_temp">
        	<H2>����Ʒ���������������װ</H2>
            {foreach from=$in_taozhuang item='list'}
            	<p><a href="{$list.url}" target="_blank">{$list.goods_name}</a> <a href="index.php?m=goods/products&a=editProducts&id={$list.goods_id}">���༭��</a></p>
            {/foreach}
        </div>
    {/if}
        <table  border="0" cellspacing="0" cellpadding="0" align="center" width="100%" id="goods_main_pannel">
          <tr>
            <td  valign="top" align="left">
            <table cellpadding="0" cellspacing="0" class="table_common" width="100%" style="width:100%">
         <tr>
            <td class="one">��Ʒ����</td>
            <td >
            <input type="text" value="{$goods_data.goods_name}" name="goods_name"  class="not_empty_val w300" /><font class="blue"> * </font></td>
        </tr>
        <tr>
            <td class="one">��Ʒ����</td>
            <td><input type="text" value="{$goods_data.goods_alias_name}" name="goods_alias_name"  class="w300"/></td>
        </tr>
        <tr>
            <td class="one">��Ʒ���</td>
            <td><input type="text" id="site_goods_sn" onblur="check_goods_sn(this);" value="{if $goods_data.goods_sn}{$goods_data.goods_sn}{else}{$goods_sn}{/if}" name="goods_sn" class=" not_empty_val w300" ><font class="blue desc"> ��������Ʒ���Ӳ����ɲ�д</font><samp id="call_back_sn_check" class="red"></samp></td>
        </tr>
            <tr>
                <td class="one">��Ʒ����</td>
                <td>
    <script type="text/javascript">
	function check_goods_sn(obj){
		$.get('index.php?m=goods/products&a=check_sn',{sn:$(obj).val(),goods_id:'{$goods_data.goods_id}'},function(data){
			switch(data){
				case 'EMPTY':
					window.parent.showNotice('����д��Ʒ����!');
				break;
				case 'HAS_EXIST':
					window.parent.showNotice('������ͬ����,����������!');
					$(obj).val('');
				break;
				case 'OK':
					$("#call_back_sn_check").html('OK');
				break;
				default:alert(data);
			}
		});
	}
    /*ajax ���ط���İ�Ʒ��*/
    function ajax_load_cate_brands(obj){
     var v = $(obj).val();
     var n =  v.split('|');
     if(n[0]=='aa'){
        var old_data = $("#goods_brands_select_hidden").html();
        var check = $("#check_is_load_brands").val();
        if(check=='1')$("#goods_brands_select").html(old_data);
     }
        if(n[0]!='00')return ;
        var id = n[1];
        if(confirm(bind_brand_load_desc)){
            $.getJSON('index.php?m=goods/products&a=ajaxCallCateBrands&cate_id='+id+'&jsoncallback=?',function(json){
                    switch(json.error.toString()){
                        case '1':
                            window.parent.showNotice(json.msg);
                        break;
                        case '2':<!--��������-->
                            var jdata = json.msg;
                            var string = '';
                            $(jdata).each(function(i){
                                string += '<option value="'+jdata[i].brand_id+'">'+jdata[i].brand_name+'</option>'+"\n";
                            });
                            $("#goods_brands_select").html(string);
                            $("#check_is_load_brands").val('1');
                            window.parent.showNotice(data_loading_ok);
                        break;
                        default:alert('system error');
                    }
            })	
        }
    }
    
    /*������Ʒ*/
    function show_promotion_item(obj){
        if($(obj).attr('checked')){
            $("#show_promotion_time").show();
            $(".select_date_time").attr("disabled",false);
            $(".promotion_price_all").attr("disabled",false);
            $(".promotion_tags").addClass('empty_input_val');
            $("#promotion_goods_desc").slideDown();
        }else{
            $("#promotion_goods_desc").slideUp();
            $("#show_promotion_time").hide();	
            $(".select_date_time").attr("disabled",true);
            $(".promotion_price_all").attr("disabled",true);
            $(".promotion_tags").removeClass('empty_input_val');
        }
    }
    var call_back_obj_select = null;
    function fast_find_pos(obj){
        var url = $(obj).attr('rel');
        call_back_obj_select = $(obj).prev();
        window.parent.showWindow('���ٶ�λ',url,650,350);
    }
    function _set_value(id,cat){
        if(cat)id = 'aa|'+id;
        $(call_back_obj_select).val(id);
        return false;
    }
      </script>
                <input type="hidden" value="0"  id="check_is_load_brands" />
                {if $goods_category}
                    <select name="goods_products_category" id="ajax_call_brands_data" onChange="return ajax_load_cate_brands(this);" class="form_option not_empty_val w300 opt_select"  >
                        <option value="" style="padding:0px;"><!--��ѡ����Ʒ����-->{$lang.goods.select_goods_cate}</option>
                        {foreach from=$goods_category item=cate}
                        <option value="{if $cate.cate_brands}00|{else}aa|{/if}{$cate.cate_id}" {if $cate.cate_id eq $goods_data.goods_category_id}selected="selected"{/if} >{$cate.spacer}{$cate.cate_name}</option>
                        {/foreach}
                    </select><input type="button" value="��λ"  class="form_submit" rel="index.php?m=goods&a=ajaxCall&type=cate" onclick="fast_find_pos(this)" />
                    {else}
                    <div class="notice">{$lang.goods.not_exist_category}</div>
                  {/if}<font class="blue"> * </font>
                </td>
            </tr>
            <tr>
                <td class="one">�������</td>
                <td>
                    {get_specail_goods_tag assign='special_data'}
                    <select  name="goods_special_tags" class="w300">
                        <option value="">{$lang.php_select}</option>
                        {foreach from=$special_data item='list'}
                            <option value="{$list.id}" {if $list.id eq  $goods_data.goods_special_tags} selected="selected"{/if}>{$list.name}</option>
                        {/foreach}
                    </select>
                </td>
            </tr>
            <tr>
                <td class="one">{$lang.goods.c_goods_brands}<!--��ƷƷ��--></td>
                <td>
                <select  style="display:none" id="goods_brands_select_hidden" class="w300" >
                        <option value="0"><!--��Ʒ��-->{$lang.goods.not_exist_brands}</option>
                       {foreach from=$goods_brands item=brand}
                        <option {if $brand.brand_id eq $goods_data.goods_brands_id} selected="selected"{/if} value="{$brand.brand_id}">{$brand.brand_name}</option>
                        {/foreach}
                    </select>
                    <select name="goods_products_brands" class="form_option w300"  id="goods_brands_select">
                        <option value="0"><!--��Ʒ��-->{$lang.goods.not_exist_brands}</option>
                       {foreach from=$goods_brands item=brand}
                        <option {if $brand.brand_id eq $goods_data.goods_brands_id} selected="selected"{/if} value="{$brand.brand_id}">{if $brand.pin}{$brand.pin}=>{/if}{$brand.brand_name}</option>{/foreach}</select><input type="button" value="��λ"  class="form_submit" rel="index.php?m=goods&a=ajaxCall&type=brand" onclick="fast_find_pos(this)" />
                </td>
            </tr>
            <tr>
                <td class="one">����</td>
                <td>
                    {get_locate assign='region'}
                    <select name="region_id"  class="form_option w300">
                    <option>{$lang.php_select}</option>
                        {foreach from=$region item='list'}
                        {foreach from=$list.son_temp item='son'}
    <option value="{$son.region_id}" {if $son.region_id eq $goods_data.region_id} selected="selected"{/if}>{if $son.p}{$son.p}=>{/if}{$list.region_main_name}=>{$son.alias_name}</option>
                        {/foreach}
                    {/foreach}
                    </select><input type="button" value="��λ"  class="form_submit" rel="index.php?m=goods&a=ajaxCall&type=region" onclick="fast_find_pos(this)" />
                </td>
            </tr>
            <tr>
                <td class="one">����</td>
                <td>
                 {get_chandi assign='chandi'}
                    <select name="goods_chandi_id"  class="form_option w300">
                    <option>{$lang.php_select}</option>
                        {foreach from=$chandi item='list'}
                        <option value="{$list.region_id}">{if $list.p}{$list.p}=>{/if}{$list.region_ename}</option>
                        {if $list.childrens}
                        {foreach from=$list.childrens item='son'}
    <option value="{$son.region_id}" {if $son.region_id eq $goods_data.goods_chandi_id} selected="selected"{/if}>&nbsp;&nbsp;|-{$son.region_ename}</option>
                        {if $son.childrens}
                        {foreach from=$son.childrens item='sons'}
                        <option value="{$sons.region_id}" {if $sons.region_id eq $goods_data.goods_chandi_id} selected="selected"{/if}>&nbsp;&nbsp;&nbsp;|--{$sons.region_ename}</option>
                        {/foreach}
                       {/if}
                        {/foreach}
                        {/if}
                    {/foreach}
                    </select><input type="button" value="��λ"  class="form_submit" rel="index.php?m=goods&a=ajaxCall&type=chandi" onclick="fast_find_pos(this)" />
                </td>
            </tr>
            <tr>
                <td class="one">��Ʒ��λ</td>
                <td>
                    <select name="unit" class="w300 form_option">
                        <option value="">{$lang.php_select}</option>
                        {foreach from=$goods_unit item='list'}
                            <option  {if $goods_data.goods_unit eq $list.id}selected="selected" {/if} value="{$list.id}">{if $list.p}{$list.p}=>{/if}{$list.name}</option>
                        {/foreach}
                    </select><input type="button" value="��λ"  class="form_submit" rel="index.php?m=goods&a=ajaxCall&type=unit" onclick="fast_find_pos(this)" />
                </td>
            </tr>
            <tr>
                <td class="one">������</td>
                <td>
                    {get_goods_suppliers assign = 'supplies'}
                    <select name="supplies_id" class="w300 form_option">
                        <option value="">��ѡ��...</option>
                        {foreach from=$supplies item='list'}
            <option value="{$list.id}" {if $list.id eq $goods_data.supplier_id} selected="selected" {/if}>{if $list.pin}{$list.pin}=>{/if}{$list.name}</option>
                        {/foreach}
                    </select><input type="button" value="��λ"  class="form_submit" rel="index.php?m=goods&a=ajaxCall&type=supp" onclick="fast_find_pos(this)" /></td>
            </tr>
            <tr>
            <td class="one">ʹ��ѯ��</td>
            <td><label><input type="checkbox" value="1" {if $goods_data.is_use_xunjia eq '1'} checked="checked"{/if}  id="is_use_xunjia_info" name="is_xunjia_info" /> <font class="blue"><!--ѯ����ָ��Ʒ��Ҫ�û�ֱ�Ӻ͹���Ա��ͨ���ּ۸�!-->{$lang.goods.goods_is_xunjia_desc}</font></label></td>
            </tr>
            <tr class="is_use_xunjia only_use_points"  style="{if $goods_data.is_use_xunjia eq '1'  || $goods_data.only_use_point eq '1'}display:none{/if}">
            <td class="one">�� �� ��</td>
          <td><input type="text" value="{$goods_data.goods_market_price}" name="goods_market_price"  class="check_xunjia w300" /> <font class="blue"> * </font> </td>
        </tr>
        <tr class="is_use_xunjia only_use_points"  style="{if $goods_data.is_use_xunjia eq '1' || $goods_data.only_use_point eq '1'}display:none{/if}" >
            <td class="one">�� �� ��</td>
            <td><input type="text" value="{$goods_data.goods_shop_price}" id="goods_shop_price" name="goods_shop_price"  class="check_xunjia w300"  /> <font class="blue"> * </font></td>
        </tr>
<tr class="is_use_xunjia" {if $goods_data.is_use_xunjia eq '1'} style="display:none" {/if}>
	<td class="one">�����ֹ���</td>
    <td><input type="checkbox" value="1" onclick="fix_goods_use_points(this);" id="fixed_use_goods_point_only" {if $goods_data.only_use_point} checked="checked"{/if} name="only_use_point" /><samp class="blue">����ѡ����Ʒֻ�������ֹ���</samp></td>
</tr>
<tr class="need_hide_point_dom is_use_xunjia" {if $goods_data.is_use_xunjia eq '1'} style="display:none" {/if}>
	<td class="one">�����������</td>
    <td><input type="text" value="{$goods_data.goods_point_fee|default:'0.00'}" class="w300" name="goods_point_fee" id="goods_point_fee" />
    
<script type="text/javascript">
	function fix_goods_use_points(obj){
		var f = $(obj).attr("checked");
		if(f){
			$(".only_use_points").hide();	
		}else{
			$(".only_use_points").show();
		}
	}
</script>
</td>
</tr>
       <tr>
        <td class="one">��Ʒ����</td>
        <td class="input_notice" title="�ر�ע��:��ʼ�����������1,������Χ����������2-5��6-10��11-n ������һ������ֱ���һ��Ĵ�,������Ϊ����.�˹��ܲ��ܺͶ༶�۸�ͬʱʹ��,������д��ȫ����Ϊ����.">
    <script type="text/javascript">
    var empty_jietijia = '{$lang.goods.empty_jieti_jia_or_price}';
    var buy_num = '{$lang.goods.goods_buy_num}';
    var buy_price = '{$lang.goods.goods_buy_price}';
    var need_delete_extend_price  = "����ɾ����Ʒ��չ�۸�����!";
    function de_extend_goods(obj){$(obj).parents('.extend_item_info').remove();}	
        function add_extend_goods(obj){
            var flag = true;
            var doms = $("#goods_kuadu_price").find('input');
                for(var i = 0;i<doms.length;i++){
                    if(!empty($(doms).val())){
                        window.parent.showNotice(need_delete_extend_price);	doms = null;
                        flag = false;
                        break;
                    }					
                }
                if(!flag)return false;
                var string = '<div class="extend_item_info"><a href="javascript:void(0);"  onclick="de_extend_goods(this);">[-]</a>&nbsp;&nbsp;'+buy_num+':<input type="text" value="" style="width:50px;" class="extend_info_t" name="extend_num1[]"/>-<input type="text" style="width:50px;" value=""  class="extend_info_t" name="extend_num2[]" />'+buy_price+':<input type="text" style="width:50px;" value="" name="extend_price[]"  class="extend_info_t"/></div>';
                $("#append_buy").append(string);	
        }
    </script>
            <div id="append_buy">
            {if $goods_extend_info}
                {foreach from=$goods_extend_info name=j item=g}
                    {if $smarty.foreach.j.index eq 0}
                  <div class="extend_item_info"><a href="javascript:void(0);"  onclick="add_extend_goods(this);">[+]</a>&nbsp;&nbsp;<!--��������-->{$lang.goods.goods_buy_num}:<input type="text" value="{$g.num1}" style="width:50px;" class="extend_info_t extend_info_f" name="extend_num1[]"/>-<input  name="extend_num2[]" style="width:50px;" class="extend_info_t extend_info_e" type="text" value="{$g.num2}" /><!--�۸�-->{$lang.goods.goods_buy_price}:<input type="text"  style="width:50px;" value="{$g.price}" name="extend_price[]"  class="extend_info_t extend_info_p"/></div>
                        {else}
    <div class="extend_item_info"><a href="javascript:void(0);"  onclick="de_extend_goods(this);">[-]</a>&nbsp;&nbsp;<!--��������-->{$lang.goods.goods_buy_num}:<input type="text" value="{$g.num1}" style="width:50px;" class="extend_info_t extend_info_f" name="extend_num1[]"/>-<input type="text" style="width:50px;" value="{$g.num2}" class="extend_info_t extend_info_e" name="extend_num2[]"/><!--�۸�-->{$lang.goods.goods_buy_price}:<input type="text" style="width:50px;" value="{$g.price}" name="extend_price[]"  class="extend_info_t extend_info_p"/></div>
                    {/if}
                {/foreach}
                {else}
              <div class="extend_item_info"><a href="javascript:void(0);"  onclick="add_extend_goods(this);">[+]</a>&nbsp;&nbsp;<!--��������-->{$lang.goods.goods_buy_num}:<input type="text" value="" style="width:50px;" class="extend_info_t extend_info_f" name="extend_num1[]"/>-<input type="text"  style="width:50px;" value="" class="extend_info_t extend_info_e"  name="extend_num2[]" /><!--�۸�-->{$lang.goods.goods_buy_price}:<input type="text" style="width:50px;" value="" name="extend_price[]"  class="extend_info_t extend_info_p"/></div>
            {/if}
            </div>
    </td>
       </tr>
        <tr>
            <td class="one">�ɻ����</td>
            <td><input type="text" value="{if $goods_data.goods_points}{$goods_data.goods_points}{else}0{/if}"  class="w300" name="goods_points" /></td>
        </tr>
        <tr>
            <td class="one">��Ʒ���</td>
            <td><input type="text" value="{$goods_data.goods_stock|default:'0'}" name="goods_stock"  class="w300"/></td>
        </tr>
        </table>
        </td>
        <td width="320" valign="top">
        <table class="pro_ys" border="0" align="center" cellpadding="0" cellspacing="0">
         <tr>
           <td class="picUp">
           <span id="detail_set">
             <span id="upload_goods_detail_pic"></span>
           </span>
           <span id="thumb_set" style="display:none">
             <span id="upload_goods_thumb_upload"></span>
           </span>
           <span id="album_set" style="display:none"><input type="file" value="" id="album_uploader"/></span></td>
           <td class="picUpset"><input type="checkbox" value="create" checked="checked" id="auto_create_thumb" title="Ĭ�Ϲ�ѡ���ϴ���Ʒͼʱ�Զ���������ͼ��"/>��������ͼ<input type="checkbox" value="enupalumb" id="upalumb" title="��ѡ�ϴ����ͼ,ȡ�����ϴ�������Ʒͼ��"/>�ϴ����</td>
         </tr>
     </table>
    <div id="show_upload_file_temp" class="show_pic_fix_c" style="text-align:center; display:block;">
    {if $goods_pic_detail.detail_thumb}
        <a href="javascript:void(0);" target="_blank" onclick="this.href='{$goods_pic_detail.detail_thumb}?rand='+Math.random();"><img src="../picture.php?s={$goods_pic_detail.detail_thumb}&w=270&h=220" height="220" width="270" /></a>
        {else}
        ���ϴ���Ʒ��ͼ
    {/if}
    <!--��ƷͼƬ����-��ͼ-->    
    </div><input type="hidden" value="{$goods_pic_detail.detail_thumb}" name="goods_detail_pic" id="goods_detail_pic_input"/><input type="hidden" value="{$goods_pic_thumb}" name="goods_thumb_small_pic"  id="goods_thumb_small_pic_input"/>
    <div class="show_upload_loading"></div>
    <div id="show_goods_thumb" class="show_pic_fix_c" style="text-align:center; display:none;">
        {if $goods_pic_thumb}
        <a href="javascript:void(0);" onclick="this.href='{$goods_pic_thumb}?rand='+Math.random()" target="_blank"><img  src="{$goods_pic_thumb}"  width="140" height="105"/></a>
        {else}
        ���ϴ���ƷСͼ
        {/if}
    </div>
    <div class="show_upload_loading_thumb"></div>
    <div class="show_alumb">
      <h1>��Ʒ���</h1>
      <div id="album_td">
      {if $all_album_pic_files}
        {foreach from=$all_album_pic_files item=album}        
        <div class="js_alumb"><input type="hidden"  value="{$album.source_pic}|{$album.small_album}|{$album.album_water_pic}|{$album.rands_string}|{$album.source_water_pic}|{$album.ablum_thumb}"  name="goods_albums[]" />
 <input type="text" style="display:none" value="{$album.album_title}" name="goods_album_desc[]" /><a href="{$album.album_water_pic}" class="al_small_img" rel="colorbox_thumb" target="_blank"><img src="../picture.php?s={$album.small_album}&w=40&h=60"/></a><span class="del_alumb" name="{$album.rands_string}" onclick="remove_album_self(this);"><a href="javascript:;">{$lang.php_delete}</a></span></div>{/foreach}
        {else}
       <center class="nomsg" id="no_goods_thumb_pic">���ϴ���Ʒ�ϲ�</center>
      {/if}
      </div>
      <div id="show_thumb_loading"></div>
    </div>
        </td>
      </tr>
    </table>    
	</div>
    <h1 class="c_bar">�������</h1>
        <div class="c_content ">
            <table class="table_common">
                <tr>
                    <td class="no_border "><input name="goods_short_desc" type="text" class="input_notice" id="goods_short_desc" title="seo,xml,rss,�������õ�" value="{$goods_data.goods_short_desc}" size="50" />
                    </td>
                </tr>
            </table>
        </div>
        <h1 class="c_bar">��Ʒ����</h1>
        <div class="c_content c_no_border">
        <table class="table_common">
            <tr>
                <td class="no_border none">{$editor}</td>
            </tr>
        </table>
        </div>
</div><!--������Ϣ���� g_base -->


<!--������Ϣ��ʼ-->
<div class="table_item" id="g_others">
	<h1 class="c_bar">��������</h1>
    <div class="c_content">
	<table class="table_common">
     <tr>
    	<td class="one">��Ʒ����<!--����--></td>
        <td><input type="text" value="{$goods_data.goods_weight}" name="goods_weight" class="w300"/><span class="blue">{$lang.goods.kg}</span></td>
    </tr>
        <tr>
    	<td class="one">�ɱ���<!--�ɱ���--></td>
        <td class="input_notice" title="{$lang.goods.cost_price_for_admin}">
		<input type="text" value="{$goods_data.goods_cost_price}" name="cost_price" class="w300"  />
</td>
    </tr>
    <tr>
    	<td class="one"><!--������-->{$lang.goods.vist_numbers}</td>
        <td><input type="text" value="{$goods_data.goods_visted|default:0}"  class="w300"  name="goods_visted"/></td>
    </tr>
    <tr>
    	<td class="one"><!--������-->{$lang.goods.sales_numbers}</td>
        <td><input type="text" value="{$goods_data.sale_numbers|default:0}"  class="w300" name="sale_numbers"/></td>
    </tr>
   <tr>
   	<td class="one">{$lang.php_template_file}</td>
    <td><input type="text" value="{$goods_data.template_file}"   class="w300" name="template_file"/> </td>
   </tr>
{include file='self_name.php'}
        <tr>
        	<td class="one">{$lang.goods.add_to_recomand}<!--�����Ƽ�--></td>
 <td>
<label><input type="checkbox" value="1" name="is_new" {if $goods_data.goods_is_new eq '1'} checked="checked" {/if}/>&nbsp;{$lang.goods.goods_new_goods}<!--��Ʒ--></label>
&nbsp;<label> <input type="checkbox" value="1" {if $goods_data.goods_is_competitive eq '1'} checked="checked"{/if} name="is_competitive" />&nbsp;{$lang.goods.goods_comptive_goods}</label>
&nbsp;<label><input value="1" type="checkbox" name="is_hot" {if $goods_data.goods_is_hot eq '1'}checked="checked"{/if} />&nbsp;{$lang.goods.goods_hot_goods}</label>
&nbsp;<label><input value="1" type="checkbox" name="goods_is_recomand" {if $goods_data.goods_is_recomand eq '1'}checked="checked"{/if} />&nbsp;{$lang.goods.remomend}</label>
&nbsp;<label><input type="checkbox" value="1" {if $goods_data.goods_is_promotion eq '1'}checked="checked"{/if} id="is_promotion" onclick="show_promotion_item(this);" name="goods_is_promotion"/>&nbsp;{$lang.goods.promotion}</label>
&nbsp;<label><input type="checkbox" value="1" name="goods_is_special" {if $goods_data.goods_is_special eq '1'}checked="checked"{/if} />&nbsp;{$lang.goods.goods_is_special}</label>
 <!--
<label> <input type="checkbox" value="1" name="goods_is_chufang" {if $goods_data.goods_is_chufang eq '1'}checked="checked"{/if} />
���� </label>-->
&nbsp;<label><input type="checkbox" value="1" {if $goods_data.goods_is_sale neq '0'} checked="checked"{/if}  name="goods_is_sale"/>{$lang.goods.goods_to_sale}</label>
&nbsp;<label><input type="checkbox" value="1" {if $goods_data.taozhuang eq '1'} checked="checked"{/if}  id="goods_taozhuang" onclick="show_taozhuang_data(this);" name="taozhuang"/>�����װ</label>
&nbsp;<label><input type="checkbox" value="1" {if $goods_data.zengpin eq '1'} checked="checked"{/if} id="goods_zhengping" onclick="show_zhengpin_data(this);"  name="zengpin"/>������Ʒ</label>
<script type="text/javascript">
	var goods_id = "{$goods_data.goods_id}";
	function show_taozhuang_data(obj){
		  var tobj = $("#goods_taozhuang_extend");
		  $(obj).attr('checked')?tobj.show():tobj.hide();
	}
	function delete_extend_call_goods(obj){
		$(obj).parents('p').remove();
	}
	function search_goods_for_taozhuang(){
		$.get('index.php?m=goods/products&a=load_part_goods&task=searchgoods',{self:goods_id,name:$("#tao_name").val(),cid:$("#load_taozhuang").val(),bid:$("#taozhuang_brands").val()},function(data){
			switch(data){
				case 'NO_RESULT':
					window.parent.showNotice('�޿�������,������ؼ���!');
				break;
				default:
					$(data).appendTo($("#ajax_call_taozhuang_data"));
					$("#remove_all_taozhuang").show();
					$("#tao_name").val('');
			}
		});
	}
	function show_zhengpin_data(obj){
		var tobj = $("#goods_zhengpin_extend");
		$(obj).attr('checked')?tobj.show():tobj.hide();	
	}
	function remove_taozhuang(obj){
		$("#ajax_call_taozhuang_data").empty();
		$(obj).parent().hide();
	}
</script>
 </td>
   </tr>
<tr class="need_remove_taozhuang" id="goods_taozhuang_extend" {if $goods_data.taozhuang neq '1'} style="display:none;"{/if}>
<!-- {if $goods_data.taozhuang neq '1'} style="display:none;"{/if}-->
	<td class="one">���������Ʒ</td>
	<td>
    	<div class="search_part_goods" id="search_taozhuang_goods_all">
        <samp class="tb p40">����</samp>
        <samp class="tb" style="height:auto;">
        <!-- {if $cate.cate_id eq $goods_data.goods_category_id} selected="selected"{/if} -->
        <select id="load_taozhuang" class="form_option"  style="margin-top:5px; height:100px;" multiple="multiple">
            <option value="" style="padding:0px;">ѡ�����</option>
            {foreach from=$goods_category item=cate}
            <option value="{$cate.cate_id}">{$cate.spacer}{$cate.cate_name}</option>
            
            {/foreach}
        </select>
		</samp>
        <samp class="tb p40">Ʒ��</samp>
		<samp class="tb" style="height:auto;">
        <select id="taozhuang_brands" class="form_option" style="margin-top:5px;height:100px;" multiple="multiple">
            <option value="0">ѡ��Ʒ��</option>
           {foreach from=$goods_brands item=brand}
            <option value="{$brand.brand_id}">{$brand.brand_name}</option>
            {/foreach}
        </select>
        </samp>
        <div class="p40">
        <samp class="tb">�ؼ���</samp>
        <samp class="tb"><input type="text" value="" id="tao_name" class="need_call_taozhuang call_append_input" /></samp>
		<samp class="tb"><a href="javascript:;" class="form_btn block_button" onclick="search_goods_for_taozhuang(this);">����</a></samp>
        <samp class="tb" id="remove_all_taozhuang" style="{if !$taozhuang_data}display:none;{/if}" ><a href="javascript:;" class="form_btn block_button" onclick="remove_taozhuang(this);">ɾ��ȫ��</a></samp>
        </div>
        </div>
        
        <div class="clear"></div>
        <div id="ajax_call_taozhuang_data" class="ajax_call_goods_part">
      	  {include file="goods/goods_extend_taozhuang_part.php"}
        </div>
    </td>
</tr>
<!--#��װ����-->
<tr class="need_remove_zhenpin" id="goods_zhengpin_extend" {if $goods_data.zengpin neq '1'} style="display:none;"{/if}>
	<td class="one">��Ʒ�б�</td>
	<td>
    	<div class="search_part_goods" id="search_zhenpin_goods_all">
        <samp class="tb p40">����</samp>
        <samp class="tb" style="height:auto;">
        <select id="zhenpin_cat" class="form_option"  style="margin-top:5px; height:100px;" multiple="multiple">
            <option value="" style="padding:0px;">ѡ�����</option>
            {foreach from=$goods_category item=cate}
            <option value="{$cate.cate_id}">{$cate.spacer}{$cate.cate_name}</option>
            
            {/foreach}
        </select>
		</samp>
        <samp class="tb p40">Ʒ��</samp>
		<samp class="tb" style="height:auto;">
        <select id="zhenpin_brands" class="form_option" style="margin-top:5px;height:100px;" multiple="multiple">
            <option value="0">ѡ��Ʒ��</option>
           {foreach from=$goods_brands item=brand}
            <option value="{$brand.brand_id}">{$brand.brand_name}</option>
            {/foreach}
        </select>
        </samp>
        <div class="p40">
        <samp class="tb">�ؼ���</samp>
        <samp class="tb"><input type="text" value="" id="zhenpin_search_name" class="need_call_taozhuang call_append_input" /></samp>
		<samp class="tb"><a href="javascript:;" class="form_btn block_button" onclick="search_goods_for_zhenpin(this);">����</a></samp>
        <samp class="tb" id="remove_all_zenping" style="{if !$zping_data}display:none;{/if}" ><a href="javascript:;" class="form_btn block_button" onclick="remove_zenpin(this);">ɾ��ȫ��</a></samp>
        </div>
        </div>
        
        <div class="clear"></div>
        <div id="ajax_call_zping_data" class="ajax_call_goods_part">
        	{include file="goods/goods_extend_zhenpin_part.php"}
        </div>
<script type="text/javascript">
function search_goods_for_zhenpin(){
	$.get('index.php?m=goods/products&a=load_part_goods&task=search_zhenpin',{self:goods_id,name:$("#zhenpin_search_name").val(),cid:$("#zhenpin_cat").val(),bid:$("#zhenpin_brands").val()},function(data){
		switch(data){
			case 'NO_RESULT':
				window.parent.showNotice('�޿�������,������ؼ���!');
			break;
			default:
				$(data).appendTo($("#ajax_call_zping_data"));
				$("#remove_all_zenping").show();
				$("#zhenpin_search_name").val('');
		}
	});
}
function remove_zenpin(obj){
	$("#remove_all_zenping").show();
	$(obj).parent().hide();
}
</script>
    </td>
</tr>
<!--#��Ʒ����-->
       <tr>
    	<td class="one"><!--������-->{$lang.goods.promotion_goods_price}</td>
 <td>
 <div class="notice_msg" style="display:none;width:95%;" id="promotion_goods_desc"><b class="green">������������������۸�ȫ������!ͬʱ��������ʱ�����ȿ�ʼʱ��Ҫ��,������Ϊ������������</b></div>
 <div class="f_left"><input type="text" disabled="disabled" value="{$goods_data.goods_promotion_price}" id="promotion_price" name="goods_promotion_price" class="promotion_price_all promotion_tags input_notice w300"  title="{$lang.goods.promotion_goods_dazhe}"/></div>
</td>
    </tr>
        <tr id="show_promotion_time" style="display:none;">
	        <td class="one"><!--����ʱ��-->{$lang.goods.promotion_time}</td>
            <td>
         <input type="text"  disabled="disabled"  id="promotion_begain_time" onfocus="show_date(this,true,true);"  class="select_date_time promotion_tags date date_input" name="promotion_begain_time"    value="{$goods_data.goods_promotion_begain_time}" /> - <input type="text" id="promotion_end_time"  disabled="disabled"  class="select_date_time promotion_tags date date_input"  name="promotion_end_time"   onfocus="show_date(this,true,true);"  value="{$goods_data.goods_promotion_end_time}" /> 
          </td>
        </tr>
            <tr>
    	<td class="one">{$lang.goods.goods_out_link}<!--�ⲿ����--></td>
        <td><input class="input_notice w300"  title="{$lang.goods.out_link_desc}" type="text" value="{$goods_data.goods_out_link}"  name="goods_out_link" /></td>
    </tr>
          <tr>
        	<td class="one">{$lang.goods.shoper_remark}<!--�̼ұ�ע--></td>
            <td><textarea name="goods_shoper_remark"  title="{$lang.goods.for_shoper_info}" class="input_notice seo_set">{$goods_data.goods_shoper_remark}</textarea>
            </td>
        </tr>
    </table>
    </div>
</div>
<!--������Ϣ���� g_others-->
<!--��Ʒ���ʼ-->
<div class="table_item" id="g_specfication">
	<h1 class="c_bar">������</h1>
    <div class="c_content">
<script type="text/javascript">
	function call_add_spec_data(obj){
		window.parent.showWindow('���ӹ��','index.php?m=goods&a=goods_spec&action=add',650,250);
	}
	function call_add_tag(obj){
		window.parent.showWindow('��Ʒ��ǩ','index.php?m=goods/products&a=tagsManage',650,250);
	}
	function canel_spec(){
		$(".need_show_spec").hide();	
	}
	function reload_data_spec_data(){
		$.get('index.php?m=goods&a=goods_spec&action=load',function(data){
			$("#goods_specification_val").html(data);
		});
	}
	function __call_extend_data(id){
		$.get('index.php?m=goods&a=goods_spec&action=call_goods',{id:id},function(data){
				$("#append_call_goods_tr").show();
				$("#append_call_goods").html(data);
			});		
	}
	$(function(){
		$("#goods_specification_val").change(function(){
			var v = $(this).val();
			if(v){
					__call_extend_data(v);	
			}else{
				$("#append_call_goods_tr").hide();
				$("#append_call_goods").empty();
			}
		});
		
		$("#goods_specification_val_fix").focus(function(){
			var c = $("#goods_specification_val").val();
			if(!c){
				window.parent.showNotice('����ѡ����������!');return false;	
			}
		}).blur(function(){
			var val = $(this).val();
			var main_id = $("#goods_specification_val").val();
			if(!empty(val)){
				$.post('index.php?m=goods&a=goods_spec',{name:val,action:'check_spec_extend_name',spec_id:main_id},function(data){
					switch(data){
						case 'EMPTY_NAME':
							window.parent.showNotice('����������!');
						break;
						case 'ERROR_PARAM':
							window.parent.showNotice('����ѡ����������!');
						break;
						case 'HAS_EXIST':
							window.parent.showNotice('������ͬ����,����������!');
							$('#goods_specification_val_fix').val('');
						break;
						case 'OK':
						break;
					}
				});	
			}
		});
	/*���ɫ���ϴ�*/
	$("#upload_goods_extend_img").upload({
		filename:'goods_spec_extend_img',
		loading_dom:$('.show_upload_extend_loading'),
		post_params:{'sid':session_id,'action':'goods_spec_extend_img'},
		url:'index.php?m=goods/products&a=ajaxUpload',
		sucess:function(file,response){
				try{
					var call = response.split('|');
					var m = call[1];
					switch(call[0]){
						case '1':
							alert(call[1]);return false; break;
						case '2':
							$("#goods_spec_extend_img").val(call[1]);
							$("#show_extend_img").html('<img src="'+m+'?rands='+Math.random()+'" width="32" height="32"/>');
						break;
						default:alert(response);
					}
			}catch(e){alert(e);}
		}
	});/*���ɫ�����*/
	});

</script>
<input type="hidden" value="{$goods_data.goods_spec_main_id}"  name="old_spec_id"/>
	<table class="table_common">
    	<tr>
        	<tr>
            	<td class="one">������������</td>
                <td>
                <div class="tb" id="reload_data_spec">
                <select class="w250 form_option" name="goods_specification[spec_id]" id="goods_specification_val" style="margin-top:6px;">
                	<option value="">��ѡ��...</option>	
                    {foreach from=$goods_specfication item='spec'}
                    	<option {if $goods_data.goods_spec_main_id eq $spec.spec_id} selected="selected"{/if} value="{$spec.spec_id}">{$spec.spec_name}{if $spec.spec_remark}��{$spec.spec_remark}��{/if}��{if $spec.spec_display eq 'select'}����{elseif $spec.spec_display eq 'radio'}ѡ��{else}ƽ��{/if}��({$spec.total})</option>
                    {/foreach}
                </select></div>
                <div class="tb"><a href="javascript:;" onclick="call_add_spec_data(this);" class="block_button form_btn">����</a></div>
                </td>
            </tr>
            <tr {if !$goods_spec_data} style="display:none" {/if} id="append_call_goods_tr">
            	<td colspan="2" id="append_call_goods">
                {if $goods_spec_data}
                	{include file="goods/goods_spec_part.php"}
                {else}
                <!--#ajax�ص�����--><img src="images/loader.gif" />
                {/if}
                </td>
            </tr>
            <tr>
            	<td class="one">�������</td>
                <td><input type="text" value="{$goods_data.goods_spec_extend_name}"  name="goods_specification[extend_name]"  id="goods_specification_val_fix"  class="w100"/>                  �����ɫ���˴������ݽ�����Ʒ���鴦��ʾ</td>
            </tr>
            <tr style="display:none">
              <td class="one">��ɫͼƬ�ϴ�</td>
              <td><input type="hidden" value="{$goods_data.goods_detail_extend_pic}" name="goods_spec_extend_img" id="goods_spec_extend_img"/>
        <div id="show_extend_img">{if $goods_detail_extend_pic}<img src="{$goods_detail_extend_pic}" width="32" height="32"/>{else}{/if}</div>
        <br><span id="upload_goods_extend_img"></span>
        <div class="show_upload_extend_loading"></div></td>
            </tr>
            <td class="no_border">
            </td>
        </tr>
    </table>
    </div>
<script type="text/javascript">
	function add_spec_call(obj){
		$.get('index.php?m=goods&a=call_spec_append',function(data){
			 $("#no_data_call_spec").remove();
			 $("#ajax_call_append_spec").append(data);
		});
	}
	function call_extend_value(obj,str){
		$.get('index.php?m=goods&a=call_spec_append_son',{rand:str},function(data){
			$(obj).parents('legend').next().append(data);	
		});
	}
	/*ɾ������*/
	function delete_spec(obj,goods_id,main_index,curent_id){
		$(obj).parents('tr').remove();
		if(goods_id>0 && main_index>0 && curent_id>0){
			if(!confirm('ȷ��ɾ��?�˲������ɻָ�!'))return false;
			$.get('index.php?m=goods&a=delete_spec',{goods_id:goods_id,main_index:main_index,son_index:curent_id,type:'son_index'},function(data){
				switch(data){
					case 'OK':
						$(obj).parents('tr').remove();
					break;
					default:alert(data);
				}
			});
		}else{
			$(obj).parents('tr').remove();	
		}
	}
	/*ɾ������*/
	function delete_main_index(obj,goods_id,main_index){		
		if(goods_id>0 && main_index>0){
			if(!confirm('ȷ��ɾ��?�˲������ɻָ�!'))return false;
			$.get('index.php?m=goods&a=delete_spec',{main_index:main_index,goods_id:goods_id,type:'main_index'},function(data){
				 switch(data){
					case 'OK':
						$(obj).parents('fieldset').remove();
					break;
					default:alert(data);
				}
			});
		}else{
			$(obj).parents('fieldset').remove();	
		}
	}
	function check_spec_goods_sn(obj){
		var temp = new Array();
		var o = $(".goods_spec_sn");
		var this_val = $(obj).val();
		if($(o).size()>1 && this_val){
			var dom_class = 'curent_fix_check_spec';
			$(obj).addClass(dom_class);
			$(o).map(function(){
				var v = $(this).val();
				if(v && !$(this).hasClass(dom_class))return temp.push(v);
			});
			$('.'+dom_class).removeClass(dom_class);
			if(inArray(this_val, temp)){
				window.parent.showNotice('������ͬ����,��������д!');
				$(obj).val('');
				return false;
			}			
		}
		$.get('index.php?m=goods/products&a=check_sn',{sn:this_val,goods_id:'{$goods_data.goods_id}',spec_tag:'true'},function(data){
			switch(data){
				case 'EMPTY':
					window.parent.showNotice('����д��Ʒ����!');
				break;
				case 'HAS_EXIST':
					window.parent.showNotice('������ͬ����,����������!');
					$(obj).val('');
				break;
				case 'OK':
					$("#call_back_sn_check").html('OK');
				break;
				default:alert(data);
			}
		});
		/*
		$.get('index.php?m=goods/products&a=check_sn',{sn:$(obj).val(),goods_id:'{$goods_data.goods_id}'},function(data){
			switch(data){
				case 'EMPTY':
					window.parent.showNotice('����д��Ʒ����!');
				break;
				case 'HAS_EXIST':
					window.parent.showNotice('������ͬ����,����������!');
					$(obj).val('');
				break;
				case 'OK':
					$("#call_back_sn_check").html('OK');
				break;
				default:alert(data);
			}
		});
		*/
	}
</script>
    	<h1 class="c_bar" style="margin-bottom:10px;"><div class="tb">���Ӳ���</div> <div class="tb"><a href="javascript:;" onclick="add_spec_call(this);" style=" font-weight:normal;" class="block_button form_btn">���Ӹ���������</a></div></h1>
        <div class="c_content" id="ajax_call_append_spec">
	        <div class="notice_msg" style="display:none;">
            ��������һ������ļ���,һ���·��кܶ�����ɫ�����ɫ,��ɫ,��ɫ��,ÿһ����ɫ�¶���N������,����X,XX,XXL,XL�ŵ�,��Ӧÿ������Ŀ��,���ž���һ��<br />
            ��ϵͳ�еĸ��Ӳ������Ա����Ƕ�Ӧ�ĳ���,��ֿ�������ݾ�Ӧ����������<br />
            ������:<strong>����</strong>,����Ϊ<strong>X</strong>
            </div>
            {if $goods_spec_extend_data}
            	{include file="goods/widget/call_goods_spec.php"}
            {else}
            	<div class="notice_msg" id="no_data_call_spec">��������������!</div>	
            {/if}
        </div>
</div>
<!--��Ʒ������ g_specfication-->

<!--������Ʒ-->
<div class="table_item" id="g_cross_goods">
	<h1 class="c_bar">������Ʒ</h1>
    <div class="c_content">
<script type="text/javascript">
	function search_goods(){
			var cate_id = $("#goods_category_search").val();
			var brand_id = $("#goods_brands_search").val();
			var keywords = url_encode($("#search_key_all_value").val());
		var  url= 'index.php?m=goods/products&a=searchGoods&cate_id='+cate_id+'&brand_id='+brand_id+'&keywords='+keywords+'&dataType=json&jsoncallback=?';
		$.getJSON(url,function(d){
				var key = d[0]['goods_id'];
				if(key!='' || key !='undefined'){
				var string = '';
				$(d).each(function(i){
					string += '<option value="'+d[i].goods_id+'">'+d[i].goods_name+'</option>'+"\n";		
				});	
			 $("#can_select_goods_list").empty().html(string);
			}else{
				window.parent.showNotice("�޿�������!");	
			}
		});
	}
</script>
<div style="padding:5px 8px; padding-left:60px;">
<input type="hidden" value="" id="choose_related_goods" />
<div class="tb"><select  style="width:150px;" class="select" id="goods_category_search"><option value="0" selected="selected">{$lang.goods.all_goods_categroy}<!--���з���--></option>{foreach from=$goods_category item=cate}<option value="{$cate.cate_id}">{$cate.spacer}{$cate.cate_name}</option>{/foreach}</select></div>
<div class="tb"><select  style="width:150px;" class="select" id="goods_brands_search"><option value="0" selected="selected">{$lang.goods.all_goods_brands}<!--����Ʒ��--></option>{foreach from=$goods_brands item=brand} <option value="{$brand.brand_id}" style="padding-left:10px;">{$brand.brand_name}</option>
{/foreach}</select></div>
<div class="tb"><input type="text"  value="" id="search_key_all_value" name="relate_search_key_words" /></div>
<div class="tb"><a href="javascript:;" class="block_button" onclick="search_goods();">{$lang.php_search}</a></div>
</div>
<div class="clear"></div>
<script type="text/javascript">
var relative_goods_notice = '{$lang.goods.please_select_relative_goods}';
function check_radio(obj){$(obj).find('input').attr("checked",true);}
function _append(sec){
	var d = sec.split(',');
	$("#can_select_goods_list").find('option').each(function(){
		var v = $(this).val();
		var tt = $.trim($(this).text());
		tt = tt.replace(/��/g,'');
		if($.inArray(v,d)!='-1' && $(this).attr('selected')){
			$("#selected_goods").append('<option value="'+$(this).val()+'">'+tt+'</option>');	
		}
	});
	v = null; d= null;
}
function _set_maps(){$("#relative_goods_id").val(_get_maps());}
function _get_maps(){return $("#selected_goods").find('option').map(function(t){return $(this).val()}).get().join(',');}
function _c(dom){
return  $(dom).find('option').map(function(){if($(this).attr("selected")){return $(this).val();flag = true;}}).get().join(',');	
}
function add_sec_goods(){
	var selected = _c($("#can_select_goods_list"));
	if(selected.length<=0)return window.parent.showNotice(relative_goods_notice);
	var has = _get_maps();<!--�ҵ���ѡ�������-->
	if(empty(has)){
		$("#relative_goods_id").val('');
		_append(selected);
		_set_maps();
	}else{
		has = has.split(',');
		$("#can_select_goods_list").find('option').each(function(){
			var tt = $.trim($(this).text());
			var t = $(this).val();
			tt = tt.replace(/��/g,'');
			if($.inArray(t,has)=='-1' && $(this).attr('selected')){
				$("#selected_goods").append('<option value="'+$(this).val()+'">'+tt+'</option>');	
			}
		});
		_set_maps();
	}
}
	function remove_sec_goods(){
		var sec = _c($("#selected_goods"));
		if(sec.length<=0)return window.parent.showNotice(relative_goods_notice);
		$("#selected_goods :selected").each(function(){$(this).remove();});
		_set_maps();
	}
</script>
<div>
<input type="hidden" value="{$relative_goods_ids}" name="relative_goods_ids" id="relative_goods_id"/>
		<table width="90%" border="0" align="center" cellpadding="5" cellspacing="5">
    	<tr>
        	<td class="table_one" align="center"><!--��ѡ��Ʒ-->{$lang.goods.can_list_goods}<span style="font-size:12px; font-weight:normal; color:#666;">&nbsp;&nbsp;<!--��סctrl��ѡ���ʵ�ָ�ѡ-->{$lang.goods.ctrl_select_data}</span></td>
            <td class="table_one" align="center">{$lang.php_do_action}<!--����--></td>
            <td class="table_one" align="center"><!--�����Ʒ��������Ʒ-->{$lang.goods.relative_goods_data}</td>
        </tr>
        <tr>
        	<td width="40%" align="center">
<select  multiple="multiple" id="can_select_goods_list" style="width:90%; height:300px;"></select></td>
            <td align="center" valign="middle">
<p style="cursor:pointer;" onclick="check_radio(this);"><input type="radio"  class="form_btn_bg b" name="goods_connet_type" value="one" onfocus="this.blur();"  checked="checked"/><!--�������-->{$lang.goods.association_goods}</p>
 <p style="cursor:pointer;" onclick="check_radio(this);"> <input type="radio"  name="goods_connet_type" value="between" {if $goods_data.goods_relative eq 'between'} checked="checked"{/if} class="form_btn_bg b"  onfocus="this.blur();" /><!--˫�����-->{$lang.goods.association_all_goods}</p>
                <input  type="button" class="form_btn_bg b" style="width:50px;" onclick="add_sec_goods();"  value=">>" onfocus="this.blur();"  /> <br />
                <input  type="button"  class="form_btn_bg b" value="<<"  style="width:50px;" onclick="remove_sec_goods();" onfocus="this.blur();"  /><br />
            </td>
            <td width="40%" align="center">
            <select multiple="multiple" id="selected_goods" style="width:90%; size:20; height:300px;">
 {if $relative_goods_data}
 {foreach from=$relative_goods_data item=re}<option value="{$re.goods_id}">{$re.goods_name}</option> {/foreach}{/if}
            </select>
            </td>
        </tr>
    </table>
</div>
</div>
</div>
<!--���� ������Ʒ g_cross_goods-->
<div class="table_item" id="g_relative_article"> 
	<h1 class="c_bar">��������</h1>
    <div class="c_content">
<input type="hidden" value="{$goods_id|default:0}" id="rel_goods_id" />
<script type="text/javascript">
<!--������������-->
function select_art_type(objs){
	$(objs).find('input').each(function(){ $(this).attr({"checked":"checked","sec":'1'})})
	$("#need_delete_ids").val('1');
}
var obj_dom = null;
function ajax_call_articles(){var opt = {cate_id:$("#article_cates").val(),key:$("#article_name").val(),dataType:'json','goods_id':$("#rel_goods_id").val()};
		$.getJSON('index.php?m=goods/products&a=searchArticle&jsoncallback=?',opt,function(data){
			var c = '';var has = ''; var string = '';
			try{ has = data[0]['id'];}catch(e){};
			if(has!='' || has !='undefined'){
				$(data).each(function(i){
					string += '<label title="'+data[i]['title']+'">'+c+'<input class="rel_article" checked="checked" type="checkbox" value="'+data[i]['id']+'"  name="relative_articles[]"/> '+data[i]['title']+'</label>';c = '';
				});
				$("#ajax_call_articles").empty().html(string+'<div class="clear"></div>');
				$("#delete_art").show();
			}else{
				$("#ajax_call_articles").html('<div class="notice_msg">'+php_nodata+'</div>');	
				$("#delete_art").hide();
			}
		});
	}
	function cache_all(){
		$("#ajax_call_articles input").attr({"checked":''});
	}
	function select_all(){$("#ajax_call_articles input").attr({"checked":"checked","sec":'1'});}
</script>
<div style="height:auto;">
<div class="tb">
<select id="article_cates" style="height:24px;"  class="select">
<option value="0">{$lang.goods.please_select_cates}</option>{foreach from=$category_tree item=cate}<option value="{$cate.category_id}">{$cate.spacer}{$cate.category_name}</option>{/foreach}</select></div>
<div class="tb"><input type="text" value="" id="article_name"/></div>
<div class="tb"><a href="javascript:;" onclick="ajax_call_articles(this);" class="block_button">{$lang.goods.relative_article_search}</a></div>
<div class="tb" id="delete_art" {if $action eq 'add_product'} style="display:none;"{/if}><a href="javascript:;" onclick="delete_select_article();" class="block_button">{$lang.goods.delete_select_articles}</a>
<a href="javascript:;" class="block_button" onclick="cache_all();">ȫ��ȡ��</a> <a href="javascript:;" class="block_button" onclick="select_all();">ȫ��ѡ��</a>
</div>
</div>
<input type="hidden" value="0"  id="need_delete_ids"/>
<div id="ajax_call_articles">
{foreach from=$relative_atricle  item='art'}
<label><input class="rel_article" type="checkbox" value="{$art.id}" checked="checked"  name="relative_articles[]"/>{$art.title}</label>
{/foreach}</div>
<script type="text/javascript">
var need_delete_article = '{$lang.goods.select_need_delete_article}';/*��ѡ��Ҫɾ��������*/
function delete_select_article(){
	var c = get_checkbox_val('rel_article');
	if(empty(c))return window.parent.showNotice(need_delete_article);
	$("#ajax_call_articles").find('input').each(function(){
		if($(this).attr('checked'))$(this).parent().remove();
	});
}
</script>
<div class="clear"></div>
</div>
</div>
<!--#end g_relative_article ������������-->
 <!--��ʼ��չ��������-->
 <div class="table_item" id="g_extend">
 	<h1 class="c_bar">��չ����</h1>
    <div class="c_content">
     <table class="table_common">
        <tr>
            <td class="no_border none">
                <select name="goods_types_id" onchange="ajax_load_extend_data(this);" class="w300">
                    <option value="0" selected="selected"><!--ͨ����Ʒ����-->{$lang.goods.common_goods_type}</option>
                    {foreach from=$type_data item=type}
                    <option id="{$type.type_id}|{$goods_data.goods_id}" value="{$type.type_id}|{$goods_data.goods_id}"  {if $goods_data.goods_types_id eq $type.type_id}selected="selected"{/if}>{$type.type_name}</option>
                    {/foreach}
                </select>
                <span>{$lang.goods.select_type_desc}<!--�����û��������Ʒ���ͻ�û����Ʒ������ѡ��<b>ͨ����Ʒ����</b>.--></span>
            </td>
        </tr>
     </table>
     </div>
 	<h1 class="c_bar">�ֹ���д����</h1>
    <div class="c_content c_no_border">
     <table class="table_common">
     	<tr>
        	<td class="no_border none">{$prefix_editor}</td>
        </tr>
     </table>
     </div>
     <div id="goods_extend_apped_area">
         {if $extend_type_data.types_extends_attr}
                <h1 class="c_bar">��չ����</h1>
                <div class="c_content">
                <!--��չ����-->
                    <table class="table_common" id="table_common_tag">
                    {foreach from=$extend_type_data.types_extends_attr item=type}
                        <tr>
                            <td class="one" width="1050">{$type.attr_name}</td>
                            <td>
                                {if $type.input_mode eq 'input'}
                                    <input type="text" value="{$type.user_fix_data}" name="goods_attr_extend_value[{$type.attr_id}]" style="width:300px;" />
                                {/if}
                                {if $type.input_mode eq 'select'}
                                    <select name="goods_attr_extend_value[{$type.attr_id}]" style="width:310px;">
                                        <option value=""><!--��ѡ��...-->{$lang.php_select}</option>
                                        {foreach from=$type.attr_value item=a_v}
                                <option value="{$a_v}"{if $type.user_fix_data eq $a_v} selected="selected"{/if}>{$a_v}</option>
                                        {/foreach}
                                    </select>
                                {/if}
                                {if $type.input_mode eq 'text'}
                                    <textarea name="goods_attr_extend_value[{$type.attr_id}]" style="width:300px;">{$type.user_fix_data}</textarea>
                                {/if}
                                 {if $type.bind_in_param eq '1'}<font class="blue">{$lang.goods.has_bind_parame}</font>{/if}
                            </td>
                        </tr>
                     {/foreach}
                    </table>
                    </div>
            {/if}
     </div>
<!--AJAX ���������õ�-->
 </div><!--��չ���Խ���-->
 
 <!--��Ʒ��ǩ-->
     <div class="table_item" id="g_tags">
     	<h1 class="c_bar">��Ʒ��ǩ</h1>
    	<div class="c_content">
        {if $goods_tags}
     <h2 class="title_notice"><a href="javascript:;" onclick="reload_tags('{$goods_data.goods_id}');" style="padding-left:30px; float:left; line-height:30px; font-size:12px;font-style:normal; cursor:pointer; font-weight:normal; color:#060; font-weight:bold;">���¼��ر�ǩ</a></h2> 
        <div style="padding:4px 20px;">
             <script type="text/javascript">
                function reload_tags(id){
                    $.get('index.php?m=goods/products&a=reloadTags',{id:id},function(d){$("#goods_tags").html(d);});	
                }
             </script>
                <div id="goods_tags">
                    {foreach from=$goods_tags item=tag}
                <label> <input type="checkbox"  name="select_tags[]" {if $tag.checked eq '1'}  checked="checked"{/if} value="{$tag.tag_id}" />{$tag.tag_value}</label>
                    {/foreach}
                </div>
         </div>
         {else}
         <a href="javascript:;" class="block_button" onclick="call_add_tag(this)">���ӱ�ǩ</a>
         {/if}
     </div>
 </div>
<!--#������Ʒ���� ��ʼSEO-->
<div class="table_item" id="g_seo">
	<h1 class="c_bar">SEO����</h1>
    <div class="c_content">
        <table class="table_common">
        <tr>
        	<td class="one" style="font-size:12px;width:170px;line-height:21px;">META Title����Ŀ���⣩<br><span style="color:#666;">��������������õı���</span></td>
            <td><textarea  name="seo[meta_title]"  class="seo_set" >{$goods_seo.meta_title}</textarea></td>
        </tr>
        	<tr>
            	<td class="one" style="font-size:12px;width:170px;line-height:21px;">Title��ҳ����⣩<br><span style="color:#666;">������Ʒҳ��ͷ������</span></td>
                <td><textarea  name="seo[title]"   class="seo_set"  >{$goods_seo.title}</textarea></td>
            </tr>
           <tr>
            	<td class="one" style="font-size:12px;width:170px;line-height:21px;">META Keywords����Ŀ�ؼ��֣�<br><span style="color:#666;">�ؼ���֮���ð�Ƕ��Ÿ���</span></td>
                <td><textarea  class="seo_set"  name="seo[keywords]">{$goods_seo.keywords}</textarea></td>
            </tr>
           <tr>
            	<td class="one" style="font-size:12px;width:170px;line-height:21px;">META Description����Ŀ������<br><span style="color:#666;">��������������õ�����</span></td>
                <td><textarea  class="seo_set" title="{$lang.goods.seo_page_desc_short}" name="seo[description]">{$goods_seo.description}</textarea></td>
            </tr>
        </table>
        </div>
</div>
<!--#��װ�嵥-->
<div id="g_goods_pack" class="table_item">
	<h1 class="c_bar">��װ�嵥</h1>
    <div class="c_content c_no_border">
	<table class="table_common">
    	<tr>
        	<td class="no_border none">
            	{$pack_editor}
            </td>
        </tr>
    </table>
    </div>
</div>
    <!--#������װ�嵥 �ۺ����-->
    <div id="g_goods_service" class="table_item">
    	<h1 class="c_bar">�ۺ����</h1>
    	<div class="c_content c_no_border">
        <table class="table_common">
            <tr>
                <td class="no_border none">
                    {$service_editor}
                </td>
            </tr>
        </table>
        </div>
    </div><!--#���� �ۺ����-->
    </div><!--#end table_item_base-->
</div>
</form>
{include file="frame_footer.php"}
{/if}
<!--������Ʒ����+�༭-->