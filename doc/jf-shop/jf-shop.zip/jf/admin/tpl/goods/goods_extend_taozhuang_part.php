<?php  exit('taozhuang'); ?>
{if $taozhuang_data}
{foreach from=$taozhuang_data item='tlist'}
    <p><label><input type="checkbox" value="{$tlist.goods_id}"   checked="checked" name="taozhuang_extend[]"/></label><a href="{$tlist.url}" target="_blank"> {$tlist.goods_name}</a> <samp class="tao_price">({$tlist.goods_shop_price})Ԫ</samp> <samp><a href="javascript:;" onclick="delete_extend_call_goods(this);">ɾ��</a></samp><samp class="red"> {if $tlist.goods_is_sale eq '0'}���¼�{/if}</samp></p>
{/foreach}
{/if}