<?php exit('os'); ?>
{if $fetch_action eq 'server_os_info'}
        	<table class="table_common" style="width:100%;">
      <tr>
        	<td class="one" nowrap="nowrap">{$lang.c.system_root}</td>
            <td>{$server.root_info}</td>
            <td class="one">{$lang.c.phpinfo} </td>
            <td><a href="index.php?m=default&a=info" target="_blank" style="color:#900;">{$lang.c.view_info}</a></td>
        </tr>
      <tr>
        	<td class="one">{$lang.c.os}</td>
            <td>{$server.os}</td>
            <td class="one" nowrap="nowrap">{$lang.c.web_server}</td>
            <td>{$server.web_server}</td>
        </tr>
                <tr>
        	<td class="one">{$lang.c.phpversion}</td>
            <td>{$server.version}</td>
            <td class="one">{$lang.c.mysql}</td>
            <td>{$server.mysql_version}</td>
        </tr>
                <tr>
        	<td class="one">{$lang.c.safe_model}</td>
            <td>{$server.safe_model}</td>
            <td class="one">{$lang.c.safe_model_gid}</td>
            <td>{$server.safe_model_gid}</td>
        </tr>
                        <tr>
        	<td class="one">{$lang.c.socket}</td>
            <td>{$server.fsockopen}</td>
            <td class="one">{$lang.c.timezone}</td>
            <td>{$server.time_zone_set} {$server.curent_time}</td>
        </tr>
          <tr>
        	<td class="one">{$lang.c.curl}</td>
            <td>{$server.curl}</td>
            <td class="one">{$lang.c.ftp}</td>
            <td>{$server.ftp}</td>
        </tr>
        <tr>
        	<td class="one">{$lang.c.xml}</td>
            <td>{$server.xml}</td>
            <td class="one">{$lang.c.memcache}</td>
            <td>{$server.memcache}</td>
        </tr>
        
              <tr>
        	<td class="one">{$lang.c.gd_version}</td>
            <td>{if $server.gd_version}{$server.gd_version}{else}<span class="red"><% _e('��');%></span>{/if}</td>
            <td class="one">{$lang.c.zlib}</td>
            <td>{$server.zlib}</td>
        </tr>
                        <tr>
        	<td class="one" nowrap="nowrap">{$lang.c.post_max_size}</td>
            <td>{$server.post_max_size}</td>
            <td class="one">{$lang.c.upload_max_size}
      </td>
            <td>{$server.upload_max_size}</td>
        </tr>
          <tr>
        	<td class="one">{$lang.c.php_version}</td>
            <td>{$php_version}</td>
            <td class="one">{$lang.c.char_set}</td>
            <td>{$server.char_set}</td>
        </tr>
           <tr>
        	<td class="one">{$lang.c.diskfree}</td>
            <td>{$server.diskfree}</td>
            <td class="one" nowrap="nowrap">{$lang.c.server_host}</td>
            <td>{$server.server_host}</td>
        </tr>
    </table>
{/if}