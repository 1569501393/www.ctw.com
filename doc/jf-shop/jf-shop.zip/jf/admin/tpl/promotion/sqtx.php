<?php exit('die'); ?>
{if $action eq 'sqtxList'}
	{include file="frame_header.php"}
<form method="post" action="index.php?m=promotion/paycard&a=sqtxList" id="search_tx">
    	<div id="php_top_bar">
        <div class="tb">����״̬��</div>
        <div class="tb"><select name="tx_statu">
        <option>==����״̬==</option>
        <option value="used">δ����</option>
        <option value="unused">������</option>
        </select></div>
        <div class="tb"><input  type="submit" value="����"  class="form_submit" style="display:none;"/>
     	<a href="javascript:;" onclick="submit_form('search_tx');" class="block_button form_btn">����</a></div>
     {if $data.total>0}
     <div class="tb"><a onclick="delete_select_card(this);" class="block_button">ɾ����ѡ</a></div>
          {/if}
      </div>
        </form>
<script type="text/javascript">
	function set_focus_time(obj){
		var val = $(obj).val();
		var is_forever = val=='forever'?true:false;
		var dt = $("#show_time_set");
		if(!is_forever){
			dt.show();
		}else{
			dt.hide();
		}
	}
</script>
        <div id="php_right_main_content">
{if $data.total>0}
        	<table class="table_list table_list_hover">
				<tr>
                	<th><input type="checkbox" value="" id="pay_sec_id" /></th>
                    <th>���ֽ��</th>
                    <th>������</th>
                    <th>����ʱ��</th>
                    <th>��ǰ״̬</th>
                </tr>
                {foreach from=$data.data item='item'}
                	<tr>
                    	<td class="center"><input  type="checkbox" {if $item.statu eq 2} disabled="disabled" value=""{else}value="{$item.tx_id}"{/if} class="pay_sec_id" /></td>
                        <td class="center">{$item.tx_money}</td>
                        <td class="center">{$item.usdata}</td>
                        <td class="center">{$item.tx_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
                        <td class="center">{if $item.tx_statu eq 1}<a class="delete_a" name="{$item.tx_id}" rel="2">δ���</a>{/if}{if $item.tx_statu eq 2}<a class="update_a" name="{$item.tx_id}" rel="1">�Ѵ��</a>{/if}</td>
                    </tr>
                {/foreach}
                <tr>
                	<td colspan="6" align="right"><% _e("��ǰҳ�����ܽ��");%> ��{$curent_total_money|default:'0'}  &nbsp;������ ��{$un_used|default:'0'} ���� {$total_used_card} &nbsp;δ���� ��{$has_used|default:'0'} &nbsp;</td>
                </tr>
            </table>
<div class="clear"></div>
            {$data.page}
{else}
<div class="notice_msg">�޿�������!</div>
{/if}
<script type="text/javascript">
$(".delete_a").click(function(){
	var id = $(this).attr("name");
	var zt = $(this).attr("rel");
	var url = "index.php?m=promotion/paycard&a=change_tx&tid=" + id + "&tx_statu=" +zt;
	$.get(url,function(data){
		switch(data){
			case "OK":
				window.parent.showNotice(php_do_ok);
				window.location.reload();
				break;
			case 'EMPTY':
				window.parent.showNotice('�޴���Ϣ!');
				break;
			default:
			alert(data);
		}
	});
});
$(".update_a").click(function(){
	var id = $(this).attr("name");
	var zt = $(this).attr("rel");
	var url = "index.php?m=promotion/paycard&a=change_tx&tid=" + id + "&tx_statu=" +zt;
	$.get(url,function(data){
		switch(data){
			case "OK":
				window.parent.showNotice(php_do_ok);
				window.location.reload();
				break;
			case 'EMPTY':
				window.parent.showNotice('�޴���Ϣ!');
				break;
			default:
			alert(data);
		}
	});
});
	$(function(){
		$("#search_tx").submit(function(){
			window.location.href=_s(this);
			return false;
		});
		checkAllFormData('pay_sec_id','pay_sec_id');
	});
	function delete_select_card(obj){
		var val= get_checkbox_val('pay_sec_id');
		if(!val){
			window.parent.showNotice("��ѡ��Ҫ����������!");return false;
		}
		if(!confirm("ȷ��Ҫɾ����?�˲��������ɻָ�!"))return false;
		$.post('index.php?m=promotion/paycard&a=delete_tx',{ids:val},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
					window.location.reload();
				break;
				default:alert(data);
			}
		});
	}
</script>
        </div>
    {include file="frame_footer.php"}
{/if}