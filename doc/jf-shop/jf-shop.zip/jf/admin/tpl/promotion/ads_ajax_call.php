<?php exit('die'); ?>
<fieldset class="efieldset">
<legend>�� ��</legend>
{if $can_delete}
<div class="ads_right_tag"><div style="float:right;" class="block_button" onclick="delete_ads_call(this);" rel="{$ads.ads_id}">ɾ���˹��</div></div>
{/if}
<div style="">
<input type="hidden" value="{$ads.ads_id}"  name="ids[{$ads.ads_id}]"/>
<table class="table_common">
	<tr>
    	<td class="one">�Ƿ�ͨ��</td>
        <td><input type="checkbox" value="1" name="ispass[{$ads.ads_id}]" {if $ads.ads_pass neq '2'} checked="checked" {/if}/></td>
    </tr>
    <tr>
        <td class="one">ʱ�䷶Χ</td><!-- ��ʼʱ�� -->
        <td><input type="text" name="adsfromdate[{$ads.ads_id}]"  style="width:170px;"   value="{if $ads.ads_fromdate}{$ads.ads_fromdate|date_format:'%Y-%m-%d'}{else}{$fromtime}{/if}" onfocus="HS_setDate(this);" class="must_fill_in" /> ��  <input type="text" name="adsenddate[{$ads.ads_id}]"  style="width:150px;"  value="{if $ads.ads_enddate}{$ads.ads_enddate|date_format:'%Y-%m-%d'}{else}{$totime}{/if}" class="must_fill_in"  onfocus="HS_setDate(this);"/></td>
    </tr>
	<tr>
    	<td class="one">�������</td>
        <td><textarea name="adsintroduce[{$ads.ads_id}]" style="width:350px; height:50px;" class="form_textarea">{$ads.ads_introduce}</textarea></td>
    </tr>
<tr>
	<td class="one">�������</td>
    <td>
    <select style="width:360px;" name="adstype[{$ads.ads_id}]" onchange="change_datas(this);">
    	<option value="image" {if  $ads.ads_type eq 'image'} selected="selected"{/if}>ͼƬ</option>
    	<option value="flash" {if  $ads.ads_type eq 'flash'} selected="selected"{/if}>FLASH</option>
        <option value="flv" {if  $ads.ads_type eq 'flv'} selected="selected"{/if}>FLV��Ƶ</option>
    	<option value="code"  {if  $ads.ads_type eq 'code'} selected="selected"{/if}>����</option>
    	<option value="text"  {if  $ads.ads_type eq 'text'} selected="selected"{/if}>�ı�</option>
    </select>
	</td>
</tr>
<tr>
 <td  colspan="4" style="border:none; padding:0px;">
 <!--#image-->
<div  class="ecall_tags call_image" {if !$is_ajax} style="display:{if $ads.ads_type eq 'image'}block;{else}none;{/if};" {/if}>
<table class="table_common">
<tr>
    <td  class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
<td width="150"><input type="text" value="{if $ads.ads_type eq 'image'}{$ads.w|default:'0'}{else}0{/if}" name="image[w][{$ads.ads_id}]" /></td>

    <td   class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
    <td><input type="text" value="{if $ads.ads_type eq 'image'}{$ads.h|default:'0'}{else}0{/if}" name="image[h][{$ads.ads_id}]" /></td>
</tr>
<tr>
<td  class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
 <td colspan="3"><input type="text" value="{$ads.ads_linkurl}" name="image[adsimglinkurl][{$ads.ads_id}]" style="width:350px;" class="form_input" /></td>
 </tr>
 <tr>
 <td  class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td> 
 <td colspan="3"><input type="text" class="form_input" value="{$ads.ads_alt}" style="width:350px;"  name="image[adsalt][{$ads.ads_id}]" /></td>
 </tr>
 {if $ads.end_image_url && $ads.ads_type eq 'image'}
 <tr>
 	<td colspan="4"><img src="{$ads.end_image_url}" width="600" height="150" alt="" title=""/></td>
 </tr>
 {/if}   
    <tr>
        <td class="one">ͼƬ��ַ</td> 
        <td colspan="4"><input type="text" style="width:350px;" value="{if $ads.ads_type eq 'image'}{$ads.end_image_url}{/if}" class="form_input" name="image[adsimagehttp][{$ads.ads_id}]" /> 
        <input type="button" value="{$lang.php_view_server}"  class="form_submit"  onclick="showDialog($(this).prev(),'index.php?m=file&type=default');"/>
        </td>
    </tr>
</table>
</div>

<!--#flash-->
<div class="ecall_tags call_flash" style="display:{if $ads.ads_type eq 'flash'}block;{else}none;{/if};">
<table class="table_common">
<tr>
	<td class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
	<td>
<input type="text" title="<% _e('Ϊ0������');%>" class="input_notice" style="width:350px" value="{if $ads.ads_type eq 'flash'}{$ads.w|default:'0'}{else}0{/if}" name="flash[w][{$ads.ads_id}]" /></td>
 </tr>
 <tr>
    <td  class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
    <td><input type="text"  title="<% _e('Ϊ0������');%>" style="width:350px;"  class="input_notice" value="{if $ads.ads_type eq 'flash'}{$ads.h|default:'0'}{else}0{/if}" name="flash[h][{$ads.ads_id}]" /></td>
    </tr>
{if $ads.end_image_url && $ads.ads_type eq 'flash'}
<tr>
<td colspan="2">
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"  codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="600" height="150">
<param name="movie" value="{$ads.end_image_url}">
<param name="wmode" value="transparent" />
<param name="quality" value="high">
 <embed src="{$ads.end_image_url}" width="600" height="150"  quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="transparent"  type="application/x-shockwave-flash"></embed></object>
 </td>
</tr>
 {/if} 
        <tr>
            <td nowrap="nowrap" class="one">Flash��ַ</td>
            <td><input type="text" value="{if $ads.ads_type eq 'flash'}{$ads.end_image_url}{/if}" class="form_input" style="width:350px;" name="flash[adsflashhttp][{$ads.ads_id}]"  />
            <input type="button" value="{$lang.php_view_server}" class="form_submit"  onclick="showDialog($(this).prev(),'index.php?m=file&type=flash');" />
            </td>
        </tr>
    </table>
        </div>

<!--#FLV��Ƶ-->
<div class="ecall_tags call_flv" style="display:{if $ads.ads_type eq 'flv'}block;{else}none;{/if};">
    <table class="table_common">
    <tr>
        <td   class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
        <td>
    <input type="text" title="<% _e('Ϊ0������');%>" class="input_notice" style="width:350px" value="{if $ads.ads_type eq 'flv'}{$ads.w|default:'0'}{else}0{/if}" name="flv[w][{$ads.ads_id}]" /></td>
     </tr>
     <tr>
        <td   class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
        <td><input type="text"  title="<% _e('Ϊ0������');%>" style="width:350px;"  class="input_notice" value="{if $ads.ads_type eq 'flv'}{$ads.h|default:'0'}{else}0{/if}" name="flv[h][{$ads.ads_id}]" /></td>
        </tr>
    {if $ads.end_image_url && $ads.ads_type eq 'flv'}
    <tr>
    <td class="one">Ԥ��</td>
    <td>
     <embed src="../shopdata/player/flvplayer1.swf" allowFullScreen="true" FlashVars="file={$ads.end_image_url}" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="440" height="300"  wmode="opaque" quality="high" menu="false" autostart="true" />
     </td>
    </tr>
     {/if} 
            <tr>
                <td nowrap="nowrap" class="one">FLV��Ƶ��ַ</td>
                <td><input type="text" value="{if $ads.ads_type eq 'flv'}{$ads.end_image_url}{/if}" class="form_input" style="width:350px;" name="flv[adsflashhttp][{$ads.ads_id}]"  />
                <input type="button" value="{$lang.php_view_server}" class="form_submit"  onclick="showDialog($(this).prev(),'index.php?m=file&type=flv');" />
                </td>
            </tr>
        </table>
</div>
<!--#code-->
    	<div  class="ecall_tags call_code" style="display:{if $ads.ads_type eq 'code'}block;{else}none;{/if};">
			<table class="table_common">
            	<tr>
                	<td class="one">�������</td>
                    <td><textarea name="code[adscode][{$ads.ads_id}]" id="adscode"  class="form_textarea" rows="10" cols="50" style=" padding:2px;width:500px; height:150px;">{if $ads.ads_type eq 'code'}{$ads.ads_text}{/if}</textarea></td>
                </tr>
            </table>
        </div>
        
<!--#text-->
    	<div   class="ecall_tags call_text" style="display:{if $ads.ads_type eq 'text'}block;{else}none;{/if};">
        <table  class="table_common">
            <tr>
                <td   class="one">���ӵ�ַ</td>
                <td><input type="text"  name="text[adstextlinkurl][{$ads.ads_id}]" id="adstextlinkurl" class="form_input" value="{$ads.ads_linkurl}" /></td>
            </tr>
            <tr>
                <td class="one">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
                <td>  <textarea  id="adstext" style="width:500px; height:100px;" name="text[adstext][{$ads.ads_id}]" class="form_textarea">{if $ads.ads_type eq 'text'}{$ads.ads_text}{/if}</textarea></td>
            </tr>
        </table>
        </div>
    </td>
</tr>
</table>
</div>
<div class="clear"></div>
</fieldset>