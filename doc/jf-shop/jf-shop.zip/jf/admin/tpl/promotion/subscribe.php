<?php exit('attempt die');?>
{if $action eq 'magazine'}
{include file="frame_header.php"}
<script type="text/javascript">
$(function(){
checkAllFormData('checked','checked');
	/*����*/
	 $("#mail_operate").submit(function(){ 
		window.location.href=_s(this);
		return false;
	});
   /*ɾ������*/
   $("#operate").click(function(){
		var val = get_checkbox_val('checked');
		if(!val)return window.parent.showNotice(php_empty_select);
		if(!confirm('ȷ��ɾ����?�˲������ɻָ�!'))return false;
		var opt = {
				'mail_ids':val
			};
		$.post('index.php?m=promotion/mailsub&a=deleteMailList',opt,function(data){
			switch(data){
				case 'EMPTY':
					window.parent.showNotice(php_empty_select);
				break;
				case 'OK':
					window.parent.showNotice(php_do_ok);
					window.location.reload();
				break;
				default:alert(data);
			}
		});
	});
});
</script>
<form action="index.php?m=promotion/mailsub&a=magazine" id="mail_operate">
<div id="php_top_bar" >
<div class="tb">�ʼ���</div>
<div class="tb"><input type="text" name="name" value="{$mail_find.mail_name}"  style="width:100px;"id="mail_name"></div>
<div class="tb">ʱ��</div>
<div class="tb"><input type="text"  name="start" id="starttime" onfocus="show_date(this);" style="width:100px;" value="" /></div>
<div class="tb"> - </div>
<div class="tb"> <input type="text"  name="stop" id="stoptime" onfocus="show_date(this);" value="" style="width:100px;" /></div>
<input type="submit" value='����'  class="form_submit" style="display:none"/>
<div class="tb"><a href="javascript:;"  class="block_button form_btn" onclick="submit_form('mail_operate');">����</a></div>
{if $data.total>0 && $can_delete}
<div class="tb"><a id="operate" href="javascript:;" class="block_button">����ɾ��</a></div>
{/if}
{if $can_import}
<div class="tb"><a class="block_button" href="javascript:;" onclick="butch_mail_list('import');">��������</a></div>
{/if}
{if $can_export}
<div class="tb"><a class="block_button" href="javascript:;" onclick="butch_mail_list('export');">��������</a></div>
{/if}
</div> 
</form>
<script type="text/javascript">
	function butch_mail_list(tag){
		switch(tag){
			case 'export':
				window.open('index.php?m=promotion/mailsub&a=exportMail');
			break;
			case 'import':
				window.parent.showWindow('��������','index.php?m=promotion/mailsub&a=importMail','600','350');
			break;
			default:alert('error');
		}
	}
</script>
<div id="php_right_main_content">
{if $data.total>0}
  <table  class="table_list">
    <tr>
      {if $can_delete}<th width="20"><input type='checkbox'  name="all_check" id="checked" /></th>{/if}
      <th width="20">ID</th>
      <th  align="center">����</th>
      <th>ʱ��</th>
      <th>IP</th>
    </tr>
     {foreach from=$data.data item=item name=name}
            <tr>
              {if $can_delete}<td class="center" style="text-align:center;" width="50"><input type='checkbox' class="checked" name="mails" value="{$item.id}"  /></td>{/if}
              <td class="center" width="50">{$item.id}</td>
              <td>{$item.email}</td>
              <td class="center">{$item.add_time|date_format:"%Y-%m-%d"}</td>
              <td class="center">{$item.ip}</td>
            </tr>
        {/foreach}
        
</table>
<div class="clear"></div>
<div id="pre_page">{$data.page} </div>
{else}
<div class="notice_msg">�޿�������!</div>
{/if}
</div>
{include file="frame_footer.php"}
{/if}
<!--AJAX ���ʼ���־-->
{if $action eq 'sendSub'}
<script type="text/javascript">
	function _show(){
		var d = $("#ajax_call_back_info");
		d.html(''); _set();	d.show();	
	}
	function _set(str){
		var strs = empty(str)?'<img src="images/zoomloader.gif" /> loading...':str;
		$("#ajax_call_back_info").html(strs);
	}
	function _hide(){$("#ajax_call_back_info").hide();}
	$(function(){
		$(".fetch_string").click(function(){
			var value  = $(this).val();
			switch(value){
				case 'select':
					$(".need_call").slideUp(); $("#select_tag").slideDown();
				break;
				case 'upload':
					$(".need_call").slideUp(); $("#upload_pannel_list").slideDown();
				break;
				case 'one':
					$(".need_call").slideUp(); 	$("#one_tag").slideDown();
				break;
				case 'all':
					$(".need_call").slideUp(); $("#all_tag").slideDown();
				break;
			}
		});
		/*��������*/
		$("#form_one").submit(function(){
			if(!check_form_is_empty('must_fill_in_info_s'))return false;
			$(this).ajaxSubmit(function(data){
				_show();
				switch(data){
					case 'EMPTY_MAIL':
					case 'ERROR_MAIL':
						_set('<span class="red">�����ַ����!</span>');return;
					break;
					case 'OK':
						$("#mail_list_one").val('');
						_set('<span class="red">���ͳɹ�!</span>'); return;
					break;
					case 'FAILED':
						_set('<span class="red">����ʧ��,������������!�����Ե��ʼ���������->�ʼ����д��鿴...</span>');
						return;
					break;
					default:alert(data);
				}
			});
			return false;
		});
		/*�ļ��ϴ����ٷ���*/
		$("#upload_text_file").submit(function(){
			var a  = $("#upload_text").val();
			if(empty(a))return false ;
			var ext = a.split('.').pop();
			if($.inArray(ext, new Array('txt'))== -1){ alert('ֻ����txt�����ļ�');return false;}
			 $(this).ajaxSubmit(function(data){
				$("#upload_list").attr('disabled',true);
				 _show();
				data = data.split('|');
				switch(data[0]){
					case 'ERROR':
					$("#upload_list").attr('disabled',false);
					_set('<span class="red">'+data[1]+'</span>');return;
					break;
					case 'EMPTY':
						$("#upload_list").attr('disabled',false);
						_set('<span class="red">��ȷ�������ϴ����ļ�������!</span>');return;
					break;
					case 'OK':/*�ϴ��ɹ� ��ʼ����*/
						$("#upload_text").val('').empty();
						$("#upload_list").attr('disabled',false);
						_set('<span class="red">�ļ��ϴ��ɹ�,�ȴ�����...</span>');
						_next();
					break;
					default:
					$("#upload_list").attr('disabled',false);
					alert(data);
				}
			});
			return false;
		});
		/*����*/
		$("#form_all").submit(function(){
			$(this).ajaxSubmit(function(data){
				_show();
				switch(data){
					case 'EMPTY':
						_set('�޿����ʼ���ַ!');return false;
					break;
					case 'OK':
					_set(); _next();
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
	function send_mail(data){
		data = data.split('|');
		switch(data[0]){
			case 'FINISHED':
				_set('<span class="red">�������,���з��Ͳ��ɹ��ʼ��뵽�ʼ����д��鿴!</span>');return;
			break;
			case 'OK':
				_set('<span> <img src="images/zoomloader.gif" /> <b>'+data[1]+'</b>,���ͳɹ�,������һ��...'+data[2]+'</span>');
				_next(); return ;
			break;
			case 'FAILED':
				_set('<span class="red"><img src="images/zoomloader.gif" /> ����ʧ��<b>'+data[1]+'</b>,�뵽�ʼ����д��鿴!</span>');
				_next(); return;
			break;
			default:alert(data);
		}
	}
	function _next(){
		$.get('index.php?m=promotion/mailsub&a=send&rand='+Math.random(),function(data){return send_mail(data);});	
	}
</script>
<div style="padding:8px;" id="send_magiz_pannel">
<div id="upload_pannel_list" style="display:none;" class="need_call">
<div class="notice_msg">��txt�ļ�,һ��һ���ʼ�,���鵥�ļ���С������2M!</div>
	<form method="post"  id="upload_text_file" action="index.php?m=promotion/mailsub&a=sendmagazine">
  	 <input type="hidden" value="upload"  name="type"/>
    	<input type="file" value=""  name="upload_text" id="upload_text"  />
	<input type="submit" value="�ϴ�������" class="form_submit" id="upload_list" />
    </form>
</div>
<!--#one-->
<div id="one_tag" style="display:none;" class="need_call">
	<form method="post" action="index.php?m=promotion/mailsub&a=sendmagazine" id="form_one" autocomplete='off'>
    	<input type="hidden" value="one"  name="type"/>
    	<input type="text"  class="must_fill_in_info_s" value="" id="mail_list_one" height="20" style="height:20px;" name="email" />
        <input type="submit" value="����" class="form_submit"/>
    </form>
</div>
<!--#ѡ���ʼ�--->
<div id="select_tag" style="display:none" class="need_call">
	<form method="post" action="">
    	ѡ��������
        <input type="hidden" value="select"  name="type"/>
		<input type="submit" value="����" class="form_submit" />
    </form>
</div>
<h1 style="font-size:15px; line-height:20px; font-weight:bold;">��ѡ��Ҫ���ŵķ�ʽ</h1>
<hr  size="1"  noshade="noshade" />
<!--<label><input type="radio"  name="select_tag" value="select"  class="fetch_string"/> ѡ���ʼ�</label>-->
&nbsp;&nbsp;<label><input type="radio"  name="select_tag" value="one"  class="fetch_string"/> ������д</label>
&nbsp;&nbsp;<label><input type="radio"  name="select_tag" value="upload"  class="fetch_string"/> �ϴ��б�</label>
&nbsp;<label><input type="radio" name="select_tag" value="all" class="fetch_string" /> ���е��ʼ������б�</label>
</div>
<!--����ȫ��-->
<div id="all_tag" style="display:none" class="need_call">
	<form method="post" action="index.php?m=promotion/mailsub&a=sendmagazine" id="form_all" autocomplete='off'>
    <input type="hidden" value="send_all"  name="type"/>
	<input type="submit" value="����" class="form_submit" />
    </form>
</div>
<div class="notice_msg" id="ajax_call_back_info" style="display:none;">
<img src="images/zoomloader.gif" /> loading...
</div>
{/if}
<!--���ݵ���-->
{if $action eq 'import_mail'}
<div class="notice_msg">ע��:ֻ֧���ı��ļ�(txt)����,һ��һ�������ַ!�ļ�������2M��,���벻����ϵͳ�Ѵ��ڵ������ַ!</div>
<div style=" padding-left:20px;">
<form enctype="multipart/form-data" method="post"  id="ajax_upload_mail" action="index.php?m=promotion/mailsub&a=importMail">
<input type="file" value="" name="uploadFile" id="upload_vals" />
 <input  type="submit" value="�� ��" class="form_submit"/>
</form>
<script type="text/javascript">
	$(function(){
		$("#ajax_upload_mail").submit(function(){
			$(this).ajaxSubmit(function(data){
			     data = data.split('|');
				 switch(data[0]){
					 case 'EMPTY':
					 	window.parent.showNotice('��ѡ��Ҫ�ϴ����ļ�!');return ;
					 break;
					case 'ERROR':
						window.parent.showNotice(data[1]);$("#upload_vals").val('');
						$("#upload_vals").empty();
						return ;
					break;
					case 'EMPTY_DATA':
						window.parent.showNotice('��ȷ�����ϴ����ļ���������!');return ;
					break;
					case 'OK':
						window.parent.showNotice(php_do_ok);
						close_window();
						$("#right_frame").attr({"src":'index.php?m=promotion/mailsub&a=magazine'});
					break;
					default:alert(data);
				  }
			});
			return false;
		});
	});
</script>
</div>
{/if}

<!--��־�б�-->
{if $action eq 'maginelist'}
{include file="frame_header.php"}
<div id="php_top_bar">
<a href="index.php?m=promotion/mailsub&a=addsubscribe" class="block_button form_btn">������־</a>
{if $data.total>0 && $can_delete}
<a href="javascript:;" onclick="submit_form('magazine_list');" class="block_button" id="del_magazine">ɾ��</a>
{/if}
</div>
<script type="text/javascript">
$(function(){	
	checkAllFormData('all_check','checked');
	$("#magazine_list").submit(function(){							
		if(!get_checkbox_val("checked")){
			showNotice('������ѡ��һ��');	return false;
		}
		if(!confirm('ȷ��ɾ����?�˲������ɻָ�!'))return false;
		$(this).ajaxSubmit(function(data){
			switch($.trim(data)){
				case "OK":
				 window.parent.showNotice('ɾ���ɹ�');
				 window.location.reload();
				break;
				case 'NO':
				window.parent.showNotice('ɾ��ʧ��');
				break;
				default:
				alert(data);
				break;
			}
		});
			return false;
		});   
 });
function send_mails(obj){
	window.parent.showWindow($(obj).html(),$(obj).attr('rel'),850,400);
}
</script>
<div id="php_right_main_content">
    {if $data.total>0}
    <form action="index.php?m=promotion/mailsub&a=delscribe" id="magazine_list" method="post">
         <table  class="table_list">
            <tr>
            	{if $can_delete}  <th width="50"><input type='checkbox'  name="all_check" id="all_check" /></th>{/if}
              <th  align="center" width="348">����</th>       
              <th  width="200">����ʱ��</th>
              <th>�鿴</th>
            </tr>    
            {foreach from=$data.data item=item name=name}
                <tr>
               {if $can_delete}  <td class="center" align="center" width="50"><input type='checkbox' class="checked" name="scr_id[]" id='scr_id' value="{$item.scr_id}"  /></td>{/if}
                  <td class="center">{$item.scr_title}</td>          
                  <td  class="center">{$item.scr_add_time|date_format:"%Y-%m-%d"}</td>
                  <td class="center">
                 {if $can_edit} <a href="index.php?m=promotion/mailsub&a=editsubscribe&id={$item.scr_id}">�༭</a>  
                 {/if}
                 {if $can_send}<a href="javascript:;" rel="index.php?m=promotion/mailsub&a=sendmagazine&id={$item.scr_id}" onclick="send_mails(this);">Ⱥ���ʼ�</a>{/if}
                  <a href="index.php?m=promotion/mailsub&a=viewshow&id={$item.scr_id}" target="_blank">Ԥ��</a></td>
                </tr>
            {/foreach}        
            </table>
             <div id="pre_page">{$data.page}  </div>
    </form>
    
    {else}
    <div class="notice_msg"><% _e('�޿�������!');%></div>
    {/if}
</div>
{include file="frame_footer.php"}
{/if}
<!--���ӱ༭ ��־-->
{if $action eq 'edit_subs' || $action eq 'add_subs'}
{include file="frame_header.php"}
<div id="php_top_bar" class="php_bot_bar">
    <a href="index.php?m=promotion/mailsub&a=maginelist" class="block_button form_btn">��־�б�</a>
    <a href="index.php?m=promotion/mailsub&a=magazine" class="block_button form_btn">�ʼ��б�</a>
    <a href="javascript:;" onclick="window.location.reload();" class="block_button">ˢ��</a>
    <a href="javascript:;" onclick="submit_form('vvvvv');" class="block_button">����</a>
</div>
<script type="text/javascript">
	$(function(){
		$("#vvvvv").submit(function(){
			var a  = KE.html('content_meg_editor');
			if(empty(a))return window.parent.showNotice('����������!');
			if(!check_form_is_empty('must_fill_in_sub'))return false;
		});
	});
</script>
<form method="post" action="{if $action eq 'edit_subs'}index.php?m=promotion/mailsub&a=editsubscribe{else}index.php?m=promotion/mailsub&a=addsubscribe{/if}" id="vvvvv"  autocomplete="off">
<div id="php_right_main_content">
<div class="table_item_base">
	<h1 class="c_bar">����</h1>
    <div class="c_content">
        <table class="table_common">
            <tr>
                <td class="no_border">
      			  <input type="text" id="title_meg" name="title_meg" value="{$data.scr_title}"  class="form_input must_fill_in_sub w350"/> <samp class="blue">*</samp>
                </td>
            </tr>
        </table> 
    </div>
	<h1 class="c_bar">����</h1>
    	<div class="c_content c_no_border">
        <input type="hidden" value="{$action}"  name="do_action"/>
        <table class="table_common">
            <tr><td class="no_border">{$editor}</td></tr>  
        </table> 
    	</div>
    </div>
</div>
      </form>
{include file="frame_footer.php"}
{/if}