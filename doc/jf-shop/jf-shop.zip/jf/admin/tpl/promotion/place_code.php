<?php exit('die'); ?>
<fieldset class="efieldset">
<legend>�����ȡ����</legend>
<div class="call_ads">
<table class="table_common">
	<tr>
    	<td class="one">��JS����</td>
        <td><textarea  class="etext" onfocus="$(this).select();">{$place.place_js_code_realy}</textarea></td>
    </tr>
	<tr>
    	<td class="one">ģ����JS����</td>
        <td><textarea  class="etext" onfocus="$(this).select();">{$place.place_js_code}</textarea></td>
    </tr>
    <tr>
    	<td class="one">ģ��������</td>
        <td><textarea class="etext" onfocus="$(this).select();">{$place.place_process_code}</textarea></td>
    </tr>
</table>
    </div>
</fieldset>