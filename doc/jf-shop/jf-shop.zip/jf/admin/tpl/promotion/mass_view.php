<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>{$data.title}</title>
<style type="text/css">
	body{ margin:0px; padding:0px; font-size:13px; line-height:normal;}
	.t{ line-height:30px; font-size:2em; text-align:center;}
	.desc{ text-align:center; border:1px solid  #CCC; border-left:none; border-right:none; height:30px; font-size:14px; color:#666; line-height:30px;}
	.ddd_content{ padding:5px 2px;}
</style>
</head>
<body>
{if $action eq 'show_view_action'}
<h1 class="t">{$data.title}</h1>
<div class="desc">
	<strong>���ͣ�</strong>{if $data.type eq '1'}����{elseif $data.type eq '2'}����{/if}   <strong>����ʱ�䣺</strong>{$data.add_time|date_format:"%Y-%m-%d %H:%M:%S"}
</div>
<div class="ddd_content">
	{$data.content}
</div>
{/if}
{if $action eq 'show_log_action'}
{foreach from=$data.data_log item=list key=key}
{$list}<br />
{/foreach}
{/if}
</body>
</html>
