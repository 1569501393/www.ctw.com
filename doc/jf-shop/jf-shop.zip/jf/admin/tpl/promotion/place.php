<?php exit('php'); // this file last modify at 20100524 ?>
{include file="frame_header.php"}
<script language="JavaScript" type="text/javascript">
{foreach from=$lang.place.js_html key=key item=item} var {$key} = "{$item}";{/foreach}
</script>
{if $action eq 'list'}
<script language='javascript'>
var do_ok  = '{$lang.place.delete_success}';
var do_error  = '{$lang.place.delete_fail}';
	function delete_ads_place(obj,id){
		 if(!confirm(ok_delete))return false;
		$.get(obj.rel,function(data){
			switch(data){
				case 'ERROR':
				return window.parent.showNotice(do_error);
				break;
				case 'OK':
					window.parent.showNotice(do_ok);
					$("#place_"+id).remove();
					if($(".place_list_tag").size()<=0)window.location.reload();
				break;
				default:alert(data);
			}
		})
	}
	$(function(){
		close_open_helper('page_helpers','page_show_helper');
		$('#search_place_form').submit(function(){
			var h = _s(this);
			window.location.href=h;
			return false;
		});
	});
</script> 
<form method="post" action="index.php?m=promotion/place&a=placelist" id="search_place_form">
<div id="php_top_bar">
<div class="tb">���ƣ�</div><div class="tb"><input type="text" value="{$place_search_key.name}" name="name" /></div>
<div class="tb">������</div>
<div class="tb">{get_locate assign = 'region'}
<select name="region_id" style="width:150px;"><option value="">��ѡ�����...</option>{foreach from=$region item='list'}
{if $list.son_temp}{foreach from=$list.son_temp item = 'son'}
<option value="{$son.region_id}" {if $place_search_key.region_id eq $son.region_id} selected="selected"{/if}>{$son.p}-{$son.region_name}-{$list.region_main_name}</option>{/foreach}{/if}{/foreach}</select></div>
<div class="tb"><a href="javascript:;" onclick="submit_form('search_place_form');" class="block_button form_btn">����</a></div>
{if $can_add}
<div class="tb"><a href="index.php?m=promotion/place&a=addPlace" class="block_button form_btn">{$lang.place.place_add}</a></div>
{/if}
</div>
 </form>
		<div class="clear"></div>
		<div id="php_right_main_content">
				<div id='show_palces'>
					{if $data.total>0} 
							<table  class="table_list table_list_hover">
								<tr>
                                <th width="50">{$lang.place.th_operation}</th>
									<th>����</th><!-- ���λ���� -->
                                    <th>����</th>
                                    <th>״̬</th>
									<th>����</th><!-- ���λ���� -->
								</tr>
								{foreach from=$data.data item=place key=key}
									<tr class="place_list_tag" id="place_{$place.place_id}" fixed='0'>
                                    <td align='center' nowrap="nowrap">
{if $can_delete}<a tilte='{$lang.place.html_delete}' style="cursor:pointer" href="javascript:;" rel='index.php?m=promotion/place&a=deletePlace&id={$place.place_id}' onclick="return delete_ads_place(this,'{$place.place_id}');">ɾ</a>
{/if}&nbsp;
{if $can_edit}
<a id="{$place.place_id}" href="index.php?m=promotion/place&a=editPlace&id={$place.place_id}" class="edit_img" style="cursor:pointer" title='{$lang.place.html_edit}'>��</a>
{/if}
</td>
										<td nowrap="nowrap"><a href="javascript:;" rel='{$place.place_id}' onclick="call_ads_data(this);">{$place.place_name}</a> <span class="blue ">(�� {$place.total} �� ���� {$place.place_width} X {$place.place_height})</span></td>
                                        <td align="center"><a href="index.php?m=promotion/place&a=placelist&region_id={$place.region_id}">{$place.region_name}</a></td>
                                        <td align="center">{if $place.total_expired>0}<span class="red">��{$place.total_expired}��������</span>{/if}</td>
										<td nowrap="nowrap" class="center">{$place.place_introduce}</td>
									</tr>
								{/foreach}
							</table>
					{$data.page}
					{else}
						<div class="notice_msg">{$lang.place.html_not_place_info}</div><!-- ���޹��λ����������  -->
					{/if}
				</div>
		</div>
<script type="text/javascript">
function call_ads_data(obj){
	var id = $(obj).attr('rel');
	var dom = $("#place_"+id);
	var is_load  = $("#call_ids_"+id);
	if(!is_load.size()){
		$.get('index.php?m=promotion/place&a=callads&id='+id,function(data){
			$(dom).after(data);
		});
	}else{
		if(is_load.is(":visible")){
			$(is_load).hide();		
		}else{
			$(is_load).show();	
		}
	}
}
function delete_ads(obj){
	if(!confirm('ȷ��ɾ���˹����?�˲������ɻָ�!'))return false;
	var id = $(obj).attr('rel'); 
	var j = $(obj).attr('place_id');
	$.get('index.php?m=promotion/place&a=deleteAds&id='+id,function(data){
		var cc = ".aaa_"+id;
		$(cc).remove();
		if(!$('.call_tags_ads').size()){
			$("#call_ids_"+j).hide();
		}
	});
}
</script>
{/if} 
{if $action eq 'add_place' || $action eq 'edit_place' }
<form id='addplace' action="{if $action eq 'add_place'}index.php?m=promotion/place&a=addPlace{else}index.php?m=promotion/place&a=editPlace{/if}" method='post'>
<input type="submit" value="" style="display:none;" />
<div id="php_top_bar" class="php_bot_bar">
    <div class="tb"><a href="javascript:;" onclick="window.location.reload();" class="block_button ">ˢ��</a></div>
    <div class="tb"><a href="javascript:;" onclick="add_new_ads();" class="block_button ">���ӹ��</a></div>
    <div class="tb"><a href="javascript:;" onclick="submit_form('addplace');" class="block_button ">{$lang.place.html_submit}</a></div>
</div>
<div id="php_right_main_content">
<script language='javascript'>
function add_new_ads(){
	$.get('index.php?m=promotion/place&a=load',function(data){
		$("#need_show_pannel").show();		
		$(data).prependTo("#prepend_call_data");
	});	
}
function delete_ads_call(obj){
	if(!confirm('ȷ��ɾ��?'))return false;
	$(obj).parents('.efieldset').remove();
	var id  = $(obj).attr('rel');
	if(id){
		$.get('index.php?m=promotion/place&a=deleteAds&id='+id,function(data){
			
		});		
	}
}
var has_exits = '{$lang.place.hava_placename}'; var empty_place_name = '{$lang.place.hava_placename}';
$(function(){
	$("#addplace").submit(function(){
		if(!check_form_is_empty('must_fill_in')){
			window.parent.showNotice('����д������!');
			return false;
		}
		$(this).ajaxSubmit(function(data){
			data = $.trim(data);
			data = data.split('|');
			switch(data[0]){
				case 'NO_ID':return showNotice("��������!");
				break;
				case 'EMPTY_NAME':
					return showNotice("��������λ����!");
				break;
				case 'HAS_EXIST':
					return showNotice("������ͬ�Ĺ��λ!");
				break;
				case 'ADD_OK':
					window.parent.showNotice("���ӳɹ�,�������Լ�������!");
					window.location.reload();
				break;
				case 'EDIT_OK':
					window.parent.showNotice("�����ɹ�!");
					window.location.href=data[1];
				break;
				default:
				alert(data);
			}
		});
		return false;
	});
});
</script>
<div class="table_item_base">
<h1 class="c_bar">���λ</h1>
<div class="c_content">
<input type="hidden" value="{$place.place_name}" id="old_place_name" />
<table class="table_common">
    <tr>
<td class="one" align='right'>���λ����</td><!-- ���λ���ƣ� -->
        <td align="left" >
<input class="form_input must_fill_in" type='text' value="{$place.place_name}" name='place[placename]' maxlength='25' style="width:350px;" /> <font color='red'>*</font></td>
    </tr>
    <tr >
        <td class="one" align='right'>���λ����</td><!-- ���λ������ -->
        <td align="left"><input type='text'  name='place[place_introduce]' class="form_input"  maxlength="50" value="{$place.place_introduce}" style="width:350px" /></td>
    </tr>
    <tr>
        <td class="one" align="right">��������</td>
        <td>
        {get_locate assign = 'region'}
        <select name="place[region_id]" style="width:360px;">
            <option value="0">��ѡ�����...</option>
            {foreach from=$region item='list'}
                {if $list.son_temp}
                {foreach from=$list.son_temp item = 'son'}
        <option value="{$son.region_id}" {if $place.region_id eq $son.region_id} selected="selected"{/if}>{$son.p}-{$son.region_name}-{$list.region_main_name}</option>
                {/foreach}
                {/if}
            {/foreach}
        </select> 
        </td>
    </tr>
    <tr>
        <td class="one" align='right'>���λ����</td><!-- ���λ���ȣ� -->
        <td align="left"><input title="Ϊ0������"  type='text' onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')"  value="{$place.place_width|default:0}"  name='place[placewidth]' class='form_input input_notice' maxlength='4' style="width:50px;"/> px </td>
    </tr>
    <tr>
        <td class="one" align='right'>���λ�߶�</td><!-- ���λ�߶ȣ� -->
        <td align="left"><input type='text' title="Ϊ0������" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')"  name="place[placeheight]"  value="{$place.place_height|default:0}"  class='form_input input_notice' maxlength='4'  style="width:50px;"/> px</td>
    </tr>	
</table> 
</div>

<!--#�������λ����-->
{if $action eq 'edit_place'}
{include file="promotion/place_code.php"}
{/if}
<!--�����ȡ-->
<script type="text/javascript">
function change_datas(obj){
	var val = $(obj).val();
	var cc = $(obj).parents('tr').next();
		$(cc).find('div.ecall_tags').hide();
		$(cc).find("div.call_"+val).show();
}
</script>
<!--#��ʼ�����������-->
<div id="prepend_call_data">
    {foreach from=$ads_data item='ads' key=key name='name'}
        {include file="promotion/ads_ajax_call.php"}
    {if !$smarty.foreach.name.last}{/if}
    {/foreach}
    </div>
</div>
</div>
</form>

{/if}
{include file='frame_footer.php'}