<?php exit('die'); ?>
{if $action eq 'ajax_call_place_ads'}
<tr id="call_ids_{$data.place_id}">
<td  colspan="30" style="border:none;">
{if $ads_data}
<table class="table_ads_list" id="_called_{$data.place_id}" width="100%">
    <tr  class="_called_{$data.place_id}">
    	<td colspan="5">
        {assign var='place' value=$data}
        {include file="promotion/place_code.php"}</td>
    </tr>
    {foreach from=$ads_data item='list'}
    <tr class="aaa_{$list.ads_id} call_tags_ads">
    	<td valign="middle" colspan="2">{$list.ads_string}</td>
    </tr>
    <tr class="aaa_{$list.ads_id} call_tags_ads" style="background:#fafafa;">
        <td valign="middle">
   	    <p><span>������{$list.w} X {$list.w} PX</span> &nbsp;���ͣ�{if $list.ads_type eq 'image'}ͼƬ{elseif $list.ads_type eq 'text'}�ı�{elseif $list.ads_type eq 'code'}����{elseif $list.ads_type eq 'flash'}FLASH{else} - {/if}  ״̬:{if $list.ads_pass eq '1'}ͨ��{else}<span class="red">����</span>{/if} {if $list.has_expired}<span class="red">�ѹ���</span>{/if}  ʱ�䣺{$list.ads_fromdate|date_format:"%Y-%m-%d %H:%M:%S"} �� {$list.ads_enddate|date_format:"%Y-%m-%d %H:%M:%S"}    <a href="javascript:;" onclick="delete_ads(this);" rel='{$list.ads_id}' place_id"{$data.place_id}" class="blue">ɾ��</a></p>
        </td>
      </tr>
    {/foreach}
</table>
{else}
	�޿��ù��
{/if}
</td>
</tr>
{/if}