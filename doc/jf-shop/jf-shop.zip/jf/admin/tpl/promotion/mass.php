<?php exit('die'); ?>
{include file="frame_header.php"}
<div id="php_top_bar">
<script type="text/javascript">
	$(function(){
		$("#do_post_mass").submit(function(){
			window.location.href= _s($(this));
			return false;
		});
		check_all('do_select_pannel','pannel');
	});
	function delete_select(obj){
		var f = get_checkbox_val('pannel');
		if(!f){
			window.parent.showNotice('��ѡ��Ҫɾ��������!');
			return false;
		}
		if(!confirm('ȷ��Ҫɾ����?�˲������ɻָ�!'))return false;
		$.post('index.php?m=promotion/mass&a=deleteMassList',{ids:f},function(data){
			var val = f.split(',');
			$(val).each(function(i){
				$(".eee_"+val[i]).remove();
				if($('.pannel_tag_tr').size()<=0)window.location.reload();
				/*window.parent.showNotice('�����ɹ�!');*/
			});
		});
	}
</script>
<form method="post" action="index.php?m=promotion/mass&a=list" id="do_post_mass">
<div class="tb">{if $s_type eq 'mail'}�ʼ�{else}����{/if}���⣺</div>
<div class="tb"><input type="text" value="{$eget.ename}"  name="ename" class="w100"/>
<input name="type" type="hidden" value="{if $s_type eq 'mail'}mail{else}mms{/if}" />
</div>
<div class="tb"><input type="submit" class="form_submit" value="����" style="display:none" />
<a href="javascript:;" onclick="submit_form('do_post_mass');"  class="block_button form_btn">����</a>
</div>
	<div class="tb"><a href="index.php?m=promotion/mass&a=masslist"  class="block_button form_btn">�ѷ���־</a></div>
{if $action eq 'send_log'}
	{if $can_send}
	<div class="tb"><a href="index.php?m=promotion/mass&a=sendMassPannel"  class="block_button form_btn">������Ϣ</a></div>
    {/if}
    {if $data.total>0 && $can_delete}
    <div class="tb"><a href="javascript:;" onclick="delete_select(this);" class="block_button form_btn">ɾ����ѡ</a></div>
    {/if}
{/if}
</form>
</div>
{if $action eq 'send_log'}
<div id="php_right_main_content">
    {if $data.total>0}
    <table class="table_list">
        <tr>
            {if $can_delete}<th><input type="checkbox" value="" id="do_select_pannel" /></th>{/if}
            <th>���</th>
            <th>����</th>
            <th>ʱ��</th>
            <th>����</th>
            <th>����</th>
        </tr>
        {foreach from=$data.data item='list'}
        	<tr class="eee_{$list.id} pannel_tag_tr"> 
            	{if $can_delete}<td align="center"><input type="checkbox" value="{$list.id}" class="pannel" /></td>{/if}
                <td align="center">{$list.id}</td>
                <td align="left">{$list.title}</td>
            	<td align="center">{$list.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
                <td align="center">{if $list.type eq '1'}<a href="index.php?m=promotion/mass&a=list&type=mail">�ʼ�</a>{elseif $list.type eq '2'}<a href="index.php?m=promotion/mass&a=list&type=mms">����</a>{/if}</td>
	            <td align="center">
<a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=promotion/mass&a=view&id={$list.id}',950,350,true);">����</a>&nbsp;
<a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=promotion/mass&a=view&type=showlog&id={$list.id}',950,350,true);">{if $list.type eq '1'}�ѷ�����{elseif $list.type eq '2'}�ѷ��ֻ�{/if}</a>
                </td>
            </tr>
        {/foreach}
    </table>
    <div align="center">{$data.page}</div>
    {else}
        <div class="notice_msg">�޿�������!</div>
    {/if}
</div>
{/if}
{if $action eq 'send_pannel'}
<div id="php_right_main_content">
<script type="text/javascript">
	function _show(msg){
		var o = $("#send_pannel_loading");
		$(o).show();
		var emsgs = '<img src="./images/zoomloader.gif" /> ���ڷ��� '+msg;
		if(msg)$(o).html(emsgs);
	}
	function _hide(){
		$("#send_pannel_loading").hide();	
	}
	$(function(){
		$("#send_msg_type").change(function(){
			var v = $(this).val();
			var dd = $(".epanel").hide();
			var cc = $('#'+v+'_content').show();
			switch(v){
				case 'mail':
					$("#call_tag").hide();
				break;
				default:
					$("#call_tag").show();
			}
		});
		$("#do_send_post").submit(function(){
			var type = $("#send_msg_type").val();
			switch(type){
				case 'mms':
					if(!check_form_is_empty('must_fill_tag'))return false;
				break;
				case 'mail':
					if(!check_form_is_empty('must_fill_tag_title'))return false;
					var cct = KE.html('mail_content_editor');
					if(empty(cct)){
						window.parent.showNotice('����д�ʼ�����!');return false;	
					}
				break;
			}
			var v = $("#send_file").val();
			if(empty(v)){
				window.parent.showNotice('��ѡ��Ҫ�ϴ����ļ�!');
				return false;	
			}
			var ext = v.split('.').pop();
			if($.inArray(ext, new Array('txt'))=='-1'){
				cleanFile('send_file');
				window.parent.showNotice('ֻ����txt�����ļ�!');
				return false;
			}
			_show();
			if(!confirm('�����ݶ���ܱȽϺķ�ʱ��,����ִ�й������벻Ҫˢ��ҳ��!\r\nȷ��������?'))return false;
			$(this).ajaxSubmit(function(data){
				data = data.split('|');
				 switch(data[0]){
					case 'OK':
						$("#send_pannel_loading").html('<img src="./images/zoomloader.gif" /> �ϴ��ɹ�,���ڴ�������,�벻Ҫˢ��ҳ��...');
						var u = data[1].replace(/&amp;/g,'&');
						$.get(u,function(data){
							return _send_msg(data);
						});
					break;
					case 'EMPTY_TITLE':
						window.parent.showNotice('����д���ű���!');
					break;
					case 'EMPTY_CONTENT':
						window.parent.showNotice('�����Ϸ��ŵ�����!');
					break;
					case 'EMPTY_FILE_DATA':
						window.parent.showNotcie('��ȷ�����ϴ����ļ����������ȷ!');
					break;
					case 'ERROR':
						window.parent.showNotcie(data[1]);
					break;
					default:alert(data);
				 }
				 cleanFile('send_file');
			});
			return false;
		});
	});
	function _send_msg(data){
		data = data.replace(/&amp;/g,'&').split('|');
		switch(data[0]){
			case 'SEND_OK':
				_hide();
				window.parent.showNotice('���ͳɹ�!');
				window.location.reload();
				return true;
			break;
			case 'SEND_OK_HAS_LOG_FILE':
				var msg = '�����ɹ�! <strong>����δ���ͳɹ�������</strong>! <a href="'+data[1]+'" target="_blank">��˲鿴</a> ';
				$("#send_pannel_loading").html(msg);
				$('.must_fill_tag').val('');
			break;
			case 'NEXT':
				var o = $("#send_pannel_loading");
				$(o).show();
				var emsgs = '<img src="./images/zoomloader.gif" />'+data[1];
				$(o).html(emsgs);
				if(data[2]){
					$.get(data[2],function(data){
						_send_msg(data);
					});		
				}				
			break;
			default:alert(data);
		}
	}
</script>
<div class="notice_msg" id="send_pannel_loading" style="display:none; height: auto; overflow:hidden;">
	<img src="./images/zoomloader.gif" /> ������,�벻Ҫˢ��ҳ��...
</div>
<div class="table_item_base">
	<h1 class="c_bar">{if $s_type eq 'mail'}Ⱥ���ʼ�{else}Ⱥ������{/if}</h1>
    <div class="c_content">
<form method="post" id="do_send_post" enctype="multipart/form-data" action="index.php?m=promotion/mass&a=sendMassPannel" autocomplete="off">
	<table class="table_common">
    	<tr>
        	<td class="one">�ϴ��ļ�</td>
            <td><input type="file" value=""  name="send_file" id="send_file" />
            <p class="blue">�ı��ļ�(*.txt),һ��һ��</p>
            </td>
        </tr>
    	<tr>
        	<td class="one">��������</td>
            <td>{if $s_type eq 'mail'}Ⱥ���ʼ�{else}Ⱥ������{/if}<input name="send_type" id="send_msg_type" type="hidden" value="{if $s_type eq 'mail'}mail{else}mms{/if}" />
            </td>
        </tr>
    	<tr>
        	<td class="one">��������</td>
            <td>
            <input type="checkbox" value="1" checked="checked" name="is_save" />
            </td>
        </tr>
        <tr>
        	<td class="one">���ű���</td>
            <td><input type="text" value="" class="must_fill_tag must_fill_tag_title form_input" style="width:190px;"   maxlength="200" name="title"/> <span class="blue"> * </span></td>
        </tr>
    	<tr>
        	<td class="one" id="call_tag">��������</td>
            <td colspan="2">
            	<div id="mms_content" class="epanel"{if $s_type eq 'mail'} style="display:none"{/if}>
                <textarea name="mms_content" class="must_fill_tag seo_set"></textarea> <span class="blue"> * </span>
                <div class="clear"></div>
                <span class="desc">�������ݽ��鲻Ҫ����!</span>
                </div>
             	<div id="mail_content" class="epanel" {if $s_type neq 'mail'}style="display:none;"{/if}>{$editor}</div>

            </td>
        </tr>
        <tr>
        	<td class="one"></td>
        	<td><input type="submit" value="����" class="form_submit" style="display:none;" />
            	<a href="javascript:;" onclick="submit_form('do_send_post');" class="block_button form_btn">����</a>
            </td>
        </tr>
    </table>
</form>
</div>
</div>
{/if}
{include file="frame_footer.php"}