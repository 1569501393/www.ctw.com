<?php if (! defined ( 'PHP_TEMPLATE' ))exit ();?>
{if $action == 'list'}
{include file="frame_header.php"}
<script language="JavaScript">
{foreach from=$lang.side.js_html key=key item=item}var {$key} = "{$item}";{/foreach}
function delete_slide(obj,id){
	if(!confirm(ok_delete))return false;
	$.get('index.php?m=promotion/slide&a=slidedelete',{id:id},function(data){
		switch(data){
			case 'OK':
				$("#dd_"+id).remove();
				if($('.d_ids').size()<=0){window.location.reload();}
			break;
			default:alert(data);
		}
	});
}
</script>
{/literal}
<div id='php_top_bar'><!-- ������ʾ������Ϣ -->
    <div class="top_bar_pannel">
    <div class="tb"><% _e('�õ�Ƭ���飺');%></div>
    <div class="tb">
    <select style="width:200px" onchange="window.location.href='index.php?m=promotion/slide&group='+$(this).val()">
    <option value=""><% _e('��ѡ��...');%></option>
    {foreach from=$slide_group key=key item=group}
    <option {if $key eq $get.group} selected="selected"{/if} value="{$key}">{$group}</option>
    {/foreach}
    </select>
    </div>
    <div class="tb"><a href="javascript:;"  onclick="window.parent.showWindow($(this).html(),'index.php?m=promotion/slide&a=addSlide',900,400)" class="block_button form_btn"><% _e('���ӻõ�Ƭ');%></a></div>
    </div>
</div>
<div id="php_right_main_content">
	{if $playerdb.total>0}
		  <table class='table_list' id="img_list">
				<tr>
					<th>{$lang.side.th_operation}</th>
                    <th>{$lang.slide.group}<!--����--></th>
					<th>{$lang.side.th_img_address}</th>
					<th>{$lang.side.th_url_link}</th>
                    <th>{$lang.side.th_title}</th>
					<th>{$lang.side.th_img_descption}</th>
                    
				</tr>
				{foreach from=$playerdb.data item=item key=key}
					<tr class="d_ids" id="dd_{$item.id}">
                   <td align='center' width="40" style="width:40px;"><a href="javascript:;" onclick="delete_slide(this,'{$item.id}')" title="{$lang.side.html_delete}"><% _e('ɾ');%></a>  <a  href="javascript:;" rel="{$lang.side.html_edit}" onclick="window.parent.showWindow($(this).attr('title'),'index.php?m=promotion/slide&a=editSlide&id={$item.id}',950,400);" title="<% _e('�༭�õ�Ƭ');%>"><% _e('��');%></a> </td>
                   <td align="center"><a href="index.php?m=promotion/slide&group={$item.slide_group}">{$item.slide_group_name}</a></td>
                        <td height="28"><a href="{$php_site_url}{$item.src}" target="_blank" class="slide_show" rel="{$php_site_url}{$item.src}">{$item.src}</a></td>
					  <td><a href='{$item.url}' target="_blank">{$item.url}</a></td>
                      <td>{$item.title}</td>
						<td>{if $item.text}{$item.text|truncate:20:'...'}{/if}</td>
					</tr>
				{/foreach}
			</table>
		<div class="clear"></div>
        {$playerdb.page}
<script type="text/javascript">
	$(function(){
		$.hoverpic('slide_show');
	});
</script>
	{else}
		<div align='center' class="notice_msg">{$lang.side.not_img_descption}</div><!-- ����ͼƬ,�������� -->
	{/if}
 			</div>
		</div>
	</div>
    {include file="frame_footer.php"}
{/if}<!--end list action-->
{if $action == 'edit_slide' || $action =='add_slide'}
{include file='part.js.php'}
<script language="javascript">
$(document).ready(function(){
	$("#img_file_src").upload({
		filename:'slide_upload_file',
		post_params:{'sid':session_id},
		url:'index.php?m=promotion/slide&a=ajaxUpload',
		sucess:function(file,response){
				try{
				var call_back_msg = response.split('|');
				var error = call_back_msg[0];
				var msg = call_back_msg[1]
				switch($.trim(error)){
					case '1':
						window.parent.showNotice(msg);
						return false;
					break;
					case '2':
						$("#slide_upload_image_id").val(call_back_msg[2]);
						$("#slide_image_src").html(' <img src="../picture.php?s='+call_back_msg[1]+'&w=650&h=200&rand='+Math.random()+'"/>');
					break;
					default:alert(!empty(response)?response:System_overtime);return false;
				}
			}catch(e){alert(e);}
		}//end function
	});
});
	<!--form action-->
$("#slide_form").submit(function(){
	$(this).ajaxSubmit({success:function(data){
			data = $.trim(data);
			var callback = data.split('|');	
			switch(callback[0]){
				case '1':
					window.parent.showNotice(callback[1]);
				break;
				case 'EDIT_OK':
					showNotice(php_do_ok);
					<!--ˢ���ӿ��-->
					window.frames['rightFrame'].location.reload();
					hidenLayer();
					return false;
				break;
				case 'ADD_OK':
				window.parent.showNotice(php_do_ok);
				$("#slide_image_src").empty();
				$(".clear_empty").val('');
				window.frames['rightFrame'].location.reload();
				break;
				default:alert(data);return false;
			}
		}
	});
	return false;
});
</script>
<div class="table_item_base">
<h1 class="c_bar">Ԥ��</h1>
    <div class="c_content">
    	<div id="slide_image_src" style="padding:0px; text-align:center;"> <img src="../picture.php?s={$data.src}&w=650&h=200" /></div>
    </div>
<h1 class="c_bar">����</h1>
    <div class="c_content">
<form id="slide_form" method="post" autocomplete="off" action="{if $action eq 'edit_slide'}index.php?m=promotion/slide&a=editSlide{else}index.php?m=promotion/slide&a=addSlide{/if}" class='sub_com'>
    <table class="table_common">
        <tr>
            <td class="one">�ϴ�</td>
            <td align="left">
            <span id="img_file_src"></span>
            <input type="hidden" value="{$data.src}" id="slide_upload_image_id" class="clear_empty" name="slide_upload_image"/>
            </td>
        </tr>
        <tr>
            <td class="one">{$lang.slide.group}</td>
            <td align="left">
            <select name="slide_group"  class="w300">
                {foreach from=$slide_group key=key item='group'}
                    <option {if $key eq $data.slide_group} selected="selected"{/if} value="{$key}">{$group}</option>
                {/foreach}
                </select></td>
        </tr>
        <tr>
            <td class="one">����</td><!-- ͼƬ���ӣ� -->
            <td >
            <input id='img_src' class="form_input w300 clear_empty " type='text' name='img_src' value="{$data.url}"/></td>
        </tr>
            <tr>
            <td class="one"><% _e('����');%></td><!-- ͼƬ���ӣ� -->
            <td >
            <input id='img_src' class="form_input w300 clear_empty" type='text' name='sort'   value="{$data.sort|default:0}"/></td>
        </tr>
        <tr>
            <td class="one">{$lang.side.th_title}</td>
            <td align="left"><input type="text" class="form_input w300 clear_empty" value="{$data.title}"  name="title"/></td>
        </tr>
        <tr>
            <td class="one">����</td>
            <td align="left">
            <textarea id='text'  class="seo_set clear_empty" name='text'  >{$data.text}</textarea>
            <span class="desc"><% _e('�������250���ַ�!');%></span>
            </td>
        </tr>
            <tr>
            <td class="one"></td>
            <td><input id='sub' class="form_submit form_btn" type="submit"  value="{$lang.side.html_submit}" style="display:none;" />
                <a href="javascript:;" onclick="submit_form('slide_form');" class="block_button form_btn">{$lang.side.html_submit}</a>
            </td>
        </tr>
    </table>
    {if $action eq 'edit_slide'}
        <input type='hidden' name='id' value='{$editid}' />
    {/if}
</form>
</div>
</div>

{/if}