<?php exit('die'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>{$data.scr_title}</title>
<style type="text/css">
	body{ margin:0px auto; padding:0px;}
</style>
</head>
<body>
<h1 align="center">{$data.scr_title}</h1>
<hr />
<div>
 {$data.scr_content}
</div>
</body>
</html>
