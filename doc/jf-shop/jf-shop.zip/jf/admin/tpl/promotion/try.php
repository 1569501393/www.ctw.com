<?php exit('try_list'); ?>
<!---��Ʒ�����嵥-->
{if $action eq 'default_list'}
{include file="frame_header.php"}
<div id="php_top_bar">
<div class="tb"><a onclick="window.parent.showWindow('����������Ʒ','index.php?m=promotion/try&a=producttry&task=add',900,440);"  class="block_button form_btn">����</a></div>
<div class="tb">
<a href="javascript:;" onclick="return window.parent.showWindow($(this).html(),'index.php?m=promotion/try&a=config','750','300');" class="block_button form_btn">����</a> <!--��ǰ״̬-->
{if $data}
	<a href="javascript:;" onclick="delete_try();" class="block_button form_btn">����ɾ��</a>
{/if}
</div>
<div class="tb">{$lang.try.curent_status}</div>
<div class="tb"><samp class="blue">{if $is_close}{$lang.try.close}{else}{$lang.try.open}{/if}</samp></div>
</div>
<div id="php_right_main_content">
{if $data}
<script type="text/javascript">
	function edit_try_list(id){
		window.parent.showWindow('�༭������Ʒ','index.php?m=promotion/try&a=producttry&task=edit&id='+id,900,400);
	}
	function delete_try(){
		var c = get_checkbox_val('cc_try');
		if(!c){
			window.parent.showNotice('��ѡ��Ҫ�����Ķ���!');return false;
		}
		if(!confirm('ȷ��ɾ����?\r\n�˲������ɻָ�!'))return false;
		$.post('index.php?m=promotion/try&a=producttry&task=delete',{ids:c,action:'delete'},function(data){
			switch(data){
				case 'OK':
					ec = c.split(',');
					var id;
					$(ec).each(function(i){
						id = ec[i];
						$("#tag_"+id).remove();				
					});
					window.parent.showNotice(php_do_ok);
					if(!$('.try_list_tr').length)window.location.reload();
				break;
				default:alert(data);
			}
		});
	}
	$(function(){
		check_all('cc_try','cc_try');
	});
    </script>
<table class="table_list">
	<tr>
    	<th width="40"><input type="checkbox" value=""  id="cc_try"/></th>
    	<th width="40">{$lang.try.index}</th>
    	<th><!--����-->{$lang.try.name}</th>
    	<th>{$lang.try.add_time}</th>
    	<th>����</th>
    </tr>
{foreach from=$data item=list key=key}
    <tr class="try_list_tr" id="tag_{$list.goods_id}">
    	<td align="center"><input type="checkbox" value="{$list.goods_id}" class="cc_try" /></td>
    	<td align="center">{$key+1}</td>
        <td align="center">{$list.goods_name}</td>
         <td align="center">{$list.goods_add_time|date_format:"%Y-%m-%d"}</td>
         <td align="center"><a href="javascript:;" onclick="edit_try_list('{$list.goods_id}');">��</a></td>
    </tr>
    {/foreach}
</table>
{else}
<div class="notice_msg">{$lang.php_nodata}</div>
{/if}
</div>
{include file="frame_footer.php"}
{/if}
<!--#end action list-->
{if $action eq 'add' || $action eq 'edit'}
<script type="text/javascript">
$(function(){
	$("#do_submit_form").submit(function(){
		if(!check_form_is_empty('must_fill_in'))return false;
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'EMPTY':
					return window.parent.showNotice('{$lang.try.must_fille_info}');
				break;
				case 'ERROR':
					return window.parent.showNotice(php_die);
				break;
				case 'OK':
					window.parent.showNotice(php_do_ok);
					_close_window_one();
					_reload_frame();
				break;
				default:alert(data);
			}
		});
		return false;
	});
});
</script>
<form method="post" action="index.php?m=promotion/try&a=producttry" id="do_submit_form" autocomplete="off">
<input type="hidden" value="{$action}" name='action' />
	<table class="table_common">
    	<tr>
        <td class="one">{$lang.try.name}</td>
        <td><input type="text" value="{$data.goods_name}"  name="goods_name" class="must_fill_in w300"/><font class="blue"> * </font></td>
        </tr>
    	<tr>
        <td class="one">{$lang.try.pics}</td>
        <td valign="middle">
		<div class="thumb_pic" >      
        <img src="../picture.php?s={$data.goods_source_pic}&w=120&h=150" />
        </div>
        <div class="thumb_upload">
        <input type="text"  value="{$data.goods_source_pic}"  name="pic" class="w300" id="do_product_pic"/> <input type="button" value="{$lang.try.select_pics}" onclick="showDialog($('#do_product_pic'),'index.php?m=file');" class="form_submit" /></div>
        </td>
        </tr>
    	<tr>
        <td class="one"><!--�������-->{$lang.try.short_desc}��</td>
        <td>
        	<textarea name="content" class="seo_set">{$data.goods_name}</textarea>
        </td>
        </tr>
        <tr>
        	<td class="one"></td>
        	<td><input  type="submit" value="{$lang.php_save}" class="form_submit" style="display:none;"/><a href="javascript:;" onclick="submit_form('do_submit_form');" class="block_button form_btn">����</a></td>
        </tr>
    </table>
</form>
{/if}
{if $action eq 'config'}
<script type="text/javascript">
	$(function(){
		$("#config_try").submit(function(){
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						close_window();
						window.parent['rightFrame'].location.reload();
						return window.parent.showNotice(php_do_ok);
					break;
						default:alert(data);	
				}
			});
			return false;
		});
	});
</script>
<form method="post" action="index.php?m=promotion/try&a=config" id="config_try" autocomplete='off'>
	<table class="table_common">
    	<tr>
        	<td class="one"><!--�Ƿ�����-->{$lang.try.is_open}</td>
            <td><select name="is_close" class="w300">
            	<option value="0" {if $data.is_close neq '1'} selected="selected"{/if}>{$lang.try.close}</option>
            	<option value="1" {if $data.is_close eq '1'} selected="selected"{/if}>{$lang.try.open}</option>
            </select> <!--Ĭ�Ϲر�-->{$lang.try.default_close}</td>
        </tr>
        <tr>
        	<td class="one"><!--ÿ��������Ʒ������-->{$lang.try.every_day_goods_info}</td>
            <td class=""><input type="text" onkeyup="value=value.replace(/[^\d]/g,'') " onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))" value="{$data.free_number|default:'0'}"  class="w300" name="free_number"/></td>
        </tr>
        <tr>
        	<td class="one"><% _e('��̽���');%></td>
            <td>
            <textarea name="short_info" class="seo_set">{$data.short_info}</textarea>
            </td>
        </tr>
        <tr>
        	<td class="one"></td>
            <td>
            <input style="display:none;" type="submit" value="{$lang.php_save}" class="form_submit" />
            <a href="javascript:;" onclick="submit_form('config_try');" class="form_btn block_button">����</a>
            </td>
        </tr>
    </table>
</form>
{/if}
{if $action eq 'try_list'}
{include file="frame_header.php"}
<div id="php_top_bar">
<script type="text/javascript">
	$(function(){
		$("#do_try_list").submit(function(){
			window.location.href=_s(this);
			return false;
		});
	});
</script>
<form method="get" action="index.php?m=promotion/try&a=trylist" id="do_try_list" autocomplete="off">
&nbsp;&nbsp;<% _e('��ʼʱ��');%>��<input  type="text" name="start" value="{$try_search_list.start}" class="date date_input"  onfocus="show_date(this);" />
 <label><% _e('����ʱ��');%>��<input type="text" value="{$try_search_list.end}"  name="end" class="date date_input" onfocus="show_date(this);" /></label>
 <label>
<select  name="do_tag">
	<option value=""><% _e('��ѡ��...');%></option>
    <option value="un_do" {if $try_search_list.do_tag eq 'un_do'} selected="selected"{/if}>δ����</option>
    <option value="has_do" {if $try_search_list.do_tag eq 'has_do'} selected="selected"{/if}>�Ѵ���</option>
</select>
</label>
<input  type="submit"  value="{$lang.php_search}" class="form_submit" />
</form>
</div>
<div id="php_right_main_content">
{if $data}
<script type="text/javascript">
	$(function(){
		checkAllFormData('select_all','select_all');
		$("#submit_forms").submit(function(){
			var d = $("#do_action").val();
			var val = get_checkbox_val('select_all');
			if(empty(val)){
				val = null; return window.parent.showNotice(php_empty_select);	
			}
			if(d=='delete' && !confirm("<%  _e('ȷ��Ҫɾ����?�˲������ɻָ�!');%>"))return false;	
		});
	});
	function view_detail(obj){
		var id = $(obj).attr('rel');
		var abc = '.append_try_tag_'+id;
		var j = $(".all_need_hide_try");
		if($(abc).length){
			//j.hide();
			$(abc).show();	
			return ;
		}
		$.get('index.php?m=promotion/try&a=ajaxcall',{id:id},function(data){
			//j.hide();
			$("#cls_"+id).after(data);
		});
	}
	function close_try(obj){
		var c = '.append_try_tag_'+$(obj).attr('rel');
		$(c).hide();
	}
</script>
<form method="post" action="index.php?m=promotion/try&a=trylist" id="submit_forms">
	<table class="table_list">
    	<tr>
        	<th width="30"><input type="checkbox" value="" id="select_all" /></th>
        	<th width="30"><% _e('���');%></th>
            <th><% _e('������');%></th>
            <th><% _e('״̬');%></th>
            <th><% _e('��Ʒ����');%></th>
            <th><% _e('����ʱ��');%></th>
			<th><% _e('����ʱ��');%></th>
			<th width="50"><% _e('����');%></th>
        </tr>
{foreach from=$data item=list key=key}
    	<tr id="cls_{$list.id}">
			<td class="center"><input type="checkbox" value="{$list.id}" name="ids[]" class="select_all"/></td>
        	<td align="center">{$key+1}</td>
             <td align="center">{$list.compay_name}</td>
             <td align="center">{if $list.status eq '0'}<font class="blue"><% _e('δ����');%></font>{elseif $list.status eq '1'}<% _e('�Ѵ���');%>{else}N/A{/if}</td>
             <td align="center">{$list.goods_name}</td>
			<td align="center">{$list.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
			<td align="center">{$list.opt_time|date_format:"%Y-%m-%d %H:%M:%S"}</th>
			<td align="center"><a href="javascript:;"  onclick="view_detail(this);" rel="{$list.id}" ><% _e('����');%></a></td>
        </tr>
{/foreach}
    </table>
<div class="spacer"></div>
<div>
	<select name="do_action" id="do_action">
    	<option value="do_ok"><% _e('���ó��Ѵ���');%></option>
    	<option value="delete"><% _e('ɾ����ѡ');%></option>
    	<option value="unok"><% _e('���ó�δ����');%></option>
    </select>
<input type="submit" class="form_submit" value="<% _e('������ѡ');%>" />
</div>
</form>
{else}
<div class="notice_msg">{$lang.php_nodata}</div>
{/if}
</div>
{include file="frame_footer.php"}
{/if}
{if $action eq 'ajaxcall'}
	<tr class="append_try_tag_{$data.id} all_need_hide_try">
    	<td colspan="10">
<div class="append_try_data">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
    <td class="a"><% _e('��˾����');%></td>
    <td>{$data.compay_name}</td>
	<td class="a"><% _e('��˾��ַ');%></td>
    <td>{$data.e.cp_address}</td>
    <td class="a"><% _e('��˾������');%></td>
    <td>{$data.e.cp_members}</td>
    <td class="a"><% _e('����Ʒ����Ĳ���');%></td>
    <td>{$data.e.eat_party_for_shenqing}</td>
</tr>
<tr>
    <td class="a"><% _e('Ʒ���ص�');%></td>
    <td>{$data.e.cp_eat_adress}</td>
	<td class="a"><% _e('�μӻ������');%></td>
    <td>{$data.e.party_members}</td>
    <td class="a"><% _e('�ʱ��');%></td>
    <td>{$data.e.party_time}</td>
	<td class="a"><% _e('���������ڵĲ���');%></td>
    <td>{$data.e.you_partment}</td>
</tr>
<tr>
    <td class="a"><% _e('���������ڵ�ְλ');%></td>
    <td>{$data.e.you_jobs}</td>
	<td class="a"><% _e('����������');%></td>
    <td>{$data.e.you_name}</td>
    <td class="a"><% _e('�����߰칫�绰');%></td>
    <td>{$data.e.you_telphone}</td>
	<td class="a"><% _e('�������ֻ�');%></td>
    <td>{$data.e.you_mobile}</td>
</tr>
<tr>
	<td class="a"><% _e('����������');%></td>
    <td colspan="7">{$data.e.you_email}
		<input type="button" value="<% _e('�ر�');%>" rel="{$data.id}" onclick="close_try(this);"  class="form_submit" /></td>
</tr>
</table>
</div>
        </td>
    </tr>
{/if}