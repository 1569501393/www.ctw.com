<?php  if(!defined('PHP_TEMPLATE'))exit();?>
{if $action eq 'addcouponrule' || $action eq 'editcouponrule'}
{include file="frame_header.php"}
<script type="text/javascript">
  $(function(){		
	var url=$("#operate_rule").attr('action');		
	$(".fav_type_class").click(function(){
			var keyid="#fav_"+$(this).val();					
			$("p[id^='fav_']").hide();
			$(keyid).show();
	});
	$("#fav_number").blur(function(){
		var fav_number=	$(this).val();
		if($.trim(fav_number)=="") return false;
		$.post(url,{'fav_number':fav_number,'type':'check'},function(data){
			if($.trim(data)=='exist'){
			  
			}
		});	   
	});				
	$("#operate_rule").submit(function(){	
		if(!check_form_is_empty('must_counp_input')){
			window.parent.showNotice('��д������!');
			return false;	
		}
		var fav_name=$("#fav_name").val();
		var fav_number=$("#fav_number").val();				
		var fav_level=$(".fav_level_class").val();
		var fav_type=$("#fav_type_class").val();
		var fav_money=$("#fav_money").val();
		var cc_start_obj = $("#coupon_begain_time");
		var cc_end_obj = $("#coupon_end_time");
		var coupon_begain_time=cc_start_obj.val();
		var coupon_end_time=cc_end_obj.val();
		
		var c_start = strtotime(coupon_begain_time);
		var c_end = strtotime(coupon_end_time);
		if(c_end<=c_start){
			window.parent.showNotice("����ʱ�����ȿ�ʼʱ���!");
			cc_start_obj.val('');
			cc_end_obj.val('');
			return false;	
		}
		var min_money=$("#min_money").val();
		var max_money=$("#max_money").val();
		var fav_ration=$("#fav_ration").val();
		var fav_type=$(".fav_type_class").val();			
		if(fav_name.length==0) {$("#fav_name").addClass('empty_input_val');return false;}				
		if(fav_number.length==0){$("#fav_number").addClass('empty_input_val');return false;}
		if(fav_money.length==0 && fav_type==1){$("#fav_money").addClass('empty_input_val');return false;}
		if(fav_level.lenght==0){return false;}
		if(min_money.length==0){$("#min_money").addClass('empty_input_val');return false;}				
		if(max_money.length==0){$("#max_money").addClass('empty_input_val');return false;}
		if(coupon_begain_time==0){$("#coupon_begain_time").addClass('empty_input_val');return false;}
		if(coupon_end_time==0){$("#coupon_end_time").addClass('empty_input_val');return false;}				
		if(fav_ration.length==0 && fav_type==2){$("#fav_ration").addClass('empty_input_val');return false;}
		$(this).ajaxSubmit(function(data){											
				switch($.trim(data)){
					case "ok":
					  window.parent.showNotice("�����ɹ�");	
					   window.location.reload();
					   window.location.href='index.php?m=promotion/coupon&a=couponList';
					  //location.href=url;
					  break;
					case "no":
					  window.parent.showNotice("û�в����ɹ�����������д");
					  break; 
					case "null":
					  window.parent.showNotice("�б�����Ϊ�գ���������д");
					  break;
					case "dateerror":
					  window.parent.showNotice("ʱ�����ò���ȷ");
					  break;
					default:
					 window.parent.showNotice("�����ɹ�");
					 window.location.href='index.php?m=promotion/coupon&a=couponList';
					 //window.location.reload();
					  break
				}		
		})	;
		return false;
		
	});
});
  function create_count_no(obj){
	 $.get('index.php?m=promotion/coupon&a=callcode',function(data){
		 $(obj).prev().val(data);	
	 });
  }
function check_number(obj){
	var value=obj.value;
	var patrn=/^[0-9]*\.{0,1}[0-9]{0,2}$/; 
	if (!patrn.exec(value)) {
		obj.value=0;
		return false;
	}else{
		if(value<0) obj.value=0;
	}
} 
</script>
<form name="operate_rule" id="operate_rule" method="post" action="{if $action eq 'addcouponrule'}index.php?m=promotion/coupon&a=madecouponrule{else}index.php?m=promotion/coupon&a=editcouponrule{/if}" autocomplete="off">
<div id="php_top_bar" class="php_bot_bar">
<div class="tb"><a href="javascript:;" class="block_button form_btn" onclick="window.location.reload();">ˢ��</a></div>
<input type="submit"  class="form_submit" value="����" style="display: none;"/>
<div class="tb"><a href="javascript:;" onclick="submit_form('operate_rule');" class="block_button form_btn">����</a></div>
</div>
<div id="php_right_main_content">
<div class="table_item_base">
	<h1 class="c_bar">��������</h1>
        <div class="c_content">
    <input type="hidden" name="type" value="{$type}">
    <input type="hidden" name='id' value="{$coupon_type_data.coupon_id}" />
    <table class="table_common">
    <tr>
        <td  class="one">�Ż�����</td>
        <td><input type="text" name="fav_name" style="width:200px;" id="fav_name" value='{$coupon_type_data.coupon_name}' class="must_counp_input" /> <span class="blue"> * </span></td>
    </tr>
    <tr>
        <td class="one">��־��</td>
        <td id="fav_number_text">
        <input class="must_counp_input"  type="text" name="fav_number" style="width:200px;" id="fav_number" value="{$coupon_type_data.coupon_number}"/>
        <input type="button" value="���ɱ�־��" onclick="create_count_no(this);" class="form_submit" /> <font class="blue">*</font></td>
    </tr>
    <tr>
        <td class="one">��Ա����</td>
        <td>
        <div  class="counp_list_tag">
        <div class="pp">
        ��Ա�ȼ� 
        {if $mem_level|@count neq 0 }
            {foreach from = $mem_level name=name item=item}
             {$item.level_name} 
             <input type="checkbox" name="fav_level[]" value="{$item.level_id}" class="fav_level_class"  {if $item.checked eq '1'}checked{/if}/>  
            {/foreach}
        {/if}
        </div>
        <div class="pp">
        ��&nbsp;��&nbsp;�� <input type="text" name="username" value="{$coupon_type_data.mem_type.name}"/>
        </div>
        <div class="pp">
        ���ִ��� <input type="text" name="point" value="{$coupon_type_data.mem_type.point}"  onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboarddata.setdata('text',clipboarddata.getdata('text').replace(/[^\d]/g,''));"/>
        </div>
        <div class="pp">
        ע��ʱ�� <input type="text" name="reg_time_start" class="select_date_time promotion_tags date date_input" id="reg_time_start"  onfocus="show_date(this)" value="{$coupon_type_data.mem_type.reg_time_start}"/>&nbsp;��&nbsp;<input type="text" name="reg_time_stop" class="select_date_time promotion_tags date date_input" id="reg_time_stop"  onfocus="show_date(this)" value="{$coupon_type_data.mem_type.reg_time_stop}"/>
        </div>
        </div>
        </td>
    </tr>
    <tr>
        <td class="one">�Żݷ�ʽ</td>
        <td>
        ����ȯ <input type="radio" name="fav_type" value="1" class="fav_type_class"  {if $coupon_type_data.coupon_type neq 2}checked="checked"{/if} />
         ���ȯ <input type="radio" name="fav_type" value="2" class="fav_type_class" {if $coupon_type_data.coupon_type eq 2}checked{/if}/>
        <div>
         <p id='fav_1' {if $coupon_type_data.coupon_type eq 2} style="display:none;"{/if}> �ɴ����� <input type="text" name='fav_text1' id='fav_money' value="{if $coupon_type_data.coupon_fav_replace neq ""}{$coupon_type_data.coupon_fav_replace}{else}0{/if}"  onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboarddata.setdata('text',clipboarddata.getdata('text').replace(/[^\d]/g,''));" />Ԫ <font class="blue"> * </font>�������ܶ����ȥָ��������Ϊ����</p> 
         <p id='fav_2' {if $coupon_type_data.coupon_type neq 2}style="display:none"{/if}>��۱��� <input class="must_counp_input"  type="text" name='fav_text2' id='fav_ration' value="{if $coupon_type_data.coupon_fav_ration neq ""} {$coupon_type_data.coupon_fav_ration}{else}9.5{/if}" onblur="check_number(this);"/> <font class="blue">*</font>  �����8.5�ۣ���д8.5 ���Ϊ10Ϊ������.Ϊ��Ҳ�ǲ�����</p>
        </div> 
        </td>
    </tr>
    <tr>
        <td class="one">ʹ�÷�ʽ</td>
        <td>
        <div class="pp">�ظ�ʹ�÷�ʽ <input type="radio" name="action_type" value="1" class="action_type_class" {if $coupon_type_data.coupon_activ_type eq 1}checked="checked" {/if}/>  ����Чʱ���ڿ���ʹ�ö��,һ��ֻ������һ��������
        </div>
        <div class="pp">
        ����ʹ�÷�ʽ <input type="radio" name="action_type" value="2" class="action_type_class"  {if $coupon_type_data.coupon_activ_type neq 1}checked="checked" {/if}/> ����Чʱ���ڿ���ʹ��һ��,һ��ֻ������һ��������</div>
        </td>
    </tr>
    <tr>
    <td class="one">��Ч��ʱ��</td>
    <td>
    <% _e("��ʼʱ��:");%><input type="text"    id="coupon_begain_time"  class="select_date_time promotion_tags must_counp_input date date_input" name="coupon_begain_time"  onfocus="show_date(this,true,true)" value="{$coupon_type_data.starttime|date_format:'%Y-%m-%d %H:%M:%S'}" /> 
     - <% _e("����ʱ��:");%>
     <input type="text" id="coupon_end_time"    class="select_date_time promotion_tags must_counp_input date date_input"  name="coupon_end_time"  onfocus="show_date(this,true,true)" value="{$coupon_type_data.stoptime|date_format:'%Y-%m-%d %H:%M:%S'}" />
     <span><font class="blue">*</font>�Ż�ȯ��Ч��ʱ������</span>
     </td></tr>
    <tr><td class="one">���ѽ��</td>
    <td><span>
    �������:&nbsp;<input type="text" name="min_money" id="min_money" value="{$coupon_type_data.min_money|default:'50'}"  onblur="check_number(this);"/>Ԫ</span>&nbsp;-&nbsp;<span>�������:
    <input type="text" name="max_money" id="max_money"  value="{$coupon_type_data.max_money|default:'2000'}" />Ԫ</span><span>&nbsp;&nbsp;&nbsp;<font class="blue">*</font> �����ܶ��������������ʱ������Ч</span>
    </td>
    </tr>
    </table>
    </div>
</div>
</div>
</form>
{include file="frame_footer.php"}
{/if}

{if $action eq 'coupon_type_list'}
{include file="frame_header.php"}
<script type="text/javascript" language="javascript">
  $(function(){
  	checkAllFormData('check_all','check_item_class');
  }); 
  /*ɾȫ�ֹ���*/
  function delete_all_rule(){
	   var varles= get_checkbox_val('check_item_class');
	   var e__msg = "��ѡ������һ��";
	   if(!varles)return window.parent.showNotice(e__msg);
	   if(!confirm("ɾ���˹����ͬʱҲ��ɾ�������µ������Ż�ȯ�Ҳ��ɻָ�,ȷ��ɾ����?"))return false;
       $.post('index.php?m=promotion/coupon&a=couponList',{deltype:'delrule',check_item:varles},function(data){
		switch($.trim(data)){
			case 'OK':
				window.location.reload();
				window.parent.showNotice(php_do_ok);
			break;
			case 'EMPTY':
				window.parent.showNotice(e__msg);
			break;
			default:alert(data);
		}	
	  });
  }
	function send_r(id){
		if(!confirm('��֮ǰ���͹�����ȯ,�˲�������ɾ�����д˹����µĹ���ȯ\n����������,�ȽϺķ���Դ,�����ڷ�������ʱ��ִ�С�\nȷ��Ҫ������?'))return false;
		  var url='index.php?m=promotion/coupon&a=sendshow&type=check&id='+id;
		  window.open(url);return ;
  }
  function delete_data(obj,id){
		if(!confirm("�˲��������ɻָ�,ȷ��ɾ��?"))return false;
		$.post('index.php?m=promotion/coupon&a=couponList',{deltype:'delete_rule_cou',id:id,ename:$(obj).attr('rel')},function(data){
			switch($.trim(data)){
				case 'OK':
					window.location.reload();
					window.parent.showNotice(php_do_ok);
				break;
				default:alert(data);
			}
		});
  }
$(function(){
	$(".submit_rulue").submit(function(){
		window.location.href=_s($(this));
		return false;
	});
});
function advance_search(obj){
	var tag = $("#subsearch");
	var none = $(tag).css('display').toLowerCase()=='none'?true:false;
	if(none){
		var off = $(obj).offset();
		var wh = $(tag).width();
		var left = off.left-(wh/2)+75;
		var h = $(obj).height();
		var top = off.top+h+8;
		$(tag).css({"left":left+'px',"top":top+'px'}).fadeIn();	
	}else{
		$(tag).fadeOut();	
	}
}
</script>
<form method="post" action="index.php?m=promotion/coupon&a=couponList"  class="submit_rulue" id="submit_rulue" autocomplete="off">
    <div id="php_top_bar" >
        <div class="tb">���ƣ�</div>
        <div class="tb"><input  type="text" value="{$eget.name}" name="name" /></div>
        <div class="tb"><input type="submit" value="����" class="form_submit" style="display:none;" /> <a href="javascript:;" onclick="submit_form('submit_rulue');" class="block_button form_btn">����</a></div>
        <div class="tb"><a onclick="advance_search(this);" href="javascript:;" class="block_button form_btn">�߼�����</a></div>
        {if $action eq 'coupon_type_operate'}
        <div class="tb"><a href="javascript:;" class="block_button" onclick="window.location.reload();">ˢ��</a></div>
        {/if} 
		{if $data.total>0}<div class="tb"><a href="javascript:;" class="block_button form_btn" onclick="delete_all_rule();">ɾ������</a></div>{/if}
    </div>
<div id="subsearch" style="display:none">
<table cellpadding="2" cellspacing="2">
	<tr>
    	<td width="70">��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
        <td width="148"><input type="text" value="{$eget.name}"  name="name" style="width:120px;"/></td>
    	<td width="66">��&nbsp;��&nbsp;�ţ�</td>
        <td width="120"><input type="text" value="{$eget.no}"  name="no" style="width:120px;"/></td>
    </tr>
	<tr>
    	<td>����ͣ�</td>
        <td>
        <select style="width:130px;" name="huodong_type">
        	<option value="">��ѡ��</option>
            <option value="2" {if $eget.huodong_type eq '2'} selected="selected"{/if}>һ��ʹ��</option>
            <option value="1" {if $eget.huodong_type eq '1'} selected="selected"{/if}>�ظ����</option>
        </select>
        </td>
    	<td nowrap="nowrap">�Ż�ȯ���ͣ�</td>
        <td>
        <select style="width:130px;" name="youhui_type">
        	<option value="">��ѡ��</option>
            <option value="1" {if $eget.youhui_type eq '1'} selected="selected"{/if}>����ȯ</option>
            <option value="2" {if $eget.youhui_type eq '2'} selected="selected"{/if}>���ȯ</option>
        </select>
        </td>
    </tr>
<tr>
	  <td>���÷�Χ��</td>
   <td colspan="4"> <input type="text" value="{$eget.money_start}"  name="money_start" style="width:100px;"/> �� <input type="text" value="{$eget.money_end}"  name="money_end"/></td>
</tr>
<tr>
	  <td>ʱ�䷶Χ��</td>
   <td colspan="4"> <input type="text" value="{$eget.time_start}"  onfocus="show_date(this);" class="date date_input" name="time_start" style="width:100px;"/> �� <input onfocus="show_date(this);" type="text" value="{$eget.time_end}" class="date date_input"  name="time_end"/></td>
</tr>
    <tr>
    	<td colspan="4">
        <input type="submit" value="�� ��" class="form_submit" />
        <input type="button" value="�ر�"  class="form_submit" onclick="$('#subsearch').hide();" />
        </td>
    </tr>
</table>
</div>
</form>
<div id="php_right_main_content">
{if $data.total>0}   
    <table class="table_list table_list_hover">
       <tr><th><input type="checkbox" id="check_all"/></th>
       <th>����</th>
       <th>����</th>
       <th>��־</th>
       <th nowrap="nowrap">�Żݷ�ʽ</th>
       <th  nowrap="nowrap">����</th>
       <th>���÷�Χ</th>
       <th>ʱ�䷶Χ</th>
       <th>����</th>
       <th nowrap="nowrap">����</th>
       </tr>
     {foreach from = $data.data item=item name=name}
       <tr>
       <td align="center" width="20"><input type="checkbox" id="check_item_{$item.coupon_id}" name='check_item[]' class="check_item_class" value="{$item.coupon_id}"/></td>
       <td align="center" nowrap="nowrap"><a href="index.php?m=promotion/coupon&a=editcouponrule&id={$item.coupon_id}" >�༭ </a> {if $item.guoqi neq '1'} <a href="javascript:;" onclick="send_r('{$item.coupon_id}');">����</a>{/if} <a href="javascript:;" onclick="delete_data(this,'{$item.coupon_id}');" rel="{$item.coupon_name}==>{$item.coupon_number}">ɾ�������Ż�ȯ</a></td>
    <td align="center" nowrap="nowrap"><a href="index.php?m=promotion/coupon&a=couponnumberlist&rule={$item.coupon_id}">{$item.coupon_name}</a></td>
       <td align="center">{$item.coupon_number}</td>
       <td align="center">{if $item.coupon_type eq '1'}����ȯ{elseif $item.coupon_type eq '2'}�ۿ�ȯ{else}N/A{/if}</td>
       <td align="center">{if $item.coupon_type eq '1'}{$item.coupon_fav_replace}{/if}{if $item.coupon_type eq '2'}{$item.coupon_fav_ration}%{/if}</td>
       <td align="center">{$item.min_money} - {$item.max_money}</td>
    <td align="center" style="padding:0px;">{$item.starttime|date_format:"%Y-%m-%d %H:%M:%S"} - {$item.stoptime|date_format:"%Y-%m-%d %H:%M:%S"}</td>
       <td align="center" nowrap="nowrap">{if $item.guoqi eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
       <td align="center"  nowrap="nowrap">{if $item.coupon_activ_type eq '1'}<span class="red">��</span>{elseif $item.coupon_activ_type eq '2'}<span class="green">��</span>{else}N/A{/if}</td>
       </tr>
     {/foreach}
    </table>
<div class="clear"></div>
	{$data.page}
{else}
   <div class="notice_msg">���޿�������</div>
{/if}
</div>
{include file="frame_footer.php"}
{/if}

{if $action eq 'coupon_list'}
{include file="frame_header.php"}
<script type="text/javascript">
  function del_coupon(delete_type){
	  var varles = '';
	  var msg = "�˲��������ɻָ�,ȷ��ɾ����?";
	  switch(delete_type){
			case  'delete_all':
				 varles= get_checkbox_val('check_item_class');
	 			 if(!varles)return window.parent.showNotice("��ѡ������һ��");
				  if(!confirm("�˲�����ɾ��������ѡ���Ż�ȯ,ȷ��ɾ����?"))return false;
			break;
			case 'delete_used':
				msg = "�˲�����ɾ��������ʹ�õ��Ż�ȯ�Ҳ��ɻָ�,ȷ��ɾ����?";
			break;
			case 'delete_over':
				msg = "�˲�����ɾ�������ѹ��ڵ��Ż�ȯ�Ҳ��ɻָ�,ȷ��ɾ����?";
			break;
			default:
	  }
	 if(msg && !confirm(msg))return false;
	 var opt = {type:delete_type, ids:varles};
	$.post('index.php?m=promotion/coupon&a=call',opt,function(data){
		 switch($.trim(data)){
			case "OK":
				window.parent.showNotice(php_do_ok);
				window.location.reload();
				break;
			case "EMPTY":
				window.parent.showNoitce("�������ɹ�");
				break;
			default:
				alert(data);
				break; 	 	
		 }	
	});	
  }
function advance_search(obj){
	var tag = $("#subsearch");
	var none = $(tag).css('display').toLowerCase()=='none'?true:false;
	if(none){
		var off = $(obj).offset();
		var wh = $(tag).width();
		var left = off.left-(wh/2)+75;
		var h = $(obj).height();
		var top = off.top+h+10;
		$(tag).css({"left":left+'px',"top":top+'px'}).fadeIn();
	}else{
		$(tag).fadeOut();
	}
}
$(function(){
checkAllFormData('check_all','check_item_class'); 
	$(".search_form_cou").submit(function(){
		window.location.href=_s($(this)); return false;
	});
});
</script>
<div id="php_top_bar">
<form method="post" action="index.php?m=promotion/coupon&a=couponnumberlist"  class="search_form_cou" id="search_form_cou" autocomplete="off">
<div class="tb">�Ż�ȯ�룺</div>
<div class="tb"><input type="text" value="{$eget_key.no}" name="no" /></div> 
<div class="tb"><input type="submit" value="����" class="form_submit" style="display:none;" />
	<a href="javascript:;" onclick="submit_form('search_form_cou');" class="block_button form_btn">����</a>
</div>
<div class="tb"><a onclick="advance_search(this);" class="block_button form_btn" >�߼�����</a></div>
</form> 
{if $data.total>0}
    <div class="tb"><a  class="block_button form_btn" href="javascript:;" onclick="del_coupon('delete_all')">����ɾ����ѡ</a> </div>
    <div class="tb"><a href="javascript:;" onclick="del_coupon('delete_over')" class="block_button form_btn">ɾ�������Ż�ȯ</a> </div>
    <div class="tb"><a href="javascript:;"  class="block_button form_btn" onclick="del_coupon('delete_used')">ɾ�������Ż�ȯ</a></div>
{/if}
</div>
<form method="post" action="index.php?m=promotion/coupon&a=couponnumberlist"  class="search_form_cou">
<div id="subsearch" style="display:none">
	<table>
    	<tr>
        	<td>��&nbsp;&nbsp;&nbsp;&nbsp;��</td>
            <td><select name="rule"  style="width:130px;"><option value="">{$lang.php_select}</option>{foreach from=$all_rules item='item'}<option {if $eget_key.rule eq $item.coupon_id} selected="selected" {/if} value="{$item.coupon_id}">{$item.coupon_name}</option>{/foreach}</select></td>
            <td nowrap="nowrap">�Ż�ȯ�룺</td>
            <td>
            	<input type="text" value="{$eget_key.no}" name="no" />
            </td>
        </tr>
        <tr>
        	<td>��&nbsp;&nbsp;&nbsp;&nbsp;Ա��</td>
            <td><input type="text" value="{$eget_key.member_name}" name="member_name" /></td>
            <td nowrap="nowrap">�Ƿ�ʹ�ã�</td>
            <td>
            	<select name="is_used" style="width:140px;">
                	<option value="">��ѡ��</option>
                    <option value="1" {if $eget_key.is_used eq '1'} selected="selected"{/if}>δʹ��</option>
                    <option value="2" {if $eget_key.is_used eq '2'} selected="selected"{/if}>��ʹ��</option>
                </select>
            </td>
        </tr>
       {*} <tr>
        	<td>��&nbsp;&nbsp;&nbsp;&nbsp;ֵ��</td>
            <td colspan="3"><input type="text" onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboarddata.setdata('text',clipboarddata.getdata('text').replace(/[^\d]/g,''));" value="{$eget_key.member_name}" name="money_start" /> ��  <input type="text" value="{$eget_key.member_name}" onkeyup="value=value.replace(/[^\d]/g,'');" onbeforepaste="clipboarddata.setdata('text',clipboarddata.getdata('text').replace(/[^\d]/g,''));" name="money_end" /></td>
        </tr>{*}
        <tr>
        	<td colspan="4">
            	 <input type="submit" value="�� ��" class="form_submit" />
      			 <input type="button" value="�ر�"  class="form_submit" onclick="$('#subsearch').hide();" />
            </td>
        </tr>
    </table>
</div>
<div id="php_right_main_content">
<script type="text/javascript">
	function show_logs(obj,val){
		var url = 'index.php?m=promotion/coupon&a=showUsedLog&no='+val;
		window.parent.showWindow("����ȯʹ����־=>"+val,url,850,400);
	}
</script>
{if $data.total > 0}
  <table  class="table_list table_list_hover">
      <tr>
          <th><input type="checkbox" name="check_all" id="check_all"/></th>
          <th>����</th>
          <th>�Ż�ȯ��</th>
          <th>�û�</th>
          <th>ʱ�䷶Χ</th>
          <th>��ֵ</th>
          <th>����</th>
          <th>����</th>
          <th>ʹ��</th>
      </tr>
   {foreach from=$data.data item=item name=name}
     <tr>
        <td align="center"><input type="checkbox" name="check_item[]" id="check_item" class="check_item_class"  value="{$item.coupon_v_id}"/></td>
        <td align="center"><a href="index.php?m=promotion/coupon&a=couponnumberlist&rule={$item.coupon_id}">{$item.coupon_name}</a></td>
        <td  align="center">{$item.coupon_v_number}</td>
        <td class="center" align="center">{$item.mem_name}</td>
        <td align="center">{$item.starttime|date_format:"%Y-%m-%d %H:%M:%S"} - {$item.stoptime|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        <td align="center">{$item.coupon_fav_replace}</td>
        <td align="center">{if $item.coupon_activ_type eq '1'}�ظ����{elseif $item.coupon_activ_type eq '2'}��һ��{/if}</td>
        <td align="center">{if $item.guoqi eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
        <td align="center">{if $item.is_used eq '1'}<span onclick="show_logs(this,'{$item.coupon_v_number}');" class="green" style="cursor:pointer;">��</span>{else}<span class="red">��</span>{/if}</td>
    </tr>
   {/foreach}
  </table>
{else}
  <div class="notice_msg">�޿�������</div>
{/if}  
</div> 
{$data.page}
{include file="frame_footer.php"}
{/if}

{if $action eq 'showUsedLog'}
    {if $data}
        <table class="table_list">
            <tr>
                <th>������</th>
                <th>����ȯ</th>
                <th>������Ʒ���</th>
                <th>�������</th>
                <th>�ۿ۷���</th>
                <th>��������</th>
            </tr>
            {foreach from=$data item='list'}
                <tr>
                    <td align="center">{$list.order_sn}</td>
                    <td align="center">{$list.coupon_number}</td>
                    <td align="center">{$list.goods_money}</td>
                    <td align="center">{$list.order_money}</td>
                    <td align="center">{$list.coupon_money}</td>
                    <td align="center"><a href="index.php?m=order&a=printOrder&id={$list.order_id}" target="_blank">����鿴</a></td>
                </tr>
            {/foreach}
        </table>
    {else}
    <div class="notice_msg">���޿�������!</div>
    {/if}
{/if}