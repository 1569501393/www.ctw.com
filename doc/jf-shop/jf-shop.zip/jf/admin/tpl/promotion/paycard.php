<?php exit('die'); ?>
{if $action eq 'list_pay_card'}
	{include file="frame_header.php"}
<form method="post" action="index.php?m=promotion/paycard&a=prepaidCardList" id="search_card">
    	<div id="php_top_bar">
        <div class="tb">���ţ�</div>
        <div class="tb"><input type="text" value="{$csearchkey.card_no}"  name="card_no"/></div>
     <div class="tb"><input  type="submit" value="����"  class="form_submit" style="display:none;"/>
     	<a href="javascript:;" onclick="submit_form('search_card');" class="block_button form_btn">����</a>
     </div>
     <div class="tb"><a id="show_advance_pannel" class="block_button form_btn">�߼�����</a></div>
      <div class="tb"><a class="block_button" onclick="butch_create_data(this);">��������</a></div>
     <div class="tb"><a onclick="window.parent.showWindow($(this).html(),'index.php?m=promotion/paycard&a=importCard',800,300);" class="block_button">��������</a></div>
     <div class="tb"><a class="block_button" onclick="butch_search_data(this);">��������</a></div>
     {if $data.total>0}
     <div class="tb"><a onclick="delete_select_card(this);" class="block_button">ɾ����ѡ</a></div>
    <div class="tb"><a onclick="delete_unse(this);"class="block_button ">ɾ��δ�ÿ�</a></div>
    <div class="tb"><a onclick="delete_expried(this);" class="block_button">ɾ�����ڳ�ֵ��</a></div>
            {/if}
        </div>
        </form>
<script type="text/javascript">
	function set_focus_time(obj){
		var val = $(obj).val();
		var is_forever = val=='forever'?true:false;
		var dt = $("#show_time_set");
		if(!is_forever){
			dt.show();
		}else{
			dt.hide();
		}
	}
</script>
<div id="subsearch" style="display:none;">
<form method="post" action="index.php?m=promotion/paycard&a=prepaidCardList" id="search_advance_card" autocomplete="off">
<table class="" width="100%" cellpadding="2" cellspacing="2">
	<tr>
    	<td>ѡ����</td>
        <td><select name="money" style="height:auto; width:135px;">
<option value="">��ѡ��...</option>
{foreach from=$money item='m'}
<option value="{$m}" {if $csearchkey.money eq $m} selected="selected"{/if}>{$m}Ԫ</option>
{/foreach}
</select></td>
	<td>״&nbsp;&nbsp;&nbsp;&nbsp;̬��</td>
    <td><select name="status" style="height:auto; width:135px; margin:0px;">
        <option value="">��ѡ��...</option>
        <option value="used" {if $csearchkey.status eq 'used'} selected="selected"{/if}>��ʹ��</option>
        <option value="unused" {if $csearchkey.status eq 'unused'} selected="selected"{/if}>δʹ��</option>
     </select>
     </td>
    </tr>
<tr>
    <td>����ʱ�䣺</td>
    <td><select name="end_time_set" onchange="set_focus_time(this);" style="height:auto; width:135px;">
    	<option value="">��ѡ��...</option>
    	<option value="fix" {if $csearchkey.end_time_set eq 'fix'} selected="selected"{/if}>ָ��ʱ��</option>
    	<option value="forever" {if $csearchkey.end_time_set eq 'forever'} selected="selected"{/if}>����</option>
    </select></td>
    <td colspan="2"><div id="show_time_set" style="{if $csearchkey.end_time_set neq 'forever'}display:block;{else}display:none;{/if}">����ʱ�䣺<input type="text" value="{$csearchkey.date}" name="date" onclick="show_date(this);" /></div></td>
    <tr>
    <td>���ţ�</td>
    <td colspan="3"><input type="text" value="{$csearchkey.card_no}" name="card_no"/></td>

</tr>
<tr>
	<td colspan="2">
    <a href="javascript:;" class="form_btn block_button" onclick="submit_form('search_advance_card');">����</a>
    <input type="submit" value="����" class="form_submit" style="display:none;" /> 
    <a onclick="$('#subsearch').slideUp();" href="javascript:;" class="block_button form_btn">�ر�</a></td>
</tr>
</table>
</form></div>
        <div id="php_right_main_content">
{if $data.total>0}
        	<table class="table_list table_list_hover">
				<tr>
                	<th><input type="checkbox" value="" id="pay_sec_id" /></th>
                    <th>����</th>
                    <th>�ܳ�</th>
                    <th>���</th>
                    <th>����ʱ��</th>
                     <th>��ֵ����ʱ��</th>
                    <th>�Ƿ���ʹ��</th>
                </tr>
                {foreach from=$data.data item='item'}
                	<tr>
                    	<td class="center"><input  type="checkbox" {if $item.is_used eq '1'} disabled="disabled" value=""{else}value="{$item.id}"{/if} class="pay_sec_id" /></td>
                        <td class="center">{$item.card_no}</td>
                        <td class="center">{$item.key}</td>
                        <td class="center"><a href="index.php?m=promotion/paycard&a=prepaidCardList&money={$item.money}">{$item.money}</a></td>
                        <td class="center">{$item.create_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
                        <td class="center">{if $item.end_time neq '999999999'}
                        {if !$item.is_exprid}
                        {$item.end_time|date_format:"%Y-%m-%d %H:%M:%S"}
                        {else}
                        <span class="red">����</span>
                        {/if}
                        {else}<span class="blue">���ò�����</span>{/if}</td>
                        <td class="center">{if $item.is_used eq '1'}<a href="javascript:;" onclick="show_use_card_info(this);"  rel="{$item.card_no}" class="blue">��ʹ��</a>{else}δʹ��{/if}</td>
                    </tr>
                {/foreach}
                <tr>
                	<td colspan="8" align="right"><% _e("��ǰҳ�ܽ��");%> ��{$curent_total_money|default:'0'}  ��ֵ���ܽ�� ��{$total_money|default:'0'} &nbsp;��ʹ�� ��{$has_used|default:'0'} ���� {$total_used_card} ��&nbsp;δʹ�� ��{$un_used|default:'0'} &nbsp;</td>
                </tr>
            </table>
<div class="clear"></div>
            {$data.page}
{else}
<div class="notice_msg">�޿�������!</div>
{/if}
<script type="text/javascript">
	function show_use_card_info(obj){
		var no = $(obj).attr('rel');
		window.parent.showWindow("�鿴��ֵ��¼ =>"+no,'index.php?m=promotion/paycard&a=viewlog&no='+no,700,200);	
	}
	$(function(){
		$("#search_card").submit(function(){
			window.location.href=_s(this);
			return false;
		});
	});
	function butch_create_data(obj){
		window.parent.showWindow($(obj).html(),'index.php?m=promotion/paycard&a=butchCreateCard',750,300);
	}
	function butch_search_data(){
		var url = _s($("#search_advance_card"))+'&dotask=export&type=xls';
		window.open(url);
		$("#search_advance_card").hide();
	}
	$(function(){
		$("#search_card").submit(function(){
			window.location.href=_s(this);return false;
		});
		$("#search_advance_card").submit(function(){
			window.location.href=_s(this);return false;
		});
		checkAllFormData('pay_sec_id','pay_sec_id');
		$("#show_advance_pannel").click(function(){
			var none = $('#subsearch').css('display').toLowerCase();
			var h = none=='none'?true:false;
			if(h){
				var off = $(this).offset();
				var top = parseInt(off.top+$(this).height())+8;
				$('#subsearch').css({"top":top,"left":'80px'}).slideDown();
			}else{
				$('#subsearch').slideUp();
			}
			h = none = null;
		});
	});
	function delete_unse(){
		if(!confirm("ȷ��Ҫɾ����?�˲��������ɻָ�!"))return false;	
		$.post('index.php?m=promotion/paycard&a=delete',{type:'unuse'},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
					window.location.reload();
				break;
				default:alert(data);
			}
		});
	}
	function delete_expried(){
		if(!confirm("ȷ��Ҫɾ�����ڳ�ֵ����?�˲��������ɻָ�!"))return false;	
		$.post('index.php?m=promotion/paycard&a=delete',{type:'expried'},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
					window.location.reload();
				break;
				default:alert(data);
			}
		});
	}
	function delete_select_card(obj){
		var val= get_checkbox_val('pay_sec_id');
		if(!val){
			window.parent.showNotice("��ѡ��Ҫ����������!");return false;
		}
		if(!confirm("ȷ��Ҫɾ����?�˲��������ɻָ�!"))return false;
		$.post('index.php?m=promotion/paycard&a=delete',{ids:val},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
					window.location.reload();
				break;
				default:alert(data);
			}
		});
	}
</script>
        </div>
    {include file="frame_footer.php"}
{/if}
{if $action eq 'view_log_action'}
<div style="padding:8px;">
	{if $member_data}<p>�û����� {$member_data.mem_username}</p>{/if}
    {if $data}
    	<p>{$data.desc}</p>
        <p>��ֵʱ�䣺{$data.date|date_format:"%Y-%m-%d %H:%M:%S"}</p>
    {else}
        <div class="notice_msg">�޿�������!</div>
    {/if}
    </div>
{/if}
<!--����-->
{if $action eq 'export_data'}
<head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" /><style>td{vnd.ms-excel.numberformat:@}</style></head><table width="100%" border="1"><tr><th filter=all>����</th><th filter=all>�ܳ�</th><th filter=all>���</th><th filter=all>����ʱ��</th><th filter=all>��ֵ����ʱ��</th><th filter=all>�Ƿ���ʹ��</th></tr>{foreach from=$data item=item}
<tr><td align="center">{$item.card_no}</td><td align="center">{$item.key}</td><td align="center">{$item.money}</td><td align="center">{$item.create_time|date_format:"%Y-%m-%d %H:%M:%S"}</td> <td class="center">{if $item.end_time neq '999999999'}{$item.end_time|date_format:"%Y-%m-%d %H:%M:%S"}{else}���ò�����{/if}</td> <td align="center">{if $item.is_used eq '1'}��ʹ��{else}δʹ��{/if}</td></tr>{/foreach}
<tr>
<td colspan="6" align="right">������:{$total_number} �ܽ�� ��{$total_money|default:'0'} &nbsp;��ʹ�� ��{$has_used|default:'0'} &nbsp;δʹ�� ��{$un_used|default:'0'} &nbsp;</td>
</tr>
</table>
{/if}
{if $action eq 'butch_create'}
<script type="text/javascript">
	$(function(){
		$("#crate_card").submit(function(){
			if(!check_form_is_empty('must_card_in'))return false;
			var mm = $("#card_money").val();
			var nn =$("#card_number").val();
			var card_set = $("#card_time_set").attr('checked');
			var tt ;
			if(card_set){
				 tt = '������Ч';	
			}else{
				 tt = $("#time_limits").val();
			}
			var cmsg = "ȷ��������?����Ҫ���ɳ�ֵ����ϢΪ\n"+'���'+mm+'Ԫһ��,����'+nn+'��,�ܶ�Ϊ:'+(mm*nn)+'Ԫ,��ֵ����ʱ��Ϊ:'+tt;
			if(!confirm(cmsg))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'EMPTY_DATE':
						window.parent.showNotice("ʱ���ʽ����!");
						return false;
					break;
					case 'OK':
						window.parent.showNotice("�����ɹ�!");
						window.frames['rightFrame'].location.reload();
						close_window();return false;
					break;
					case 'EMPTY_SELECT':
					window.parent.showNotice("��ѡ��Ҫ����������!");return false;
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
	function set_card_staus(obj){
		var a = $(obj).attr('checked');
		if(!a){
			$(obj).parent().next().show().find('input').addClass('must_card_in');	
		}else{
			$(obj).parent().next().hide().find('input').removeClass('must_card_in');
		}
	}
</script>
<form method="post" id="crate_card" action="index.php?m=promotion/paycard&a=butchCreateCard" autocomplete="off">
<table class="table_common">
	<tr>
    	<td class="one">����С</td>
        <td>
<select name="money" class="must_card_in" id="card_money" style="height:auto; width:200px;">
<option value="">��ѡ�����</option>
{foreach from=$money item='m'}
<option value="{$m}">{$m}Ԫ</option>
{/foreach}
</select></td>
    </tr>
    <tr>
    	<td class="one">��Ч��ֵ����ʱ��</td>
        <td>
<span class="red">������Ч   <input type="checkbox" value="forever" name="is_forever" id="card_time_set" onclick="set_card_staus(this);" checked="checked" /></span>
        <div class="set_card_date" style="display:none; margin-top:5px;"><input type="text" value="" id="time_limits" class="form_input" style="width:200px;" name="date"  onfocus="show_date(this,true,true);"/></div>
        </td>
    </tr>
    <tr>
    	<td class="one">�����ɵĿ�������</td>
        <td><input type="text" value="500" class="must_card_in form_input" style="width:200px;" id="card_number" name="num"/>
        <p class="desc">һ�����3000��,������3000������</p></td>
    </tr>
    <tr>
    	<td class="one"></td>
        <td><input type="submit" value="��������" class="form_submit" style="display:none;"/>
        	<a href="javascript:;" onclick="submit_form('crate_card');" class="form_btn block_button">����</a>
        </td>
    </tr>
</table>
</form>
{/if}
{if $action eq 'import_card'}
<div class="notice_msg">
	һ�ε��������ļ���С���ܳ���2M,��ʽΪ*.txt,<a href="./card.txt" target="_blank">������������</a>
</div>
<form method="post" id="import_card" action="index.php?m=promotion/paycard&a=importCard">
	<table class="table_common">
    	<tr>
        	<td class="one">ѡ���ļ�</td>
            <td><input  type="file" value="" name="card" id="upload_card" /></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" value="����" class="form_submit" /></td>
        </tr>
    </table>
</form>
<script type="text/javascript">
	$(function(){
		$("#import_card").submit(function(){
			var e = $("#upload_card").val();
			if(empty(e)){alert("��ѡ��Ҫ�ϴ����ļ�!");return false;}
			var ee = e.split('.').pop();
			if($.inArray(ee, new Array('txt'))){
				alert("�������ı���ʽ!");
				return false;
			}
			$(this).ajaxSubmit(function(data){
				data = data.split('|');
				switch(data[0]){
					case 'EMPTY':
						alert('ϵͳ��������������,����!');
					break;
					case 'UPLOAD_OK':
					   window.parent.showNotice('����ɹ�!,������ '+data[1]+' ��');
					   close_window();
					   window.frames['rightFrame'].location.reload();
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
{/if}