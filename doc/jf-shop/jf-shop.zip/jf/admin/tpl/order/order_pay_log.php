<?php exit('die'); ?>
{if $action eq 'view_order_pay_log'}
    {if !$pay_log_data && !$pay_log_points_data}
    <div class="notice_msg">�޿�������!</div>
    	{else}
            {if $pay_log_data}
                {include file="order/order_pay_log_part.php"}
            {/if}	
        	
            {if $order_payed_points_log}
            	{include file="order/order_pay_point_log_part.php"}
            {/if}
        
    {/if}
{/if}
