<?php exit('die'); ?>
 {if $o.taozhuang_extend_data}
<div class="call_append_data">
    <samp class="gray"><strong>��װ:</strong>{foreach from=$o.taozhuang_extend_data item='tao' name='ename'} {$tao.goods_name}{if !$smarty.foreach.ename.last}��{/if}{/foreach}</samp>
  </div>
{/if}