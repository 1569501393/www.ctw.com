<?php  exit('die');?>
 {foreach from=$order_data.status.array item=st}{$st}&nbsp;{/foreach}