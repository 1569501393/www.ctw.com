<?php exit('die_view_order'); ?>
{if $action eq 'order_detail'}
{include file="frame_header.php"}
<script type="text/javascript">
	$(function(){
		close_open_helper('order_helper','notice_msg',false);
		//table_color('order_table');
		$.table_bars($("#order_view_base .menu li"));
	});
	function edit_order_data(obj,type){
		window.parent.showWindow($(obj).val(),'index.php?m=order&a=editOrder&type='+type,970,450);
	}
	function get_remark_info(){
		return $("#order_confim_info").val();	
	}
</script>
<div id="php_top_bar" class="php_bot_bar">
    <div class="tb"><a href="index.php?m=order&a=viewOrder&id={$order_detail.order_id}" class="block_button ">{$lang.php_refresh}</a></div>
    {if $can_edit_order}
    <div class="tb"><a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=order&a=editOrder&id={$order_detail.order_id}',970,500);" class="block_button">�༭����</a></div>{/if}
    {if $order_one_data.prev}
    <div class="tb"><a href="index.php?m=order&a=viewOrder&id={$order_one_data.prev}" class="block_button ">{$lang.order.last_order}</a></div>
    {/if}
    {if $order_one_data.next}
    <div class="tb"><a href="index.php?m=order&a=viewOrder&id={$order_one_data.next}" class="block_button ">{$lang.order.next_order}</a></div>
    {/if}
    <div class="tb"><a class="block_button" href="index.php?m=order&a=printOrder&id={$order_id}" target="_blank">{$lang.order.print_order}</a></div>
    <div class="tb"><a href="javascript:;" class="block_button" id="order_helper">{$lang.php_open_help}</a></div>
</div>
<div id="php_right_main_content">
<div class="notice_msg" id="notice_msg" style="display:none;">
<!--������������:
ȷ�϶���->ȷ��֧��->���(��Ϊδ����)->����->���ﵽ��->�ۺ� (�˻�,�˿�)-->
<div>1������һ:(�������)ȷ�϶���->ȷ��֧��->���(��Ϊδ����)->����->���ﵽ��->�ۺ� (�˻�,�˿� ��)</div>
<div>2�����̶�:(��������)ȷ�϶���->���->����->���ﵽ��->�տ�->�ۺ� (�˻�,�˿� ��)</div>
<div>3���������޸Ķ��������ͷ���,�ջ�����Ϣ,��Ʒ�Ĺ�������,���ͷ�ʽ,��Ʒ�ĵ�ǰ�۵�,�޸Ķ���ʱ�����޸���д������ע!</div>
<div>4�����޸���Ʒ���ۻ�������ʱ����Ϊ����,��С�ڵ���0��������!�۸�λ����������λ!</div>
</div>
<div id="order_view_base" class="table_scroll">
    <div class="menu" style="padding-left:20px;">
    	 <li name="cfg_all" >ȫ��</li>
        <li name="cfg_base" class="wintable_curent">����</li>
         <li name="cfg_goods">��Ʒ</li>
        <li name="cfg_delivery">����</li>
        <li name="cfg_dicount">�Ż�</li>
        <li name="cfg_buyer">������</li>
        <li name="cfg_reciver">�ջ���</li>
       
    </div>
</div>

<div class="table_item_base">
    <div class="table_item" id="cfg_base">
    <!--#֧����־-->
{include file="order/order_pay_log_small.php"}
    <h1 class="c_bar">������Ϣ</h1>
    <div class="c_content">
    <table class="table_common">
        	<tr>
            	<td class="one"><!--������-->{$lang.order.order_no}</td>
                <td>{$order_detail.order_sn}</td>
                <td class="one"><!--����״̬-->{$lang.order.order_status}</td>
                <td>
            <strong>
            {assign var=order_data value=$order_detail}
             {include file="order/order_status.php"}
             </strong>
 			</td>
            </tr>
            <tr>
            	<td class="one"><!--������-->{$lang.order.buyer}</td>
                <td>
                {if $order_detail.mem_username}
                <a href="javascript:;"  onclick="window.parent.showWindow('{$order_detail.member_info.mem_username}','index.php?m=member&a=detail&memid={$order_detail.member_info.mem_id}&noborder=true',900,300);" ><strong>{$order_detail.member_info.mem_username}</strong></a>{if $order_detail.member_info.mem_name} ({$order_detail.member_info.mem_name}){/if}
                {else}
                	��������
                {/if}
                </td>
                <td class="one"><!--�µ�ʱ��-->{$lang.order.order_time}</td>
                <td>{$order_detail.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
            </tr>
               <tr>
            	<td class="one"><!--���ͷ�ʽ-->{$lang.order.shiping_method}</td>
                <td>{$order_detail.delivery_name}
                 </td>
                <td class="one">����ʱ��</td>
                <td>
                {if $order_detail.shiping_delivery_time}{$order_detail.shiping_delivery_time|date_format:"%Y-%m-%d %H:%M:%S"}{else}-{/if}
                </td>
            </tr>
               <tr>
                 <td class="one">{$lang.order.deliver_order}</td>
                 <td>
<div class="tb">{$order_detail.delivery_no|default:'-'}</div>
<div class="tb"><input  type="hidden" id="order_delivery_no" value="{$order_detail.delivery_no}" /></div>
{if $order_detail.shiping_status>0 && $order_detail.shiping_status<3}
<div class="tb"><input type="button" class="form_submit" onclick="window.parent.showWindow($(this).val(),'index.php?m=order&a=editOrder&type=delivery_no&id={$order_detail.order_id}',850,350)"  value="�༭��������"/>
</div>
{/if}
{if $order_detail.delivery_no}
 <div class="tb">
 {assign var = cpno value=$order_detail.order_delivery_data.extend_name}
 {assign var =no value=$order_detail.delivery_no}
  <a href="javascript:;" onclick="window.parent.showWindow('��ݵ���ѯ','index.php?m=system/plugin&a=test&name=express_inquiry&no={$no}&cpno={$cpno}',750,300);" class="block_button form_btn">��ݵ���ѯ</a>
 </div>
 {/if}
                 </td>
                 <td class="one"></td>
                 <td>&nbsp;</td>
               </tr>
                  <tr>
                 <td class="one">���ͷ���</td>
                 <td>
            {$order_detail.delivery_fee_format}
                 </td>
                 <td class="one">��Ʊ����</td>
                 <td>
            {$order_detail.fapiao_money_format}
                 </td>
               </tr>
               <tr>
               	<td class="one">�Ż�ȯ</td>
                <td>{$order_detail.coupon_number|default:'-'}</td>
                <td class="one">�Ż�ȯ����</td>
                <td>{$order_detail.coupon_money_format|default:'-'}</td>
               </tr>
               <tr>
               	<td class="one">��Ա�ۿ�</td>
                <td>{if $order_detail.discount eq '1' || $order_detail.discount eq ''}���ۿ�{else}{$order_detail.discount*10}�� ({$order_detail.discount_money_format}){/if} </td>
                <td class="one">���Ͷ����</td>
                <td>{$order_detail.delivery_extend_money|default:'0'}</td>
               </tr>
            <tr>
            	<td class="one red">���������ܼ�</td>
                <td >{$order_detail.order_total_fee}{if $order_detail.order_total_point_fee>0} + {$order_detail.order_total_point_fee}��{/if}</td>
            	<td class="one red">����֧��</td>
                <td>
                {if $order_detail.order_total_need_pay_fee>0}
	                <strong class="red">
	                {$order_detail.order_total_need_pay_fee_format}
                    </strong>
                {elseif $order_detail.order_total_need_pay_fee<0}
	                <strong class="red">
	                ���� {$order_detail.order_total_need_pay_fee_format}
                    </strong>
                {/if}
                </td>
            </tr>
               {if $order_detail.user_cancel_flag>0}
               <tr>
               	<td class="one">����ȡ��ԭ��</td>
                <td colspan="3"><strong class="red">{$order_detail.cache_order_reason|nl2br}</strong></td>
               </tr>
               {/if}
               <tr>
                 <td class="one">�˿�����</td>
                 <td colspan="3">
                 <script type="text/javascript">
				 {if $order_detail.tuikuan_flag eq '1' && $order_detail.tuikuan_flag neq '2'}
					$(function(){
						 window.parent.showWindow('�û��˿�����','index.php?m=order&a=dotuikuan',940,500);
					});
				 {/if}
                 </script>
                 {if $can_tuikuan}
                 <script type="text/javascript">
					function do_tuikuan_data(obj){
						 window.parent.showWindow($(obj).val(),'index.php?m=order&a=dotuikuan',940,500);
					}
                 </script>
                     {if $order_detail.tuikuan_flag >=1}
                     {if $order_detail.tuikuan_flag eq '2'}
                     	<input type="button" class="form_submit red" style="color:#F00; font-weight:bold;" onclick="do_tuikuan_data(this);"  value="�鿴������־" />
                        {else}
                        <input type="button" class="form_submit red" style="color:#F00; font-weight:bold;" onclick="do_tuikuan_data(this);"  value="�����˿�" />
                     {/if}
                        
                             {if $order_detail.tuikuan_flag eq '2'}
                                    <span class="red"><strong>�Ѵ������</strong></span>
                             {elseif $order_detail.tuikuan_flag eq '1'}
                                       {if $order_detail.tuikuan_do_flag eq '2'}
                                        <span class="red"><strong>�û��ѻظ�</strong></span>     
                                        {elseif $order_detail.tuikuan_do_flag eq '1'}
                                            <strong class="red">�ȴ��û���</strong>                       
                                        {/if}
                             {elseif $order_detail.tuikuan_flag eq '3'}
                             	<strong class="red">����Ա�ֶ������˿�</strong>		
                             {else}
                                        -                             
                             {/if}
                        {else}
                            - 
                     {/if}
                 {/if}
                 </td>
               </tr>
               <tr>
                 <td class="one">�˻�����</td>
                 <td colspan="3">
                 {if $can_tuihuo}
                     {if $order_detail.tuihuo_sign >=1}
                     {if $order_detail.tuihuo_sign eq '2'}
                     	<input type="button" class="form_submit red" style="color:#F00; font-weight:bold;" onclick="do_tuihuo_data(this);"  value="�鿴������־" />
                        {else}
                        <input type="button" class="form_submit red" style="color:#F00; font-weight:bold;" onclick="do_tuihuo_data(this);"  value="�����˻�" />
                     {/if}
                        
                        <script type="text/javascript">
                            function do_tuihuo_data(obj){
                                 window.parent.showWindow('�û��˻�����','index.php?m=order&a=dotuihuo',960,500);
                            }
							{if $order_data.tuihuo_sign > '0' && $order_data.tuihuo_sign!='2'}
								do_tuihuo_data();
							{/if}
                        </script>
                            
                             {if $order_detail.tuihuo_sign eq '2'}
                                    <span class="red"><strong>�Ѵ������</strong></span>
                             {elseif $order_detail.tuihuo_sign eq '1'}
                                       {if $order_detail.tuihuo_do_flag eq '2'}
                                        <span class="red"><strong>�û��ѻظ�</strong></span>     
                                        {elseif $order_detail.tuihuo_do_flag eq '1'}
                                            <strong class="red">�ȴ��û���</strong>                       
                                        {/if}
                             {elseif $order_detail.tuihuo_sign eq '3'}
                             	<strong class="red">����Ա�ֶ������˻�</strong>		
                             {else}
                                        -                             
                             {/if}
                        {else}
                            - 
                     {/if}
                 {/if}
                 </td>
               </tr>
               </table>
        </div>
<h1 class="c_bar">����ͳ��</h1>
    <div class="c_content">
    <div align="right">{include file="order/order_money_status.php"} </div>
</div>


    </div><!--#end ������Ϣ-->
 <!--#������Ϣ-->   
<div class="table_item" id="cfg_delivery">
    <h1 class="c_bar">������Ϣ</h1>
    <div class="c_content">
        <table class="table_common">
          <tr>
                <td class="one"><!--���ͷ�ʽ-->{$lang.order.shiping_method}</td>
                <td> {$order_detail.delivery_name}</td>
                <td class="one"><!--����ʱ��-->{$lang.order.fahuo_time|default:'-'}</td>
                <td>
                {if $order_detail.shiping_delivery_time}{$order_detail.shiping_delivery_time|date_format:"%Y-%m-%d %H:%M:%S"}{else} - {/if}
                </td>
            </tr>
               <tr>
                 <td class="one">{$lang.order.deliver_order|default:'-'}</td>
                 <td>
             <div class="tb">{$order_detail.delivery_no}</div>
             <div class="tb"><input  type="hidden" id="order_delivery_no" value="{$order_detail.delivery_no}" /></div>
{if $order_detail.delivery_no}
 <div class="tb">
 {assign var = cpno value=$order_detail.order_delivery_data.extend_name}
 {assign var = no value=$order_detail.delivery_no}
 <a href="javascript:;" onclick="window.parent.showWindow('��ݵ���ѯ','index.php?m=system/plugin&a=test&name=express_inquiry&no={$no}&cpno={$cpno}',750,300);" class="block_button form_btn">��ݵ���ѯ</a></div>
 {/if}
</td>
                 <td class="one"><!--���ͷ���-->{$lang.order.o.peisong_feiyong}</td>
                 <td>
            {$order_detail.delivery_fee_format}
                 </td>
               </tr>
               <tr>
               	  <td class="one"><!--���ͷ���-->{$lang.order.o.peisong_feiyong}</td>
                 <td> {$order_detail.delivery_fee_format}
                 </td>
                 <td class="one"></td>
                 <td></td>
               </tr>
        </table>
    </div>
 </div>
 
 
 
   <!--#�Ż���Ϣ-->   
<div class="table_item" id="cfg_dicount">
    <h1 class="c_bar">�Ż���Ϣ</h1>
    <div class="c_content">
    <table class="table_common">
       <tr>
            <td class="one">�Ż�ȯ</td>
            <td>{$order_detail.coupon_number|default:'-'}</td>
            <td class="one">�Ż�ȯ����</td>
            <td>{$order_detail.coupon_money_format|default:'-'}</td>
       </tr>
       <tr>
            <td class="one">��Ա�ۿ�</td>
            <td>{if $order_detail.discount eq '1' || $order_detail.discount eq ''}���ۿ�{else}{$order_detail.discount*10}��{/if}</td>
            <td class="one">��Ա�ۿ۷���</td>
            <td>{$order_detail.discount_money_format|default:'-'}</td>
       </tr>
    </table>
    </div>
 </div>
 
    <!--#��������Ϣ-->   
<div class="table_item" id="cfg_buyer">
    <h1 class="c_bar">��������Ϣ</h1>
    <div class="c_content">
    <table class="table_common">
          <tr> 
            <td class="one"><!--����-->{$lang.order.order_user_name}</td>
            <td>{$order_detail.member_info.mem_name}</td>
            <td class="one"><!--�û���-->{$lang.order.order_site_user_name}</td>
            <td  nowrap="nowrap">
        {if $order_detail.member_info.mem_username}<a href="javascript:;" onclick="window.parent.showWindow('{$order_detail.member_info.mem_username}','index.php?m=member&a=detail&memid={$order_detail.member_info.mem_id}&noborder=true',900,300);" ><strong>{$order_detail.member_info.mem_username}</strong></a>
                {else}
                <span class="blue">{$lang.order.niming_buyer_no_info}</span>
            {/if}
            </td>
          </tr>
          <tr> 
            <td class="one"><!--�绰-->{$lang.order.order_u_phone}</td>
            <td>{$order_detail.member_info.mem_phone}</td>
        
            <td class="one">Email��</td>
            <td>{$order_detail.member_info.mem_email}</td>
          </tr>
          <tr> 
            <td class="one"><!--�ʱ�-->{$lang.order.order_money_zip}</td>
            <td>{$order_detail.member_info.mem_zip}</td>
            <td class="one"><!--��ʱͨ��-->{$lang.order.order_jishi_info}</td>
            <td>{if $order_detail.member_info.mem_qq}QQ:{$order_detail.member_info.mem_qq} {/if} {if $order_detail.member_info.mem_msn}MSN:{$order_detail.member_info.mem_msn} {/if}</td>
          </tr>
          <tr> 
            <td class="one"><!--��ַ-->{$lang.order.order_i_address}</td>
            <td colspan="3">{$order_detail.art}</td>
          </tr>
	        <tr>
            	<td class="one">Ҫ���ͻ�ʱ��</td>
                <td colspan="3">{$order_detail.receive_date_type}</td>
            </tr>
        	<tr>
            	<td class="one">�����߱�ע</td>
                <td colspan="3">{$order_detail.receive_note}</td>
                </tr>
                <tr>
                <td class="one"><!--ȱ������-->{$lang.order.quehuochuli}</td>
               <td colspan="3">{$order_detail.receive_out_of_stock}</td>
            </tr>
            <tr>
            	<td class="one"><!--��Ʊ��Ϣ-->{$lang.order.fapiao_info}</td>
                <td colspan="3">{$order_detail.receive_invoice}</td>
            </tr>
    </table>
    </div>
 </div>
 
     <!--#�ջ�����Ϣ-->   
<div class="table_item" id="cfg_reciver">
    <h1 class="c_bar">�ջ�����Ϣ</h1>
    <div class="c_content">
    	<table class="table_common">
        	<tr>
            	<td class="one">����</td>
                <td> {$order_detail.receive_realname} </td>
                <td class="one">��ַ</td>
                <td>{$order_detail.receive_address}</td>
            </tr>
            <tr>
            	<td class="one">�ʼ�</td>
                <td>{$order_detail.receive_email}</td>
                <td class="one">�ʱ�</td>
                <td>{$order_detail.receive_postno}</td>
            </tr>
            <tr>
            	<td class="one">�绰</td>
                <td>{$order_detail.receive_phone}</td>
                <td class="one">�ֻ�</td>
                <td>{$order_detail.receive_mobile}</td>
            </tr>
          <tr>
          	<td class="one">����</td>
            <td colspan="3"> {$order_detail.receive_area_format_string} </td>
          </tr>
        </table>
    </div>
 </div>
      <!--#��Ʒ��Ϣ-->   
<div class="table_item" id="cfg_goods">
    <h1 class="c_bar">��Ʒ��Ϣ</h1>
    <div class="c_content">
    {if $order_detail.order_goods_data}
      <table class="table_list">
        <tr>
            <th>����</th>
            <th>����</th>
            <th>����</th>
            <th>�յ�</th>
            <th>�ۼ�</th>
            <th>����</th>
            <th>����</th>
            <th>С��</th>
        </tr>
            {foreach from=$order_detail.order_goods_data item=good}
            	<tr>
                <td><a href="{$good.url}" target="_blank" style="color:#333">{$good.goods_name}</a>
                {include file="order/order_taozhuang.php"}
                {include file="order/order_zenpin.php"}
                </td>
                <td  class="center">{$good.goods_sn}</td>
                <td class="center">{$good.region_alias_name}</td>
                <td class="center">{if $good.is_additional eq '1'}<font class="red">��</font>{else}��{/if}</td>
                <td class="center">
                {if $good.only_use_point eq '1'}
                	{$good.goods_point_fee}
                {else}
               	 {$good.goods_curent_price}{if $good.goods_point_fee>0} + {$good.goods_point_fee}��{/if}
                {/if}
                </td>
                <td class="center">{$good.goods_total}</td>
                <td class="center">{$good.goods_weight|default:'0'}��</td>
                <td class="center">{$good.subtotal_format}{if $good.sub_point_total>0}+{$good.sub_point_total}��{/if}</td>
        	  </tr>
           {/foreach}
        </table>
        <div class="clear"></div>
        <div align="right" class="order_money_status_msg">
			<p>�ϼƣ�<strong class="red">{$order_detail.goods_money|money_format} </strong>��<strong class="red"> {$order_detail.order_count}</strong> ��</strong>
        </div>
         {else}
         	<div class="notice_msg">�޿�������!</div>
        {/if}
    </div>
 </div><!--#������Ʒ��Ϣ-->  
 <!--������ע-->
 {if $order_detail.order_confirm_status neq '3'}<!--�������״̬��Ϊ3 ��û���-->
  <h1 class="c_bar">������ע</h1>
 <div class="c_content">
 <div style="padding:8px;"> <textarea name="remark_info" style="width:500px; height:100px;" id="order_confim_info"></textarea></div>
<div class="clear"></div>
<script type="text/javascript">
	var empty_order_remark_info = '{$lang.order.empty_order_remark_info}';
	var shut_order_notice = '{$lang.order.shut_order_notice}';
		function _call_no(){
			return window.parent.showWindow('���÷���','index.php?m=order&a=editOrder&type=delivery_no&id={$order_detail.order_id}',850,300);	
		}
    	function submit_order_confirm(tag,order_id){
			var config = true;
			var pay_status = '{$order_detail.pay_status}';
			var cc = $("#receive_paycode").val();
			if(pay_status=='0'){
				config = false;	
			}
			var val = $("#order_confim_info").val();
			if(empty(val)){
				window.parent.showNotice(empty_order_remark_info);
				$("#order_confim_info").addClass('empty_input_val'); return false;	
			}else{
				$("#order_confim_info").removeClass('empty_input_val');		
			}
			if(tag=='delete'){
				if(!confirm('ɾ����˶������������ݽ����ɻָ�!\r\n����֧��,�˻�����־!\r\n��ȷ��Ҫɾ���Ķ�����?'))	return false;	
			}
			if(tag=='invalid'){
				var strs = "���������رնԴ˶����Ĳ���.\r\n��ȷ��Ҫ���ô˶���Ϊ�����ö�����?\r\n�˲������ɻָ�!";
				if(!confirm(strs))return false;	
			}
			if(tag=='finished'){
				var str = "���������رմ˶������߼�����.\r\n�رպ���ֻ�ܶԶ��������ۺ���!��ȷ��Ҫ������?";
				if(!confirm(str))return false;
			}
			/*�ٳֵ�*/
			if(tag=='confirm' && config){
				window.parent.showWindow('ȷ�϶�����֧��','index.php?m=order&a=set_actul_pay_money&tag=confirm',850,400);
				return false;	
			}
			/*�ٳֵ�*/
			if(tag =='confirm_pay'){
				window.parent.showWindow('ȷ��֧��','index.php?m=order&a=set_actul_pay_money&tag=actual',850,400);
				return false;	
			}
			
			if(tag=='unpay' && !confirm('�˲���������ʵ��֧������Ϊ0,\r\n�����ڽ���ɾ���û���֧����־.\r\nȷ��Ҫ����Ϊδ֧��״̬��?\r\n'))return false;
			if(tag=='delivery' && !confirm('ȷ��Ҫ����Ϊ����״̬��?\r\n�˲��������Իع�!'))return false;
			var deliver_no = $("#order_delivery_no").val();
			
			/*�ٳֵ�*/
			if(tag=='delivery'){
				_call_no();
				return false;
			}
			var post_options = {
					task:tag,
					content:val,
					delivery_no:deliver_no
			};
			$.ajax({type:'POST',url:'index.php?m=order&a=confirmOrder',data:post_options,success:function(callback){
						window.parent.hidenLayer();
					switch(callback){
						case 'EMPTY':
							window.parent.showNotice('�޿��ö�������!');
						break;
						case 'EMPTY_REMAK':
							window.parent.showNotice('����д��ע!');
							return false;
						break;
						case 'empty_order_delivery_no':
							window.parent.showNotice('����д��������!');
							window.location.reload();
							return false;
						break;
						case 'NO_AUTH':
							alert('����Ȩִ�д˲���!');
							window.location.reload();
						break;
						case 'must_confirm_order_and_do':
							window.parent.showNotice('����ȷ�϶�����');
						break;
						case 'must_confirm_order_and_pay':
							window.parent.showNotice('����ȷ�϶�������֧����');
						break;
						case 'must_confirm_all':
							window.parent.showNotice('����ȷ�϶��������ȴ��֧��');
						break;
						case 'must_confim_3':
							window.parent.showNotice('����ȷ�϶���,֧����������ܲ�������״̬!');
						break;
						case 'delete_ok_and_page_reload':
							alert('ɾ�������ɹ�,ҳ�潫��ת');
							window.location.href='index.php?m=order&a=orderList';
						break;
						case 'CAN_NOT_DELETE_ORDER':
							window.parent.showNotice('��֧����������ɾ��,��������Ϊδ֧��״̬!');
						break;
						case 'CAN_NOT_SET_STATUS':
							window.parent.showNotice('�������øö�����״̬.����ȷ�ϸö����Ƿ�������״̬��,��ȷ��,�Ѿ�֧��,�ѷ���');
						break;
						case 'CAN_NOT_DELETE':
							window.parent.showNotice('����ɾ���ö���!');
						break;
						case 'OK':<!--ҳ����״-->
							window.parent.showNotice('�����ɹ�!');
							window.location.reload();
						break;
						default:alert(callback);return false;
					}
				}
			});
		}
    </script>
 </div>
 {/if}<!--����������ע�߼�����-->
 <!--#������ע ����-->
 
  <!--����ѡ��-->
  <h1 class="c_bar">����ѡ��</h1>
 <div class="c_content">

<!--��������״̬����-->
<div id="order_status_set">
<!--#δȷ��-->
{if $order_detail.order_confirm_status neq '2'} <!--�����˻� ��������-->
<table width="100%" cellpadding="0" cellspacing="0" align="center">
	<tr>
        <td align="left">
<!--�ж϶���״̬-->
{if ($order_detail.order_confirm_status eq '0' || $order_detail.order_confirm_status eq '1')  && !$order_detail.user_cancel_flag}
 	{if $can_set_confirm && $order_detail.order_confirm_status eq '0'}<a onclick="submit_order_confirm('confirm','{$order_detail.order_id}');" class="block_button form_btn">ȷ�϶���</a>{/if}
    {if $order_detail.pay_status eq '0' && $order_detail.order_confirm_status  eq '0'}
 		 {if $can_set_invaild}<a onclick="submit_order_confirm('invalid','{$order_detail.order_id}');" class="block_button form_btn">��Ϊ��Ч��</a>{/if}
         {if $can_deleteorder}<a onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a><!--ɾ������-->{/if}
     {/if}
    {if $order_detail.pay_status eq '3'}
  	  {if $can_set_payconfirm}<a class="block_button form_btn" onclick="submit_order_confirm('confirm_pay','{$order_detail.order_id}');">֧��ȷ��</a> {/if}
 		 {if $can_set_invaild}<a onclick="submit_order_confirm('invalid','{$order_detail.order_id}');" class="block_button form_btn">��Ϊ��Ч��</a>{/if}
         {if $can_deleteorder}<a onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a><!--ɾ������-->{/if}
     {/if}
{/if}
<!--#���� ��ȷ��-->
{if $order_detail.order_confirm_status eq '2'}
    {if $can_set_confirm}<a onclick="submit_order_confirm('confirm','{$order_detail.order_id}');"  class="block_button form_btn">ȷ�϶���</a><!--ȷ�϶���-->{/if}
    {if $can_deleteorder}<a  onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a>{/if}
{/if}
<!--��������-->
{if $is_huodaofukuan}
<!--#�����������������-->
<!--����ж�-->
{if $order_detail.pay_status eq '0' && $order_detail.order_confirm_status=='1' && $order_detail.shiping_status =='0'}
    {if $can_set_setpeihuo}<a  class="block_button form_btn" onclick="submit_order_confirm('rationing','{$order_detail.order_id}');">���</a>{/if}
    <a class="block_button form_btn"  href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank">��ӡ������</a>
   {if $can_deleteorder}<a onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a><!--ɾ������-->{/if}  
 {/if}
 
 <!--�����ж�-->
 {if $order_detail.pay_status eq '0' && $order_detail.order_confirm_status=='1' && $order_detail.shiping_status =='1'}
     {if $can_set_fahuo}<a class="block_button form_btn" onclick="submit_order_confirm('delivery','{$order_detail.order_id}');">����</a>{/if}
     	<a class="block_button form_btn" onclick="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank" >��ӡ������</a>
 {if $can_deleteorder}<a onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a><!--ɾ������-->{/if}
     
 {/if}
 <!--����ȷ���ж�-->
{if $order_detail.pay_status eq '0' && $order_detail.order_confirm_status=='1' && $order_detail.shiping_status =='2'}
	{if $can_orderarrival}
		<a class="block_button form_btn"  onclick="submit_order_confirm('arrival','{$order_detail.order_id}');">����ȷ��</a>
 		<a class="block_button form_btn" href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank">��ӡ������</a>
 	{/if}
{/if}
<!--������Ǯ-->
{if $order_detail.pay_status eq '0' && $order_detail.order_confirm_status=='1' && $order_detail.shiping_status =='3'}
    {if $can_set_payconfirm}<a class="block_button form_btn" onclick="submit_order_confirm('confirm_pay','{$order_detail.order_id}');">֧��ȷ��</a> {/if}
	{if $can_orderarrival} 		<a class="block_button form_btn" href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank">��ӡ������</a>{/if}

{/if}

{else}

<!--��������-->
 {if $order_detail.pay_status eq '0' && $order_detail.order_confirm_status eq '1' }<!--���δ֧��-->
    {if $can_set_payconfirm}<a class="block_button form_btn" onclick="submit_order_confirm('confirm_pay','{$order_detail.order_id}');">֧��ȷ��</a>{/if}
    {if $can_set_invaild}<a class="block_button form_btn" onclick="submit_order_confirm('invalid','{$order_detail.order_id}');" >��Ϊ��Ч��</a>{/if}
     {if $can_deleteorder}<a onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a><!--ɾ������-->{/if}  
{/if}
<!--����ж�-->
{if $order_detail.pay_status eq '1' && $order_detail.order_confirm_status=='1' && $order_detail.shiping_status =='0'}
    {if $can_set_setpeihuo}
         <a  class="block_button form_btn" onclick="submit_order_confirm('rationing','{$order_detail.order_id}');">���</a>
    {/if}
    {if $can_set_setunpay}
 	<a class="block_button form_btn" onclick="submit_order_confirm('unpay','{$order_detail.order_id}');">��Ϊδ֧��</a>
    {/if}
    <a class="block_button form_btn" onclick="window.open('index.php?m=order&a=print_delive&id={$order_detail.order_id}')">��ӡ������</a>
 {/if} 
 <!--�����ж�-->
 {if $order_detail.pay_status eq '1' && $order_detail.order_confirm_status=='1' && $order_detail.shiping_status =='1'}
     {if $can_set_fahuo}
        <a class="block_button form_btn" onclick="submit_order_confirm('delivery','{$order_detail.order_id}');">����</a>
        <a class="block_button form_btn" href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank">��ӡ������</a>
     {/if}

    {if $can_set_setunpay}
 	<a class="block_button form_btn" onclick="submit_order_confirm('unpay','{$order_detail.order_id}');">��Ϊδ֧��</a>
    {/if}
     
 {/if}
 <!--����ȷ���ж�-->
{if $order_detail.pay_status eq '1' && $order_detail.order_confirm_status=='1' && $order_detail.shiping_status =='2'}
	{if $can_orderarrival}
		<a class="block_button form_btn"  onclick="submit_order_confirm('arrival','{$order_detail.order_id}');">����ȷ��</a>
 		<a class="block_button form_btn" href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank">��ӡ������</a>
 	{/if}
{/if}
    
{/if}<!--�������� ����-->


{if $order_detail.pay_status eq '1' && $order_detail.order_confirm_status=='1' && $order_detail.shiping_status =='3' && $order_detail.tuihuo_sign <=0}
	{if $can_set_closeorder}
        <a  onclick="submit_order_confirm('finished','{$order_detail.order_id}');" class="block_button form_btn">�������</a>
       <a class="block_button form_btn" href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank">��ӡ������</a>
       <a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=order&a=editOrder&type=settuihuo&id={$order_detail.order_id}',750,350);" class="block_button form_btn">�ֶ������˻�</a>
 	{/if}
{/if}

{if $order_detail.pay_status eq '1' && $order_detail.order_confirm_status eq '3' && $order_detail.shiping_status eq '3'}
        <div class="order_finished">�ö��������!
     <a class="block_button form_btn" href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank">��ӡ������</a>
     <a href="index.php?m=order&a=printOrder&id={$order_id}" target="_blank"  class="block_button form_btn">��ӡ����</a>
     {if $order_detail.tuihuo_sign neq '3'  &&  $order_detail.tuihuo_sign neq '2'}
     <a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=order&a=editOrder&type=settuihuo&id={$order_detail.order_id}',750,350);" class="block_button form_btn">�ֶ������˻�</a>
     {/if}
        </div>
 {/if}
{*}
{if $order_detail.tuihuo_sign  >=1 || $order_detail.tuikuan_flag>=1}
    <a href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank"  class="block_button form_btn">�鿴������</a>
    <a href="index.php?m=order&a=printOrder&id={$order_id}" target="_blank"  class="block_button form_btn">��ӡ����</a>
{/if}
{*}
</td>
    </tr>
</table>
{elseif $order_detail.order_confirm_status eq '2' && !$order_detail.user_cancel_flag && !$order_detail.tuihuo_sign}
	<div class="order_finished" style="height:30px; line-height:30px;">
<div style="float:left; line-height:30px;"> <strong>����Ա��Ϊ��Ч����!</strong></div>
     {if $can_deleteorder}<a onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a><!--ɾ������-->{/if}
    </div>
{elseif $order_detail.order_confirm_status eq '2' && $order_detail.user_cancel_flag>0}
	<div class="order_finished" style="height:30px; line-height:30px;">
<div style="float:left; line-height:30px;">    <strong>�û�������ȡ������!</strong></div>
     {if $can_deleteorder}<a onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a><!--ɾ������-->{/if}
</div>
{elseif $order_detail.tuihuo_sign > '0' && !$order_detail.user_cancel_flag}
    {if $order_detail.pay_status eq '0'}
    <a onclick="submit_order_confirm('delete','{$order_detail.order_id}');"  class="block_button form_btn">ɾ������</a>
    {/if}
    <a href="index.php?m=order&a=print_delive&id={$order_detail.order_id}" target="_blank"  class="block_button form_btn">�鿴������</a>
    <a href="index.php?m=order&a=printOrder&id={$order_id}" target="_blank"  class="block_button form_btn">��ӡ����</a>
    </div>
{else}
	- 
{/if}
</div>

 </div><!--#����ѡ�����-->
 
 <!--#������־-->
{if $remark_data}
 <h1 class="c_bar">������־</h1>
 <div class="c_content">
  <table class="table_list">
    <tr>
        <th>{$lang.order.order_oprator}</th>
        <th>{$lang.order.opt_time}</th>
        <th>{$lang.order.order_status}</th>
        <th>{$lang.order.order_pay_status}</th>
        <th><!--����״̬-->{$lang.order.roauting_status}</th>
        <th><!--��ע��Ϣ-->{$lang.order.remark_info}</th>
    </tr>
{foreach from=$remark_data item=re}
	<tr>
        <td align="center">{$re.re_operator_name}</td>
        <td align="center" nowrap="nowrap">{$re.re_add_time}</td>
        <td align="center">{if $re.order_confirm_status eq '3'}{$lang.order.has_finished}<!--�����-->{elseif $re.order_confirm_status eq '1'}<!--��ȷ��-->{$lang.order.order_has_confirmed}{elseif $re.order_confirm_status eq '2' }<font class="blue">{$lang.order.invild}<!--��Ч--></font>{elseif $re.order_confirm_status eq '0' }<!--�ȴ�ȷ��-->{$lang.order.waiting_stautus}{else}N/A{/if}</td>
        <td align="center"><font class="blue">{if $re.pay_status eq '0'}<!--δ֧��-->{$lang.order.order_not_pay}{elseif $re.pay_status eq '1'}<!--��֧��-->{$lang.order.order_has_pay}{elseif $re.pay_status eq '2'}<!--֧��ʧ��-->{$lang.order.pay_error}{elseif $re.pay_status eq '3'}֧������{else}N/A{/if}</font></td>
         <td align="center">
    {if $re.shiping_status eq '0'}<font class="blue"><!--δ����-->{$lang.order.not_shiping_order}</font>{elseif $re.shiping_status eq '1'}{$lang.order.peihuozhong}{elseif $re.shiping_status eq '2'}<!--������-->{$lang.order.pay_and_shiping}{elseif $re.shiping_status eq '3'}{$lang.order.order_has_confirmed}{else}N/A{/if}</td>
         <td><div style=" width:430px;overflow:hidden;">{$re.re_content}</div></td>
     </tr>
     {/foreach}
</table>
 </div>{/if}
 <div class="clear"></div>
</div><!--#���� table_item_base-->
 <div class="clear"></div>
</div><!--#end php_right_main_content-->

{include file="frame_footer.php"}
{/if}