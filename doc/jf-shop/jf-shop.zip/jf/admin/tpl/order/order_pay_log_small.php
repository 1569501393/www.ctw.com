<?php exit('die'); ?>
<h1 class="c_bar">֧����־</h1>
<div class="c_content">
 {if !$order_detail.order_pay_log && !$order_detail.order_payed_points_log.pay_log_data}
  	<div class="notice_msg"> �޿���֧����־! </div>
  {else}
  <!--#RMB֧����־-->
  {if $order_detail.order_pay_log}
      {assign var='pay_log_data' value=$order_detail.order_pay_log}
      {assign var='pay_log_all_payed_money' value=$order_detail.pay_log_all_payed_money}
      {include file="order/order_pay_log_part.php"}
  {/if}
  
  <!--#����֧����־-->
  {if $order_detail.order_payed_points_log.pay_log_data}
  	{assign var='order_payed_points_log' value=$order_detail.order_payed_points_log}
	{include file="order/order_pay_point_log_part.php"}
  {/if}

{/if}
</div>
