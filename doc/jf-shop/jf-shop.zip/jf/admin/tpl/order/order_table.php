<?php exit(); ?>
{if $action eq 'show'}
<script type="text/javascript">
	$(function(){
		$("input[name='name[]']").addClass('export_must_fill_in')
		$("#php_export_order_form").submit(function(){
			if(!get_checkbox_val('export_must_fill_in')){
				window.parent.showNotice('������ѡһ��!');
				return false;
			}
		});
	});
</script>
<div class="table_item_base">
<div class="notice_msg">
�˴���������������Ϊ��Ӧ�����������,��������2010-10-15 �� 2010-11-15�յĵĶ��� �� �ٵ㵼�����ǵ����˷�Χ�ڵĶ�������!
</div>
	<h1 class="c_bar">��������ѡ��</h1>
        <div class="c_content">
            <div class="order_export_set">
            <form action="index.php?m=order&a=exportorder" id="php_export_order_form"  target="_blank" method="post">
            <div id="export_order_pannel">
            <ul class="set_menus">
                <li><input type="checkbox"  class="check_box_call"  value="order_sn" name="name[]"  checked="checked"  /><samp>������</samp></li>
               <li><input type="checkbox" class="check_box_call" value="order_count" name="name[]" checked="checked" /><samp>��Ʒ����</samp></li> 
               <li><input type="checkbox"  class="check_box_call"  value="order_confirm_status_all" checked="checked" name="name[]" /><samp>����״̬</samp></li>
                <li><input type="checkbox" class="check_box_call" value="add_time" name="name[]" checked="checked" /><samp>�µ�ʱ��</samp></li>
                <li><input type="checkbox" class="check_box_call" value="delivery_id" name="name[]" checked="checked" /><samp>��ݷ�ʽ</samp></li>
                <li><input type="checkbox" class="check_box_call" value="delivery_no" name="name[]" checked="checked"  /><samp>��������</samp></li>
                <li><input type="checkbox" class="check_box_call" value="shiping_delivery_time" name="name[]" /><samp>����ʱ��</samp></li>
                <li><input type="checkbox"  class="check_box_call" value="shiping_status" name="name[]" /><samp>����״̬</samp></li>  
               <li><input type="checkbox" class="check_box_call" value="pay_status" name="name[]" checked="checked"  /><samp>֧��״̬</samp></li>  
                <li><input type="checkbox" class="check_box_call" value="shipping_time" name="name[]" /><samp>����ʱ��</samp></li>
                <!--
                <li><input type="checkbox" class="check_box_call" value="order_pay_log" name="name[]" /><samp>֧����־</samp></li>
                <li><input type="checkbox" class="check_box_call" value="order_goods_log" name="name[]" /><samp>��Ʒ��־</samp></li>
                -->
                <li><input type="checkbox" value="pay_confirm_time" name="name[]" /><samp>ȷ�ϸ���ʱ��</samp></li>
                <li><input type="checkbox" class="check_box_call" value="goods_money" name="name[]" /><samp>��Ʒ����</samp></li> 
                <li><input type="checkbox" class="check_box_call" checked="checked" value="order_money" name="name[]" /><samp>�ܶ�</samp></li> 
                <li><input type="checkbox" class="check_box_call" checked="checked" value="order_total_point_fee" name="name[]" /><samp>�ܶ�(����)</samp></li> 
                <li><input type="checkbox" class="check_box_call" value="delivery_fee" name="name[]" /><samp>���ͷ���</samp></li>
                <li><input type="checkbox" class="check_box_call" value="mem_username" name="name[]" /><samp>������</samp></li>
                <li><input type="checkbox" class="check_box_call" value="receive_realname" name="name[]" /><samp>�ջ�������</samp></li>
                <li><input type="checkbox" class="check_box_call" value="receive_phone" name="name[]" /><samp>�ջ��˵绰</samp></li>
                <li><input type="checkbox" class="check_box_call" value="receive_postno" name="name[]"/><samp>�ջ����ʱ�</samp></li>  
                <li><input type="checkbox" class="check_box_call" value="receive_email" name="name[]" /><samp>�ջ���E-mail</samp></li>  
                <li><input type="checkbox" class="check_box_call" value="receive_mobile" name="name[]" /><samp>�ջ����ֻ�</samp></li>
                <li><input type="checkbox" class="check_box_call" value="receive_area" name="name[]"/><samp>�ջ��˵���</samp></li>
                <li><input type="checkbox" class="check_box_call" value="receive_address" name="name[]"/><samp>�ջ��˵�ַ</samp></li>
            </ul>
            </div>
            <div class="clear"></div>
            <input type="submit"  value="<% _e('����');%>"  class="form_submit " style="display:none;"/>
            <a  href="javascript:;" onclick="submit_form('php_export_order_form');" class="block_button form_btn" >����</a>
            <input type="checkbox" value="" id="check_box_call" />ȫѡ
            <script type="text/javascript">
            	$(function(){
					$("#export_order_pannel li").each(function(){
						var s = $(this).find('samp');
						var i = $(this).find('input');
						$(i).val($(i).val()+'__temp__'+$(s).html());
					});
					check_all('check_box_call','check_box_call');
					$("#php_export_order_form").submit(function(){
						if(!get_checkbox_val('check_box_call')){
							window.parent.showNotice('��ѡ��Ҫ����������!');
							return false;
						}
					});
				});
            </script>
            </form>
            <div>
    </div>
</div>
{/if}

{if $action eq 'export'}

<head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<style>td{vnd.ms-excel.numberformat:@}</style>
</head>
	<table  class="table_list"  width="100%" border="1">
        <tr>
        {foreach from=$menus item=item}
        	<th nowrap="nowrap">{$item.name}</th>
        {/foreach}
          </tr>
        {foreach from=$order_data.data item=order}
        {if $order.order_confirm_status eq '2'}
        	{assign var='invaild_order' value=1}	
        {/if}
        	<tr>
            {foreach from=$menus item='item'}
            	<td align="center">
                	{foreach from=$order key=key item='list'}
                    	{if $item.key eq $key}
                        	{if $key eq 'add_time'}
                           		{$order.add_time|date_format:"%Y-%m-%d %H:%M:%S"}
							{elseif $key eq 'delivery_no'}
                           		{if $order.delivery_no}
                                {if $order.delivery_cp_no}{$order.delivery_no}{else}{$order.delivery_no}{/if}
                                {else}-{/if}
                            {elseif $key eq 'delivery_id'}
                            	{$order.delivery_names}
                             
                            {elseif $key eq 'receive_paycode'}
								{$order.receive_paycode_ename}
                            {elseif $key eq 'mem_username'}
                              	 {$order.mem_username|default:'<span class="blue">����</span>'}
                            {elseif $key eq 'pay_status'}
									 {if !$order.user_cancel_flag} 
                                	{if $order.pay_status eq '1'}<span class="green">��</span>{elseif $order.pay_status eq '3'}<span class="red">֧������</span>{else}<span class="red">��</span>{/if}
										{else}
                                        	-
									{/if}
                             {elseif $key eq 'pay_checked_status'}
                                {if $order.pay_checked_status eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                            {elseif $key eq 'has_payed_order_money'}
                             	{$order.has_payed_order_money|default:'-'}
							{elseif $key eq 'user_cancel_flag'}<!--ȡ������-->
                               
                            	{if $order.user_cancel_flag}
                                <strong class="red">��ȡ��</strong>
                                	{else}
                                    -
                                {/if}
                            {elseif $key eq 'order_confirm_status' && $item.name eq '��Ч'}<!--��Ч����-->
                         
                            	{if !$order.user_cancel_flag}  
	                            	{if $order.order_confirm_status eq '2'}<span class="green">��</span>{else} - {/if}
                                {else}
                                	-
                                {/if}
                            {elseif $key eq 'order_confirm_status' && $item.name eq 'ȷ��'}<!--ȷ�϶���-->
                           	
                            {if !$order.user_cancel_flag} 
                            	
                            	{if $order.order_confirm_status >='1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                                
                                {else}
                                -
                                {/if}
                            {elseif $key eq 'shiping_status' && $item.name eq '���'}<!--���״̬-->
                            
                            	{if !$order.user_cancel_flag}                             
                                	{if $order.shiping_status eq '1' ||  $order.shiping_status eq '2'  || $order.shiping_status eq '3'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                                    {else}
                                    	-
                                    {/if}
                                    
                            {elseif $key eq 'shiping_status' && $item.name eq '����'}<!--����״̬-->
                            
                            	{if !$order.user_cancel_flag}  
                                	{if $order.shiping_status eq '2' || $order.shiping_status eq '3'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                                   {else}
                                   	-
                                {/if}
                            {elseif $key eq 'order_confirm_status'}<!--ȷ��״̬-->
                            	{if !$order.user_cancel_flag}  
	                           		{if $order.order_confirm_status eq '3' ||   $order.order_confirm_status eq '2'}<span class="green">��</span>{else}<span class="red">��</span>{/if}		
                                	{else}
                                    	-	
                                {/if}
                                

                            {elseif $key eq 'receive_paycode'}
                            	
	{if $order.receive_paycode eq '��������'}<span class="red">��������</span>{else} {$order.receive_paycode|default:'-'}{/if}
    
                            {elseif $key eq 'waterline_no'}
                            	 {$order.waterline_no|default:'-'} 
                             {elseif $key eq 'tuihuo_sign'}
                             	{if $order.tuihuo_sign eq '1'}
                                        {if $order.tuihuo_sign eq '1' && !$order.tuihuo_do_flag}
                                         <span class="red">������</span>
                                        {elseif $order.tuihuo_do_flag eq '2'}
                                        <span class="red">�û�������</span>     
                                        {elseif $order.tuihuo_do_flag eq '1'}
                                            <span class="red">�ȴ��û���</span>
                                        {/if}
                                	{elseif $order.tuihuo_sign eq '2'}
                                    	<span class="red">�˻����</span>
                                    {elseif $order.tuihuo_sign eq '3'}
                                    	<span class="red">����Ա�����˻�</span>
                                	{else} 
                                    	- 
                                    {/if}
                                    
                             {elseif $key eq 'tuikuan_flag'}<!--�˿�-->
                             	{if $order.tuikuan_flag eq '1'}
			                          {if $order.tuikuan_flag eq '1' && !$order.tuikuan_do_flag}
                                      	<span class="red">�ȴ�����</span>
                                     {elseif $order.tuikuan_do_flag eq '2'}
                                        <span class="red">������<br />�û�������</span>     
                                        {elseif $order.tuikuan_do_flag eq '1'}
                                            <span class="red">������<br />�ȴ��û��ظ�</span>
                                        {/if}
                                 {elseif $order.tuikuan_flag eq '2'}
                                 	<span class="red">�˿����</span>
                                    {else}
                                     - 
                                {/if}
							
                            {else}
                           		{$list|default:'-'}
                            {/if}
                            
                        {/if}
                    {/foreach}
                </td>
            {/foreach}
      </tr>
      {/foreach}
{if $edata.total_order_money}
      <tr>
      	<td colspan="{$key_total|default:'20'}" align="right"><!-- colspan="{$key_total}"-->

<strong>�ܶ</strong>{$edata.total_order_money|format_money}��
<strong>ʵ�գ�</strong>{$edata.total_order_payed_money|format_money} 
     {if $edata.total_order_payed_money|format_money}(�Ѻˣ� {$edata.checked_money|format_money}���ˣ�{$edata.unchecked_money|format_money}) {/if}
     {if $edata.total_order_unpayed_money} <strong>δ����</strong>{$edata.total_order_unpayed_money|format_money}  {/if} 
        </td>
      </tr>
{/if}
{if $edata.checked_money_data}
<tr>
	<td colspan="{$key_total|default:'20'}" align="right">
    	<strong>�Ѻˣ�</strong><br />
{foreach from=$edata.checked_money_data item='item'}
    {$item.payment_name|default:'δ֪֧����ʽ'} ��{$item.total_checked_money}<br />
{/foreach}
    </td>
</tr>
{/if}
{if $edata.unchecked_money_data}
<tr>
	<td colspan="{$key_total|default:'20'}" align="right">
<strong>���ˣ�</strong><br />
{foreach from=$edata.unchecked_money_data item='item'}
  {$item.payment_name|default:'δ֪֧����ʽ'} ��{$item.total_unchecked_money|format_money}<br />
{/foreach}
    </td>
</tr>
{/if}
    </table>
{/if}