<?php exit('die'); ?>
{if $action eq 'setMenu'}
<script type="text/javascript">
	$(function(){
		$("#submit_menu_form").submit(function(){
			var msg = '������ѡ��һ��!';
			if(!get_checkbox_val('fixed_val')){
				window.parent.showNotice(msg);return false;
			}
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
					window.parent.showNotice(php_do_ok);
					window.frames['rightFrame'].location.reload();
					close_window();
					break;
					case 'EMPTY':
						window.parent.showNotice(msg);
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
<form method="post" action="index.php?m=order&a=setMenu" id="submit_menu_form">
<div class="table_item_base">
	<h1 class="c_bar">�����б�ѡ������</h1>
    <div class="c_content">
	<div class="set_menu_main">
        <div class="set_menus">
        <ul>
        {foreach from=$data item='item'}
        	<li><label><input  type="checkbox" class="fixed_val" value="{$item.key}__{$item.name}" {if $item.sec eq '1'} checked="checked"{/if} name="set[]" /> 
            {$item.name}</label></li>
        {/foreach}
        <div class="clear"></div>
        </ul>
<div class="set_sub"><a  class="block_button form_btn" href="javascript:;" onclick="$('#submit_menu_form').submit();">��������</a></div>
        </div>
    </div>
    </div>
    </div>
</form>
{/if}