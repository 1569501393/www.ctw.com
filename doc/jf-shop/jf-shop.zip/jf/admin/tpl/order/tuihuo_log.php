<?php exit('�˻�����'); ?>
{if $action eq 'tuihuanhuo_log'}
<div id="tuikuan_logs">
	<h1 class="tui_title">�˻����봦��-SN{$order_sn} </h1>
{if $data}
    <div class="all_pannel_tag">
    {foreach from=$data item='list'}
    <!--�û�-->
    {if $list.content}
    <div class="user_post_list">
    <div class="user_post_bar">[#{$list.id}]�ύʱ�䣺{$list.time|date_format:"%Y-%m-%d %H:%M:%S"} IP��{$list.ip} ��ϵ��ʽ��{$list.user_contact_method}</div>
    <span class="lines">------------------------------------------------------------------------------------------------------------------------------------</span>
    <div class="user_post_content">{$list.content|nl2br}</div>
    <div class="clear"></div>
    </div>
    {/if}
    <!--����Ա-->
    {if $list.who_do}
    <div class="adminpannel">
    <div class="user_post_bar">[#{$list.id}]�ظ��ˣ�{$list.who_do} �ظ�ʱ�䣺{$list.time|date_format:"%Y-%m-%d %H:%M:%S"}</div>
    <span class="lines">------------------------------------------------------------------------------------------------------------------------------------</span>
        <div class="admin_content">{$list.do_remark|nl2br}</div>
         <div class="ccolor"></div>
    </div>
    {/if}
    {/foreach}
    </div>
<div class="replay_contents">
{if $order_data.tuihuo_sign neq '2'}
	<form method="post" action="index.php?m=order&a=dotuihuo" id="do_admin_replay">
    	<input type="hidden" value="" id="close_tag"  name="close_tag"/>
    	<textarea name="replay_content" class="do_tags_post_must" style="width:450px; height:100px;"></textarea>
        <br />
        <input type="submit" value="�ظ�"  class="form_submit"  style="display:none;"/> 
        <a onclick="submit_form('do_admin_replay');" class="block_button form_btn" >�ظ�</a>
        <a onclick="set_tuihuo_ok(this);" class="block_button form_btn" >�����˻��ɹ�</a>
         <a onclick="reload_data(this);" class="block_button form_btn">ˢ��</a>
    </form>
<script type="text/javascript">
	function reload_data(){
		var c = find_window_class();
		$('.'+c).html(getData('index.php?m=order&a=dotuihuo&rand='+Math.random()));
	}
	function set_tuihuo_ok(){
		if(!check_form_is_empty('do_tags_post_must'))return false;
		if(!confirm('ȷ�������˻��ɹ���?\r\n������ɺ����ֹ�����Ӧ��Ա�˿�!\r\nͬʱ�˶���������!'))return false;
		$("#close_tag").val('tuihuo_ok');
		$("#do_admin_replay").submit();
	}
	$(function(){
		var doms = $("#tuikuan_logs").parent().attr('class').split(' ');
		var kee = '.'+doms[1];
		$("#do_admin_replay").submit(function(){
			if(!check_form_is_empty('do_tags_post_must'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						window.parent.showNotice('�����ɹ�!');
						_close_window_one();
						window.frames['rightFrame'].location.reload();
					break;
					case 'NO_DATA':
						alert('�Ƿ�����!');
					break;
					case 'EMPTY':
						alert('����д������!');
					break;
					default:
						alert(data);
				}
			});
			return false;
		});
	});
</script>
{else}
<div class="notice_msg">�ѹر�!</div>
{/if}
</div>
{else}
<div class="no_data">�޿�������!</div>
{/if}
</div>
{/if}