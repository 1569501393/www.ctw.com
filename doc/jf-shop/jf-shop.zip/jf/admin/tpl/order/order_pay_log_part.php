<?php exit('die'); ?>
<table class="table_list">
<tr>
	<td colspan="10"><h3>֧����־(RMB)</h3></td>
</tr>
<tr>
    <th>���</th>
    <th>ʵ��֧��</th>
    <th>ʱ��</th>
    <th>֧����ʽ</th>
    <th>��ˮ��</th>
    <th>״̬</th>
    <th>��Ա</th>
</tr>
{foreach from=$pay_log_data item='tag'}
    <tr>
        <td align="center">{$tag.order_sn}</td>
        <td align="center">{$tag.payed_money}</td>
        <td align="center">{$tag.pay_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        <td align="center">{$tag.pay_name}</td>
        <td align="center">{$tag.pay_sn}</td>
        <td align="center">{if $tag.check_status eq '1'}<samp class="blue">�Ѻ�</samp>{else}<samp class="red">δ��</samp>{/if}</td>
        <td align="center">{if $tag.mem_id}<a href="javascript:;" onclick="window.parent.showWindow('��Ա����','index.php?m=member&a=detail&memid={$tag.mem_id}&noborder=true',960,350);">��Ա����</a>{else} - {/if}</td>
    </tr>
{/foreach}
<tr>
    <td colspan="7" align="right" style="padding-right:10px;">ʵ�գ�{$pay_log_all_payed_money.money_format}
    {if $order_detail.order_total_need_pay_fee>0}
	    <strong class="red">
        ����֧����
        {$order_detail.order_total_need_pay_fee_format}
        </strong>
	{elseif $order_detail.order_total_need_pay_fee<0}
    	 <strong class="red">
        ���գ�
        {$order_detail.order_total_need_pay_fee_format}
        </strong>
     {/if}
    </td>
</tr>
</table>