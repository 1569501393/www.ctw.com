<?php  if(!defined('PHP_TEMPLATE'))exit(); /*����*/?>
{if $action eq 'ordermerge'}
{literal}
<script language="javascript">
$(document).ready(function(){	
			$("#searchmerge").submit(function(){	
			
			$(this).ajaxSubmit(function(data){				
					$("#search_merge").show();	
					$("#search_merge").html(data);
			});
			return false;   
			
			 }); 
			
})
</script>
<script language="javascript">
$(document).ready(function(){
$('#form_ordermerge').submit(function (){
 var varles= get_checkbox_val('order_list');					 
	 if(!varles){ 
	   alert('��ѡ������һ���Ӷ���');
	   return false;
	 }else{				
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'ok':								
				showNotice('�ϲ������ɹ�');	
				//$.closeLayer();								
				break;
				case 'no':
				showNotice('�ϲ�������������');	
				break;
			}		
		})	
		return false;	  
	 }
	});
});
</script>
{/literal}

{if $error eq '0'}
<form action="index.php?m=order&a=ordermerge" method="post"  id='searchmerge'>
<table width="100%" style="width:100%; padding:0px; margin:0px;">
<input type="hidden" name="search" value="true">
<input type="hidden" name="main_sn" value="{$data.0.onum}">
<input type="hidden" name="user" value="{$data.0.memid}">
<input type="hidden" name="re_user" value="{$data.0.rnam}" />

<tr>

<td>&nbsp;&nbsp;{$lang.order.order_no}: <input type="text" value="" style="width:100px;" id="order_no" name="order_no"/></td>
<td>��ʼʱ��: <input type="text"    id="begain_time"  class="select_date_time promotion_tags date date_input" name="begain_time" onfocus="show_date(this);" value="{$get_data.goods_promotion_begain_time}" /></td>
<td>����ʱ��: <input type="text" id="end_time"    class="select_date_time promotion_tags date date_input"  name="end_time"  onfocus="show_date(this);" value="{$get_data.goods_promotion_end_time}" /> </td>

<td><input type="submit" value="��ѯ" class="form_submit" /></td>
</tr>

</table>
</form>


<form action="index.php?m=order&a=ordermerge"  id="form_ordermerge" method="post">
<input type="hidden" name="main_id" value="{$data.oid}" />
<input type='hidden' name='main_sn' value="{$data.0.onum}" />

<table class="table_list" width="100%" style="width:100%; padding:0px; margin:0px;">


<tr> <td width="18%"><input type='checkbox' name='check_all_order' id='check_all_order' value="{$data.0.oid}"> ȫѡ</td> <td width="40%" class="main_num">&nbsp;&nbsp;��������:{$data.0.onum}</td><td colspan="2" >&nbsp;&nbsp;������:{$data.0.memname} &nbsp;�ջ���:{$data.0.rnam}&nbsp;�û���:{$data.0.memname}</td></tr>

<tr ><td colspan="4" id='search_merge' style="display:none;"></td></tr>

</table>
</form>
{else}
 <table class="table_list" width="100%" style="width:100%; padding:0px; margin:0px;">


<tr><td>{$error}</td></tr>

</table>
{/if}
{literal}
<script language="javascript">
$(function(){
		   
checkAllFormData('check_all_order','order_list');


});

function show_detail(tr_id){

 var detail="#order_detail_"+tr_id;	
 
 $(detail).show();

 if($.trim($(''+detail+' > td').html())=="" || $.trim($(''+detail+' > td').html())==null ){
	
	 $.get("index.php?m=order&a=orderdetail&oid="+tr_id+"",function(data){																		
	 $(''+detail+' > td').html(data);	 
	 }); 
 }

}

function hide_detail(tr_id){
	
	var detail="#order_detail_"+tr_id;		
	var detail_c='detail_content_'+tr_id;
	
	unset(detail_c);
	$(detail).hide();	
	
}
</script>




{/literal}
{/if}

<!--------------�ϲ���Ʒ�б�------------->
{if $action eq 'mergesearch'}
<table border="0" cellpadding="0" cellspacing="1" width="100%" style="padding:0; margin:0;">

{if $ordermerge}
{foreach from=$ordermerge name=name item=item}
<tr id="list_{$item.oid}">
<td height="28px;"><input type='checkbox' name='order_id[]' class="order_list"  value="{$item.oid}"></td>
<td>&nbsp;&nbsp;�Ӷ�����:<a href='index.php?m=order&a=viewOrder&id={$item.oid}'>{$item.onum}</a></td><td width="31%">&nbsp;&nbsp;����ʱ��: {$item.otime|date_format:"%Y-%m-%d"} </td><td width="11%"><a href='javascript:;' onclick="show_detail({$item.oid})"  >&nbsp;&nbsp;�鿴</a><a href="#" onclick="hide_detail({$item.oid})">&nbsp;&nbsp;�ر�</a></td>
</tr>
<tr id='order_detail_{$item.oid}' style="display:none;">
<td colspan="5" style="border:1px #F60 solid; height:27px;" id='detail_content_{$data.0.oid}'>  </td>
</tr>
{/foreach}
<tr><td colspan="5" align="center"><input type="submit" value='�ύ' class="form_submit" /></td></tr>
{else}
<tr><td>�Ӷ��� ������</td></tr>
{/if}

</table>
{else}
{/if}



<!---------------------------��Ʒ��ϸ------------------------>
{if $action eq 'orderdetail'}
<div   class="detail_content">

{if $data}

{foreach from=$data item=item name=name}
<div style="width:34%; text-align:left"><span >��Ʒ:{$item.gname}</span></div>
<div style="width:20%;">��Ʒ����:{$item.g_total}</div>
<div style="width:15%;">�۸�:{$item.cp}</div>
<div style="width:15%;">֧��״̬:δ֧��</div>
<div style="width:15%;">����״̬:δȷ��</div>
{/foreach}

{else}

<div align="center">û����Ʒ</div>
{/if}
</div>

{/if}
