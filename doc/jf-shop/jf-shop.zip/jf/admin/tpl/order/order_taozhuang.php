<?php exit('die'); ?>
 {if $good.taozhuang_extend_data}
<div class="cart_taozhuang">
    <samp class="blue">��װ��({foreach from=$good.taozhuang_extend_data item='tao' name='ename'} {$tao.goods_name} {if !$smarty.foreach.ename.last}��{/if}{/foreach})</samp>
  </div>
{/if}