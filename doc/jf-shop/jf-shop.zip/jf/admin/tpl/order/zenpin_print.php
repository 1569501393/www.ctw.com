<?php exit('die'); ?>
 {if $o.zenpin_extend_data}
<div class="call_append_data" style="text-align:left; width:250px;">
    <samp class="gray"><strong>��Ʒ:</strong>{foreach from=$o.zenpin_extend_data item='zp' name='zp_name'} {$zp.goods_name}{if !$smarty.foreach.zp_name.last}��{/if}{/foreach}</samp>
  </div>
{/if}