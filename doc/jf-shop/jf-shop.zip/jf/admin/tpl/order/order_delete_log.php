<?php exit('die'); ?>
{if !$is_ajax}{include file="frame_header.php"}{/if}
<!--����������ɾ����Ĳ���-->
{if $action eq 'view_delete_log'}
<div id="php_right_main_content">
<script type="text/javascript">
	function show_log_history(obj){
		var id = $(obj).attr('order_id');
		window.parent.showWindow($(obj).html()+'=>'+$(obj).attr('sn'),'index.php?m=order&a=viewDeleteOrderRemark&id='+id,950,400);
	}
</script>
    {if $data.total >0}
    <table class="table_list">
            <tr>
                <th>{$lang.order.order_oprator}</th>
                <th>{$lang.order.opt_time}</th>
                <th><!--������-->{$lang.order.order_no}</th>
                <th><!--״̬-->{$lang.order.status}</th>
                <th>��ʷ������¼</th>
                <th><!--������¼-->{$lang.order.order_recorder}</th>
            </tr>
           {foreach from =$data.data item=log}
            <tr>
                <td nowrap="nowrap" align="center">{$log.re_operator_name}</td>
                <td nowrap="nowrap" align="center">{$log.re_add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
                <td nowrap="nowrap" align="center">{$log.order_sn}</td>
                <td nowrap="nowrap" align="center">{if $log.flag eq '0'}�ճ�{elseif $log.flag eq '1'}<b class="blue">ɾ��</b>{/if}</td>
                <td align="center">
                {if $log.order_id}
                	<a href="javascript:;" onclick="show_log_history(this);" order_id="{$log.order_id}" sn="{$log.order_sn}" class="block_button form_btn">��־</a>
                {/if}
                </td>
                <td><div style="display:table-cell; width:500px; overflow:hidden;">{$log.re_content}</div></td>
            </tr>
            {/foreach}
    </table>
            {if $data.page}<div id="error_log"> {$data.page}</div>  {/if}
    {else}
        <div class="notice_msg">{$lang.php_nodata}</div>
    {/if}
</div>
{/if}
{if $action eq 'view_do_remark_history_log'}
    {if $data}
        <table class="table_list">
            <tr>
                <th>SN</th>
                <th>��������</th>
                <th>״̬</th>
                <th>����</th>
                <th>��ע</th>
            </tr>
            {foreach from=$data item='list'}
                <tr>
                    <td align="center">{$list.order_sn}</td>
                    <td align="center">{$list.re_add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
                    <td align="center"><span class="blue">{if $list.pay_status eq '0'}δ֧��{elseif $list.pay_status eq '1'}֧��{elseif $list.pay_status eq '3'}����֧��{/if}&nbsp;{if $list.order_confirm_status eq '0'}δȷ��{elseif $list.order_confirm_status eq '1'}ȷ��{elseif $list.order_confirm_status eq '2'}����{elseif $list.order_confirm_status eq '3'}���{/if}&nbsp;{if $list.shiping_status eq '0'}δ����{elseif $list.pay_status eq '1'}�����{elseif $list.pay_status eq '2'}������{elseif $list.pay_status eq '3'}����{/if}</td>
                    <td align="center">{if $list.flag eq '0'}������־{elseif $list.flag eq '1'}����{elseif $list.flag eq '2'}ȡ������{/if}<!--��־λ0->�����Ĳ�����¼ 1->�������� 2->ȡ������--></td>
                    <td>{$list.re_content}</td>
                </tr>
            {/foreach}
        </table>
    {else}
    	<div class="notice_msg">�޿�������!</div>
    {/if}
{/if}
{if !$is_ajax}
{include file="frame_footer.php"}
{/if}