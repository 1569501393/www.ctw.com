<?php  if(!defined('PHP_TEMPLATE'))exit('php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset={$outPutChar}" />
<title>{$alise_name}������</title>
<style type="text/css" media="screen">
body{ font-size:12px; color:#343434;}
a{ text-decoration:none; color: #272727;}
table{ border-collapse:collapse;}
table th{ font-weight:bold;}
.bar{ font-size:14px; border-bottom:1px solid #666; padding-bottom:4px; text-indent:15px;}
.ttitle{ border-bottom:1px solid #000; margin-bottom:8px; padding:10px;text-align:center; line-height:30px; font-size:2.5em; font-weight:bold;}
.print_now{background:#369; margin:0px auto;border:2px solid #efefef; width:80px; height:30px; line-height:30px; text-align:center; cursor:pointer; display:block; color:#fff; font-size:14px; font-weight:700;}
.main_pannel{ width:770px; margin:0px auto;}
.etright{ text-align:center; font-size:13px;line-height:20px; height:20px;}
.etright div{ float:left; width:250px; overflow:hidden; height:20px; line-height:20px;}
.bline{ border-bottom:1px solid #666; margin:10px auto;}
.status{ text-align:right; padding-right:20px; line-height:20px;}
.grays{border-bottom:1px solid #C8C8C8;margin:10px auto;}
.call_append_data{ border:1px dotted #CCC; padding:4px 1px; width:250px;}
.call_append_data strong{}
</style>
<style type="text/css" media="print">
.print_now{ display:none;}
body{ font-size:12px; color:#343434;}
a{ text-decoration:none; color: #272727;}
table{ border-collapse:collapse;}
table td{ line-height:20px;}
table th{ font-weight:bold;}
.bar{ font-size:14px; border-bottom:1px solid #666; padding-bottom:4px; text-indent:15px;}
.ttitle{ border-bottom:1px solid #000; margin-bottom:8px; padding:10px;text-align:center; line-height:30px; font-size:2.5em; font-weight:bold;}
.main_pannel{ width:770px; margin:0px auto;}
.etright{ text-align:center; font-size:13px;line-height:20px; height:20px;}
.etright div{ float:left; width:250px; overflow:hidden; height:20px; line-height:20px;}
.bline{ display:none;}
.need_hide{ display:none;}
.status{ text-align:right; padding-right:20px; line-height:20px;}
.grays{border-bottom:1px solid #C8C8C8;margin:10px auto;}
</style>
</head>
<body>
<div class="main_pannel">
<div class="ttitle">{$alise_name}�����嵥</div>
<div class="etright"><div class="ll">������ţ�{$data.order_sn}</div><div class="cc">����ʱ�䣺{$data.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</div>
<div class="rr">�ͻ�������{$data.receive_realname}</div></div>
<div class="grays"></div>
<h1 class="bar">��Ʒ�嵥</h1>
<table  width="100%" border="0" cellpadding="2" cellspacing="1"  align="center" >
  <tr>
    <th  height="26" align="center">����</th>
    <th  height="26" align="center">����</th>
    <th  height="26" align="center">����</th>
    <th  align="center"  headers="26">�۸�</th>
    <th  height="26" align="center">����</th>
    <th  height="26" align="center">С��</th>
  </tr>
  {foreach from=$data.order_goods_data item=o}
    <tr> 
    <td  height="20" align="center" >{$o.goods_sn}</td>
    <td   height="20" align="center">{$o.region_alias_name}</td>
    <td  height="20" align="center">
    {$o.goods_name}
   	{include file="order/taozhuang_print.php"}
    {include file="order/zenpin_print.php"}
   </td>
     <td  height="20" align="center" >{$o.goods_curent_price}</td>
    <td  height="20" align="center" >{$o.goods_total}</td>
    <td  height="20" align="center" >{$o.subtotal}</td>
  </tr>
{/foreach}
</table>
<div class="grays"></div>
<div  class="status">{assign var='order_detail' value=$data}
  {include file="order/order_money_status.php"}
  </div>
<div class="bline need_hide"></div>
<div  onclick="window.print()" class="print_now">������ӡ</div></div></div>

</div>
</body></html>