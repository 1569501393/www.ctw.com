<?php exit('die'); ?>
 {if $good.zenpin_extend_data}
<div class="cart_taozhuang">
    <samp class="blue">��Ʒ��({foreach from=$good.zenpin_extend_data item='zp' name='zpin'} {$zp.goods_name} {if !$smarty.foreach.zpin.last}��{/if}{/foreach})</samp>
  </div>
{/if}