<?php  if(!defined('PHP_TEMPLATE'))exit(); /*����*/?>
{if $action eq 'order_list'}
{if !$is_ajax}
	{include file="frame_header.php"}
{/if}
<script type="text/javascript">
 function showmerge(obj){
	var id=obj.name;	
	var oid=id.split('&')[0];
	var mid=id.split('&')[1];
	window.parent.showWindow('�ϲ�����','index.php?m=order&a=ordermerge&oid='+oid+'&mid='+mid+'&ismerge=true',800,400);
}
$(function(){
	$("#o_advance_search").click(function(){
		var n = $("#subsearch").css('display').toLowerCase();
		var hide = n=='none'?true:false;
		if(hide){
			var d = $("#subsearch");var offset = $(this).offset();
			var tt = parseInt(offset.top+$(this).height()+10);
			$(d).css({"top":tt+'px','left':parseInt(offset.left-($(d).width()/2)+20)+'px'});
			$(d).slideDown(); d=offset = null;
		}else{
			$("#subsearch").slideUp();		
		}
	});
	$("#simple_search").submit(function(){
		window.location.href=_s($(this));
		return false;
	});
	$("#advance_search").submit(function(){
		window.location.href=_s($(this));
		return false;
	});
	check_all('need_delete_order','need_delete_order');
});
function set_order_menu(obj){
	window.parent.showWindow($(obj).html(),'index.php?m=order&a=setMenu',850,300);
}
{if $can_add_order}
function add_new_order(obj){
	window.parent.showWindow($(obj).html(),'index.php?m=order&a=addorder',950,500);
}
{/if}
</script>

{if !$is_ajax}
<form method="post" action="index.php?m=order&a=orderList" id="simple_search">
<div id="php_top_bar">
{if $can_search}
<div class="tb">�����ţ�</div>
<div class="tb"><input type="text" value="{$get_data.order_no}" name="order_no"  /></div>
<div class="tb"><input  type="submit" value="{$lang.php_search}" class="form_submit" style="display:none;"  />
	<a href="javascript:;" onclick="submit_form('simple_search');" class="block_button form_btn">����</a>
</div>
<div class="tb"><a onfocus="this.blur();" id="o_advance_search" class="block_button form_btn">�߼�����</a></div>
{/if}
{if $can_delte_order && $order_data.total>0}
<div class="tb">
<a href="javascript:;" onclick="butch_delete_order(this);" class="block_button form_btn">����ɾ��</a>
</div>
{/if}
{if $can_add_order}
<div class="tb">
<a href="javascript:;" onclick="add_new_order(this);" class="block_button form_btn">���Ӷ���</a>
</div>
{/if}
<!--��������-->
<div class="tb">
<a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=order&a=exportorder',900,400);" class="block_button form_btn">��������</a>
</div>
<div class="block_button form_btn" onclick="set_order_menu(this);" style="float:right; margin-right:10px;">�б�������</div>
</div>
 </form>
<form method="post" action="index.php?m=order&a=orderList" id="advance_search" autocomplete="off">
   <div id="subsearch" style="display:none; width:480px;">
     <table>
       <tr>
         <td align="right">ʱ��</td>
         <td nowrap="nowrap"><input type="text"   id="promotion_begain_time"  style="width:90px;" class="select_date_time promotion_tags date date_input " name="start_time" onfocus="show_date(this);" value="{$get_data.start_time}" />��<input type="text" id="promotion_end_time"  style="width:90px;"   class="select_date_time promotion_tags date date_input w150"  name="stop_time" onfocus="show_date(this);" value="{$get_data.stop_time}" /></td>
         <td align="right">����</td>
         <td nowrap="nowrap">
<input type="text" class="w100"  style="width:80px;" name="start_fee" value="{$get_data.start_fee}" />��<input type="text"    style="width:80px;"  class="w100"  name="stop_fee" value="{$get_data.stop_fee}" /></td>
       </tr>
       <tr>
         <td align="right">��Ա</td>
         <td><input type="text" value="{$get_data.member_name}"  class="w180"  name="member_name"/></td>
         <td align="right">����</td>
         <td> <input type="text" value="{$get_data.order_no}"  class="w180" name="order_no"/></td>
       </tr>
       <tr>
         <td align="right">�ջ���</td>
           <td><input type="text" name="reciver" value="{$get_data.reciver}" class="w180" /></td>
        <td>������</td>
        <td><input type="text" value="{$get_data.fahuono}" name="fahuono" class="w180"  /></td>
       </tr>
       <tr>
       	<td>����</td>
        <td>
        <!--receive_paycode-->
	        {get_payment assign='pay_method'}
        	<select name="payment" class="w180">
            	<option value="">ѡ��֧����ʽ</option>
        	{foreach from=$pay_method item='pay'}
            	<option value="{$pay.pay_code}" {if $get_data.payment eq $pay.pay_code} selected="selected"{/if}>{$pay.pay_name}</option>
            {/foreach}
            <option value="CORE_ADMIN_ADD" {if $get_data.payment eq 'CORE_ADMIN_ADD'} selected="selected"{/if}>����Ա�ֹ��շ�</option>
            </select>
        </td>
        
         <td align="right">״̬</td>
         <td>
            <select name="order_status" class="w180">
             <option value="default" selected="selected">��ѡ��...</option>
{if $wait_confirmed} <option value="wait_confirmed"  {if $get_data.order_status eq 'wait_confirmed"'} selected="selected" {/if} > ��ȷ��</option>{/if}
{if $has_confirmed}<option  {if $get_data.order_status eq 'has_confirmed'} selected="selected" {/if} value="has_confirmed">��ȷ��</option>{/if}
{if $wait_pay}<option {if $get_data.order_status eq 'wait_pay'} selected="selected" {/if}  value="wait_pay">������</option>{/if}
{if $has_pay}<option {if $get_data.order_status eq 'has_pay'} selected="selected" {/if}  value="has_pay">�Ѹ���</option>{/if}
{if $pay_checked}<option {if $get_data.order_status eq 'has_pay'} selected="selected" {/if}  value="pay_checked">�Ѻ˸���</option>{/if}
{if $has_pay}<option {if $get_data.order_status eq 'has_pay'} selected="selected" {/if}  value="pay_unchecked">δ�˸���</option>{/if}
{if $pay_part}<option {if $get_data.order_status eq 'pay_part'} selected="selected" {/if}  value="pay_part">֧������</option>{/if}
{if $wait_ship}<option  {if $get_data.order_status eq 'wait_ship'} selected="selected" {/if}  value="wait_ship">������</option>{/if}
{if $rationing}<option {if $get_data.order_status eq 'rationing'} selected="selected" {/if}   value="rationing">�����</option>{/if}
{if $has_ship}<option {if $get_data.order_status eq 'has_ship'} selected="selected" {/if}  value="has_ship">�ѷ���</option>{/if}
{if $arrival}<option {if $get_data.order_status eq 'arrival'} selected="selected" {/if}  value="arrival">���ջ�</option>{/if}
{if $invalid_order}<option  {if $get_data.order_status eq 'invalid_order'} selected="selected" {/if} value="invalid_order">��Ч����</option>{/if}
{if $cacneled_order}<option  {if $get_data.order_status eq 'cacnel'} selected="selected" {/if} value="cacneled_order">��ȡ��</option>{/if}
{if $return}<option  {if $get_data.order_status eq 'return'} selected="selected" {/if}  value="return">�˻�����</option>{/if}
{if $tuikuan}<option  {if $get_data.order_status eq 'tuikuan'} selected="selected" {/if}  value="tuikuan">�˿��</option>{/if}
{if $finished}<option  {if $get_data.order_status eq 'finished'} selected="selected" {/if}  value="finished">�����</option>{/if}
{if $huodaofukuan}<option  {if $get_data.order_status eq 'huodaofukuan'} selected="selected" {/if}  value="huodaofukuan">��������</option>{/if}
           </select>
        </td>
       </tr>
       <tr>
       	<td>���</td>
        <td>
        {get_delivery assign='delivery'}
        	<select name="delivery_id" class="w180">
            	<option value="">��ѡ��...</option>
                {foreach from=$delivery item='list'}
                	<option value="{$list.id}"  {if $get_data.delivery_id eq $list.id} selected="selected"{/if}>{$list.delivery_name}</option>
                {/foreach}
            </select>
        </td>
       </tr>
       <tr>
         <td colspan="4" align="center">
           <input  type="submit" value="{$lang.php_search}" class="form_submit" style="display:none" />
           <a href="javascript:;" onclick="submit_form('advance_search');" class="block_button form_btn">�� ��</a>
             <a href="javascript:;" onclick="$('#subsearch').slideUp();"  class="form_btn block_button">�� ��</a></td>
       </tr>
     </table>
   </div>
   </form>
<div class="clear"></div>
{/if}<!--#AJAX �ж� ����-->

{if !$is_ajax}
<div id="php_right_main_content">
{/if}

{if $order_data.total>0}
<script type="text/javascript">
{if $can_delte_order}
	function butch_delete_order(obj){
		var vals = get_checkbox_val('need_delete_order');
		if(!vals){
			window.parent.showNotice('�޶�����ɾ��,����!');return false;
		}
		$.post('index.php?m=order&a=deleteorder',{order_id:vals},function(data){
			switch(data){
				case 'OK':
				window.parent.showNotice('�����ɹ�!');
				window.location.reload();
				break;
				case 'EMPTY':
					window.parent.showNotice('�޶�����ɾ��,����!');return false;
				break;
				case 'SOME_NOT_DELETE':
				window.parent.showNotice('�в��ֶ�������ɾ��!');
				break;
				default:alert(data);
			}
		});
	}
{/if}
function check_delivery(obj){
	var url = 'index.php?m=system/plugin&a=test&name=express_inquiry&autodo=true&no='+$(obj).attr('no')+'&cpno='+$(obj).attr('cpno');
	window.parent.showWindow('��ݵ���ѯ',url,750,300);
}
function go_order_info(id){
	var url = 'index.php?m=order&a=viewOrder&id='+id;
	{if $is_ajax}
	_close_window_one();
	reload_frame_url(url);
	{else}
		window.location.href=url;
	{/if}
}
</script>
<!--table_list_hover-->
	<table  class="table_list">
        <tr>
       {if !$is_ajax} <th align="center"><input type="checkbox" value="" id="need_delete_order" /></th>{/if}
        <th width="15" align="center">��</th>
    {if $can_view}
    	<th nowrap="nowrap">����</th>
    {/if}
        {foreach from=$menus item=item}
        	<th nowrap="nowrap">{$item.name}</th>
        {/foreach}
          </tr>
        {foreach from=$order_data.data item=order}
        {if $order.order_confirm_status eq '2'}
        	{assign var='invaild_order' value=1}	
        {/if}
        	<tr>
              {if !$is_ajax}<td align="center"><input type="checkbox" {if $order.can_delete} value="{$order.order_id}" class="need_delete_order" {else} disabled="disabled" {/if}/></td>{/if}
              <td align="center" width="15">{$order.sort_order_key}</td>
              {if $can_view}
              <td  width="32"  align="center" nowrap="nowrap">
              <!--{if $order.order_confirm_status eq 0 and $order.pay_status eq 0 && $can_merge}<a href="javascript:;" name="{$order.order_id}&{$order.mem_id}" onclick="showmerge(this)" title="�ϲ�����">��</a>{/if} -->
              <a  title="�鿴��������"  onclick="go_order_info('{$order.order_id}');" href="javascript:;">��</a>
              </td>
                {/if}
            {foreach from=$menus item='item'}
            	<td align="center">
                	{foreach from=$order key=key item='list'}
                    	{if $item.key eq $key}
                        	{if $key eq 'add_time'}
                           		{$order.add_time|date_format:"%Y-%m-%d %H:%M:%S"}
							{elseif $key eq 'delivery_no'}
                           		{if $order.delivery_no}
                                {if $order.delivery_cp_no}<a href="javascript:;" onclick="check_delivery(this);" no="{$order.delivery_no}" cpno="{$order.delivery_cp_no}">{$order.delivery_no}</a>{else}{$order.delivery_no}{/if}
                                {else}-{/if}
                            {elseif $key eq 'delivery_id'}
                            	{$order.delivery_names}
                             
                            {elseif $key eq 'receive_paycode'}
								{$order.receive_paycode_ename}
                            {elseif $key eq 'mem_username'}
                              	 {$order.mem_username|default:'<span class="blue">����</span>'}
                            {elseif $key eq 'pay_status'}
									 {if !$order.user_cancel_flag} 
                                	{if $order.pay_status eq '1'}<span class="green">��</span>{elseif $order.pay_status eq '3'}<span class="red">֧������</span>{else}<span class="red">��</span>{/if}
										{else}
                                        	-
									{/if}
                             {elseif $key eq 'pay_checked_status'}
                                {if $order.pay_checked_status eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                            {elseif $key eq 'has_payed_order_money'}
                            	{if $order.has_payed_order_points>0}
                                	{if $order.has_payed_order_money>0}{$order.has_payed_order_money|money_format}{/if} {$order.has_payed_order_points}��
                                	{else}
                                	{$order.has_payed_order_money|default:'0'}    
                                {/if}
							{elseif $key eq 'user_cancel_flag'}<!--ȡ������-->
                               
                            	{if $order.user_cancel_flag}
                                <strong class="red">��ȡ��</strong>
                                	{else}
                                    -
                                {/if}
                            {elseif $key eq 'order_confirm_status' && $item.name eq '��Ч'}<!--��Ч����-->
                         
                            	{if !$order.user_cancel_flag}  
	                            	{if $order.order_confirm_status eq '2'}<span class="green">��</span>{else} - {/if}
                                {else}
                                	-
                                {/if}
                            {elseif $key eq 'order_confirm_status' && $item.name eq 'ȷ��'}<!--ȷ�϶���-->
                           	
                            {if !$order.user_cancel_flag} 
                            	
                            	{if $order.order_confirm_status >='1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                                
                                {else}
                                -
                                {/if}
                                

                                
                            {elseif $key eq 'shiping_status' && $item.name eq '���'}<!--���״̬-->
                            
                            	{if !$order.user_cancel_flag}                             
                                	{if $order.shiping_status eq '1' ||  $order.shiping_status eq '2'  || $order.shiping_status eq '3'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                                    {else}
                                    	-
                                    {/if}
                                    
                            {elseif $key eq 'shiping_status' && $item.name eq '����'}<!--����״̬-->
                            
                            	{if !$order.user_cancel_flag}  
                                	{if $order.shiping_status eq '2' || $order.shiping_status eq '3'}<span class="green">��</span>{else}<span class="red">��</span>{/if}
                                   {else}
                                   	-
                                {/if}
                            {elseif $key eq 'order_confirm_status'}<!--ȷ��״̬-->
                            	{if !$order.user_cancel_flag}  
	                           		{if $order.order_confirm_status eq '3' ||   $order.order_confirm_status eq '2'}<span class="green">��</span>{else}<span class="red">��</span>{/if}		
                                	{else}
                                    	-	
                                {/if}
                                

                            {elseif $key eq 'receive_paycode'}
                            	
	{if $order.receive_paycode eq '��������'}<span class="red">��������</span>{else} {$order.receive_paycode|default:'-'}{/if}
    
                            {elseif $key eq 'waterline_no'}
                            	 {$order.waterline_no|default:'-'} 
                             {elseif $key eq 'tuihuo_sign'}
                             	{if $order.tuihuo_sign eq '1'}
                                        {if $order.tuihuo_sign eq '1' && !$order.tuihuo_do_flag}
                                         <span class="red">������</span>
                                        {elseif $order.tuihuo_do_flag eq '2'}
                                        <span class="red">�û�������</span>     
                                        {elseif $order.tuihuo_do_flag eq '1'}
                                            <span class="red">�ȴ��û���</span>
                                        {/if}
                                	{elseif $order.tuihuo_sign eq '2'}
                                    	<span class="red">�˻����</span>
                                    {elseif $order.tuihuo_sign eq '3'}
                                    	<span class="red">����Ա�����˻�</span>
                                	{else} 
                                    	- 
                                    {/if}
                                    
                             {elseif $key eq 'tuikuan_flag'}<!--�˿�-->
                             
                             	{if $order.tuikuan_flag eq '1'}
			                          {if $order.tuikuan_flag eq '1' && !$order.tuikuan_do_flag}
                                      	<span class="red">�ȴ�����</span>
                                     {elseif $order.tuikuan_do_flag eq '2'}
                                        <span class="red">������<br />�û�������</span>     
                                        {elseif $order.tuikuan_do_flag eq '1'}
                                            <span class="red">������<br />�ȴ��û��ظ�</span>
                                        {/if}
                                 {elseif $order.tuikuan_flag eq '2'}
                                 	<span class="red">�˿����</span>
                                    {else}
                                     - 
                                {/if}
							
                            {else}
                           		{$list}
                            {/if}
                            
                        {/if}
                    {/foreach}
                </td>
            {/foreach}
      </tr>
      {/foreach}
    </table>
    <div class="clear"></div>
        <div id="order_page_data">
         {$order_data.page}
        </div>
{if $is_ajax}
<script type="text/javascript">
	$(function(){
		page_function('order_page_data',find_window_class(),'.');
	});
</script>
{/if}
<div class="count_datas" style="text-align:right; line-height:180%; font-size:13px; padding-right:10px;">
{if $edata.total_order_money}
<div style="float:right; text-align:right; padding-right:5px;clear:both; height:25px; line-height:25px; padding-top:10px;">
<strong>�ܶ</strong>{$edata.total_order_money|format_money}��
<strong>ʵ�գ�</strong>{$edata.total_order_payed_money|format_money} 
 {if $edata.total_order_payed_money|format_money}(<samp class="blue"> �Ѻˣ�</samp> {$edata.checked_money|format_money} <samp class="blue">���ˣ�</samp>{$edata.unchecked_money|format_money}) {/if}
 {if $edata.total_order_unpayed_money} <strong>δ����</strong>{$edata.total_order_unpayed_money|format_money}  {/if} 
 </div>
{/if}
{if $edata.checked_money_data}
    <fieldset class="efieldset pay_method_item">
    <legend class="red"><strong>�Ѻ�</strong></legend>
    <div class="mmm">
        {foreach from=$edata.checked_money_data item='item'}
            <p>{$item.payment_name|default:'<span class="red">δ֪֧����ʽ</span>'} ��{$item.total_checked_money}</p>
        {/foreach}
        <div class="clear"></div>
    </div>
    </fieldset>
{/if}
{if $edata.unchecked_money_data}
    <fieldset class="efieldset pay_method_item">
    <legend class="red"><strong>����</strong></legend>
    <div class="mmm">
        {foreach from=$edata.unchecked_money_data item='item'}
            <p>{$item.payment_name|default:'<span class="red">δ֪֧����ʽ</span>'} ��{$item.total_unchecked_money|format_money}</p>
        {/foreach}
        <div class="clear"></div>
    </div>
    </fieldset>
{/if}
</div>
    {else}
    <div class="notice_msg">{$lang.php_nodata}</div>
    {/if}
<!--#AJAX �жϿ�ʼ-->
{if !$is_ajax}
</div>
{include file="frame_footer.php"}
{/if}
<!--#AJAX �жϽ���-->
{/if}
