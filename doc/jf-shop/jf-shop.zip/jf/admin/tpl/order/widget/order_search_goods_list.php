<?php exit('die'); ?>
{if $call_action eq 'load_search_res_order'}
    {if $goodsdata}
    <script type="text/javascript">
    	$(function(){
			check_all('check_append_order','check_append_order');
		});
    </script>
    <table class="table_list call_ajax_append_table_data">
    <tr>
    	<th></th>
    	<th width="40"><input checked="checked"  type="checkbox" value="" id="check_append_order" /></th>
    	<th>����</th>
        <th>����</th>
        <th>�ۼ�</th>
        <th>����</th>
        <th>״̬</th>
        <th>����</th>
    </tr>
    {foreach from=$goodsdata item='tlist' key=key}
    	<tr class="remove_call_goods_data">
        	<td align="center">{$key+1}</td>
        	<td align="center"><input type="checkbox" value="{$tlist.goods_id}"  checked="checked" class="check_append_order" name="new_add_goods_id[]" /></td>
        	<td align="center"><a href="{$tlist.url}" target="_blank"> {$tlist.goods_name}</a></td>
            <td align="center">{$tlist.goods_sn}</td>
            <td align="center"><input type="text" value="{$tlist.goods_shop_price}" name="add_goods[{$tlist.goods_id}][price]"  class="form_input" style="width:70px;"/></td>
            <td align="center"><input type="text" value="1" name="add_goods[{$tlist.goods_id}][num]"   class="form_input" style="width:40px;"/></td>
            <td align="center">{if $tlist.goods_is_sale eq '0'}<samp class="red">���¼�</samp>{else}����{/if}</td>
            <td align="center"><a href="javascript:;" onclick="remove_call_append_goods(this);">ɾ��</a></td>
         </tr>
    {/foreach}
    </table>
    {else}
    <div class="notice_msg">�޿�������!</div>
    {/if}
{/if}