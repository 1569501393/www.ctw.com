<?php exit('die'); ?>
<script type="text/javascript">
    function getRegionChild(obj){
		var val = $(obj).val();
		var parent = $(obj).attr("parent");
		if(val != ''){
			$.get('index.php?m=default&a=getRegion',{'parentid':val},function(callback){
				$(obj).parent().nextAll().remove();
				$(obj).nextAll().remove();
				$(obj).parent().append(callback);
			});
		}
  }
  function add_order_goods(obj){
	
  }
</script>
<div id="edit_order_all_form">
<form method="post" action="index.php?m=order&a=editOrder" autocomplete='off' id="submit_edit_order_main">
	<input  type="hidden" value="{$has_payed_str}" name="has_payed" />
    <input type="hidden" value="{$action}" name="action"/>
    <input type="hidden" value="{$data.order_id}" name="order_id" />
{if !$has_payed}
    <div class="edit_order_pannel">
      <table class="table_list">
        <tr>
          <th>ɾ</th>
          <th>����</th>
          <th>����</th>
          <th>�յ�</th>
          <th>�ۼ�</th>
          <th>����</th>
          <th>С��</th>
        </tr>
        {foreach from=$data.order_goods_data item=good}
        <tr>
          <td align="center"><input type="checkbox" value="{$good.goods_id}" name="need_delete_goods[]"  class="all_check_tag" /></td>
          <td><a href="{$good.url}" target="_blank" style="color:#333">{$good.goods_name}</a></td>
          <td align="center">{$good.goods_sn}</td>
          <td align="center">{if $good.is_additional eq '1'}<font class="red">��</font>{else}��{/if}</td>
          <td align="center"><input type="text" value="{$good.goods_curent_price}"  name="change_order_goods[{$good.id}][goods_curent_price]" style="width:70px;"  maxlength="20"/></td>
          <td align="center"><input type="text" value="{$good.goods_total}" name="change_order_goods[{$good.id}][goods_total]" style="width:30px;" maxlength="11" /></td>
          <td align="center">{$good.subtotal_format}</td>
        </tr>
        {/foreach}
      </table>
<div class="clear"></div>
<div id="show_goods_append_call">
<script type="text/javascript">
	function remove_call_append_goods(obj){
		$(obj).parent('td').parent('tr').remove();
		if($('.remove_call_goods_data').size()<=0){
			$(".call_ajax_append_table_data").remove();	
		}
	}
	function search_goods_for_order(){
		$.get('index.php?m=goods/products&a=load_part_goods&task=searchordergoods',{limit:'10',name:$("#key_name").val(),cid:$("#load_cat").val(),bid:$("#order_brands").val()},function(data){
			switch(data){
				case 'NO_RESULT':
					window.parent.showNotice('�޿�������,������ؼ���!');
				break;
				default:
					$("#ajax_call_app_data").html(data);
					$("#key_name").val('');
			}
		});
	}
</script>
<h2 style="border-bottom:1px solid #DDDDDF;">������Ʒ</h2>
<table class="table_common">
	<tr>
        <td colspan="4">
        	   <div class="search_part_goods" id="search_order_goods_all">
        <samp class="tb p40"><strong>����</strong></samp>
        <samp class="tb" style="height:auto;">
        <select id="load_cat" class="form_option"  style="margin-top:5px; height:100px;" multiple="multiple">
            <option value="" style="padding:0px;">ѡ�����</option>
            {foreach from=$goods_category item=cate}
            <option value="{$cate.cate_id}">{$cate.spacer}{$cate.cate_name}</option>
            {/foreach}
        </select>
		</samp>
        <samp class="tb p40"><strong>Ʒ��</strong></samp>
		<samp class="tb" style="height:auto;">
        <select id="order_brands" class="form_option" style="margin-top:5px;height:100px;" multiple="multiple">
            <option value="0">ѡ��Ʒ��</option>
           {foreach from=$goods_brands item=brand}
            <option value="{$brand.brand_id}">{$brand.brand_name}</option>
            {/foreach}
        </select>
        </samp>
        <div class="p40">
        <samp class="tb"><strong>�ؼ���</strong></samp>
        <samp class="tb"><input type="text" value="" id="key_name" class="need_call_taozhuang " /></samp>
		<samp class="tb"><a href="javascript:;" class="form_btn block_button" onclick="search_goods_for_order(this);">����</a></samp>
        </div>
        </div>
        <div class="clear"></div>
        <div id="ajax_call_app_data"></div>
        </td>
    </tr>
</table>
        </div>
    </div>
{else}
    <div class="edit_order_pannel">
    	<table class="table_list">
            <tr>
              <th>����</th>
              <th>����</th>
              <th>�յ�</th>
              <th>�ۼ�</th>
              <th>����</th>
              <th>С��</th>
            </tr>
            {foreach from=$data.order_goods_data item=good}
            <tr>
              <td><a href="{$good.url}" target="_blank" style="color:#333">{$good.goods_name}</a></td>
              <td align="center">{$good.goods_sn}</td>
              <td align="center">{if $good.is_additional eq '1'}<font class="red">��</font>{else}��{/if}</td>
              <td align="center">{$good.goods_curent_price}</td>
              <td align="center">{$good.goods_total}</td>
              <td align="center">{$good.subtotal_format}</td>
            </tr>
            {/foreach}
        </table>
    </div>
{/if}
    <div class="clear"></div>
    <div class="edit_order_pannel">
      <table class="order_table table_common">
      <tr>
      	<td colspan="4"><h2>������Ϣ</h2></td>
      </tr>
        <tr>
          <td class="left one">����</td>
          <td colspan="3">{$data.receive_area_format}  <samp class="red">*</samp></td>
        </tr>
        <tr>
          <td  class="left one">����</td>
          <td><input type="text" value="{$data.receive_realname}" name="receive_realname" class="edit_order_must_fill_in form_input w250" /> <samp class="red">*</samp></td>
          <td  class="left one">��ַ</td>
          <td><input type="text" value="{$data.receive_address}" name="receive_address" class="edit_order_must_fill_in form_input w250" /> <samp class="red">*</samp></td>
        </tr>
        <tr>
          <td  class="left one">����</td>
          <td><input type="text" value="{$data.receive_email}" name="receive_email" class="edit_order_must_fill_in form_input w250" /> <samp class="red">*</samp></td>
          <td  class="left one">�ʱ�</td>
          <td><input type="text" value="{$data.receive_postno}" name="receive_postno"  class="edit_order_must_fill_in form_input w250" /> <samp class="red">*</samp></td>
        </tr>
        <tr>
          <td  class="left one">�绰</td>
          <td><input type="text" value="{$data.receive_phone}" name="receive_phone"  class="edit_order_must_fill_in form_input w250"/> <samp class="red">*</samp></td>
          <td  class="left one">�ֻ�</td>
          <td><input type="text" value="{$data.receive_mobile}" name="receive_mobile" class="edit_order_must_fill_in form_input w250" /> <samp class="red">*</samp></td>
        </tr>
        <tr>
          <td class="one">��Ա�ۿ�</td>
          <td colspan="3">{if $data.discount neq '1' && $data.discount}{$data.discount}�� �� {$data.discount_money|money_format} {/if}  {if !$has_payed} <input type="checkbox" value="1" name="cancel_member_discount" /> <samp class="blue">��ѡ������������ۿ���</samp>{/if}</td>
        </tr>
        <tr>
          <td class="left one">�ջ��˱�ע��Ϣ</td>
          <td colspan="4"><textarea name="receive_note" style="height:50px; width:600px;">{$data.receive_note}</textarea></td>
        </tr>
        <tr>
          <td class="left one">ȱ������</td>
          <td colspan="4"><textarea name="receive_out_of_stock" style="height:50px; width:600px;">{$data.receive_out_of_stock}</textarea></td>
        </tr>
        <tr>
          <td class="one">���ͷ�ʽ</td>
          <td colspan="3"><select name="delivery_id"  onchange="set_vals(this);" id="deliver_name"  class="form_delive_select w250">
              <option value="">��ѡ�����ͷ�ʽ</option>
  			  {foreach from=$delivery_data item='de'}
              <option value="{$de.id}" {if $de.id eq $data.delivery_id} selected="selected" {/if}>{$de.delivery_name}</option>
   			 {/foreach}
            </select> <samp class="blue">ע�⣺���ͷ�ʽ����������������ͷ���</samp></td>
        </tr>
        <tr>
          <td class="one">���ͷ���</td>
          <td>
          {if $has_payed}
          	{$data.delivery_fee|default:'0.00'}Ԫ          
          {else}
          <input type="text" value="{$data.delivery_fee|default:'0.00'}" name="delivery_fee"  class="form_input w250" /> Ԫ
          {/if}
          </td>
          <td class="one">���͸��ӷ�(��������)</td>
           <td>
           {if $has_payed}
	           	{$data.delivery_extend_money|default:'0.00'}Ԫ
           {else}
           <input type="text" value="{$data.delivery_extend_money|default:'0.00'}" name="delivery_extend_money"  class="form_input w250" /> Ԫ
           {/if}
           </td>
        </tr>
        <tr>
          <td class="left one">��Ʊ��Ϣ</td>
          <td><textarea name="receive_invoice" style="height:40px; width:250px;">{$data.receive_invoice}</textarea></td>
    	<td class="one">��Ʊ����</td>
        <td>{if $has_payed}{$data.fapiao_money|default:'0.00'}{else}<input type="text" value="{$data.fapiao_money|default:'0.00'}" name="fapiao_fee"  class="form_input w250" /> Ԫ{/if}</td>
    </tr>
    <tr>
    	<td class="one">������ע</td>
        <td colspan="4"><textarea name="remark" class="edit_order_must_fill_in" style="height:50px; width:600px;"></textarea> <samp class="red">*</samp></td>
    </tr>
        <tr>
          <td class="one"></td>
          <td colspan="4"><input type="submit" value="�� ��"  style="display:none" class="form_submit"/>
			<a href="javascript:;" onclick="submit_form('submit_edit_order_main');" class="block_button form_btn">����</a>
          </td>
        </tr>
      </table>
    </div>
  </form>
<script type="text/javascript">
	$(function(){
		$("#submit_edit_order_main").submit(function(){
			if(!check_form_is_empty('edit_order_must_fill_in')){
				window.parent.showNotice('����д������!');
				return false;	
			}
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						window.parent.showNotice('�����ɹ�!');
						_close_window_one();
						_reload_frame();
					break;
					case 'EMPTY':
						window.parent.showNotice('�����ڴ˶���!');
					break;
					case 'EMPTY_REMARK':
						window.parent.showNotice('����д��ע!');
					break;
					case 'CAN_NOT_DELETE_ORDER':
						window.parent.showNotice('����ɾ���˶�����Ʒ!');
					break;
					case 'DELETE_ORDER_OK':
						window.parent.showNotice('ɾ�������ɹ�,ҳ�潫��ת!');
						_close_window_one();
						reload_frame_url('index.php?m=order&a=orderList');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
</div>