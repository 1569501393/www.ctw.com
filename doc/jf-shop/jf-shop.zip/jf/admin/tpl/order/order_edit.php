<?php exit('die'); ?>
{if $action eq 'delivery_no' || $action eq 'edit_delivery_no'}
<script type="text/javascript">
	$(function(){
		{if $action eq 'delivery_no'}
		var v = window.frames["rightFrame"].get_remark_info();
		$("#remark_data").val(v);
		{/if}
		$("#do_fahuo_set").submit(function(){
			if(!check_form_is_empty('must_fill_fahuo'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						window.parent.showNotice(php_do_ok);
						window.frames['rightFrame'].location.reload();
						_close_window_one();
					break;
					case 'EMPTY':
					case 'EMPTY_REMAK':
						window.parent.showNotice('��д�ϱ�ע��Ϣ!');
					break;
					case 'empty_order_delivery_no':
						window.parent.showNotice('����д��������!');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
<div class="notice_msg" style="margin:2px 1px;">��ǰ���ͷ�ʽ<strong>{$data.delivery_name}</strong></div>
<form method="post" action="{if $action eq 'delivery_no'}index.php?m=order&a=confirmOrder{else}index.php?m=order&a=editOrder{/if}" id="do_fahuo_set" autocomplete='off'>
<input type="hidden" value="{$action}" name="action" />
<input type="hidden" value="delivery" name="task" />
<input type="hidden" value="{$data.order_id}" name="order_id" />
	<table class="order_table table_common">
    	<tr>
        	<td class="one">��������</td>
            <td><input type="text" name="delivery_no" value="{$data.delivery_no}" class="must_fill_fahuo form_input" /></td>
        </tr>
        <tr>
       		 <td class="left one">��ע��Ϣ</td>
       		 <td colspan="8"><textarea   name="{if $action eq 'delivery_no'}content{else}remark{/if}" class="must_fill_fahuo" id="remark_data" style="height:50px; width:450px;"></textarea></td>
        </tr>
    <tr>
        <td colspan="10"><input type="submit" value="�� ��"  class="form_submit"/></td>
    </tr>
    </table>
    </form>
{/if}



{if $action eq 'settuihuo'}
<script type="text/javascript">
	$(function(){
		var v = window.frames["rightFrame"].get_remark_info();
		if(v)$("#admin_remark_tuihuo").val(v);
		$("#submit_edit_form_t").submit(function(){
			if(!check_form_is_empty('must_fill_t_info'))return false;
			if(!confirm('ȷ��Ҫ�ֹ������˻���?\r\n�˲������ɻع�!\r\n�˻���ɺ����ֹ��˿�!'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':
						window.parent.showNotice(php_do_ok);
						_close_window_one();
						window.frames['rightFrame'].location.reload();
					break;
					default:
					alert(data);
				}
			});
			return false;
		});
	});
</script>
<form method="post" action="index.php?m=order&a=editOrder" autocomplete='off' id="submit_edit_form_t">
<input type="hidden" value="{$data.order_id}" name="order_id" />
<input type="hidden" value="{$action}" name="action"/>
<table class="table_common">
    <tr>
    	<td class="one">�û�������Ϣ</td>
        <td><textarea name="remark_data_user" style="width:400px; height:50px;" class="must_fill_t_info"></textarea></td>
    </tr>
    <tr>
    	<td class="one">����������ע</td>
        <td><textarea name="remark" style="width:400px; height:50px;" id="admin_remark_tuihuo" class="must_fill_t_info"></textarea></td>
    </tr>
    <tr>
    	<td class="one"></td>
    	<td><input type="submit" value="�� ��" class="form_submit" /></td>
    </tr>
</table>
</form>
{/if}


<!--#�����༭-->
{if $action eq 'edit_order_main'}
{include file="order/widget/edit_order_all.php"}
{/if}