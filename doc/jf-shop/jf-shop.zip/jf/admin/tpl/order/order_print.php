<?php  if(!defined('PHP_TEMPLATE'))exit('php');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset={$outPutChar}" />
<title>{$alise_name} ��������</title>
<style type="text/css" media="screen">
body{ font-size:12px; color:#343434;}
.box{border:1px solid #000;border-bottom:0px;}
.b_bottom{border-bottom:1px solid #000;}
.por_left{padding:0 10px 10px 0}
.aa{border:1px solid #000;width:90px;font-size:14px;display:block;position:relative;padding:3px;bottom:12px;margin-left:18px;text-align:center;background:#FFF;}

a{ text-decoration:none; color: #272727;}
table{ border-collapse:collapse;}
table th{ font-weight:bold;}
.bar{ font-size:14px; border-bottom:1px solid #666; padding-bottom:4px; text-indent:15px;}
.ttitle{ border:1px solid #DBDBDB; background:#F6F6F6; margin-bottom:8px; padding:10px;text-align:center; line-height:30px; font-size:2.5em; font-weight:bold;}
.print_now{background:#369; margin:0px auto;border:2px solid #efefef; width:80px; height:30px; line-height:30px; text-align:center; cursor:pointer; display:block; color:#fff; font-size:14px; font-weight:700;}
.main_pannel{ width:770px; margin:0px auto;}
.etright{ text-align:right; line-height:20px;}
.bline{ border-bottom:1px solid #666; margin:10px auto;}
.status{ text-align:right; padding-right:20px; line-height:20px;}
.grays{border-bottom:1px solid #C8C8C8;margin:10px auto;}
.grays{border-bottom:1px solid #C8C8C8;margin:10px auto;}
.call_append_data{ border:1px dotted #CCC; padding:4px 1px; width:250px;}
.call_append_data strong{}
</style>
<style type="text/css" media="print">
.print_now{ display:none;}
body{ font-size:12px; color:#343434;}
a{ text-decoration:none; color: #272727;}
table{ border-collapse:collapse;}
table td{ line-height:20px;}
table th{ font-weight:bold;}
.bar{ font-size:14px; border-bottom:1px solid #666; padding-bottom:4px; text-indent:15px;}
.tt_ttitle{ border-bottom:1px solid #000; margin-bottom:8px; padding:10px;text-align:center; line-height:30px; font-size:2.5em; font-weight:bold;}
.main_pannel{ width:770px; margin:0px auto;}
.etright{ text-align:right; line-height:20px;}
.bline{ display:none;}
.status{ text-align:right; padding-right:20px; line-height:20px;}
</style>
</head>
<body>
<div class="main_pannel">
<div class="ttitle">{if $alise_name}{$alise_name}-{/if}�����嵥</div>
<div class="etright">��ַ��{$data.receive_area} - {$data.receive_address}<br />
 <span>�绰��{$data.receive_phone} {if $data.recive_mobile} | {/if} {$data.receive_mobile}</span>&nbsp;&nbsp;�ʱࣺ{$data.receive_postno}</div>
<div class="box">
<span class="aa">��Ʒ�嵥</span>
<table  width="100%" border="0" cellpadding="2" cellspacing="1"  align="center" >
  <tr>
    <th  height="26" align="center" >����</th>
    <th headers="26">����</th>
    <th  height="26" align="center">����</th>
    <th  align="center"  headers="26">�۸�</th>
    <th  height="26" align="center">����</th>
    <th  height="26" align="center">С��</th>
  </tr>
  {foreach from=$data.order_goods_data item=o}
    <tr> 
    <td  height="20" align="center" >{$o.goods_sn}</td>
    <td  height="20" align="center">{$o.region_alias_name}</td>
    <td  height="20" align="center">
   {$o.goods_name}
	{include file="order/taozhuang_print.php"}
	{include file="order/zenpin_print.php"}
   </td>
     <td  height="20" align="center" >{$o.goods_curent_price}</td>
    <td  height="20" align="center" >{$o.goods_total}</td>
    <td  height="20" align="center" >{$o.subtotal}</td>
  </tr>
{/foreach}
</table><br>
</div>
<div class="box">
<span class="aa">������Ϣ</span>
<table  width="100%"  border="0" cellspacing="1" cellpadding="4" >
  <tr> 
    <td width="18%"  align="right" nowrap  >��&nbsp;��&nbsp;�ţ�</td>
    <td width="27%"  nowrap >{$data.order_sn}</td>

    <td width="18%"  align="right" nowrap  >����״̬��</td>
    <td  nowrap >
 <strong>
 {assign var=order_data value=$data}
 {include file="order/order_status.php"}
 </strong>
 <!--   {$data.status.confirm_status} {$data.status.pay_status} {$data.status.shiping_status}--></td>
  </tr>
  <tr> 
    <td width="18%"  align="right" valign="top" nowrap="nowrap">�µ����ڣ�</td>
    <td width="27%"  nowrap >{$data.add_time|date_format:"%Y-%m-%d %H:%M"}</td>
    <td width="18%"  align="right" valign="top" nowrap  >��Ʒ�ܶ</td>
    <td  nowrap >{$data.order_goods_total_fee}</td>
  </tr>
    <tr> 
    <td width="18%"  align="right" valign="top" nowrap  >���ͷ�ʽ��</td>
    <td width="27%"  nowrap >{$data.delivery_name}</td>
    <td width="18%"  align="right" valign="top" nowrap  >���ͷ��ã�</td>
    <td  nowrap >{$data.order_shiping_fee}</td>

  </tr>
    <tr> 
    <td width="18%"  align="right" valign="top" nowrap  >֧����ʽ��</td>

    <td width="27%"  >{$data.pay_method_str}</td>
  <td width="18%"  align="right" >ȱ��������</td>
  <td >{$data.receive_out_of_stock}</td>
  
  </tr>
    <tr>
      <td width="18%"  align="right" valign="top" nowrap  >�������ţ�</td>
      <td width="27%"  nowrap >{$data.delivery_no}</td>
    <td width="18%"  align="right" valign="top" nowrap  >��&nbsp;��&nbsp;ȯ��</td>
    <td nowrap >{$data.coupon_money_format}</td>
    </tr>
    <tr>
      <td  align="right" valign="top" nowrap>��Ա�ۿۣ�</td>
      <td nowrap >{if $data.discount eq '1' || $data.discount eq ''}���ۿ�{else}{$data.discount*10}��{/if} ʡ{$data.discount_money_format}</td>
       <td  align="right" valign="top" nowrap>��Ʊ���ã�</td>
      <td nowrap >{if $data.fapiao_money}{$data.fapiao_money_format}{else}-{/if}</td>
    </tr>
  </table><br>
</div>
<div class="box">
<span class="aa">��������Ϣ</span>
<table  width="100%"  border="0" cellspacing="1" cellpadding="4" >
  <tr> 
    <td width="18%"  align="right" valign="top" nowrap  >������</td>

    <td width="27%"  nowrap >{$data.member_info.mem_name}</td>
    <td width="18%"  align="right" valign="top" nowrap  >�û�����</td>
    <td  nowrap >{$data.member_info.mem_username}</td>
  </tr>
  <tr> 
    <td width="18%"  align="right" valign="top" nowrap  >�绰��</td>
    <td width="27%"  nowrap >{$data.member_info.mem_phone}</td>

    <td width="18%"  align="right" valign="top" nowrap  >Email��</td>
    <td  nowrap >{$data.member_info.mem_email}</td>
  </tr>
  <tr> 
    <td width="18%" align="right" valign="top" nowrap  >�ʱࣺ</td>
    <td width="27%"   nowrap >{$data.member_info.mem_zip}</td>
        <td width="18%"  align="right" valign="top" nowrap  >��ʱͨ�ţ�</td>
    <td  nowrap >{if $data.member_info.mem_qq}QQ:{$data.member_info.mem_qq} {/if} {if $data.member_info.mem_msn}MSN:{$data.member_info.mem_msn} {/if}</td>
  </tr>
  <tr> 
    <td width="18%"  align="right" valign="top" nowrap  >��ַ��</td>

    <td colspan="3" nowrap >{$data.member_info.full_adress}</td>
  </tr>
  <tr> 
    <td width="18%" align="right" valign="top" nowrap  >���ԣ�</td>
    <td colspan="3" nowrap >{$data.receive_note}</td>
  </tr>
</table><br>
</div>
<div class="box">
<span class="aa">�ջ�����Ϣ</span>
<table  width="100%"  border="0" cellspacing="1" cellpadding="4" >
  <tr> 
    <td width="18%"  align="right" valign="top" nowrap  >������</td>
    <td width="27%"  nowrap >{$data.receive_realname}</td>
    <td width="18%"  align="right" valign="top" nowrap  >Email��</td>
    <td  align="left" nowrap="nowrap" >{$data.receive_email}</td>
  </tr>

  <tr> 
    <td width="18%"  align="right" valign="top" nowrap  >�绰��</td>
    <td width="27%"  nowrap >{$data.receive_phone}</td>
    <td width="18%"  align="right" valign="top" nowrap  >��&nbsp;����</td>
    <td  align="left" nowrap > {$data.receive_mobile}
    </td>
  </tr>
  <tr> 
    <td width="18%" align="right" valign="top" nowrap  >�ʱࣺ</td>
    <td width="27%" nowrap >{$data.receive_postno}</td>
    <td width="18%"  align="right" valign="top" nowrap  >�ͻ�ʱ�䣺</td>
    <td  align="left" nowrap > 
    {$data.receive_date_type}
    </td>
  </tr>
  <tr> 
    <td width="18%" align="right" valign="top" nowrap  >�ͻ���ַ��</td>
    <td colspan="3" nowrap >{$data.receive_area} {$data.receive_address}</td>
  </tr>
</table><br>
</div>
<div class="box b_bottom">
<span class="aa">����ͳ��</span>
<div  class="status">{assign var='order_detail' value=$data}
  {include file="order/order_money_status.php"}
  </div>
</div>
<div onclick="window.print()" class="print_now">������ӡ</div></div></div>
</div>
</body></html>