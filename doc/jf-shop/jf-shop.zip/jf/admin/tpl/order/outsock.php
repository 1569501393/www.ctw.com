<?php exit('die'); ?>
{if $action eq 'list'}
{include file="frame_header.php"}
<div id="php_main_content">
{if $data.total>0}
<form method="post" action="index.php?m=order/outstock&a=outstock" id="do_delete">
<input type="hidden" value="delete"  name="action"/>
	<table class="table_list">
    	<tr>
        	<th width="50"><input type="checkbox" value=""  id="select_all"/></th>
            <th><% _e('��ϵ��');%></th>
            <th><% _e('�Ǽǵ���Ʒ');%></th>
            <th><% _e('����');%></th>
            <th><% _e('�绰');%></th>
            <th><% _e('����');%></th>
            <th><% _e('QQ');%></th>
            <th><% _e('�Ǽ�ʱ��');%></th>
            <th><% _e('����ʱ��');%></th>
            <th><% _e('״̬');%></th>
            <th><% _e('����');%></th>
        </tr>
        {foreach from=$data.data item='list'}
                <tr>
        	<td align="center"><input type="checkbox" value="{$list.id}"  name="ids[]" class="select_all"/></td>
            <td>{$list.user}</td>
            <td align="center">{$list.goods_name}</td>
            <td align="center">{$list.num}</td>
            <td align="center">{$list.mobile}</td>
            <td align="center">{$list.email}</td>
			<td align="center">{$list.qq}</td>
            <td align="center">{$list.to_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
            <td align="center">{$list.do_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
            <td align="center">{if $list.status eq '0'}<a href="index.php?m=order/outstock&a=outstock&type=undo"><font class="red"><% _e('δ����');%></font></a>{else}<a href="index.php?m=order/outstock&a=outstock&type=hasdo"><% _e('�Ѵ���');%></a>{/if}</td>
            <td align="center">
<a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=order/outstock&a=outstock&task=opt&id={$list.id}','850','450');"><% _e('�鿴');%></a></td>
        </tr>
        {/foreach}
    </table>
<div><div style="float:left; padding-top:7px;"><input type="submit" value="<% _e('ɾ����ѡ');%>" class="form_submit" /></div>{if $data.page}<div style="float:left">{$data.page}</div>{/if}</div>
</form>
    <script type="text/javascript">
    	$(function(){
			checkAllFormData('select_all','select_all');
			$("#do_delete").submit(function(){
				var val  = get_checkbox_val('select_all');
				if(!val){
					window.parent.showNotice(php_empty_select);
					return false;
				}
			});
		});
    </script>
    {else}
    <div class="notice_msg"><% _e('�޿�������!');%></div>
    {/if}
</div>
{include file="frame_footer.php"}
{/if}

{if $action eq 'opt'}
<div style="padding:5px;">
<% _e('��ǰ״̬');%>��{if $data.status eq '0'}<font class="red"><% _e('δ����');%></font>{else}<% _e('�Ѵ���');%>{/if}
</div>
	<table class="table_common">
    	<tr>
        	<td class="one"><% _e('��ϵ��');%></td>
            <td>{$data.user}</td>
        	<td class="one"><% _e('�Ǽ�ʱ��');%></td>
            <td>{$data.to_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        </tr>
        <tr>
        	<td class="one"><% _e('��Ʒ����');%></td>
            <td>{$data.goods_name}</td>

        	<td class="one"><% _e('����');%></td>
            <td>{$data.num}</td>
        </tr>
        <tr>
        	<td class="one"><% _e('�绰');%></td>
            <td>{$data.mobile}</td>

        	<td class="one"><% _e('����');%></td>
            <td>{$data.email}</td>
        </tr>
        <tr>
        	<td class="one"><% _e('IP');%></td>
            <td>{$data.ip}</td>

        	<td class="one"><% _e('QQ');%></td>
            <td>{$data.qq}</td>
        </tr>
        <tr>
        	<td class="one"><% _e('����');%></td>
            <td colspan="4">{$data.detail|nl2br}</td>
        </tr>
	</table>
<div class="notice_msg"><% _e('���跢���ʼ�,��ע��Ϣ����Ϊ�ʼ�����!���Ƕ���֪ͨҲһ��!');%></div>
<div class="spacer"></div>
{if $data.remark}
<p>
	<table class="table_common">
    	<tr>
        	<td align="right" width="160"><% _e('����Ա');%>��</td>
            <td>{$data.do_user}</td>
        	<td  align="right"><% _e('����ʱ��');%>��</td>
            <td>{$data.do_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        </tr>
        <tr>
        	<td align="right"><% _e('������ע');%>��</td>
            <td colspan="4"><font class="blue">{$data.remark|nl2br}</font></td>
        </tr>
    </table>
    </p>
{/if}
<div class="spacer"></div>
<form method="post" action="index.php?m=order/outstock&a=outstock" id="do_opt_info" autocomplete="off">
<input type="hidden" value="do" name="action" />
    <table class="table_common">
    <tr>
    	<td align="right" width="160"><% _e('����');%>��</td>
        <td colspan="4"> <p><label> <% _e('�ֻ�����֪ͨ');%> <input type="checkbox" value="1"  name="send_mobile"/></label>
        <label><% _e('�����ʼ�');%> <input type="checkbox" value="1" name="send_mail" id="send_mail" /></label>
        </p></td>
    </tr>
    <tr>
    	<td align="right"><% _e('�ʼ�����');%>��</td>
        <td colspan="4"> <label> <input type="text" name="subject" id="mail_subject"  size="40" style="width:300px;" /></label></td>
    </tr>
    <tr>
    	<td align="right">
        	<% _e('������ע');%>��
        </td>
		<td colspan="4">
		<textarea class="must_fill_in" name="remark" style="width:300px; height:100px;"></textarea> <font class="blue"> * </font>
        </td>
    </tr>
    <tr>
    	<td colspan="10" style="border:none;"><input  type="submit" value="<% _e('��������');%>" class="form_submit" /></td>
    </tr>
    </table>
</form>
<script type="text/javascript">
	var empty_val = "<% _e('����д��ѡ��!');%>";
	$(function(){
		$("#do_opt_info").submit(function(){
			if(!check_form_is_empty('must_fill_in'))return false;
			var mail = $("#send_mail").attr('checked');
			var subject = $("#mail_subject").val();
			if(mail && empty(subject)){
				$("#mail_subject").addClass('empty_input_val');return false;
			}else{
				$("#mail_subject").removeClass('empty_input_val');	
			}
			$(this).ajaxSubmit(function(data){
				 switch(data){
					case 'OK':
						window.parent.showNotice(php_do_ok);
					 	close_window();
					break;
					case 'EMPTY':
						window.parent.showNotice(empty_val);
						return ;
					break;
					default:alert(data);
				 }
			});
			return false;
		});
	});
</script>
{/if}