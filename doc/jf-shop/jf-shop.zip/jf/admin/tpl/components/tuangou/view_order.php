{if !$is_ajax} {include file="frame_header.php"} {/if}
<link href="tpl/components/tuangou/style/tuangou.css" rel="stylesheet" type="text/css" media="screen"/>
{if $action eq 'tuangou_order_detail'}
<div id="php_top_bar" class="php_bot_bar">
  <p class="tb"><a  href="index.php?m=components/tuangou&a=tuangou_order" class=" block_button">�����б�</a></p>
  <p class="tb"><a  href="javascript:;" onclick="window.location.reload();" class=" block_button">ˢ��</a></p>
  <p class="tb"><a  href="javascript:;" onclick="$('#do_tuangou_order_form').submit();" class=" block_button">����</a></p>
</div>
<div id="php_right_main_content" class="tuangou_order_detail">
<div class="table_item_base">
	<h1 class="c_bar">��Ʒ�嵥</h1>
    <div class="c_content">
   <table class="table_common" cellpadding="0" cellspacing="0">
      <tr>
        <th>��Ŀ����</th>
        <th>����</th>
        <th></th>
        <th>�۸�</th>
        <th></th>
        <th>�ܼ�</th>
      </tr>
      <tr>
        <td class="pname"><a href="{$data.view_link}" target="_blank">{$data.project_name} {$data.goods_name}</a></td>
        <td class="center">{$data.count}
        </td>
        <td class="center">X</td>
        <td class="center">{$data.goods_money|money_format}</td>
        <td class="center">=</td>
        <td class="center"><strong  id="tuan_goods_price_{$data.id}">{$data.total_goods_money|money_format}</strong></td>
      </tr>
      <tr>
        <td>��ݷ���</td>
        <td id="tuan_buy_number" class="center">{$data.count}</td>
        <td class="center">X</td>
        <td class="center" id="one_peison_fee">{$data.delivery_fee}</td>
        <td class="center">=</td>
        <td class="center" id="all_peison_fee">{$data.total_delivery_fee|money_format}</td>
      </tr>
      <tr>
        <td><strong class="e_red">�����ܶ�</strong></td>
        <td></td>
        <td></td>
        <td></td>
        <td class="center">=</td>
        <td class="center e_red"><strong  class="e_red" id="tuan_total_fee">{$data.total_order_fee|money_format}</strong></td>
      </tr>
    </table>
</div>
<h1 class="c_bar">֧����־</h1>
    <div class="c_content">
    {if $pay_log_data.data}
 <table class="table_common" cellpadding="0" cellspacing="0">
    	<tr>
    <th>���</th>
    <th>ʵ��֧��</th>
    <th>ʱ��</th>
    <th>֧����ʽ</th>
    <th>��ˮ��</th>
    <th>��Ա</th>
</tr>
{foreach from=$pay_log_data.data item='tag'}
    <tr>
        <td align="center">{$tag.id}</td>
        <td align="center">{$tag.money}</td>
        <td align="center">{$tag.pay_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        <td align="center">{$tag.pay_name}</td>
        <td align="center">{$tag.pay_sn}</td>
        <td align="center">{if $tag.mem_id}<a href="javascript:;" onclick="window.parent.showWindow('��Ա����','index.php?m=member&a=detail&memid={$tag.mem_id}&noborder=true',960,350);">��Ա����</a>{else} - {/if}</td>
    </tr>
{/foreach}
<tr>
    <td colspan="7" align="right" style="padding-right:10px;">�ܶ{$pay_log_data.money_format}</td>
</tr>
</table>
{else}
<div class="notice_msg">�޿�������!</div>
{/if}
    </div>
 
	<h1 class="c_bar">����˵��</h1>
    <div class="c_content">

    <table class="table_common">
      <tr>
        <td class="one">�ռ���</td>
        <td class="left">{$data.re_name}</td>
      </tr>
      <tr> 
        <td class="one">�ֻ�����</td>
        <td class="left">{$data.re_phone}</td>
      </tr>
      <tr>
        <td class="one">�ռ���ַ</td>
        <td class="left">{$data.re_address}</td>
      </tr>
      <tr>
        <td class="one">��������</td>
        <td class="left">{$data.re_zip}</td>
      </tr>
    </table>
    </div>
    <h1 class="c_bar">������Ϣ</h1>
    <div class="c_content">
    <table class="table_common">
    {if $data.goods_extend_prefix_temp}
      <tr>
        <td class="one">����ѡ��</td>
        <td class="left">
        	{foreach from=$data.goods_extend_prefix_temp item='son'}
            	{$son}&nbsp;
            {/foreach}
        </td>
      </tr>
      {/if}
      <tr>
        <td class="one">��������</td>
        <td class="left">{$data.re_extend}</td>
      </tr>
    </table>
    </div>
<form method="post" action="index.php?m=components/tuangou&a=do_order_detail" id="do_tuangou_order_form"> 
<input type="hidden" value="{$data.order_id}" name="order_id" />
<input type="hidden" value="{$data.order_sn}"  name="order_sn" />
 <h1 class="c_bar">������Ϣ</h1>
    <div class="c_content">
    <table class="table_common">
      <tr>
        <td class="one">������ʽ</td>
        <td class="left">
        	<input type="text" value="{$data.wuliu_name}"  name="wuliu_name" class="form_input w300 must_fill_data"/>
        </td>
      </tr>
      <tr>
        <td class="one">����</td>
        <td class="left"><input type="text" value="{$data.wuliu_sn}"  name="wuliu_sn" class="form_input w300 must_fill_data"/></td>
      </tr>
    </table>
    </div>
 <h1 class="c_bar">������ע</h1>
    <div class="c_content">
    <table class="table_common">
      <tr>
        <td class="one">��ע��Ϣ</td>
        <td class="left">
        	<textarea class="form_textarea w400 h100 must_fill_data" name="order_remark">{$data.order_remark}</textarea>
        </td>
      </tr>
    </table>
    </div>
    </form>
    <script type="text/javascript">
    	$(function(){
			$("#do_tuangou_order_form").submit(function(){
				if(!check_form_is_empty('must_fill_data')){
					window.parent.showNotice('�����������!');
					return false;	
				}
				$(this).ajaxSubmit(function(data){
					switch(data){
						case 'OK':
						 window.parent.showNotice('�����ɹ�!');
						 window.location.reload();
						break;
						case 'EMPTY':
						 window.parent.showNotice('�����������!');
						break;
						default:alert(data);
					}
				});
				return false;
			});
		});
    </script>
    
  <h1 class="c_bar">������ע</h1>
    <div class="c_content">
    {if $remark}
    <table class="table_list">
     <tr>
        <th>���</th>
        <th>����</th>
        <th>ʱ��</th>
        <th>����</th>
      </tr>
      {foreach from=$remark item='list'}
      <tr>
        <td class="center">{$list.id}</td>
        <td class="center">{$list.who}</td>
        <td class="center">{$list.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        <td class="left">{$list.desc}</td>
      </tr>
		{/foreach}
    </table>
    {else}
    	<div class="notice_msg">�޿�������!</div>
    {/if}
    </div>
    
    
    </div>
</div>
{/if}
{if !$is_ajax}{include file="frame_footer.php"}{/if}