{if !$is_ajax} {include file="frame_header.php"} {/if}
<link href="tpl/components/tuangou/style/tuangou.css" rel="stylesheet" type="text/css" media="screen"/>
{if $action eq 'tuangou_mail_list'}
<form method="post" action="index.php?m=components/tuangou&a=tuangou_mail_list" id="do_tuangou_search_form" autocomplete="off">
<div id="php_top_bar">
<p class="tb"><input type="text" value="{$get.mail}" name="mail" class="w100" /></p>
<p class="tb"><a  href="javascript:;" class="form_btn block_button" onclick="$('#do_tuangou_search_form').submit();">����</a></p> 
 {if $data.total>0}<p class="tb"><a  href="javascript:;" class="form_btn block_button" onclick="delete_select_data();">ɾ����ѡ</a> </p>
 <p class="tb"><a  href="index.php?m=components/tuangou&a=tuangou_mail_list&type=mail" class="form_btn block_button" target="_blank">��������</a> </p>
 {/if} 
</div>
 </form>

<div class="clear"></div>

<script type="text/javascript">
	$(function(){
		$("#do_tuangou_search_form").submit(function(){
			window.location.href=_s(this); return false;
		}); 
		check_all('check_box_cal','check_box_cal');
	});
	function delete_select_data(){
		var c = get_checkbox_val('check_box_cal');
		if(!c){
			window.parent.showNotice('��ѡ��Ҫ����������!');return false;
		}
		if(!confirm('ȷ��Ҫɾ����?\r\n�˲������ɻָ�!'))return false;
		$.post('index.php?m=components/tuangou&a=tuangou_mail_list',{ids:c,action:'delete'},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					var cc = c.split(',');
					$(cc).each(function(i){
						var j = $(".fix_val_called_"+cc[i]).remove();
					});
					if(!$(".fix_tuan_goods_list").size()){
						window.location.reload();	
					}
					return false;
				break;
				case 'EMPTY':
					window.parent.showNotice('��ѡ��Ҫ����������!');
				break;
				default:alert(data);
			}
		});
	}
</script>
<div id="php_right_main_content">
 {if $data.total>0}
  <table class="table_list">
    <tr>
      <th><input type="checkbox" value="" id="check_box_cal" /></th>
      <th>���</th>
      <th>����</th>
      <th>�绰</th>
      <th>����</th>      
      <th>����ʱ��</th>
    </tr>
    {foreach from=$data.data item='list'}
    <tr class="fix_val_called_{$list.id} fix_tuan_goods_list">
      <td class="center"><input type="checkbox"  class="check_box_cal" value="{$list.id}"  /></td>
      <td class="center" style="width:20px;"> {$list.id}</td>
      <td class="center">{$list.mail}</td>
      <td class="center">{$list.phone}</td>
      <td class="center tuangou_goods_name">{$list.region_name}</td>
      <td class="center">{$list.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
    </tr>
    {/foreach}
  </table>
	{$data.page}
  {else}
  <div class="notice_msg">�޿�������!</div>
  {/if} </div>
{/if}
{if !$is_ajax}{include file="frame_footer.php"}{/if}