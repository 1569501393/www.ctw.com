{if !$is_ajax} {include file="frame_header.php"} {/if}
{if $action eq 'tuangou_category'}
<div id="php_top_bar" class="php_bot_bar"> 
{if $data}<a  href="javascript:;" class=" block_button" onclick="delete_select_data();">ɾ����ѡ</a> {/if}
<a  href="javascript:;" class="block_button" onclick="window.location.reload();">ˢ��</a> 
 <a  href="javascript:;" class=" block_button" onclick="add_data('{$curent_app}','����');">����</a> </div>
<script type="text/javascript">
  function add_data(tag,type,id){
	  id = !id?0:id;
	  var str = '';
	  switch(tag){
		case 'region':
			str = '����';
		break;
		case 'category':
		default:
			str = '����';
	  }
	  window.parent.showWindow(type+str,'index.php?m=components/tuangou&a=tuangou_do_category&type='+tag+'&id='+id,850,500);
  }
  function delete_select_data(){
	var c = get_checkbox_val('check_box_cal');
	if(!c){
		window.parent.showNotice('��ѡ��Ҫ����������!');return false;
	}
	if(!confirm('ȷ��Ҫɾ����?�˲������ɻָ�!'))return false;
	$.post('index.php?m=components/tuangou&a=tuangou_do_category',{ids:c,action:'delete','do_type':'{$curent_app}'},function(data){
		switch(data){
			case 'OK':
				window.parent.showNotice('�����ɹ�!');
				$(".table_list tr").each(function(){
					if($(this).attr('fixed')==1){
						$(this).remove();	
					}
				});
				if(!$(".fix_tuan_cat_data").size()){
					window.location.reload();	
				}
				return false;
			break;
			case 'HAS_DATA':
				
			break;
			case 'EMPTY':
				window.parent.showNotice('��ѡ��Ҫ����������!');
			break;
			default:alert(data);
		}
	});
  }
  $(function(){
		check_all('check_box_cal','check_box_cal');
  });
</script>
<form method="post" action="index.php?m=components/tuangou&a=tuangou_category" id="form_action_categorys">
  <input type="hidden" value="{$curent_app}" name="do_app" />
  <div id="php_right_main_content">
    <div class="table_scroll">
      <ul class="menu">
        <li {if $curent_app eq 'category'} class="wintable_curent"{/if}><a href="index.php?m=components/tuangou&a=tuangou_category&app=category">�������</a></li>
        <li {if $curent_app eq 'region'} class="wintable_curent"{/if}><a href="index.php?m=components/tuangou&a=tuangou_category&app=region">��������</a></li>
      </ul>
    </div>
    <div class="table_item" id="cfg_base">
      <div class="table_item_base">
        <h1 class="c_bar"> {if $curent_app eq 'category'}
          ���з���
          {elseif $curent_app eq 'region'}
          ���е���
          {/if} </h1>
        <div class="c_content"> {if $data}
          <table class="table_list">
            <tr>
              <th><input type="checkbox" value="" id="check_box_cal" /></th>
              <th>����</th>
              <th>����</th>
              <th>����</th>
              <th>Ӣ��</th>
              <th>����ĸ</th>
             <!-- <th>����ģ��</th>-->
              <th>����ʱ��</th>
              <th>�༭ʱ��</th>
              <th>����</th>
            </tr>
            {foreach from=$data item='list'}
            <tr class="fix_val_called_{$list.id} fix_tuan_cat_data">
              <td class="center"><input type="checkbox"  {if $list.total <=0} value="{$list.id}" class="check_box_cal"  {/if} /></td>
              <td class="center">{$list.name} <samp class="blue">({$list.total})</samp></td>
              <td class="center">{$list.group_name|default:'-'}</td>
              <td class="center">{$list.sort}</td>
              <td class="center">{$list.en_name}</td>
              <td class="center">{$list.en_first}</td>
             <!-- <td class="center">{if $list.tpl}<samp class="red">��</samp>{else}��{/if}</td>-->
              <td class="center">{$list.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
              <td class="center">{if $list.add_time neq $list.edit_time}<samp class="blue">{$list.edit_time|date_format:"%Y-%m-%d %H:%M:%S"}</samp>{else}{$list.edit_time|date_format:"%Y-%m-%d %H:%M:%S"}{/if}</td>
              <td class="center"><a href="javascript:;" onclick="add_data('{$curent_app}','�༭','{$list.id}');">�༭</a></td>
            </tr>
            {/foreach}
          </table>
          {else}
          <div class="notice_msg">�޿���<samp class="blue">{if $curent_app eq 'category'}����{elseif $curent_app eq 'region'}����{/if}</samp>����,������!</div>
          {/if} </div>
      </div>
    </div>
  </div>
</form>
{/if}

{if $action eq 'do_tuangou_category'}
<div id="do_tuangou_category" class="table_scroll">
  <div class="menu">
    <ul>
      <li name="cfg_all" id="g_base_all">ȫ��</li>
      <li name="cfg_base" class="wintable_curent">������Ϣ</li>
      <li name="cfg_seo">SEO��Ϣ</li>
    </ul>
  </div>
</div>
<form method="post" action="index.php?m=components/tuangou&a=tuangou_do_category" id="do_tuangou_category_form">
<input type="hidden" value="{$curent_app}"  name="do_type"/>
<input type="hidden" value="{$data.name}"  name="old_name"/>
<input type="hidden" value="{$data.id}"  name="id"/>
<input type="submit" value="����" style="display:none;" />
<div class="table_item" id="cfg_base">
  <div class="table_item_base">
    <h1 class="c_bar">������Ϣ</h1>
    <div class="c_content">
      <table class="table_common">
        <tr>
          <td class="one">����</td>
          <td><input type="text" value="{$data.name}" id="t_name" class="w300 must_fill_data form_input"  name="name"/><samp class="red">*</samp></td>
        </tr>
        <tr>
          <td class="one">����</td>
          <td><input type="text" value="{$data.group_name}"  class="w300 form_input"  name="group_name"/></td>
        </tr>
        <tr>
          <td class="one">����</td>
          <td><input type="text" value="{$data.sort|default:'0'}" class="w300 must_fill_data form_input"  name="sort"/></td>
        </tr>
        <tr>
          <td class="one">Ӣ��</td>
          <td>
          <div class="tb"><input type="text" value="{$data.en_name}"   class="w300  must_fill_data form_input" name="en_name" id="t_sign"/><samp class="red">*</samp> </div>
          <div class="tb"><a href="javascript:;" class="form_btn block_button"  onclick="window.parent.get_pinyin($('#t_name').val(),$('#t_sign'));">��ȡƴ��</a></div>
          </td>
        </tr>
        <tr>
          <td class="one">����ĸ</td>
          <td><input type="text" maxlength="1" value="{$data.en_first}"   class="w300 must_fill_data form_input" name="en_first"/><samp class="red">*</samp></td>
        </tr>
        <!--
        <tr>
          <td class="one">�Զ���ģ��</td>
          <td><input type="text" value="{$data.tpl}"  class="w300 form_input"  name="tpl"/></td>
        </tr>
        -->
        <tr>
          <td  class="one">����</td>
          <td><textarea  name="desc" class="seo_set ">{$data.desc}</textarea></td>
        </tr>
      </table>
    </div>
  </div>
</div>
<div class="table_item" id="cfg_seo">
  <div class="table_item_base">
    <h1 class="c_bar">SEO��Ϣ</h1>
    <div class="c_content">
      <table class="table_common">
        <tr>
          <td  class="one">����</td>
          <td ><input type="text" name="seo[title]"  value="{$data.seo.title}" class="w350 form_input"/></td>
        </tr>
        <tr>
          <td  class="one">������Ϣ</td>
          <td ><textarea class="seo_set"  name="seo[description]" >{$data.seo.description}</textarea></td>
        </tr>
        <tr>
          <td  class="one">�ؼ���</td>
          <td><textarea  name="seo[keywords]" class="seo_set">{$data.seo.keywords}</textarea></td>
        </tr>
      </table>
    </div>
  </div>
</div>
<div class="table_item_base" style="margin-bottom:0px; padding-top:5px; text-align:center;">
    <a href="javascript:;" onclick="submit_form('do_tuangou_category_form')" class="block_button form_btn">����</a>
</div>
</form>
<script type="text/javascript">
  $(function(){
	 $.table_bars($("#do_tuangou_category .menu li"));
	 $("#do_tuangou_category_form").submit(function(){
		if(!check_form_is_empty('must_fill_data')){
			window.parent.showNotice('����д������!'); return false;
		}
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					_close_window_one();
					_reload_frame();
					return false;
				break;
				case 'HAS_EXIST':
					window.parent.showNotice('������ͬ������,��������д!');
					$("#t_name").val('');
					return false;
				break;
				case 'HAS_EXIST_EN':
					window.parent.showNotice('������ͬ��Ӣ������,��������д!');
					$("#t_sign").val('');
					return false;
				break;
				case 'EMPTY':
					window.parent.showNotice('����д������!');return false;
				break;
				default:alert(data);
			}
		});
		return false;
	 });
  });
</script>
{/if}

{if !$is_ajax}{include file="frame_footer.php"}{/if}