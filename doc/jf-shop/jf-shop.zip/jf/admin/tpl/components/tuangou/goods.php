{if !$is_ajax} {include file="frame_header.php"} {/if}
{if $action eq 'add_tuangou' || $action eq 'edit_tuangou'}
<div id="php_top_bar" class="php_bot_bar"> 
<div class="tb"><a  href="javascript:;" class="block_button" onclick="window.location.reload();">ˢ��</a></div>
<div class="tb"><a  href="javascript:;" class="block_button" onclick="submit_form('do_tuangou_goods_pack');">����</a></div>
<div class="tb"><a  href="index.php?m=components/tuangou&a=tuangou_list" class="block_button">����</a></div>
</div>
<form method="post" action="index.php?m=components/tuangou&a={$do_action}" id="do_tuangou_goods_pack">
<input type="hidden" value="{$do_action}" name="do_action"  />
<input type="hidden" value="{$data.id}"  name="id"/>
<input type="submit" value="����" style="display:none;" />
  <div id="php_right_main_content">
    <div id="do_tuangou_goods" class="table_scroll">
      <div class="menu">
        <ul>
          <li name="cfg_all" id="g_base_all">ȫ��</li>
          <li name="cfg_base" class="wintable_curent">������Ϣ</li>
          <li name="tuan_goods_data">��Ʒ��Ϣ</li>
          <li name="tuangou_prisong_info">������Ϣ</li>
          <li name="cfg_seo">SEO��Ϣ</li>
        </ul>
      </div>
    </div>
    <div class="table_item" id="cfg_base">
      <div class="table_item_base">
        <h1 class="c_bar">������Ϣ</h1>
        {if $data.expired}<div class="notice_msg">�ѹ���!</div>{/if}
        <div class="c_content">
          <table class="table_common tuangou_table">
            <tr>
              <td class="one">��Ŀ����</td>
              <td  colspan="5"><input type="text" value="{$data.project_name}"   class="w400 must_fill_data form_input" name="project_name"/>
                <samp class="red">*</samp></td>
            </tr>
            <tr>
              <td class="one">��Ŀ����</td>
              <td nowrap="nowrap">
              <select name="type" class="w200" id="project_item">
                  <option value="1" {if $data.type neq '2'} selected="selected"{/if}>�Ź���Ŀ</option>
                  <option value="2" {if $data.type eq '2'} selected="selected"{/if}>��ɱ��Ŀ</option>
                </select>
                <%
          	$this->assign('category',_get_tuangou_category());
          %>
<script type="text/javascript">
$(function(){
	//t_start_time
	var o = $(".t_time_set");
	$("#project_item").change(function(){
		switch($(this).val()){
			case '2':
			 	$(o).each(function(){
					$(this).val($(this).attr('miao'));
				});
			break;
			default:
				$(o).each(function(){
					$(this).val($(this).attr('tuan'));
				});
		}
	});
});
</script>
          
          <select name="cate_id" class="w200">
          {foreach from=$category item='list'}<option value="{$list.id}" {if $list.id eq $data.cate_id} selected="selected"{/if}>{$list.name}</option>{/foreach}
          </select></td>
            </tr>
            <tr>
              <td class="one">��������</td>
              <td nowrap="nowrap"><select name="conduser"  class="w200">
                  <option value="Y" {if $data.conduser neq 'N'} selected="selected"{/if}>�Թ���ɹ���������</option>
                  <option value="N" {if $data.conduser eq 'N'} selected="selected"{/if}>�Բ�Ʒ������������</option>
                </select>
                <select  class="w200" name="buyonce">
                  <option selected="" value="Y" {if $data.buyonce neq 'Y'} selected="selected"{/if}>������һ��</option>
                  <option value="N" {if $data.buyonce eq 'N'} selected="selected"{/if}>�ɹ�����</option>
                </select></td>
            </tr>
            <tr>
              <td class="one">��չѡ��</td>
              <td nowrap="nowrap"><input type="checkbox" value="1" {if $data.is_recomand eq '1'}  checked="checked" {/if}  name="is_recomand"/>�Ƽ�</td>
            </tr>
            <tr>
              <td class="one">��Ŀ����</td>
              <td>
                {foreach from=$region item='re'}
                <input type="checkbox" name="region_ids[]" {if $re.checked eq '1'}  checked="checked" {/if} value="{$re.id}" />
                {$re.name} 
                {/foreach} </td>
            </tr>
            <tr>
              <td class="one">�Զ���ģ��</td>
              <td><input type="text" value="{$data.tpl}" class="w400" name="tpl"  /></td>
            </tr>
            <tr>
              <td class="one">��Ŀ����</td>
              <td><input type="text" value="{$data.sort|default:'0'}" class="w400" name="sort"  /></td>
            </tr>
            <tr>
              <td class="one">�۸�����</td>
              <td><div class="tb">�г���</div>
                <div class="tb">
                  <input type="text" value="{$data.market_price|default:'2'}"   class="w50 must_fill_data form_input" name="market_price"/> CNY
                </div>
                <div class="tb">��վ��</div>
                <div class="tb">
                  <input type="text" value="{$data.shop_price|default:'1'}"   class="w50 must_fill_data form_input" name="shop_price"/> CNY
                </div>
                <div class="tb">���⹺��</div>
                <div class="tb">
                  <input type="text" value="{$data.pre_number|default:'0'}"   class="w50 must_fill_data form_input" name="pre_number"/> ��
                </div></td>
            </tr>
            <tr>
              <td class="one">ʱ������</td>
              <td><div class="tb">��ʼʱ��</div>
                <div class="tb">
                  <input type="text"  id="t_start_time" tuan="{$data.start_time_tuan}" miao="{$data.start_time_miao}" value="{if $data.type eq '1'}{$data.start_time_tuan}{elseif $data.type eq '2'}{$data.start_time_miao}{else}{$start}{/if}" class="w150 must_fill_data form_input t_time_set" name="start_time"/>
                </div>
                <div class="tb">����ʱ��</div>
                <div class="tb">
                <input type="text" id="t_end_time" tuan="{$data.end_time_tuan}" miao="{$data.end_time_miao}" value="{if $data.type eq '1'}{$data.end_time_tuan}{elseif $data.type eq '2'}{$data.end_time_miao}{else}{$end_time}{/if}"   class="w150 must_fill_data form_input t_time_set" name="end_time"/>
                </div>
                <!--
                <div class="tb">�Ż�ȯ��Ч��</div>
                <div class="tb">
                  <input type="text" value="{if $data.coupon_expire}{$data.coupon_expire}{else}{$coupon_expire}{/if}"   class="w100 must_fill_data form_input" name="coupon_expire"/>
                </div>-->
                <p class="desc">ʱ���ʽ��hh:ii:ss (����14:05:58)�����ڸ�ʽ��YYYY-MM-DD ������2010-06-10��</p>
                </td>
            </tr>
            <tr>
              <td class="one">��������</td>
              <td><div class="tb">�������</div>
                <div class="tb">
                  <input type="text" value="{$data.min_number|default:'10'}" id="min_number" class="w50 must_fill_data form_input" name="min_number"/>
                </div>
                <div class="tb">�������</div>
                <div class="tb">
                  <input type="text" value="{$data.max_number|default:'0'}"  id="max_number"  class="w50 must_fill_data form_input" name="max_number"/>
                </div>
                <div class="tb">ÿ���޹�</div>
                <div class="tb">
                  <input type="text" value="{$data.per_buy_number|default:'1'}" id="per_buy_number"   class="w50 must_fill_data form_input" name="per_buy_number"/>
                </div>
                <div class="tb">��͹���</div>
                <div class="tb">
                  <input type="text" value="{$data.min_buy_number|default:'1'}"  id="min_buy_number"  class="w50 must_fill_data form_input" name="min_buy_number"/>
                </div>
                <p class="desc">��������������0���������/ÿ���޹���0 ��ʾû������� ����Ʒ��|���� �ɳ�������������</p>
                </td>
            </tr>
            <tr>
              <td class="one">�������</td>
              <td><textarea name="short_desc" class="w500 h150" style="width:98%;">{$data.short_desc}</textarea></td>
            </tr>
            <tr>
              <td class="one">�ر���ʾ</td>
              <td class="no_border c_no_border" style="margin:0px auto; text-align:center;">
              {$spec_content}
              <p class="clear desc">���ڱ�����Ŀ����Ч�ڼ�ʹ��˵��</p>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="table_item" id="tuan_goods_data">
      <div class="table_item_base">
        <h1 class="c_bar">��Ʒ��Ϣ</h1>
        <div class="c_content">
          <table class="table_common tuangou_table">
            <tr>
              <td class="one">��Ʒ����</td>
              <td><input type="text" name="goods_name"  value="{$data.goods_name}" class="w450 form_input must_fill_data"/> <samp class="red">*</samp></td>
            </tr>
            <tr>
              <td class="one">�����ѡ��</td>
              <td>
              	<input type="text"  name="goods_extend_prefix" value="{$data.goods_extend_prefix}" class="w450 form_input"/>
              	<p class="desc">��ʽ�磺{��ɫ}{��ɫ}{��ɫ}@{���}{�к�}{С��}@{�п�}{Ů��}������ʹ��@���ŷָ� , �û�����ı�ѡ��</p>
              </td>
            </tr>
            <tr>
              <td  class="one">��ƷͼƬ1</td>
              <td>
              <div class="tb"><input type="text" name="pic1" id="tuan_pic1"  value="{$data.pic1}" class="w450 form_input must_fill_data"/> <samp class="red">*</samp></div><div class="tb"><a href="javascript:;" onclick="showDialog(document.getElementById('tuan_pic1'),'index.php?m=file&type=tuan')"  class="form_btn block_button">ѡ��ͼƬ</a> </div>
               <p class="desc">���磺http://.../pic.jpg</p> 
              </td>
            </tr>
             <tr>
              <td  class="one">��ƷͼƬ2</td>
              <td>
              <div class="tb"><input type="text" name="pic2" id="tuan_pic2"  value="{$data.pic2}" class="w450 form_input"/></div><div class="tb"><a href="javascript:;" onclick="showDialog(document.getElementById('tuan_pic2'),'index.php?m=file&type=tuan')"  class="form_btn block_button">ѡ��ͼƬ</a></div>
               <p class="desc">���磺http://.../pic.jpg</p>
              </td>
            </tr>
             <tr>
              <td  class="one">��ƷͼƬ3</td>
              <td>
              <div class="tb"><input type="text" name="pic3" id="tuan_pic3"  value="{$data.pic3}" class="w450 form_input"/></div><div class="tb"><a href="javascript:;" onclick="showDialog(document.getElementById('tuan_pic3'),'index.php?m=file&type=tuan')"  class="form_btn block_button">ѡ��ͼƬ</a></div>
               <p class="desc">���磺http://.../pic.jpg</p>
              </td>
            </tr>
             <tr>
              <td  class="one">��ƷͼƬ4</td>
              <td>
              <div class="tb"><input type="text" name="pic4"  id="tuan_pic4" value="{$data.pic4}" class="w450 form_input"/></div><div class="tb"><a href="javascript:;" onclick="showDialog(document.getElementById('tuan_pic4'),'index.php?m=file&type=tuan')"  class="form_btn block_button">ѡ��ͼƬ</a></div>
               <p class="desc">���磺http://.../pic.jpg</p>
              </td>
            </tr>
             <tr>
              <td  class="one">FLV��Ƶ��Ƭ</td>
              <td>
                <div class="tb"><input type="text" name="flv" id="tuan_flv"  value="{$data.flv}" class="w450 form_input"/></div><div class="tb"><a href="javascript:;"  onclick="showDialog(document.getElementById('tuan_flv'),'index.php?m=file&type=flv')" class="form_btn block_button">ѡ����Ƶ</a></div>
               <p class="desc">���磺http://.../vedio.flv</p>
              </td>
            </tr>
             <tr>
              <td  class="one">���ѵ���</td>
              <td>
              	<textarea class="w500 h100" style="width:98%;"  name="member_dianpin">{$data.member_dianpin}</textarea>
              	<p class="desc">��ʽ���������|С��|http://ww....|XXX������һ��һ������</p>
              </td>
            </tr>
             <tr>
              <td  class="one">��������</td>
              <td class="no_border c_no_border">{$goods_detail}</td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    


    <div class="table_item" id="tuangou_prisong_info">
      <div class="table_item_base">
        <h1 class="c_bar">������Ϣ</h1>
        <div class="c_content">
          <table class="table_common tuangou_table">
            <tr>
              <td class="one">�ⵥ����</td>
              <td>
              	<input type="text" value="{$data.mian_dan_num|default:'0'}" name="mian_dan_num" class="w450" />
              	<p class="desc">�ⵥ������-1��ʾ���˷�, 0��ʾ�����˷ѣ�1��ʾ������1�����˷�, 2��ʾ������2�����˷� ,�Դ�����</p>
              </td>
            </tr>
            <tr>
              <td class="one">���ͷ���</td>
              <td>
              	<input type="text" value="{$data.peisong_fee|default:'0.00'}" name="peisong_fee" class="w450" /> ÿ��
              	<p class="desc">���ͷ��ã�Ĭ��Ϊ0,����д�����������,������Ʒ��������</p>
              </td>
            </tr>
            <tr>
              <td class="one">����˵��</td>
              <td>
              <textarea class="w400 h150"  style="width:98%;" name="peisong_desc">{$data.peisong_desc}</textarea>
              </td>
            </tr>
          </table>
        </div>
        </div>
        </div>

    <div class="table_item" id="cfg_seo">
      <div class="table_item_base">
        <h1 class="c_bar">SEO��Ϣ</h1>
        <div class="c_content">
          <table class="table_common tuangou_table">
            <tr>
              <td  class="one">����</td>
              <td ><input type="text" name="seo[title]"  value="{$data.seo.title}" class="w450 form_input"/></td>
            </tr>
            <tr>
              <td  class="one">������Ϣ</td>
              <td ><textarea class="seo_set w450"  name="seo[description]" >{$data.seo.description}</textarea></td>
            </tr>
            <tr>
              <td  class="one">�ؼ���</td>
              <td><textarea  name="seo[keywords]" class="seo_set w450">{$data.seo.keywords}</textarea></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <script type="text/javascript">
  $(function(){
	 $.table_bars($("#do_tuangou_goods .menu li"));
	 $("#do_tuangou_goods_pack").submit(function(){
		var max_number = $("#max_number").val();
		var min_number = $("#min_number").val();
		if(!check_form_is_empty('must_fill_data')){
			window.parent.showNotice('����д������!'); return false;
		}
		if(min_number<=0){
			window.parent.showNotice('�����������>0!');
			return false;
		}
		if(parseInt($("#per_buy_number").val())<=0){
			window.parent.showNotice('ÿ���޹���������>0!');
			return false;
		};
		if(parseInt($("#min_buy_number").val())<=0){
			window.parent.showNotice('��͹���������>0!');
			return false;
		}
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'EDIT_OK':
					window.parent.showNotice('�����ɹ�,ҳ�潫��ת!');
					window.location.href='index.php?m=components/tuangou&a=tuangou_list';
				break;
				case 'ADD_OK':
					window.parent.showNotice('�����ɹ�,�������Լ�������!');
					window.location.reload();
				break;
				case 'LESS_MIN_NUMBER':
					window.parent.showNotice('�����������>0!'); return false;
				break;
				case 'MAX_NUMBER_LESS_MIN_NUMBER':
					window.parent.showNotice('�����������>�������!'); return false;
				break;
				case 'LESS_PER_BUY_NUMBER':
					window.parent.showNotice('��͹���������1!'); return false;
				break;
				case 'EMPTY_CATE':
					window.parent.showNotice('��ѡ�����!'); return false;
				break;
				case 'EMPTY_REGION':
					window.parent.showNotice('��ѡ�����!'); return false;
				break;
				case 'EMPTY_PIC':
					window.parent.showNotice('��ѡ��ͼƬ!'); return false;
				break;
				case 'EMPTY':
					window.parent.showNotice('����д������!');return false;
				break;
				default:alert(data);
			}
		});
		return false;
	 });
  });
</script>
  </div>
</form>
{/if}
{if !$is_ajax}{include file="frame_footer.php"}{/if}