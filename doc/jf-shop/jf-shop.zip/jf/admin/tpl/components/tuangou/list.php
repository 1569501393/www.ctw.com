{if !$is_ajax} {include file="frame_header.php"} {/if}

{if $action eq 'tuangou_goods_list'}
<form method="post" action="index.php?m=components/tuangou&a=tuangou_list" id="do_tuangou_search_form" autocomplete="off">
<div id="php_top_bar">
<p class="tb"><input type="text" value="{$get.project_name}" name="project_name" class="w100" /></p>
<p class="tb"><a  href="javascript:;" class="form_btn block_button" onclick="$('#do_tuangou_search_form').submit();">����</a></p>
<p class="tb"><a  href="javascript:;" class="form_btn block_button"   id="addvace_search" onfocus="this.blur();" >�߼�����</a></p>
 {if $data.total>0}<p class="tb"><a  href="javascript:;" class="form_btn block_button" onclick="delete_select_data();">ɾ����ѡ</a> </p>{/if} 
<p class="tb"><a  href="index.php?m=components/tuangou&a=tuangou_add_project" class="form_btn block_button">����</a></p>
<!--
<p class="tb" style="float:right; padding-right:15px;"><a href="index.php?m=components/tuangou&a=tuangou_list&type=1" class="blue">������</a> <a href="index.php?m=components/tuangou&a=tuangou_list&type=2" class="blue">�����</a></p>
-->
</div>
 </form>
<div id="subsearch" style="display:none; width:450px;">
<form method="get"  action="index.php?m=components/tuangou&a=tuangou_list" id="addvace_search_form" autocomplete="off">
  <table>
    <tr>
        <td nowrap="nowrap" align="center">��Ŀ����</td>
        <td><input type="text" value="{$get.project_name}" name="project_name"  class="w150"/></td>
	    <td>����</td>
	    <td>
			<select name="type" class="w150 form_select">
        	<option value="0">��ѡ��...</option>
        	<option value="1" {if $get.type eq '1'} selected="selected"{/if}>�Ź�</option>
        	<option value="2" {if $get.type eq '2'} selected="selected"{/if}>��ɱ</option>
        </select>
    </td>
</tr>
<tr>
	<td>����</td>
    <td>
    		<select name="cate_id" class="w150 form_select">
        	<option value="0">��ѡ��...</option>
            {foreach from=$cate_data item='cat'}
        	<option value="{$cat.id}" {if $get.cate_id eq $cat.id} selected="selected"{/if}>{$cat.name}</option>
            {/foreach}
        </select>
    </td>
    <td>����</td>
    <td>
		<select name="region_id" class="w150 form_select">
        	<option value="0">��ѡ��...</option>
            {foreach from=$region_data item='region'}
        	<option value="{$region.id}" {if $get.region_id eq '1'} selected="selected"{/if}>{$region.name}</option>
            {/foreach}
        </select>
    </td>
</tr>

<tr>
	<td>״̬</td>
    <td>
    		<select name="project" class="w150 form_select">
        	<option value="0">��ѡ��...</option>
        	<option value="1" {if $get.project eq '1'} selected="selected"{/if}>�����</option>
        	<option value="2" {if $get.project eq '2'} selected="selected"{/if}>������</option>
        	<option value="3" {if $get.project eq '3'} selected="selected"{/if}>δ�ɹ�</option>
            
        </select>
    </td>
    <td></td>
    <td>

    </td>
</tr>

    <tr>
      <td colspan="4" align="center">
      <input type="submit" value="{$lang.goods.goods_search}" class="form_submit" style="display:none" />
      	<a href="javascript:;" onclick="submit_form('addvace_search_form');" class="form_btn block_button">����</a>
        <a href="javascript:;" onclick="$('#subsearch').hide();try{close_date();}catch(e){}" class="block_button form_btn">�ر�</a></td>
    </tr>
  </table>
  </form>
</div>
<div class="clear"></div>

<script type="text/javascript">
	$(function(){
		$("#do_tuangou_search_form").submit(function(){
			window.location.href=_s(this); return false;
		});
		$("#addvace_search").click(function(){
			var d = $("#subsearch");
			var is_hide = $(d).css('display').toLowerCase()=='none'?true:false;
			if(is_hide){
				var offset = $(this).offset();
				var h = $(this).height() + $(d).height();
				var tt = offset.top+$(this).height()+10;
				$(d).css({"top":tt+'px','left':parseInt(offset.left-($(d).width()/2)+100)+'px'});
				$(d).fadeIn();d=offset = null;		
			}else{
				$("#subsearch").fadeOut();	
			}
		});
		/*�߼�����*/
		$("#addvace_search_form").submit(function(){
			window.location.href=_s(this);$("#subsearch").fadeOut();return false;
		});
		check_all('check_box_cal','check_box_cal');
	});
	function delete_select_data(){
		var c = get_checkbox_val('check_box_cal');
		if(!c){
			window.parent.showNotice('��ѡ��Ҫ����������!');return false;
		}
		if(!confirm('ȷ��Ҫɾ����?\r\n�˲������ɻָ�!\r\n�Ź�ͼƬ����ֱ��ɾ��,���ֶ�ɾ��.'))return false;
		$.post('index.php?m=components/tuangou&a=tuangou_delete_project',{ids:c,action:'delete'},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					$(".table_list tr").each(function(){
						if($(this).attr('fixed')==1){
							$(this).remove();	
						}
					});
					if(!$(".fix_tuan_goods_list").size()){
						window.location.reload();	
					}
					return false;
				break;
				case 'EMPTY':
					window.parent.showNotice('��ѡ��Ҫ����������!');
				break;
				default:alert(data);
			}
		});
	}
</script>
<div id="php_right_main_content">
 {if $data.total>0}
  <table class="table_list" id="tuan_table_list">
    <tr>
      <th><input type="checkbox" value="" id="check_box_cal" /></th>
      <th>��Ŀ����</th>
      <th>����</th>
      <th>����</th>
      <th>����</th>      
      <th>�۸�</th>
      <th>�ɽ�</th>
      <th>����ʱ��</th>
      <th>�༭ʱ��</th>
      <th>����</th>
    </tr>
    {foreach from=$data.data item='list'}
    <tr class="fix_val_called_{$list.id} fix_tuan_goods_list">
      <td class="center"><input type="checkbox"    value="{$list.id}" class="check_box_cal"  /></td>
      <td class="left">{$list.project_name|truncate:'30':'...'}</td>
      <td class="center">{if $list.type eq '1'}<a href="index.php?m=components/tuangou&a=tuangou_list&type=1">�Ź�</a>{elseif $list.type eq '2'}<a href="index.php?m=components/tuangou&a=tuangou_list&type=2">��ɱ</a>{else}-{/if}</td>
      <td class="center">{$list.category_name}</td>
      <td class="center" style=" font-size:12px;">
      {if $list.type eq '1'}{$list.start_time|date_format:"%Y-%m-%d"}
      {elseif $list.type eq '2'}{$list.start_time|date_format:"%Y-%m-%d %H:%M:%S"}
      {/if}
      <br />{if $list.expired}<samp class="red">{/if}
      {if $list.type eq '1'}{$list.end_time|date_format:"%Y-%m-%d"}
      {elseif $list.type eq '2'}{$list.end_time|date_format:"%Y-%m-%d %H:%M:%S"}
      {/if}
      {if $list.expired}</samp>{/if}</td>
      <td class="center">{$list.shop_price}<br />{$list.market_price}</td>
      <td class="center">0/{$list.min_number}</td>
      <td class="center">{$list.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
      <td class="center">{if $list.add_time neq $list.edit_time}<samp class="blue">{$list.edit_time|date_format:"%Y-%m-%d %H:%M:%S"}</samp>{else}{$list.edit_time|date_format:"%Y-%m-%d %H:%M:%S"}{/if}</td>
      <td class="center"><a href="index.php?m=components/tuangou&a=tuangou_edit_project&id={$list.id}">�༭</a></td>
    </tr>
    {/foreach}
  </table>
	{$data.page}
  {else}
  <div class="notice_msg">�޿�������!</div>
  {/if} </div>
{/if}
{if !$is_ajax}{include file="frame_footer.php"}{/if}