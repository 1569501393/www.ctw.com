{if !$is_ajax} {include file="frame_header.php"} {/if}
{if $action eq 'tuangou_config'}
<div id="php_top_bar" class="php_bot_bar"> <a  href="javascript:;" class="block_button" onclick="window.location.reload();">ˢ��</a> 
<a  href="javascript:;" class=" block_button" onclick="submit_form('tuangou_config');">����</a> </div>
<div id="php_right_main_content">
  <div id="tuangou_base_config" class="table_scroll">
    <div class="menu" style="padding-left:20px;">
      <ul>
        <li name="cfg_all" id="g_base_all">ȫ��</li>
        <li name="cfg_base" class="wintable_curent">��������</li>
         <li name="cfg_gonggao">��������</li>
        <li name="cfg_seo">SEO����</li>
      </ul>
    </div>
  </div>
<form method="post" action="index.php?m=components/tuangou&a=tuangou_config" id="tuangou_config">
<input type="submit" value="����" style="display:none;" />
  <div class="table_item" id="cfg_base">
    <div class="table_item_base">
      <h1 class="c_bar">��������</h1>
      <div class="c_content">
          <table class="table_common">
           <tr>
              <td class="one">���м</td>
              <td><input type="text" value="{$config.crumb}" name="crumb"  class="w300" /></td>
            </tr>
           <tr>
              <td class="one">��ҳ��ʾ����</td>
              <td><input type="text" value="{$config.index_number|default:'20'}" name="index_number"  class="w300" /></td>
            </tr>
           <tr>
              <td class="one">�б�ҳ��ʾ����</td>
              <td><input type="text" value="{$config.list_number|default:'20'}" name="list_number"  class="w300" /></td>
            </tr>
            <tr>
              <td class="one">������</td>
              <td><input type="text" value="{$config.tuangou_url}" name="tuangou_url"  class="w300" /><samp class="desc blue">��http://</samp></td>
            </tr>
           <tr>
              <td class="one">��Ҫ����ʱ��</td>
              <td><input type="text" value="{$config.will_expire_time|default:'10'}" name="will_expire_time"  class="w300" />Сʱ</td>
            </tr>
          </table>
      </div>
    </div>
  </div>
  
  
  <div class="table_item" id="cfg_gonggao">
    <div class="table_item_base">
      <h1 class="c_bar">ȫ�ֹ���</h1>
      <div class="c_content">
          <table class="table_common">
           <tr>
              <td><textarea name="gonggao[site_base]" class="form_textarea seo_set"  style="width:500px;">{$config.gonggao.site_base}</textarea></td>
            </tr>
          </table>
      </div>
      {foreach from=$region item='list'}
      <h1 class="c_bar">{$list.name}_����ȫ�ֹ���</h1>
      <div class="c_content">
          <table class="table_common">
           <tr>
              <td><textarea name="gonggao[site_notice_{$list.id}][data]" class="form_textarea seo_set" style="width:500px;">{$list.config_data.data}</textarea>
              <input type="hidden" value="{$list.id}"  name="gonggao[site_notice_{$list.id}][id]"/>
              </td>
            </tr>
          </table>
      </div>
      {/foreach}
    </div>
  </div>
  
  
  
  <div class="table_item" id="cfg_seo">
    <div class="table_item_base">
      <h1 class="c_bar">SEO����</h1>
      <div class="c_content">
	<table class="table_common">
    <tr>
        <td  class="one">����</td>
        <td >
         <input type="text" class="w350"  name="seo[title]"  value="{$config.seo.title}"/></td>
    </tr>
    <tr>
        <td  class="one">������Ϣ</td>
        <td >
         <textarea class="seo_set"  name="seo[description]" >{$config.seo.description}</textarea></td>
    </tr>
    <tr>
    	<td  class="one">�ؼ���</td>
        <td><textarea  name="seo[keywords]" class="seo_set">{$config.seo.keywords}</textarea></td>
     </tr>
</table>
      </div>
    </div>
  </div>
</form>
</div>
<script type="text/javascript">
  $(function(){
		$.table_bars($("#tuangou_base_config .menu li"));
  });
</script>
{/if}
{if !$is_ajax}{include file="frame_footer.php"}{/if}