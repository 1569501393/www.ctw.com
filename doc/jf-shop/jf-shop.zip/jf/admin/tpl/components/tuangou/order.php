{if !$is_ajax} {include file="frame_header.php"} {/if}
<link href="tpl/components/tuangou/style/tuangou.css" rel="stylesheet" type="text/css" media="screen"/>
{if $action eq 'tuangou_order_list'}
<form method="post" action="index.php?m=components/tuangou&a=tuangou_order" id="do_tuangou_search_form" autocomplete="off">
<div id="php_top_bar">
<p class="tb"><input type="text" value="{$get.order_sn}" name="order_sn" class="w100" /></p>
<p class="tb"><a  href="javascript:;" class="form_btn block_button" onclick="$('#do_tuangou_search_form').submit();">����</a></p>
<p class="tb"><a  href="javascript:;" class="form_btn block_button"   id="addvace_search" onfocus="this.blur();" >�߼�����</a></p>
 {if $data.total>0}<p class="tb"><a  href="javascript:;" class="form_btn block_button" onclick="delete_select_data();">ɾ����ѡ</a> </p>{/if} 
</div>
 </form>
<div id="subsearch" style="display:none; width:450px;">
<form method="get"  action="index.php?m=components/tuangou&a=tuangou_order" id="addvace_search_form" autocomplete="off">
  <table>
    <tr>
        <td nowrap="nowrap" align="center">������</td>
        <td><input type="text" value="{$get.project_name}" name="order_sn"  class="w150"/></td>
	    <td>״̬</td>
	    <td>
			<select name="pay_status" class="w150 form_select">
        	<option value="0">��ѡ��...</option>
        	<option value="1" {if $get.pay_status eq '1'} selected="selected"{/if}>��֧��</option>
        	<option value="2" {if $get.pay_status eq '2'} selected="selected"{/if}>δ֧��</option>
        </select>
    </td>
</tr>
    <tr>
      <td colspan="4" align="center">
      <input type="submit" value="{$lang.goods.goods_search}" class="form_submit" style="display:none" />
      	<a href="javascript:;" onclick="submit_form('addvace_search_form');" class="form_btn block_button">����</a>
        <a href="javascript:;" onclick="$('#subsearch').hide();try{close_date();}catch(e){}" class="block_button form_btn">�ر�</a></td>
    </tr>
  </table>
  </form>
</div>
<div class="clear"></div>

<script type="text/javascript">
	$(function(){
		$("#do_tuangou_search_form").submit(function(){
			window.location.href=_s(this); return false;
		});
		$("#addvace_search").click(function(){
			var d = $("#subsearch");
			var is_hide = $(d).css('display').toLowerCase()=='none'?true:false;
			if(is_hide){
				var offset = $(this).offset();
				var h = $(this).height() + $(d).height();
				var tt = offset.top+$(this).height()+10;
				$(d).css({"top":tt+'px','left':parseInt(offset.left-($(d).width()/2)+100)+'px'});
				$(d).fadeIn();d=offset = null;		
			}else{
				$("#subsearch").fadeOut();	
			}
		});
		/*�߼�����*/
		$("#addvace_search_form").submit(function(){
			window.location.href=_s(this);$("#subsearch").fadeOut();return false;
		});
		check_all('check_box_cal','check_box_cal');
	});
	function delete_select_data(){
		var c = get_checkbox_val('check_box_cal');
		if(!c){
			window.parent.showNotice('��ѡ��Ҫ����������!');return false;
		}
		if(!confirm('ȷ��Ҫɾ����?\r\n�˲������ɻָ�!'))return false;
		$.post('index.php?m=components/tuangou&a=tuangou_order_delete',{ids:c,action:'delete'},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					var cc = c.split(',');
					$(cc).each(function(i){
						var j = $(".fix_val_called_"+cc[i]).remove();
					});
					if(!$(".fix_tuan_goods_list").size()){
						window.location.reload();	
					}
					return false;
				break;
				case 'EMPTY':
					window.parent.showNotice('��ѡ��Ҫ����������!');
				break;
				default:alert(data);
			}
		});
	}
</script>
<div id="php_right_main_content">
 {if $data.total>0}
  <table class="table_list" id="tuan_table_list">
    <tr>
      <th><input type="checkbox" value="" id="check_box_cal" /></th>
      <th>���</th>
      <th>����</th>
      <th>��Ŀ����</th>
      <th>����</th>      
      <th>����</th>
      <th>�����ܶ�</th>
      <th>�ܶ�</th>
      <th>״̬</th>
      <th>ʱ��</th>
      <th>����</th>
    </tr>
    {foreach from=$data.data item='list'}
    <tr class="fix_val_called_{$list.order_id} fix_tuan_goods_list">
      <td class="center"><input type="checkbox"  value="{if $list.pay_status neq '1'}{$list.order_id} {else} 0 {/if}"  {if $list.pay_status eq '1'} disabled="disabled" {/if} class="check_box_cal"  /> {$data.pay_status}</td>
      <td class="center">{$list.order_id}</td>
      <td class="center">{$list.order_sn}</td>
      <td class="center tuangou_goods_name">{$list.project_name} {$list.goods_name}</td>
      <td class="center">{$list.count}</td>
      <td class="center">{$list.goods_money}</td>
      <td class="center">{$list.total_delivery_fee}</td>
      <td class="center">{$list.total_order_fee}</td>
      <td class="center">{if $list.pay_status eq '1'}��֧��{else}<samp class="red">��֧��</samp>{/if}</td>
      <td class="center">{$list.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
      <td class="center"><a href="index.php?m=components/tuangou&a=tuangou_order_detail&id={$list.order_id}">����</a></td>
    </tr>
    {/foreach}
  </table>
	{$data.page}
  {else}
  <div class="notice_msg">�޿�������!</div>
  {/if} </div>
{/if}
{if !$is_ajax}{include file="frame_footer.php"}{/if}