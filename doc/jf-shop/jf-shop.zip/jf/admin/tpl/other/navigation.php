<?php if(!defined('PHP_TEMPLATE'))exit('php');?>
{if $action eq 'nav_list'}
{include file="frame_header.php"}
<div id="php_top_bar">
	<div class="top_bar_pannel">
        <a class="block_button form_btn" href="javascript:;" rel="{$lang.nav.add_nav}" onclick="add_nav(this);"><!--���ӵ���-->{$lang.nav.add_nav}</a>	
        <a class="block_button" href="javascript:;" name="top" onclick="filter_nav(this);">{$lang.nav.top_nav}</a>
        <a class="block_button" href="javascript:;" name="center" onclick="filter_nav(this);"><!--�м䵼��-->{$lang.nav.center_nav}</a>
        <a class="block_button" href="javascript:;" onclick="filter_nav(this);"  name="bottom" ><!--�ײ�����-->{$lang.nav.footer_nav}</a>	
        <a class="block_button" href="javascript:;" onclick="filter_nav(this);" name="all"><!--ȫ������-->{$lang.nav.nav_all}</a>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function(){ close_open_helper("open_nav_helers",'notice_msg');});
	function filter_nav(obj){ window.location.href='index.php?m=other&a=navManage&tag='+$(obj).attr('name');}
	function open_window(url,title){window.parent.showWindow(title,url,800,350);}
	function edit_nav(obj){ return open_window('index.php?m=other&a=navManage&task=edit&id='+$(obj).attr("name"),$(obj).attr('rel')); }
	function add_nav(obj){
		return 	open_window('index.php?m=other&a=navManage&task=add',$(obj).attr('rel'));
	}
	function delete_nav(obj,id){
		if(!confirm('�˲������ɻָ�!ȷ��ɾ����?'))return false;
		$.get('index.php?m=other&a=navManage&task=delete&id='+id,function(d){
			window.parent.showNotice(php_delete_ok); 
			$(obj).parents('tr').remove();
			if(!$('.all_tags').length)window.location.reload();
		});
	}
</script>
<div id="php_right_main_content">
{if $nav_list.total>0}
<table class="table_list">
	<thead>
    	<tr>
            <th><!--����-->{$lang.nav.opt_allal}</th>
        	<th><!--����-->{$lang.nav.name}</th>
            <th><!--��ַ-->{$lang.nav.address}</th>
            <th><!--��ʾ-->{$lang.nav.display}?</th>
            <th><!--�´���-->{$lang.nav.new_window}</th>
            <th><!--����-->{$lang.nav.paixu}</th>
            <th><!--λ��-->{$lang.nav.position}</th>
        </tr>
    </thead>
    <tbody>
    {foreach from=$nav_list.data item=nav}
    	<tr class="all_tags">
         <td align="center" width="50"><a href="javascript:;"  rel="{$lang.php_delete}" onclick="delete_nav(this,'{$nav.nav_id}');">ɾ</a> <a href="javascript:;" rel="{$lang.php_edit}" name="{$nav.nav_id}" onclick="edit_nav(this)">��</a></td>
        	<td align="center">{$nav.name}</td>
            <td>{$nav.link}</td>
            <td align="center">{if $nav.display eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
            <td align="center">{if $nav.blank eq '1'}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
            <td align="center">{$nav.sort}</td>
         <td align="center">{if $nav.position eq 'top'}<!--����-->{$lang.nav.top}{elseif $nav.position eq 'center'}<!--�м�-->{$lang.nav.center}{elseif $nav.position eq 'bottom'}<!--�ײ�-->{$lang.nav.bot}{else}N/A{/if}</td>
        </tr>
       {/foreach}
    </tbody>
</table>
        	{$nav_list.page}
    <!--page else-->
    {else}
    <div class="notice_msg"><!--�޿�������.-->{$lang.php_nodata}</div>
{/if}
</div>
{include file="frame_footer.php"}
{/if}
<!--end nav_list-->
{if $action eq 'add_nav' || $action eq 'edit_nav'}
<script type="text/javascript">
	$(document).ready(function(){
	$("#nav_form_id").submit(function(){
		if(!check_form_is_empty('must_fill_in')){
			window.parent.showNotice('����д������!');
			return false;	
		}
		$("#nav_form_id").ajaxSubmit({
			success:function(d){
				var dt = d.split('|');
				switch(dt[0]){
					case '1':
						window.parent.showNotice(dt[1]); return false;
					break;
					case '2':
						window.parent.showNotice(dt[1]);
						window.frames['rightFrame'].location.reload();
						close_window();
					break;
					case '3':
						window.parent.showNotice(dt[1]);		
						window.frames['rightFrame'].location.reload();
						$("#link_name").val('');
					break;
					default:alert(d);return false;
				}
			}
		});
		return false;
	});
});
</script>
<div class="table_item_base">
	<div class="c_content">
<form method="post" action="index.php?m=other&a=navManage" id="nav_form_id">
{if $action eq 'edit_nav'}
	<input type="hidden" value="{$nav_data.nav_id}"  name="id"/>
{/if}
<input type="hidden"  name="action"  value="{if $action eq 'add_nav'}add_nav{else}edit_nav{/if}"/>
	<table class="table_common">
    	<tr>
        	<td class="one"><!--����-->{$lang.nav.name}</td>           
            <td><input type="text" value="{$nav_data.name}" class="empty_val bg_input must_fill_in" style="width:350px;"  id="link_name"  name="name"/>&nbsp;<span class="blue">*</span></td>
        </tr>
        <tr>
        	 <td class="one"><!--����-->{$lang.nav.extend_name}</td>
             <td><input type="text"  value="{$nav_data.extend_name}" name="extend_name" style="width:350px;"  id="extend_name"/></td>
        </tr>
        <tr>
        	<td class="one"><!--����-->{$lang.nav.link}</td>
            <td><input type="text"  style="width:350px;"  class="empty_val bg_input"  value="{$nav_data.link|default:'#'}" name="link" /></td>
        </tr>
        <tr>
        	<td class="one"><!--����-->{$lang.nav.paixu}</td>
            <td><input type="text" style="width:350px;"  class="bg_input" value="{if $nav_data.sort}{$nav_data.sort}{else}0{/if}" name="sort" /></td>
        </tr>
        <tr>
        	<td class="one"><!--�Ƿ���ʾ-->{$lang.nav.is_display}</td>
            <td>
            	<select name="display" style="width:350px;">
                	<option {if $nav_data.display eq '1'} selected="selected"{/if} value="1">{$lang.yes}</option>
                    <option value="0" {if $nav_data.display eq '0'} selected="selected"{/if}>{$lang.no}</option>
                </select>
            </td>
        </tr>
        <tr>
        	<td class="one"><!--�Ƿ��´���-->{$lang.nav.is_new_window}</td>
            <td>
            	<select name="blank" style="width:350px;">
                	<option value="1" {if $nav_data.blank eq '1'} selected="selected"{/if}>{$lang.yes}</option>
                    <option value="0" {if $nav_data.blank eq '0'} selected="selected"{/if}>{$lang.no}</option>
                </select>
            </td>
        </tr>
       <tr>
        	<td class="one"><!--��ʾλ��-->{$lang.nav.display_position}</td>
            <td>
            	<select name="position" style="width:350px;">
                	<option value="top" {if $nav_data.position eq 'top'} selected="selected"{/if}>{$lang.nav.top}</option>
                    <option value="center" {if $nav_data.position eq 'center'}selected="selected"{/if}>{$lang.nav.center}</option>
                    <option value="bottom" {if $nav_data.position eq 'bottom'} selected="selected"{/if}>{$lang.nav.bot}</option>
                </select>
            </td>
        </tr>
        <tr>
        	<td style="border:none;" class="one"></td>
        	<td style="border:none;"><input type="submit" class="form_submit form_btn" value="{$lang.php_save}"  style="display:none" />
				<a href="javascript:;" onclick="submit_form('nav_form_id');" class="block_button form_btn">�� ��</a>
            </td>
        </tr>
    </table>
    </form>
    	</div>
    </div>
{/if}