<?php if (! defined ( 'PHP_TEMPLATE' ))exit ();?>
{if $action eq 'list' }
{include file="frame_header.php"}
<script language="JavaScript">
{foreach from=$lang.friendlink.js_html key=key item=item}var {$key} = "{$item}";{/foreach}
$(document).ready(function(){
	checkAllFormData("checkallfriendlink", "form_checkbox")
	$("#batchoperationfriendlink").submit(function(){
		$(this).ajaxSubmit({success:function(data){
			data = $.trim(data);
			var callback = data.split('|');
			switch(callback[0]){
				case '1':
					window.parent.showNotice(callback[1]);
					return false;
				break;
				case '2':
					window.parent.showNotice(callback[1]);
					window.location.href='index.php?m=other/friendlink';
				break;
				default:alert(data);return false;
			}
		}
	});
		return false;
});
});
function display_link(obj){
	var value = $(obj).val();
	if(value!='0'){
		window.location.href='index.php?m=other/friendlink&a=php&type='+value;	
	}
}
function optionDataUpDeBatch(items){
	if(!get_checkbox_val('form_checkbox')){
		window.parent.showNotice("<% _e('��ѡ��Ҫ����������!');%>");return false;	
	}
	if(items=='delete' && !confirm(delete_ok))return false;	
	$("#action_types").val(items)
	$("#batchoperationfriendlink").submit();
}
</script>
<div id="php_top_bar">
    <div class="top_bar_pannel">
    <div class="tb"><select id="link_display_model" onchange="display_link(this);">
    <option value="">{$lang.php_select}</option>
    <option value="all" {if $uget.type eq 'all'} selected="selected"{/if}>{$lang.link.all}</option>
    <option value="image" {if $uget.type eq 'image'} selected="selected"{/if}><!--ͼƬ����-->{$lang.link.pic_link}</option>
    <option value="text" {if $uget.type eq 'text'} selected="selected"{/if}><!--��������-->{$lang.link.text_link}</option>
    <option value="hide" {if $uget.type eq 'hide'} selected="selected"{/if}><!--�鿴��������-->{$lang.link.view_all_hide}</option>
    <option value="show" {if $uget.type eq 'show'} selected="selected"{/if}><!--�鿴δ��������-->{$lang.link.view_not_hide_link}</option>
    </select>
    </div>
    <div class="tb"><a onclick="window.parent.showWindow($(this).html(),'index.php?m=other/friendlink&a=addLink',700,400);" class="block_button form_btn">{$lang.friendlink.html_add_friendlink}</a></div>
      {if $friendlinks}
        <div class="tb"><a href="javascript:;" onclick="optionDataUpDeBatch('delete')" class="block_button form_btn">{$lang.friendlink.html_batch_delete}</a></div>
        <div class="tb"><a href="javascript:;" onclick="optionDataUpDeBatch('sort')" class="block_button form_btn">{$lang.link.save_sort}</a></div>
		<div class="tb"><a href="javascript:;" onclick="optionDataUpDeBatch('show')" class="block_button">{$lang.friendlink.html_batch_show}</a> </div>
        <div class="tb"><a href="javascript:;" onclick="optionDataUpDeBatch('hide')" class="block_button">{$lang.friendlink.html_batch_hide}</a> </div>
    {/if}
    </div>
</div>
<div id="php_right_main_content">
<div id='show_friendlink'>
	{if $friendlinks}
		<form method="post" id="batchoperationfriendlink" action="index.php?m=other/friendlink&a=operation">
        <input type="hidden" value="" name="action_type"  id="action_types"/>
			<table class="table_list table_list_hover" id="table_friendlink">
				<tr>
					<th><input type="checkbox" id="checkallfriendlink" /></th><!-- ȫѡ -->
					<th>{$lang.friendlink.th_operation}</th><!-- ���� -->
					<th width="70">����</th><!-- ��ʾ˳�� -->
					<th>{$lang.friendlink.th_friendlink_name}</th><!-- �������� -->
					<th>{$lang.friendlink.th_friendlink_url}</th><!-- ���ӵ�ַ -->
					<th width="50">{$lang.friendlink.th_friendlink_type}</th><!-- ���� -->
                  <th>{$lang.friendlink.th_friendlink_isshow}</th><!-- ״̬ -->
					<th>{$lang.friendlink.th_friendlink_time}</th><!-- ����ʱ�� -->
				</tr>
				{foreach from=$friendlinks item=friendlink}
					<tr>
						<td align="center" width="20"><input type="checkbox" name="link_id[]" value="{$friendlink.friendlink_id}" class="form_checkbox" /></td>
						<td align="center" width="20">
<a class="edit_img" href="javascript:;"  onclick="window.parent.showWindow($(this).attr('title'),'index.php?m=other/friendlink&a=editLink&id={$friendlink.friendlink_id}',950,400)" title="{$lang.friendlink.html_edite}">��</a>
						</td>
						<td align="center" nowrap="nowrap"><input type="text" name="link_sort[]" class="from_input" style="width:20px;" maxlength="4" value="{$friendlink.friendlink_show_order}" /></td>
						<td align="left" id="{$friendlink.friendlink_image}" class="show_image">{$friendlink.friendlink_name}</td>
						<td align="left"><a href="{$friendlink.friendlink_url}" target="_blank">{$friendlink.friendlink_url}</a></td>
                        <td align="center"><div style="padding:3px 0px;">{if $friendlink.friendlink_image}<img  src="{$friendlink.friendlink_image}" width="150" />{/if}</div></td>
						<td align="center" name="{$friendlink.friendlink_id}" value="{$friendlink.friendlink_isshow}" title="{$lang.friendlink.html_dblclick_update_isshow}" class="update_show">{if $friendlink.friendlink_isshow == 'show'}{$lang.friendlink.js_html.friendlink_show}{else}<font class="blue">{$lang.friendlink.js_html.friendlink_hide}</font>{/if}</td>
						<td align="center" >{$friendlink.friendlink_time|date_format:"%Y-%m-%d"}</td>
					</tr>
				{/foreach}
			</table>
<div class="clear"></div>
{$pageurl}
		</form>
	{else}
		<div class="notice_msg">{$lang.friendlink.html_not_data}</div><!-- �������� -->
	{/if} 
 <!--���ݽ���-->
      </div>
</div>
    {include file="frame_footer.php"}
    {/if}
{if $action eq 'add_link' || $action eq 'edit_link'}
<script language="javascript">
	$(document).ready(function(){
	removeEnter();
	$("#frindlinkimage").upload({
		filename:'friend_link',
		post_params:{'sid':session_id},
		url:'index.php?m=other/friendlink&a=ajaxUpload',
		sucess:function(event,response){
			window.parent.closeLoading();
				try{
				var call_back_msg = response.split('|');
				var error = call_back_msg[0];
				var msg = call_back_msg[1]
				switch($.trim(error)){
					case '1':
						window.parent.showNotice(msg);
						return false;
					break;
					case '2':
						$("#link_image_file").val(call_back_msg[2]);
						$("#show_upload_pic").html(' <img src="'+call_back_msg[1]+'" width="150" />');
					break;
					default:alert(!empty(response)?response:System_overtime);return false;
				}
			}catch(e){alert(e);}
		}//end function
	});
});
	<!--form action-->
	$("#link_form").submit(function(){
		var link_name = $("#link_name").val();
		if(empty(link_name)){
			$("#link_name").addClass('empty_input_val');
			return false;
		}
		$(this).ajaxSubmit({success:function(data){
				data = $.trim(data);
				var callback = data.split('|');	
				switch(callback[0]){
					case '1':
						showNotice(callback[1]);
						return false;
					break;
					case '2':
						showNotice(callback[1]);
						_reload_frame();	
						return false;
					break;
					case '3':
					showNotice(callback[1]);
					$("#link_name").val('');
					$("#out_link_pic").val('');
					$("#show_upload_pic").empty();
					$("#link_image_file").val('');
					$("#friendlinkurl").val('');
					_reload_frame();
					break;
					default:alert(data);return false;
				}
			}
		});
		return false;
	});
</script>
<div class="table_item_base">
    <div class="c_content">
			<form action="{if $action eq 'edit_link'}index.php?m=other/friendlink&a=editLink{else}index.php?m=other/friendlink&a=addLink{/if}" id="link_form" method="post" autocomplete="off" class="sub_com">
				<table class="table_common">
					<tr>
						<td  class="one">��������</td><!-- �������ƣ� -->
						<td><input type="text" maxlength="25"  id="link_name" value="{$data.friendlink_name}" name="friendlinkname" class="form_input w250"> <font class="blue">*</font></td>
					</tr>
					<tr>
						<td align="right" class="one">���ӵ�ַ</td><!-- ���ӵ�ַ�� -->
                        
						<td><input maxlength="200" type="text" id="friendlinkurl"  value="{$data.friendlink_url}" class="form_input w250" name="friendlinkurl"  /></td>
					</tr>
					<tr>
					  <td class="one">ͼƬ��ַ</td>
					  <td><input type="text" value="{$data.friendlink_image}" id="out_link_pic" name="out_link" class="w250 form_input input_notice" title="{$lang.friendlink.image_fix}" />
                      </td>
				  </tr>
                  <tr>
                  	<td class="one"></td>
                    <td>  <div id="show_upload_pic">
                        	{if $data.friendlink_image}<img src="{$data.friendlink_image}"/>{/if}
                     	   </div>
                     </td>
                  </tr>
					<tr>
						<td class="one">�ϴ�ͼƬ</td><!-- �ϴ�ͼƬ�� -->
						<td title="{$lang.friendlink.html_optimum_size} {$lang.friendlink.html_defalut_friendlink_text}" class="input_notice">
                      
                      <input type="file" id="frindlinkimage" class="form_input" />
                      <input type="hidden" value="" name="link_image" id="link_image_file" />
                      </td>
					</tr>
					<tr>
						<td class="one">�Ƿ���ʾ</td><!-- �Ƿ���ʾ�� -->
						<td><input type="radio" value="show"  name="friendlinkisshow" {if $data.friendlink_isshow != 'hide'} checked="checked"{/if}>{$lang.friendlink.js_html.friendlink_show} <input type="radio" value="hide" {if $data.friendlink_isshow eq 'hide'} checked="checked"{/if} name="friendlinkisshow">{$lang.friendlink.js_html.friendlink_hide}</td>
					</tr>
					<tr>
						<td  class="one">��ʾ˳��</td><!-- ��ʾ˳�� -->
						<td><input value="{if $data.friendlink_show_order}{$data.friendlink_show_order}{else}0{/if}" maxlength="4" type="text" id="friendlinkshoworder" name="friendlinkshoworder" class="form_input w250" /></td>
					</tr>
                    	<tr>
						<td  class="one">{$lang.friendlink.friendlink_desc}</td><!-- ��ʾ˳�� -->
						<td><textarea class="textarea seo_set" maxlength="255" name="friendlink_desc">{$data.friendlink_desc}</textarea></td>
					</tr>
					<tr>
                    	<td class="one"></td>
						<td>
                        <input type="submit" value="{$lang.friendlink.html_btn_save}" class="form_submit form_btn" style=" display:none;" />
                        <a href="javascript:;" onclick="submit_form('link_form');" class="block_button form_btn">�� ��</a>
                        </td>
					</tr>
				</table>
            <input type="hidden" value="{$data.friendlink_id}" name="link_id" />
	  </form>
	</div>
</div>
{/if}