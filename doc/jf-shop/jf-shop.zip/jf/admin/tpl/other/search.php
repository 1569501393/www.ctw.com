<?php if(!defined('IN_SYS'))exit('crack die'); ?>
{include file="frame_header.php"}
<div id="php_top_bar">
    <div class="top_bar_pannel">
    <div class="tb">{$lang.php_add_key_words}��</div>
    <div class="tb"><input type="text" value="" id="key" class="cc" /></div>
    <div class="tb">{$lang.php_sort}��</div>
    <div class="tb"><input type="text" value="0"  id="sorts"  style="width:30px; text-align:center;"/></div>
    <div class="tb"><a href="javascript:;" onclick="add_key();" class="block_button form_btn">{$lang.search.addsearch_key}</a></div>
    {if $data.total>0}
    <script type="text/javascript">
        function delete_all_keys(task){
            if(confirm(php_delete_confirm)){
                $.get('index.php?m=other&a=search',{task:task},function(data){
                            if(data=='OK'){
                                window.parent.showNotice(php_save_ok);window.location.reload();	
                            }else{
                                alert(data);return false;	
                            }
                    });	
            }
        }
        $(document).ready(function(){
            $("#sub_all").submit(function(){
                if(!get_checkbox_val('s_v')){
                    window.parent.showNotice('��ѡ��Ҫ����������!');
                    return false;
                }
                if(!confirm(php_delete_confirm))return false;
                $(this).ajaxSubmit(function(data){
                    switch(data){
                        case 'OK':
                            window.parent.showNotice(php_save_ok);window.location.reload();	
                        break;
                        default:alert(data);
                    }
                });return false;
            });
            checkAllFormData('select_search','s_v');
            $("#delete_select").click(function(){
                 $("#sub_all").submit();
            });
        });
    </script>
    <div class="tb"><a href="javascript:;" class="block_button form_btn" onclick="delete_all_keys('deleteall');">{$lang.search.delete_all}</a></div>
    <div class="tb"><a href="javascript:;" class="block_button form_btn" id="delete_select">{$lang.search.delete_select}</a></div>
    {/if} 

    </div>
</div>
<div id="php_right_main_content">
<script type="text/javascript">
function add_key(){
	if(!check_form_is_empty('cc'))return false;
	$.post('index.php?m=other&a=search',{key:$("#key").val(),sorts:$("#sort").val(),task:'add'},function(data){
		switch(data){
			case 'OK':
				window.parent.showNotice(php_save_ok);window.location.reload();	
			break;
			default:
			alert(data);
		}
	})	
}
</script>
{if $data.total>0}
<form method="post" action="index.php?m=other&a=search"  name="delete_all" id="sub_all">
<table class="table_list table_list_hover">
    	<th><input type="checkbox" value=""  id="select_search"/></th>
        <th><!--�ؼ���-->{$lang.search.key_words}</th>
        <th><!--�ܴ���-->{$lang.search.zongcishu}</th>
        <th><!--����-->{$lang.search.paixu}</th>
        <th><!--�Զ���-->{$lang.search.self_do}</th>

   {foreach from=$data.data item='item'}
    	<tr>
      <td style="width:20px; text-align:center;"><input class="s_v" name="delete_ids[]" type="checkbox" value="{$item.id}" /></td>
            <td>{$item.keywords}</td>
            <td class="center">{$item.count}</td>
             <td class="center">{$item.sort}</td>
            <td class="center">{if $item.hot eq '1'}<a href="index.php?m=other&a=search&task=yes"><span class="green">��</span></a>{else}<a href="index.php?m=other&a=search&task=no"><span class="red">��</span></a>{/if}</td>
        </tr>{/foreach}
</table></form>
{if $data.page}{$data.page}{/if}
{else}
<div class="notice_msg">{$lang.php_nodata}</div>
{/if}
</div>
{include file="frame_footer.php"}