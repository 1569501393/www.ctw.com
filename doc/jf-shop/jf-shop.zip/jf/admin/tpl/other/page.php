<?php if (! defined ( 'PHP_TEMPLATE' ))exit (); ?>
{if $action == "list"}
{include file="frame_header.php"}
<div id="php_top_bar">
    <div class="top_bar_pannel">
        <div class="tb">��ҳ����飺</div>
        <div class="tb"><select id="select_type" name="select_type"  onchange="show_group_page(this);"><option value="0">{$lang.page.html_type_look_all}</option>{foreach from=$pagetypes item=item}<option value="{$item.type_id}" {if $item.type_id eq $type_id} selected="selected"{/if}>{$item.type_name}</option>{/foreach}</select>
        </div>
        <input type="hidden" value="" name="page_type_state" id="page_type_state"  />
        <div class="tb"><a class="block_button" onclick="window.parent.showWindow($(this).html(),'index.php?m=other/page&a=groupOperation',323,423);">{$lang.page.js_html.edit_page_type}</a></div>
        <div class="tb"><a class="block_button form_btn" href="index.php?m=other/page&a=addPage">{$lang.page.html_add_page}</a></div>
        {if $pagelist.total>0}
        <div class="tb"><a class="block_button form_btn" href="{$create_all}" target="_blank">{$lang.page.create_all}</a></div>
        {/if}
    </div>
</div><!--#end php_top_bar-->
 <div id="php_right_main_content">  <!-- ������ʾ�� -->
<script type="text/javascript">
	var qurl = "index.php?m=member/level";
	{foreach from=$lang.page.js_html key=key item=item}var {$key} = "{$item}";{/foreach}
	function show_group_page(obj){
		var v = $(obj).val();
		if(v!=0){window.location.href='index.php?m=other/page&type_id='+v;}
	}
	//ɾ����
	function delete_page(url,id){
		if(confirm(php_delete_confirm)){
			$.getJSON(url,function(d){
				switch(d.error.toString()){
					case '1':
						window.parent.showNotice(d.msg);
						return false;
					break;
					case '2':
						window.parent.showNotice(d.msg);
						$(".tall_"+id).remove();
						if($(".alltags").size()<=0){window.location.reload();}
					break;
					default:alert('crack die');
				}
			})	
		}
	}
		</script>
    {if $pagelist.total>0}
    	 <table id="page_show_list" name="page_show_list" class="table_list">
                <tr>
                    <th>{$lang.page.html_th_pageopreation}</th><!-- ���� -->
                    <th>{$lang.page.html_th_pagename}</th><!-- ���� -->
                    <th>{$lang.page.html_th_pagetypename}</th><!-- �������� -->
                    <th>{$lang.page.page_sign}</th>
                    <th>{$lang.page.html_th_pagefilename}</th><!-- ���ɺ���ļ��� -->
                    <th>{$lang.page.html_th_pageupatetime}</th><!-- �޸�ʱ�� -->
                </tr>
                {foreach from = $pagelist.data item=page}
                	<tr  class="alltags tall_{$page.page_id}">
 <td align="center" width="90"><a alt="{$lang.page.html_create_static_clew}" title="{$lang.page.html_create_static_clew}" target="_blank" href="{$page.html_url}">��</a> <a title="{$lang.page.html_delete_clew}" href="javascript:;" onclick="delete_page('index.php?m=other/page&a=deletepage&pageid={$page.page_id}','{$page.page_id}');" class="delete_image">ɾ</a> <a  href="index.php?m=other/page&a=editPage&pageid={$page.page_id}" title="{$lang.page.html_update_clew}" class="edit_image">��</a>
 <a  href="{$page.view_url}" target="_blank">��</a>
                        </td>
                        <td nowrap="nowrap"><a title="{$lang.page.click_can_look}"  target="_blank" href="{$page.view_url}">{$page.page_name}</a></td>
                        <td class="pagetypeone" align="center">
{if $page.type_name neq ''}<a href="index.php?m=other/page&type_id={$page.page_type}">{$page.type_name}</a>{else}<% _e('������');%>{/if}</td><!-- ������ -->
                        <td nowrap="nowrap" align="center">{$page.page_sign}</td>
                        <td align="center">{$page.page_filename}</td>
                        <td align="center" nowrap="nowrap">{$page.page_posttime|date_format:"%Y-%m-%d %H:%M:%S"}</td>
                       
                    </tr>
                {/foreach}
        </table>
        <input type="hidden"  value="{$curpage}" id="curpage" />
        	<div class="center">{$pagelist.page}</div>
	{else}
		<div class="notice_msg" align="center">{$lang.page.html_not_data}</div><!-- �������� -->
	{/if}
      </div>
       <!--�м����ݽ���-->
      {include file="frame_footer.php"}
{/if}<!--end list-->
 <!--action edit_page-->  
{if $action eq 'edit_page' || $action  eq 'add_page'}
{include file="frame_header.php"}
<script type="text/javascript">
	var qurl = "index.php?m=member/level";
	{foreach from=$lang.page.js_html key=key item=item}var {$key} = "{$item}";{/foreach}
		$(document).ready(function(){
			removeEnter();
			$("#operation_page").submit(function(){
				if(!check_form_is_empty('page_check_val')){window.parent.showNotice(php_must_fill); return false;}
				var cc = KE.html('pagecontent_editor');
				if(empty(cc))return window.parent.showNotice("<% _e('����д����!');%>");
				$(this).ajaxSubmit({
					success:function(data){
						data = data.split('|');
						switch(data[0]){
							case 'EMPTY':window.parent.showNotice("<% _e('����д������!');%>");return false;break;
							case 'HAS_EXIST':window.parent.showNotice("<% _e('������ͬ������!');%>");return ; break;
							case 'HAS_SAME_SIGN': window.parent.showNotice("<% _e('������ͬ�ı�־λ!');%>");return ; break;
							case 'ADD_OK':
								window.parent.showNotice("<% _e('�����ɹ�,�����Լ�������!');%>");
								window.location.reload();
								return ;
							break;
							case 'EDIT_OK':
							window.parent.showNotice("<% _e('�����ɹ�!');%>"); window.location.href=data[1];
								break;
							default:alert(data);return false;
						}
					}				
				})
				return false;
			});<!--end submit-->
	});
			function add_group(obj){
				$(obj).parent().html('<input type="text" style="width:100px; height:20px;line-height:20px;" value="" id="create_group" />   <input type="button" value="'+php_add+'" onclick="post_group(this);" class="form_submit" />   <input type="button"  class="form_submit" onclick="cacel_group(this);" value="'+php_cancel+'"/>');
				}
			function cacel_group(){
$("#group_item").html('<span onclick="add_group(this);" class="block_button form_btn" style="margin:0px;">'+add_new_page_type+'</span>');
			}
			function post_group(){
				var val = $("#create_group").val();
				if(empty(val)){$("#create_group").addClass('empty_input_val');return false;}
				var post_data = {
						name:val,
						action:'add',
						show_insert:'ok'
				};
			$.ajax({type:'POST',url:'index.php?m=other/page&a=groupOperation',data:post_data,success:function(data){
						var call = data.split('|');
						switch(call[0]){
							case 'HAS_EXIST':
								window.parent.showNotice('������ͬ����!');
								return false;
							break;
							case 'OK':
							case '2':
								$("#create_group").val('');
								$("#pagetype").append('<option value="'+call[2]+'">'+val+'</option>');
								cacel_group();
							break;
							default:alert(data);return false;
						}
				}
			})	;
		}
</script>
<form name="operation_page" id="operation_page" action="{if $action eq 'add_page'}index.php?m=other/page&a=addPage{else}index.php?m=other/page&a=editPage{/if}" method="post" autocomplete="off">
<div id="php_top_bar" class="php_bot_bar">
    <div class="top_bar_pannel">
        <a href="javascript:;" onclick="submit_form('operation_page');" class="block_button form_btn">{$lang.page.html_button_save}</a>
        <a href="javascript:;" onclick="window.location.reload();" class="block_button">ˢ��</a>
    </div>
</div>
  <input type="hidden" value="{$pagedata.page_id}" name="page_id" />
<div id="php_right_main_content">
<script type="text/javascript">
$(function(){
	$.table_bars($("#site_page_content .menu li"));
});
</script>
<div id="site_page_content" class="table_scroll">
    <div class="menu" style="padding-left:20px;">
       <ul>
       		<li name="cfg_all">ȫ��</li>
            <li name="cfg_base" id="g_base_item" class="wintable_curent">������Ϣ</li>
            <li name="cfg_seo">SEO����</li>
            <li name="cfg_content">��ϸ����</li>
       </ul>
    </div>
</div>
<div class="table_item_base">
<div class="table_item" id="cfg_base">
    <h1 class="c_bar">������Ϣ����</h1>
       <div class="c_content">
    <table class="table_common" >
    <tr>
        <td class="one" width="150">����</td><!-- ����ҳ�����ƣ� -->
        <td>
    <input type="text" value="{$pagedata.page_name}"  name="pagename" id="pagename" class="form_input page_check_val" maxlength="25" style="width:300px;"/>
        </td>
    </tr>
        <tr>
        <td class="one">��־λ</td>
        <td><input value="{$pagedata.page_sign}" type="text" name="page_sign" class="form_input" maxlength="50" style="width:300px;" /> <input type="button"  onclick="window.parent.get_pinyin($('#pagename').val(),$(this).prev());" class="form_submit" value="<% _e('�Զ���ȡ');%>" /></td>
    </tr>
    <tr>
        <td class="one">��Ӧ����</td><!-- �������ͣ� -->
        <td>
            <div class="tb">
    <select  name="pagetype" id="pagetype" style="margin-top:3px;"><option value='0'>�޷���</option><!-- ������ --> {foreach from=$pagetypes item=item}<option value="{$item.type_id}" {if $item.type_id eq $pagedata.page_type}selected="selected"{/if}>{$pagestyle.page_type}{$item.type_name}</option>{/foreach} </select> </div>
            <div id="group_item" class="tb"><span onclick="add_group(this);" class="block_button form_btn" style="margin:0px;">{$lang.page.js_html.add_new_page_type}</span></div><!-- ���������� -->
            
        </td>
    </tr>
    <tr>
        <td class="one">�Զ���ģ��</td><!-- ����ģ�� -->
        <td>
            <input type="text"  value="{$pagedata.page_tpl_main}" name="pagemain" id="pagemain" class="form_input" maxlength="50" style="width:300px;"/>
        </td>
    </tr>
    <tr>
        <td class="one">���ɺ���ļ���</td><!-- ��̬��ҳ���� -->
        <td> <input type="text" value="{$filename}" id="pagefilename" name="pagefilename" class="form_input page_check_val" maxlength="50" style="width:300px;"/>
        </td>
    </tr>
    </table>
    </div>
</div>

<div class="table_item" id="cfg_seo">
<h1 class="c_bar">SEO����</h1>
   <div class="c_content">
    <table class="table_common">
      <tr>
        <td class="one">ҳ�����</td>
        <td>
        <textarea name="seo[title]" class="form_textarea seo_set">{$pagedata.seo.title}</textarea>
        </td>
    </tr>
      <tr>
        <td class="one">meta->title</td>                        
        <td><textarea name="seo[meta_title]"  class="form_textarea seo_set">{$pagedata.seo.meta_title}</textarea></td>
    </tr>
    <tr>
        <td class="one">�ؼ���</td>
        <td>   <textarea name="seo[keywords]"   class="form_textarea seo_set">{$pagedata.seo.keywords}</textarea></td>
    </tr>
      <tr>
        <td class="one">������Ϣ</td>
        <td><textarea name="seo[description]"  class="form_textarea seo_set">{$pagedata.seo.description}</textarea></td>
    </tr>
    </table>
    </div>
</div>

<div class="table_item" id="cfg_content">
	<h1 class="c_bar">��������</h1>
       <div class="c_content c_no_border">
        <table class="table_common">
            <tr><td class="no_border none">{$fckeditor}</td></tr>
        </table>
        </div>
	</div>
    
    
	</div>
</div>
 </form>
      {include file="frame_footer.php"}
   {/if}
   <!--begain action-->
   <!--��������б�-->
{if $action eq 'showall_edit_page_type'}
<script type="text/javascript">
	var qurl = "index.php?m=member/level";
	{foreach from=$lang.page.js_html key=key item=item}
		var {$key} = "{$item}";
	{/foreach}
	function delete_group(id){
		if(!confirm("<% _e('ȷ��ɾ��?');%>"))return false;
		$.get('index.php?m=other/page&a=groupOperation&action=delete&id='+id,function(data){
			switch(data){
				case 'EMPTY': 
					window.parent.showNotice("<% _e('��������');%>");return  false;break;
				case 'HAS_DATA':
					window.parent.showNotice("<% _e('�����´�������!');%>");return false;	break;
				case  'OK':
					$("#pagetype"+id).remove();
					if($('.all_tags').length<1){
						$("#pagetypelist").empty();	
					}
				break;
			}
		});
	}
	function edit_group(id){
		$("#do_page_group_action").val('edit');
		$("#do_group_id").val(id);
		$("#group_all_mame").val($.trim($("#edit_page_type_name"+id).html()));
	}
	$(function(){
		$("#page_group_data").submit(function(){
			if(!check_form_is_empty('must_page_group'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'ERROR':
						window.parent.showNotice("<% _e('��������!');%>");
					break;
					case 'EMPTY':
						window.parent.showNotice("<% _e('����Ϊ��!');%>"); return false;
					break;
					case 'HAS_EXIST':
						window.parent.showNotice("<% _e('������ͬ����!');%>");return false;
					break;
					case 'OK':
						window.parent.showNotice("<% _e('�����ɹ�!');%>");
						$.get('index.php?m=other/page&a=groupOperation',function(dd){
							$(".window-content").html(dd);
						});
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
		</script>
	<div style=" text-align:center; margin-top:4px;">
    <form method="post" action="index.php?m=other/page&a=groupOperation" id="page_group_data" autocomplete="off">
    <div class="tb">
    		<% _e('��������');%>��
    </div>
    <div class="tb"><input maxlength="20" type="text" name="name"  id="group_all_mame" class="form_input must_page_group"  /></div>
    <input  type="hidden" value="add" name="action" id="do_page_group_action" />
    <input type="hidden" value="" name="id" id="do_group_id" />
	<input type="submit" value="<% _e('�� ��');%>" class="form_submit form_btn" style="display:none" />
	<div class="tb"><a href="javascript:;" onclick="submit_form('page_group_data');" class="block_button form_btn">�� ��</a></div>
</form>
	</div>
    <div class="clear"></div>
    <div style="margin:3px;">
    {if $pagetypes}
  <table id="pagetypelist" class="table_list">
            <tr>
                <th>{$lang.page.th_page_type_name}</th><!-- �������� -->
                <th>{$lang.page.html_th_pageopreation}</th><!-- ���� -->
            </tr>
            {foreach from=$pagetypes item=item}
                <tr id="pagetype{$item.type_id}" class="all_tags" >
                    <td><span id="edit_page_type_name{$item.type_id}">{$item.type_name}</span> <span class="blue">({$item.num|default:'0'})</span></td>
                    <td align="center" style="width:30%">
                        <a title="{$lang.page.js_html.html_update_clew}" onclick="edit_group('{$item.type_id}')" value="{$item.type_name}" class="update_pagetype" href="javascript:;">{$lang.page.js_html.html_update_clew}</a><!-- �޸� -->
                        {if !$item.num} | <a title="{$lang.page.js_html.html_delete_clew}" onclick="delete_group('{$item.type_id}')" class="delete_pagetype" href="javascript:;">{$lang.page.js_html.html_delete_clew}</a>{/if}</td>
                </tr>
            {/foreach}
        </table>
        {/if}
   </div>
{/if}