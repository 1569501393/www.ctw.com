<?Php if(!defined('PHP_TEMPLATE'))exit('php.com'); ?>
{include file="frame_header.php"}
<div  id="php_right_main_content">
 <div class="notice_msg" id="call_help_tag" style="display:none;">
 �������ϴ�ѹ������ʽ(zip)��ģ��,������1M����.���ϴ���ѹ�������ᱣ��,�����б���.�ϴ�ģ��֮ǰ��ȷ��templateĿ¼��д.�ϴ�ѹ����ʱ�벻Ҫˢ��ҳ��.<strong>�м��ٲ���������֧�����߽�ѹ,���,�����д���.</strong>�л�ģ������&ldquo;��������ģ��&ldquo;��������Ҫ�л���ģ�弴��.�ٷ�Ĭ��Ƥ��������ɾ��!<strong>�ϴ�����Ĭ��Ϊ php</strong>,��������php.config.php(�����ļ�)���ҵ�UPLOAD_TPL_PASS�����޸�,��û�������д���,define("UPLOAD_TPL_PASS","php"); <br /><strong class="red">�Ǵ�ʼ�˲����ϴ�,�л�,����ģ��!</strong> </div>

<div class="table_item_base">
<script type="text/javascript">
	function setTemplate(obj){
		var url = 'index.php?m=other/siteTemplate&a=setTemplate&tpl_name='+obj.name;
		$.get(url,function(data){
			switch(data){
				case 'EMPTY_TPL_NAME':
					window.parent.showNotice('��������!');
				break;
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					window.location.reload();
				break;
				default:alert(data);
			}
		});
	}
</script>
{if $can_upload}
	<h1 class="c_bar">�ϴ�ģ��</h1>
    <div class="c_content">
 {include file="part.js.php"}
<script type="text/javascript">
	var delete_tpl_confirm  = '{$lang.template.delete_tpl_confirm}';
	var need_upload_pass = "����������!";
	var pass_error = "�������!";
{if $do_pass}
	var check_upload_pass = true;
{/if}
$(function(){
	close_open_helper('call_help_click','call_help_tag');
	var swf_upload = $("#tpl_tag").upload({
		filename:'upload_template',
		post_params:{'sid':session_id},
		url:'index.php?m=other/siteTemplate&a=uploadTpl',
		filetype:'*.zip',
		sucess:function(file,response){
				try{
				var call_back_msg = response.split('|');
				switch($.trim(call_back_msg[0])){
					case 'NEED_PASS':
						$("#upload_pass").focus();
						return window.parent.showNotice(need_upload_pass);
					break;
					case 'PASS_ERROR':
						$("#upload_pass").val('');
						return window.parent.showNotice(pass_error);
					break;
					case '1':
						window.parent.showNotice(call_back_msg[1]);
						return false;
					break;
					case '2':
						window.parent.showNotice(call_back_msg[1]);
						window.location.reload();
					break;
					default:alert(!empty(response)?response:System_overtime);return false;
				}
			}catch(e){alert(e);}
		}//end function
 });
	$("#upload_pass").blur(function(){
		swf_upload.setPostParams({
			'sid':session_id,
			'pass':$("#upload_pass").val()
		});
	});
});	
function delete_template(tpl_name){
	if(!confirm(delete_tpl_confirm))return false;
	var u = 'index.php?m=other/siteTemplate&a=deleteTpl&folder='+tpl_name;
	$.get(u,function(data){
		var r = data.split('|');
		switch(r[0]){
			case '1':
				window.parent.showNotice(r[1]); return false;
			break;
			case '2':
				window.parent.showNotice(r[1]); 
				window.location.reload(); return ;
			break;
			default:alert(data);
		}
	});
}
 </script>
    <!--�ϴ�ģ��-->
 {if $do_pass}<div style="float:left; overflow:hidden;">���룺<input type="text" value="" id="upload_pass"  name="do_pass"/></div>{/if}
    <div style="float:left; overflow:hidden; padding-left:10px; margin-top:-3px;"> <span id="tpl_tag"></span></div>
   <div class="clear"></div>
    </div>

{/if}<!--����ģ���ϴ�-->

<div class="curent_use_tpl">
    <h1 class="c_bar"><samp style="display:block; float: left;">����ʹ���е�ģ��</samp><a class="block_button form_btn" id="call_help_click" style="float:left; margin-top:2px; margin-left:5px;"> �򿪰���</a></h1>
        <div class="c_content">
    <table cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td width="20%"  valign="middle">
            <div id="curent_tpl_set">
            <img src="{$template_list.default.thumb_url}" width="200" height="150" />
            </div>
            </td>
            <td width="80%" id="tpl_desc">
              <div style="padding:3px;">
                <p><b>{$lang.template.tpl_name}:</b>{$template_list.default.xml_info.templateName}</p>
                <p><b>{$lang.template.version}:</b>{$template_list.default.xml_info.templateVersion}</p>
                <p><b>{$lang.template.introduce}:</b>{$template_list.default.xml_info.templateInfo}</p>
                <p><b>{$lang.template.author}:</b>{$template_list.default.xml_info.templateAuthor}</p>
                <p><b>{$lang.template.siteUrl}:</b>{$template_list.default.xml_info.site}</p>
                <p><b>{$lang.template.send_time}:</b>{$template_list.default.xml_info.send_time}</p>
                <p><b>{$lang.template.pack_template}:</b>{if $can_bak} <input name="" class="block_button" type="button" onclick="window.location.href='index.php?m=other/siteTemplate&a=packTpl&folder={$template_list.default.xml_info.templateFolder}'" value="{$lang.template.pack_template}"/></a>
            {/if}<!--��������--></p>
              </div>
            </td>
        </tr>
    </table>
    </div><!--#curent_use_tpl-->
</div>
{if $template_list.other}
<div class="another_tpl">
    <h1 class="c_bar">��������ģ��</h1>
        <div class="c_content">
    		<div id="template_other">
            {foreach from=$template_list.other item= tpl}
                <div class="template_list">
                    <h1 class="title">{if $tpl.xml_info.site}<a href="{$tpl.xml_info.site}" target="_blank">{/if}{$lang.template.tpl_name}:{$tpl.xml_info.templateName}{if $tpl.xml_info.site}</a>{/if}</h1>
                    <h1 class="img"><img style="cursor:pointer" {if $can_change}  title="�����л�ģ��"  onclick="setTemplate(this);" name="{$tpl.path_info.realname}" {/if} src="{$tpl.thumb_url}" width="200" height="150" /></h1>
                    <h1 class="desc">
                    <hr />
                   <div style="color:#F00; font-weight:bold;"><!-- ģ��Ŀ¼:{$tpl.xml_info.templateFolder}-->
                 <!--can delete--> {if $can_delete} {if $tpl.xml_info.templateFolder neq 'default'} <span style="cursor:pointer;" onclick="delete_template('{$tpl.xml_info.templateFolder}')" class="blue"><!--ɾ��ģ��-->{$lang.template.delete_tpl}</span>&nbsp;{/if} {/if}<!--����ɾ��ģ��-->
                 <!--��ʼ����--> {if $can_bak}<a href="index.php?m=other/siteTemplate&a=packTpl&folder={$tpl.xml_info.templateFolder}"  target="_blank" class="blue">{$lang.template.pack_tpl}<!--����ģ��--></a> {/if}
                    </div>
                    </h1>
                </div>
       {/foreach}
       <div class="clear"></div>
		</div><!--#template_other-->
	</div><!--#c_content-->
</div><!--#another_tpl-->
{/if}
	 </div><!--#table_item_base-->
 </div>
{include file="frame_footer.php"}