<?php if(!defined('PHP_TEMPLATE'))exit('php');?>
{if $action eq 'list' || $action eq 'purchase' || $action eq 'orderbook'}
{include file="frame_header.php"}
<div class="table_scroll">
<ul class="menu">
	<li class="wintable_curent" id="g_common"><a href="index.php?m=other&a=messageBoard&task=common">��ͨ����</a></li>
    <!--    <li id="g_purchase"><a href="index.php?m=other&a=messageBoard&task=purchase">�Ź���Ϣ</a></li>-->
    <!--<li id="g_orderbook"><a href="index.php?m=other&a=messageBoard&task=orderbook">������Ϣ</a></li>-->
</ul>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		var url = window.location.href;
		var pa = url.split('&task=').pop().split('&').shift();
		if(pa.length<20){
			$('.wintable_curent').removeClass('wintable_curent');
			$("#g_"+pa).addClass('wintable_curent');		
		}
	});
	function delete_b(id){
		$.get('index.php?m=other&a=messageBoard&task=delete&id='+id,function(data){
			switch(data){
				case '1':
					window.parent.showNotice('hack attempt');
				break;
				case '2':
					$("#main_"+id).remove();
					$("#"+id).remove();
					var size = $(".aaa").size();
					if(size<=0)window.location.href='index.php?m=other&a=messageBoard';
				break;
				default:alert(data);
			}
		});
	}
	function view_msg_detail(obj){
		window.parent.showWindow($(obj).html(),$(obj).attr('rel'),780,400);	
	}
</script>
{if $data.total>0}
<table class="table_list">
    	<tr>
        	<td  class="center b">IP</td>
             {if $action neq 'purchase'} <td class="center b"><!--���Ա���-->{$lang.kefu.title}</td>{/if}
            <td class="center b">Time</td>
            <td class="center b">Phone</td>
              <td class="center b"><% _e('��ϵ��');%></td>
              <td class="center b"><!--����״̬-->{$lang.kefu.status}</td>
            <td class="center b"><!--����-->{$lang.kefu.opt}</td>
        </tr>
        {foreach from=$data.data  key=k item=d}
        <tr id="main_{$d.b_id}" class="aaa">
        	<td  class="show_content" name="{$k}" width="100" align="center">{$d.ip}</td>
           {if $action neq 'purchase'} <td  class="show_content" name="{$k}">{$d.title}</td>{/if}
            <td  class="show_content" name="{$k}" align="center">{$d.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
            <td class="show_content" name="{$k}" align="center">{$d.other.phone}</td>
             <td class="show_content" name="{$k}" align="center">{$d.other.name}</td>
             <td class="show_content" name="{$k}" align="center">{if $d.status neq '1'}<a href="{$un_do}"><font class="red"><!--δ����-->{$lang.kefu.not_opt}</font></a>{else}<!--�Ѵ���--><a href="{$has_do}">{$lang.kefu.has_opt}</a>{/if}</td>
            <td align="center">{if $d.link}<a href="{$d.link}" target="_blank">{$lang.kefu.preview}</a> {/if}<a href="javascript:void(0);" onclick="delete_b('{$d.b_id}')">ɾ</a> <a href="javascript:;" rel="index.php?m=other&a=messageBoard&task=detail&id={$d.b_id}" onclick="view_msg_detail(this);">��</a></td>
        </tr>
        {/foreach}
</table>
{if $data.page}
<div>{$data.page}</div>
{/if}
{else}
<div class="notice_msg">{$lang.php_nodata}</div>
{/if}
{include file='frame_footer.php'}
{/if}
{if $action eq 'detail'}
<div style="padding:0px 0px;">
<table class="table_common">
	<tr>
    	<td class="one" width="100">�ύʱ�䣺</td>
        <td>{$data.add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
        <td class="one" width="100">IP��</td>
        <td>{$data.ip}</td>
    </tr>
   
    <tr>{if $data.title}
    	<td class="one" width="100">���⣺</td>
        <td>{$data.title}</td>
        {/if}
        {if $data.other.brand}
        <td class="one" width="100">��ƷƷ�ƣ�</td>
        <td>{$data.other.brand}</td>
		{/if}
    </tr>
   
  
    <tr>
        {if $data.other.type_num}
    	<td class="one" width="100">��Ʒ�ͺţ�</td>
        <td>{$data.other.type_num}</td>
        {/if}
        {if $data.other.buy_num}
        <td class="one" width="100">��Ʒ������</td>
        <td>{$data.other.buy_num}</td>
        {/if}
    </tr>
 
    	<tr>
    	<td class="one" width="100">��ϵ�绰��</td>
        <td>{$data.other.phone}</td>
        {if $data.flag eq '1'}
        <td class="one" width="100">��˾���ƣ�</td>
        <td>{$data.other.cpname}</td>
        {/if}
        {if $data.flag eq '0' || $data.flag eq ''}
        <td class="one" width="100">��ϵ���䣺</td>
        <td>{$data.other.email}</td>
        {/if}
    </tr>
    <tr>
    	<td class="one">����״̬��</td>
        <td><span class="blue">{if $data.status eq '1'}�Ѵ���{else}δ����{/if}</span></td>
        <td class="one">��ϵ��ַ��</td>
        <td>{$data.other.address}</td>
    </tr>
    <tr>
        <td class="one">��ϵ������</td>
        <td>{$data.other.name}</td>
        <td class="one"></td>
        <td></td>
    </tr>
    <tr>
    	<td class="one">�������飺</td>
        <td colspan="4">{$data.content|nl2br}</td>
    </tr>
    <tr>
    	<td class="one">������ע��</td>
        <td colspan="4">
        	<span class="blue"  id="font_beizhu">{$data.replay|nl2br}</span>
        </td>
    </tr>
    <tr>
    	<td>��д������ע��</td>
        <td colspan="4">
<form method="post" action="index.php?m=other&a=messageBoard" id="ajax_post_borad">
<input type="hidden" value="{$data.b_id}"  name="bid"/>
    <textarea style="height:80; width:450px;" id="bak_contents" name="content" class="must_fill_b_info"></textarea>
    <br />
    <input type="submit" value="<% _e('�ύ������ע');%>"  class="form_submit" />
</form>
<script type="text/javascript">
var empty_vals = "<% _e('����д����.');%>";
	$(function(){
		$("#ajax_post_borad").submit(function(){
			if(!check_form_is_empty('must_fill_b_info'))return false;
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'EMPTY':
						window.parent.showNotice('����д������!');
					break;
					case 'OK':
						window.parent.showNotice('�����ɹ�');
						$("#font_beizhu").html($("#bak_contents").val());
						$("#bak_contents").val('');
					break;
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
        </td>
    </tr>
</table>
</div>
{/if}