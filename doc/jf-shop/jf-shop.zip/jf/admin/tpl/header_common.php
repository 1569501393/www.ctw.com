<?php  exit('die');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset={$outPutChar}" />
<!--<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />-->
<title>{$lang.common.site_admin_title}</title>
<link href="style/layout.css" rel="stylesheet" type="text/css"/>
<link href="style/{$__default_skin__}.css" id="call_css_tag_frame" rel="stylesheet" type="text/css" media="screen"/>
{insert_scripts files='js/jquery-1.4.min.js'}
{$editor_js}
{include file="frame_js.php"}
{if $calendar}
<script type="text/javascript" charset="gbk" src="js/jscal2.js"></script>
{/if}
</head>