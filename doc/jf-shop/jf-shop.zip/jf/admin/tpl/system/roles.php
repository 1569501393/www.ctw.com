<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{if $action  eq 'list'}
{include file="frame_header.php"}
<div id="php_top_bar" class="">
	<div class="top_bar_pannel">
    {if $showAddroles}<a href="javascript:;" class="block_button form_btn" onclick="window.location.href='index.php?m=system/roles&a=addRoles'">���ӹ�����</a>{/if} 
    </div>
</div>
<div id="php_right_main_content">
{if $group}
<script type="text/javascript">
	function delete_roles(obj){
		if(confirm('{$lang.roles.delete_confirm}')){/*ȷ��Ҫɾ����Ȩ������?�˲������ɻָ�!*/
			var id = $(obj).attr('rel');
			$.get('index.php?m=system/roles&a=deleteRoles',{id:id},function(data){
				switch(data){
					case 'ERROR':
						return window.parent.showNotice('{$lang.php_die}');
					break;
					case 'HAS_DATA':
						return window.parent.showNotice('�÷����´��ڹ���Ա����ɾ��!');
					break;
					case 'OK':
						$("#group_dom_"+id).remove();
						return window.parent.showNotice('{$lang.php_do_ok}');
					break;
					default:alert(data);
				}
			});
		}
	}
</script>
	<table class="table_list">
    	<tr>
        	<th><% _e('��������');%></th>
			<th><!--ϵͳĬ��-->{$lang.roles.is_system_default}</th>
			<th><!--����-->{$lang.roles.group_opt}</th>
        </tr>
        {foreach from=$group item=list}
        <tr id="group_dom_{$list.group_id}">
        	<td>{$list.group_name}</td>
            <td class="center">{if $list.is_system eq '1'}<font class="blue">{$lang.yes}</font>{else}{$lang.no}{/if}</td>
            <td class="center">{if $showEditRoles}<a href="javascript:;" onclick="window.location.href='index.php?m=system/roles&a=editRoles&id={$list.group_id}'">�༭</a>{/if} {if $list.is_system neq '1'} 
            {if $showDeleteRoles}
            | <a href="javascript:;" onclick="delete_roles(this);" rel="{$list.group_id}">ɾ��</a>{/if} {/if}</td>
        </tr>
        {/foreach}
    </table>
    {else}
    <div class="notice_msg">{$lang.php_nodata}</div>
    {/if}
</div>
{include file="frame_footer.php"}
{/if}<!---end action for list-->
{if $action eq 'edit_roles' || $action eq 'add_roles'}
 {if !$is_ajax}
    {include file="frame_header.php"}
    <div id="php_top_bar"><a  href="javascript:;" onclick="window.location.href='index.php?m=system/roles'" class="block_button"><!--����Ȩ���б�-->{$lang.roles.return_aulist}</a></div>
 	<div id="php_right_main_content">
 {/if}
<script type="text/javascript">
	$(function(){
		$("#role_list_form").submit(function(){
			 if(!check_form_is_empty('form_must_in'))return window.parent.showNotice('{$lang.roles.empty_data}');
			 $(this).ajaxSubmit(function(data){
				switch(data){
					case 'ERROR':
						return window.parent.showNotice('{$lang.roles.crack_die}');
					break;
					case 'EMPTY':
						return window.parent.showNotice('{$lang.roles.empty_data}');
					break;
					case 'HAS_EXIST':
						$("#group_name").val('');
						return window.parent.showNotice('{$lang.roles.has_exist}');
					break;
					case 'OK':
						close_window();
						{if $action eq 'add_roles' && !$is_ajax}
							window.location.href='index.php?m=system/roles';
						{/if}
						$("#right_frame").attr({"src":'index.php?m=system/roles'});
						return window.parent.showNotice(php_do_ok);
					break;
					default:alert(data);
				}
			 });
			 return false;
		});
	});
	function select_first(obj){
		var k= $(obj).attr('for');
		var oo = $(obj).find('input');
		var s = $(oo).attr('checked');
		var j = s?false:true;
		var f = j?false:true;
		$(oo).attr('checked',j);
		$(".role_"+k).attr({"checked":j,"disabled":f});
	}
	function select_n(obj){
		var a = $(obj).attr('checked');
		var b = a?false:true;
		var c = '.'+$(obj).attr("curent");
		$(c).attr({"checked":a,"disabled":b});
	}
</script>
<form method="post"  autocomplete="off" action="{if $action eq 'edit_roles'}index.php?m=system/roles&a=editRoles{else}index.php?m=system/roles&a=addRoles{/if}" id="role_list_form">
<input type="hidden" value="{$group_id}"  name="group_id"/>
<table class="table_common">
 	<tr>
    	<td class="one">{$lang.roles.auth_name}</td>
        <td><input type="text" size="35" style="width:300px;" class="form_input form_must_in" name="group_name"  {if $group_data.is_system=='1'} readonly="readonly"  {/if} value="{$group_data.group_name}" id="group_name" />&nbsp;<span id="msgs1" class="notice" ><font class="blue">*</font></span></td>
    </tr>
    <tr>
    	<td class="one">{$lang.roles.auth_desc}</td>
        <td><textarea name="group_desc"  class="form_textarea" style="width:300px; height:50px;">{$group_data.group_desc}</textarea></td>
    </tr>
 </table>
 <!--����Ȩ������-->
 {if $role_list}
 <table class="table_common table_roles">
   <tr>
     <td><br>
     {foreach from=$role_list item='a' key=key}
     <div class="roles_box">
        <span class="roles_one">
          <label for="{$key}" onclick="select_first(this);">
          <input class="sec_all" onclick="select_first($(this).parent('label'));" type="checkbox" {if $a.checked eq '1'}  checked="checked"{/if} value="{$a.id}"  name="group[]"/> {$a.name}</label>1��
        </span>
        <div class="clear"></div>
        {if $a.childrens}
        {foreach from=$a.childrens item='b'}        
        <div class="child_two_box {if !$b.childrens}s_{/if}">
        <span class="roles_two_one">
         <input onclick="select_n(this);" curent='parent_two_{$b.id}' class="sec_all role_{$key}"{if $b.checked eq '1'} checked="checked" {else} disabled="disabled" {/if} type="checkbox" value="{$b.id}"  name="group[]"/> {$b.name}2��
        </span>
          {if $b.childrens}
          {foreach from=$b.childrens item='c'}
          <div class="child_three_box{if !$c.childrens} s_{/if}">
             <span class="child_three_one">
             <input onclick="select_n(this);"  curent='parent_three_{$c.id}'  class="parent_two_{$b.id} sec_all role_{$key}" {if $c.checked eq '1'} checked="checked" {else} disabled="disabled"{/if} type="checkbox" value="{$c.id}"  name="group[]"/> {$c.name}3��
             </span>
             {if $c.childrens}
             <div class="child_box_four">
                {foreach from=$c.childrens item='d'}
<label><input class="sec_all parent_two_{$b.id} parent_three_{$c.id} role_{$key}" {if $c.checked eq '1' && $d.checked eq '1'} checked="checked" {else} disabled="disabled"{/if} type="checkbox" value="{$d.id}"  name="group[]"/> {$d.name}</label>
                {/foreach}
             </div>
             {/if}
          </div>
          {/foreach}
          {/if}
        </div>
        {/foreach}
        {/if}
     </div>
     {/foreach}
     </td>
   </tr>
   <tr>
     <td align="center"><input type="submit" value="{$lang.php_save}"  class="form_submit form_btn" /></td>
   </tr>
 </table>
{/if}
 <!--Ȩ�޴�������-->
 </form>
 {if !$is_ajax}
 	</div>
    {include file="frame_footer.php"}
 {/if}
{/if}