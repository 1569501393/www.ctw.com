<?php exit('die'); ?>
</div>
{include file="frame_footer.php"}