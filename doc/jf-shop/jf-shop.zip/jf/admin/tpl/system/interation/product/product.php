<?php exit('die'); ?>
{include file="system/interation/header.php"}
{if $action eq 'product_api_list'}
<script type="text/javascript">
	function _c(data){
		var d = data.split('|');
		var e = d[0];
		switch($.trim(e)){
			case '1':
				window.parent.showNotice(d[1]);
				return false;
			break;
			case '2':// success 
				window.parent.showNotice(d[1]);
				window.location.href='index.php?m=system/integration&a=doProduct';
			break;
			default:alert(data);
		}	
	}
</script>
<div id="php_right_main_content"> {if $data}
  <table class="table_list">
    <tr>
      <th>����</th>
       <th>����</th>
      <th>�汾</th>
      <th>����״̬</th>
      <th>����</th>
      <th></th>
    </tr>
    {foreach from=$data item=a}
    <tr>
      <td>{$a.fullname}</td>
      <td align="center">{$a.author}</td>
      <td align="center">{$a.version}</td>
      <td align="center">{if $a.selected eq '1'}<samp class="blue">����</samp>{else}<samp class="red">����</samp>{/if}</td>
      <td>{$a.desc}</td>
      <td align="center"><a href="index.php?m=system/integration&a=doProductApi&app={$a.name}">����</a></td>
    </tr>
    {/foreach}
  </table>
  {else}
  <div class="notice_msg">�޿��ò��!</div>
  {/if} </div>
{/if}

<!--#�б�����-->
{if $action eq 'do_product_api'}
  <div id="php_top_bar" class="php_bot_bar">
   <a href="javascript:;" onclick="window.location.reload();" class="block_button form_btn">ˢ��</a>
   <a href="index.php?m=system/integration&a=productApi" class="block_button form_btn">����</a>
   <a href="javascript:;" onclick="submit_form('do_integration');" class="block_button form_btn">����</a>
   </div>
  <div id="php_right_main_content">
<script type="text/javascript">
	$(function(){
		$("#do_product_api_data").submit(function(){
			if(!check_form_is_empty('must_fill_api'))return false;
			$(this).ajaxSubmit(function(data){
				alert(data);
			});
			return false;
		});
	});
</script>
  <form method="post" action="index.php?m=system/integration&a=doProductApi" id="do_product_api_data">
    <div class="table_item_base">
      <h1 class="c_bar">������Ϣ</h1>
      <div class="c_content">
        <table class="table_common">
            <tr>
            	<td class="one">�ӿ��ܳ�</td>
                <td><input type="text" value="" name="product_api[api_key]"  class="form_input w300 must_fill_api"/> <samp class="red">*</samp></td>
            </tr>
            <tr>
            	<td class="one">������ݸ�ʽ</td>
                <td>
					<select name="product_api[data_type]" class="w300 must_fill_api">
                    	<option value="xml">XML��ʽ</option>
                        <option value="json">JSON��ʽ</option>
                    </select>
                </td>
            </tr>
            <tr>
            	<td class="one">������ݲ���</td>
                <td>
					<label><input type="checkbox" value="" />��Ʒ����</label>
                    <label><input type="checkbox" value="" />��Ʒ����</label>
                    <label><input type="checkbox" value="" />��Ʒ�ۼ�</label>
                    <label><input type="checkbox" value="" />��Ʒ���</label>
                    <label><input type="checkbox" value="" />��Ʒ��ͼ</label>
                    <label><input type="checkbox" value="" />��ƷСͼ</label>
                </td>
            </tr>
            <tr>
            	<td class="one">��������</td>
                <td>
                	<p><label><input type="checkbox" value="1" {if $config.product_api.syn_product_stock eq '1'} checked="checked"{/if}  name="product_api[syn_product_stock]" />ͬ�����</label></p>
                    <p><label><input type="checkbox" value="1" />ͬ����Ʒ</label></p>
                </td>
            </tr>
        </table>
    </div>
    </div>
    </form>
    </div>
{/if}
{include file="system/interation/footer.php"}