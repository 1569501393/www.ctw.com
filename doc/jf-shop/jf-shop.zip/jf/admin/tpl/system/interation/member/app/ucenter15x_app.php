<?php exit('die');?>
<script type="text/javascript">
	$(function(){
		$("#do_integration").submit(function(){
			var v = $("#db_type_link_model").val();
			if(v=='mysql' && !check_form_is_empty('must_fill_pannel_app_db') || !check_form_is_empty('must_fill_pannel_app')){
				window.parent.showNotice('�����������!');
				return false;
			}
		});
		   var o = $(".need_hide_one");
		  $("#db_type_link_model").val()=='mysql'?$(o).show():$(o).hide();
	});
	function show_db_link_type(obj){
		var o = $(".need_hide_one");	
		$(obj).val()!='mysql'?$(o).hide():$(o).show();
	}
</script>
<div class="notice_msg" id="show_init_help" style="display:none;">
	<strong>ע�����</strong><br  />
    1,Ӧ�ýӿ��ļ�����Ϊ uc15.php<br />
    2,Ӧ�õ��� URL:Ϊ���̳Ƿ��ʵ�����,���治Ҫ��/ Ĭ�϶�ȡapiĿ¼<br  />
    3,uc_client�ļ�����uc_client/uc15/Ŀ¼��<br />
    4,�ӿ�����ɾ����Ա�̳ǲ���ͬ��ɾ��<br />
    5,�����ǲ���,����UC 1.5���ϵİ汾,ʹ��mysql�ͻ���ʱ,�����ж�������,��ʱ�޸ĵİ취,��uc_client/model/user.php �ҵ� function check_mergeuser Լ72��
    �޸� $this->base->app['appid'] ΪUC_APPID �޸ĺ�Ľ������.
    �ҵ� $data = $this->db->result_first("SELECT count(*) FROM ".UC_DBTABLEPRE."mergemembers WHERE appid='".UC_APPID."' AND username='$username'");
</div>
<h1 class="c_bar">������Ϣ</h1>
<div class="c_content">
{if !$client_exits}
<div class="notice_msg"><samp class="red">�����ڽӿ��ļ��� uc_client/uc15,���ϴ���Ӧ�Ľӿڳ����!</samp></div>
{/if}

<table class="table_common">
          <tr>
            <td class="one">Ucenter���ʵ�ַ��ַ</td>
            <td><input type="text" class="must_fill_pannel_app w300" value="{$data.config.uc_api}"  name="config[uc_api]" /> <samp class="blue">*</samp> ����http://yousite.com/ucenter_server/</td>
          </tr>
          <tr>
            <td class="one">ͨ��֤�ܳ�</td>
            <td><input type="text" name="config[uc_se_key]" class="must_fill_pannel_app w300" value="{$data.config.uc_se_key}" /> <samp class="blue">*</samp></td>
          </tr>
          <tr>
            <td class="one">Ӧ��ID</td>
            <td><input type="text" value="{$data.config.uc_app_id}" name="config[uc_app_id]" class="must_fill_pannel_app w300" /> <samp class="blue">*</samp></td>
          </tr>
          <tr>
            <td class="one">������IP</td>
            <td><input type="text" value="{$data.config.uc_ip}"  class="w300" name="config[uc_ip]" /></td>
          </tr>
          <tr>
            <td class="one">�ӿ�ϵͳ����</td>
            <td><select name="config[uc_char]"  class="must_fill_pannel_app_db w300"  style="width:310px;">
                <option value="gbk" {if $data.config.uc_char eq 'gbk'} selected="selected"{/if}>GBK</option>
                <option value="utf-8" {if $data.config.uc_char eq 'utf-8'} selected="selected"{/if}>UTF-8</option>
              </select> <samp class="blue">*</samp></td>
          </tr>
          <tr>
            <td class="one">�ӿ����ӷ�ʽ</td>
            <td>
              <select  id="db_type_link_model" class="must_fill_pannel_app w300" name="config[uc_api_type]" style="width:310px;" onchange="show_db_link_type(this);">
              	<option value="mysql" {if $data.config.uc_api_type eq 'mysql'} selected="selected"{/if}>���ݿ�ģʽ</option>
                <option value="sock" {if $data.config.uc_api_type eq 'sock'} selected="selected"{/if}>sock����ģʽ</option>
              </select> <samp class="blue">*</samp>
              </td>
          </tr>
          <tr class="need_hide_one">
            <td class="one">�ӿ����ݿ����</td>
            <td><select name="config[uc_db_char]" class="must_fill_pannel_app_db w300" style="width:310px;">
                <option value="gbk" {if $data.config.uc_db_char eq 'gbk'} selected="selected"{/if}>GBK</option>
                <option value="utf8" {if $data.config.uc_db_char eq 'utf8'} selected="selected"{/if}>UTF-8</option>
              </select> <samp class="blue">*</samp></td>
          </tr>
          <tr class="need_hide_one">
            <td class="one">���ݿ��ַ</td>
            <td><input type="text" value="{$data.config.uc_db_host|default:'localhost'}"   name="config[uc_db_host]"  class="must_fill_pannel_app_db w300" /> <samp class="blue">*</samp> ����localhost ��localhost:3306</td>
          </tr>
          <tr class="need_hide_one">
            <td class="one">���ݿ��û���</td>
            <td><input type="text" value="{$data.config.uc_user_name}"  name="config[uc_user_name]" class="must_fill_pannel_app_db w300"/> <samp class="blue">*</samp> ����root</td>
          </tr>
          <tr class="need_hide_one">
            <td class="one">���ݿ�����</td>
            <td><input type="text" value="{$data.config.uc_db_pass}" name="config[uc_db_pass]" class="must_fill_pannel_app_db w300"/> <samp class="blue">*</samp></td>
          </tr>
          <tr class="need_hide_one">
            <td class="one">���ݿ�����</td>
            <td><input type="text" value="{$data.config.uc_db_name}"  name="config[uc_db_name]"  class="must_fill_pannel_app_db w300"/> <samp class="blue">*</samp>  ����ucenter</td>
          </tr>
          <tr class="need_hide_one">
            <td class="one">���ݿ�ǰ׺</td>
            <td><input type="text" value="{$data.config.uc_db_prefix}" name="config[uc_db_prefix]" class="must_fill_pannel_app_db w300"/> <samp class="blue">*</samp> ����:`project_test_dx2`.pre_ucenter_<!--`project_test_dx2`.--></td>
          </tr>
        </table>
</div>