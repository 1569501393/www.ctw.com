{include file="system/interation/header.php"}
{if $action eq 'member_login_api_list'}
<script type="text/javascript">
	function _c(data){
		var d = data.split('|');
		var e = d[0];
		switch($.trim(e)){
			case '1':
				window.parent.showNotice(d[1]);
				return false;
			break;
			case '2':// success 
				window.parent.showNotice(d[1]);
				window.location.href='index.php?m=system/integration&a=memberLoginApi';
			break;
			default:alert(data);
		}	
	}
	function install_member_api(obj){
		var u = $(obj).attr('rel');
		if($(obj).attr('show')=='true'){
			alert('�����ǹٷ���Ȩ�û�,����ϵ�ͷ���ȡ��ز��!');return false;	
		}
		$(obj).attr({'href':u});
	}
</script>
<div id="php_right_main_content"> 
{if $data}
  <table class="table_list">
    <tr>
      <th>����</th>
      <th>����</th>
      <th>�汾</th>
      <th>����״̬</th>
      <th>����</th>
      <th></th>
    </tr>
    {foreach from=$data item=a}
    <tr>
      <td>{$a.fullname}</td>
      <td align="center">{$a.author}</td>
      <td align="center">{$a.version}</td>
      <td align="center">{if $a.selected eq '1'}<samp class="blue">����</samp>{else}<samp class="red">����</samp>{/if}</td>
      <td>{$a.desc}</td>
      <td align="center"><a  href="javascript:;" rel="index.php?m=system/integration&a=doMemberLoginApi&app={$a.name}" onclick="install_member_api(this);" show="{$a.alert}">��װ</a></td>
    </tr>
    {/foreach}
  </table>
  {else}
  <div class="notice_msg">�޿��ò��!</div>
  {/if} 
  </div>
{/if}

{if $action eq 'do_member_login_api_list'}
<form method="post" action="index.php?m=system/integration&a=doMemberLoginApi" id="doMemberLoginApi_form" autocomplete="off">
<input type="hidden" value="{$data.id}" name="id" />
  <div id="php_top_bar" class="php_bot_bar">
   <a href="javascript:;" onclick="window.location.reload();" class="block_button form_btn">ˢ��</a>
   <a href="index.php?m=system/integration&a=memberLoginApi" class="block_button form_btn">����</a>
   <a href="javascript:;" onclick="submit_form('doMemberLoginApi_form');" class="block_button form_btn">����</a>
   </div>
  <div id="php_right_main_content">
    <div class="table_item_base">
      <h1 class="c_bar">����״̬</h1>
      <div class="c_content">
        <input type="hidden" value="{$app_name}"  name="appname"/>
        <table class="table_common">
          <tr>
            <td class="one">״̬</td>
            <td>
            <select name="enable" style="width:150px;">
                <option value="1" {if $data.enable eq 1} selected="selected"{/if}>����</option>
                <option value="0" {if $data.enable neq 1} selected="selected"{/if}>����</option>
              </select></td>
          </tr>
        </table>
        </div>
    	<div id="call_config_append">
      {include file="$app_file"}
      </div>
</div>
</div>
</form>	
<script type="text/javascript">
	$(function(){
		$("#doMemberLoginApi_form").submit(function(){
			if(!check_form_is_empty('must_fill_in'))return false;
		});
	});
</script>
{/if}

{include file="system/interation/footer.php"}