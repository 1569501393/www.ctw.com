<?php exit('die'); ?>
{include file="frame_header.php"}
<div id="php_right_main_content">
<div class="table_scroll">
<ul class="menu">
   {if $show_member}<li {if $curent_app eq 'member_api'} class="wintable_curent"{/if}><a href="index.php?m=system/integration&a=memberApi">��Ա�ӿ�</a></li>{/if}
   {if $show_member_login} <li {if $curent_app eq 'member_login_api'} class="wintable_curent"{/if}><a href="index.php?m=system/integration&a=memberLoginApi">��½�ӿ�</a></li>{/if}
   <!--
   {if $show_product} <li {if $curent_app eq 'product_api'} class="wintable_curent"{/if}><a href="index.php?m=system/integration&a=productApi">��Ʒ�ӿ�</a></li>{/if}
   {if $show_member} <li {if $curent_app eq 'order_api'} class="wintable_curent"{/if}><a href="index.php?m=system/integration&a=orderApi">�����ӿ�</a></li>{/if}
   -->
</ul>
</div>