<?php exit('die'); ?>
{include file="system/interation/header.php"}
{if $action eq 'order_api_list'}
<script type="text/javascript">
	function _c(data){
		var d = data.split('|');
		var e = d[0];
		switch($.trim(e)){
			case '1':
				window.parent.showNotice(d[1]);
				return false;
			break;
			case '2':// success 
				window.parent.showNotice(d[1]);
				window.location.href='index.php?m=system/integration&a=doOrderApi';
			break;
			default:alert(data);
		}	
	}
</script>
<div id="php_right_main_content"> {if $data}
  <table class="table_list">
    <tr>
      <th>����</th>
      <th>����</th>
      <th>�汾</th>
      <th>����״̬</th>
      <th>����</th>
      <th></th>
    </tr>
    {foreach from=$data item=a}
    <tr>
      <td>{$a.fullname}</td>
      <td align="center">{$a.author}</td>
      <td align="center">{$a.version}</td>
      <td align="center">{if $a.selected eq '1'}<samp class="blue">����</samp>{else}<samp class="red">����</samp>{/if}</td>
      <td>{$a.desc}</td>
      <td align="center"><a href="index.php?m=system/integration&a=doOrderApi&app={$a.name}">����</a></td>
    </tr>
    {/foreach}
  </table>
  {else}
  <div class="notice_msg">�޿��ò��!</div>
  {/if} </div>
{/if}

{if $action eq 'do_order_api'}
<script type="text/javascript">
	$(function(){
		close_open_helper('core_helper_dom','show_init_help');
	});
</script>
do_order_api
{/if}
{include file="system/interation/footer.php"}