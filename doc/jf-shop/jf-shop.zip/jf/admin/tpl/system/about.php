<?php if(!defined('PHP_TEMPLATE'))exit('188'); ?>
{if $action eq 'server'}
{$server_info}
{/if}
{if $action eq 'othersoft'}
    <div class="lic_other">
    <table class="table_list">
    	<thead>
        	<tr>
        	<th>{$lang.a.other_name}</th>
            <th>{$lang.a.other_license}</th>
            <th>{$lang.a.other_link}</th>
            </tr>
        </thead>
        <tbody>
                 <tr>
                <td align="center">open-flash-chart</td>
                <td align="center">GNU</td>
                <td align="center"><a href="http://www.gnu.org/" target="_blank">{$lang.a.other_enter}</a>
                  <a href="http://teethgrinder.co.uk/open-flash-chart/index.php" target="_blank"><!--����-->{$lang.a.guan_site}</a>
                  </td>
            </tr>
                <tr>
                <td align="center">Phpmail</td>
                <td align="center">GNU</td>
                <td align="center"><a href="http://www.gnu.org/"  target="_blank">{$lang.a.other_enter}</a>
                <a href="http://phpmailer.codeworxtech.com/" target="_blank"><!--����-->{$lang.a.guan_site}</a>
                </td>
            </tr>
                <tr>
                <td align="center">jQuery</td>
                <td align="center">MIT AND GPL</td>
                <td align="center"><a href="http://docs.jquery.com/License" target="_blank">{$lang.a.other_enter}</a>
                <a href="http://www.jquery.com" target="_blank"><!--����-->{$lang.a.guan_site}</a>
                </td>
            </tr>
              <tr>
                <td align="center">jquery.colorbox</td>
                <td align="center">MIT </td>
                <td align="center"><a href="http://www.opensource.org/licenses/mit-license.php" target="_blank">{$lang.a.other_enter}</a>
                <a href="http://www.colorpowered.com" target="_blank"><!--����-->{$lang.a.guan_site}</a>
                </td>
            </tr>
              <tr>
                <td align="center">jquery.editable</td>
                <td align="center">MIT </td>
                <td align="center"><a href="http://valums.com/mit-license/" target="_blank">{$lang.a.other_enter}</a>
                
                 <a href="http://valums.com" target="_blank"><!--����-->{$lang.a.guan_site}</a>
                 </td>
            </tr>
                <tr>
                <td align="center">jquery.form</td>
                <td align="center">GPL</td>
                <td align="center"><a href="http://www.gnu.org/licenses/gpl.html" target="_blank">{$lang.a.other_enter}</a>
                <a href="http://malsup.com/jquery/form/" target="_blank"><!--����-->{$lang.a.guan_site}</a>
                </td>
            </tr>
               <tr>
                <td align="center">kindeditor</td>
                <td align="center">GBU</td>
                <td align="center"><a href="http://www.kindsoft.net/lgpl_license.html" target="_blank">{$lang.a.other_enter}</a>
                <a href="http://www.kindsoft.net/" target="_blank"><!--����-->{$lang.a.guan_site}</a>
                </td>
            </tr>
           
        </tbody>
    </table>
</div>
{/if}
{if $action eq 'default'}
{if !$is_ajax}{include file="frame_header.php"}{/if}
<div class="php_table_window" style=" position:relative;">
	<div class="table_scroll" id="find_menus">
        <ul class="menu">
            <li class="wintable_curent" id="visted_default">{$lang.a.about}</li>
            <li rel="index.php?m=system/about&a=server" name="server">{$lang.a.server_info}</li>
             <li rel="index.php?m=system/about&a=othersoft" name="other"><% _e('����������');%></li>
            <li style="float:right; margin-right:10px; border:none; cursor: default;" id="aaaa">{$lang.a.current_version}��<a href="changelog.txt" target="_blank">{$php_version}</a></li>
 	   </ul>
       <div class="clear" />
    </div>
    <div class="php_table_content" id="append_contents" style="padding:0px; margin:0px; border-top:none;"></div>
<div id="__temp__" style="display:none;">{$about_info}</div>
<div class="clear"></div>
</div>
<script type="text/javascript">
$(function(){
	$("#append_contents").html($("#__temp__").html());
	$("#find_menus li").click(function(){
		var jd = $(this).attr('id');
		if(jd=='aaaa' )return ;
		var name = $(this).attr('name');
		$(".wintable_curent").removeClass('wintable_curent');
		$(this).addClass('wintable_curent');
		if(jd =='visted_default'){
			$("#append_contents").html($("#__temp__").html());	
			return ;
		}
		var uri = $(this).attr('rel');
		$.ajax({
			 beforeSend:function(){
			$("#append_contents").html('<p class="loading"><img src="images/windows_loading.gif" /></p>');
		},type:'GET',url:uri,success:function(data){
			$("#append_contents").empty().html(data);
		}});
	});
});
</script>
{if !$is_ajax}{include file="frame_footer.php"}{/if}
{/if}   