<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{if $action eq 'region_list'}<!--�б�������-->
{include file="frame_header.php"}
<div id="php_top_bar">
<div class="top_bar_pannel">
    <a href="javascript:;" title="{$lang.deliver.add_top_area}" onclick="add_region(this);" rel="index.php?m=system/deliveryregion&a=do&task=add" class="block_button  form_btn">{$lang.deliver.add_top_area}</a>
    <a href="javascript:;" onclick="butch_region_goods('changguan');" class="block_button form_btn">ͳ�Ƶ�����Ʒ����</a>
    <a href="javascript:;" onclick="butch_region_goods('chandi');" class="block_button form_btn">ͳ�Ʋ�����Ʒ����</a>
</div>
<script type="text/javascript">
	function butch_region_goods(tags){
		$.get('index.php?m=system/deliveryregion&a=butchgoods',{tag:tags},function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
				break;
				default:alert(data);
			}
		});	
	}
</script>
</div>
<div class="clear"></div>
<div id="php_right_main_content">
{if $region_data}
<script type="text/javascript">
var do_yes = "��";
var do_no = "��";
var have = "��";
var no = "��";
/*�ص�����*/
	function append_parent_region(id){/*���Ӹ���*/
		$.get('index.php?m=system/deliveryregion&a=do&task=call',{id:id},function(data){
			$("#regionsdata").find('tbody').append(data);data =id  = null;
		});
	}
	function append_region(data){
		/*���鷳 ��ʱ������*/
		/*$.get('index.php?m=system/deliveryregion&a=do&task=call',{id:data[1],parent_id:data[2],level:data[4]},function(d){
			$("#region_son_"+data[2]).after(d); data=d=null;
		});*/
	}
	function eidt_region_append(data){/*�༭*/
		var id = data[1];
		$("#r_name_"+id).html(data[4]);
		$("#r_sort_"+id).html(data[5]);
		$("#r_aliasename_"+id).html(data[10]);
		var tpl = $("#r_tpl_"+id);
		if(data[6]=='true'){
			$(tpl).html('<span class="green">��</font>');
		}else{
			$(tpl).html('<span class="red">��</font');	
		}
		$("#r_alias_"+id).html(data[7]);
		$("#r_sign_"+id).html(data[8]);/*��־λ*/
		var t = $("#r_thumb_"+id);
		if(data[9]=='true'){
			$(tpl).html('<span class="green">��</font>');
		}else{
			$(tpl).html('<span class="red">��</font');
		}
		tpl=id=data = null;
	}
/*�ص�����*/
	function _set_opened(obj){$(obj).attr({"src":'images/sitemapopened.gif','hide':'0'});}
	function _set_closeed(obj){$(obj).attr({"src":'images/sitemapclosed.gif','hide':'1'});}
	/*�ݹ�ģʽ*/
	function _do_region(obj,do_action){			
		var son = $(obj).attr('son').split(',');
		if(son){
			$(son).each(function(i){
				var d = $("#region_son_"+son[i]);
				switch(do_action){
					case 'show':$(d).show();if($(d).attr('son')){_do_region(d,do_action);}break;
					case 'hide':$(d).hide();if($(d).attr('son')){_do_region(d,do_action);}break;
				}
			});
		}
	}
	function clickTree(obj){
		switch($(obj).attr('hide')){
			case '0':_do_region(obj,'hide');_set_closeed(obj);return ;break;/*��ģʽ��Ҫ����*/
			case '1':_do_region(obj,'show');_set_opened(obj);return ;break;/*����ģʽģʽ��Ҫ��*/
			default:
			$.get('index.php?m=system/deliveryregion&a=getSon&id='+$(obj).attr('id')+'&level='+$(obj).attr('level'),function(data){
				_set_opened(obj);data = data.split('||||||||||');
				$(obj).attr({'son':data[0]}).parents('tr').attr({"son":data[0]}).after(data[1]);
			});	
		}
	}
	//var edit_obj = add_obj = null;
	var delete_confirm = "ȷ��Ҫɾ����?�˲������ɻָ�!";
	var has_son = "�����ӵ���,����ɾ���ӵ���!";
	function _do_re(obj){ window.parent.showWindow($(obj).attr('title'),obj.rel,970,500); }
	function edit_region(obj){return _do_re(obj);}
	function add_region(obj){return _do_re(obj);}
	function deleterigiona(obj){
		if(!confirm(delete_confirm))return false;
		var id = $(obj).attr('cid');
		$.get('index.php?m=system/deliveryregion&a=do',{id:id,task:'delete'},function(data){
			switch(data){
				case 'OK':
					$("#region_son_"+id).remove();
					window.parent.showNotice(php_do_ok);
				break;
				case 'HAS_EXIST':
					return window.parent.showNotice(has_son);
				break;
				default:alert(data);
			}
		});
	}
</script>
    	<table cellpadding="0" cellspacing="0" id="regionsdata" class="table_list">
            	<th>{$lang.deliver.area_name}</th>
                <th>�ֹ�</th>
                <th>����</th>
                <th>��־</th>
                <th>����</th>
                <th>ģ��</th>
                <th>ͼ</th>
                <th>����</th>
                
         {foreach from=$region_data item=region}
            <tr id="region_son_{$region.region_id}">
            	<td  class="b region_title" style="width:230px; text-indent:10px;overflow:hidden;">
<img src="images/sitemapclosed.gif" style="cursor:pointer;" son='' level='0' id="{$region.region_id}" onclick="clickTree(this);" />&nbsp;<span id="r_name_{$region.region_id}" class='b'>{$region.region_name}</span></td>
                <td id="r_alias_{$region.region_id}" align="center">{$region.alias_name}</td>
				<td id="r_aliasename_{$region.region_id}" align="center">{$region.region_ename}</td>
                <td align="center" id="r_sign_{$region.region_id}">{$region.sign}</td>
                <td class="center" id="r_sort_{$region.region_id}">{$region.sort}</td>
                <td class="center" id="r_tpl_{$region.region_id}">{if $region.template_file}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
                <td align="center" id="r_thumb_{$region.region_id}">{if $region.thumb}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
                <!-- ���� -->
<td class="center">
<a href="javascript:;" onclick="add_region(this);"  rel="index.php?m=system/deliveryregion&a=do&task=add&id={$region.region_id}&name={$region.region_name}&level=0" cid="{$region.region_id}"  title="�����ӵ���">��</a>&nbsp;
<a href="javascript:;" onclick="edit_region(this);" cid="{$region.region_id}" title="�޸ĵ���" rel="index.php?m=system/deliveryregion&a=do&task=edit&id={$region.region_id}">��</a>&nbsp;
<a href="javascript:;" cid="{$region.region_id}" title="{$lang.php_delete}" onclick="return deleterigiona(this)">ɾ</a></td>
            </tr>
            {/foreach}
        </table>
{else}
<div class="notice_msg">{$lang.php_nodata}</div>
{/if}
</div>
{include file="frame_footer.php"}
{/if}<!--#end region_list �б����� ����-->
<!--AJAX �ص�����-->
{if $action eq 'get_region_son' || $action eq 'callparent'}
    {if $region_data}
             {foreach from=$region_data item=region}
                <tr onmouseover="this.bgColor='#F2F9FD'" onmouseout="this.bgColor='#FFFFFF'" id="region_son_{$region.region_id}">
                    <td  class="b region_title" style="{if $level eq '0'}width:230px; text-indent:10px;overflow:hidden;{else}border-top:none;  padding-left:{$level * 30}px;{/if}" >
    <img src="images/sitemapclosed.gif" id="{$region.region_id}" son=''  level='{$level}' onclick="clickTree(this);" style="cursor:pointer;"/>&nbsp;<span id="r_name_{$region.region_id}" class='b'>{$region.region_name}</span></td>
                <td id="r_alias_{$region.region_id}" align="center">{$region.alias_name}</td>
				<td id="r_aliasename_{$region.region_id}" align="center">{$region.region_ename}</td>
                <td align="center" id="r_sign_{$region.region_id}">{$region.sign}</td>
                         <td class="center"  id="r_sort_{$region.region_id}">{$region.sort}</td>
                <td class="center" id="r_tpl_{$region.region_id}">{if $region.template_file}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
                <td align="center" id="r_thumb_{$region.region_id}">{if $region.thumb}<span class="green">��</span>{else}<span class="red">��</span>{/if}</td>
                    <td class="center" style=" border-top:none;">
<a href="javascript:;" onclick="add_region(this);"  rel="index.php?m=system/deliveryregion&a=do&task=add&id={$region.region_id}&name={$region.region_name}&level=0" cid="{$region.region_id}"  title="�����ӵ���">��</a>&nbsp;
<a href="javascript:;" onclick="edit_region(this);" cid="{$region.region_id}" title="�޸ĵ���" rel="index.php?m=system/deliveryregion&a=do&task=edit&id={$region.region_id}">��</a>&nbsp;
<a href="javascript:;" cid="{$region.region_id}" title="{$lang.php_delete}" onclick="return deleterigiona(this)">ɾ</a></td>
                </tr>
                {/foreach}
    {/if}
{/if}<!--�ص�����-->
<!--for action add or edit-->
{if $action eq 'add' || $action eq 'edit'}
<script type="text/javascript">
	$(function(){
		var empty_vals = "����д������!";
		var has_exist_data = "������ͬ�ĵ���,����!";
		var add_ok_and_do_then = "���ӳɹ�,�������Լ�������!";
		var has_exist_sign = "������ͬ�ı�־λ";
		$("#do_region_options").submit(function(){
			if(!check_form_is_empty('must_fill_in_re')){
				window.parent.showNotice('����д������!');
				return false;	
			}
			$(this).ajaxSubmit(function(data){
				data = $.trim(data);
				data = data.split('|||');
				 switch(data[0]){
					case 'HAS_EXIST_SIGN':
						window.parent.showNotice(has_exist_sign);return false;
					break;
					case 'OK':
						switch(data[3]){
							case 'add':
								if(data[2]==0){
									window.frames["rightFrame"].append_parent_region(data[1]);
								}else{
									window.frames["rightFrame"].append_region(data);	
								}
								$("#do_region_options").find("input[type=text]").val('');
								return window.parent.showNotice(add_ok_and_do_then);
							break;
							case 'edit':
								window.frames["rightFrame"].eidt_region_append(data);	
								close_window();
							break;
						}
						window.parent.showNotice(php_do_ok);
						//close_window();
					break;
					case 'HAS_EXITS':
						$("#region_name_id").val('');
						return window.parent.showNotice(has_exist_data)						
					break;
					case 'EMPTY':
						return window.parent.showNotice(empty_vals)
					break;
					default:alert(data);
				 }
			});
			return false;
		});
		$("#region_picture").upload({
				file_size_limit:1024*2,/*2M*/
				filename:'thumb',
				post_params:{'sid':session_id},
				url:'index.php?m=system/deliveryregion&a=upload',
				sucess:function(file,res){
					res = $.trim(res);
					res = res.split('|');
					switch(res[0]){
						case 'ERROR':
							window.parent.showNotice(data[1]);
						break;
						case 'OK':
							var str = '<img src="../picture.php?s='+res[1]+'&w=755&h=230" />';
							$("#call_imgs").html(str);$("#thumbs_files").val(res[1]);
							
						break;
						default:alert(res);
					}
				}
		});
	});
	function delete_pic(obj){
		if(!confirm(ok_delete))return false;
		$.get('index.php?m=system/deliveryregion&a=deletepic&id='+$(obj).attr('rid'),function(data){
			 switch(data){
			 	case 'OK':
					window.parent.showNotice(php_do_ok);
					$("#call_imgs").empty();$("#thumbs_files").val('');
				break;
				default:alert(data);
			 }
		});
	}
$.table_bars($("#show_menus li"));
</script>
<form method="post" action="index.php?m=system/deliveryregion&a=do" id="do_region_options" autocomplete='off'>
<div id="do_region_pannel_tag" class="table_scroll">
    <div class="menu" id="show_menus">
        <ul>
            <li name="cfg_all">ȫ��</li>   
            <li name="cfg_base" class="wintable_curent">������Ϣ</li>           
            <li name="cfg_pics">����ͼ</li>
            <li name="cfg_htmls">HTML����</li>
            <li name="cfg_seo">SEO����</li>
        </ul>
    </div>
</div>
<div class="table_item_base">
<div class="table_item" id="cfg_base">
	<h1 class="c_bar">������Ϣ</h1>
    <div class="c_content">
	<table class="table_common">
    	{if $parent_name}
        	<tr>
            	<td class="one">�ϼ�</td>
                <td>{$parent_name}</td>
            </tr>
        {/if}
        <tr>
        	<td class="one">����</td>
            <td><input type="text" value="{$data.region_name}" id="region_name_id" class="must_fill_in_re w350" name="region_name"/> <font class="blue"> * </font></td>
        </tr>
        <tr>
        	<td class="one">����</td>
            <td><input type="text" value="{$data.region_ename}" name="region_ename" class="w350"  maxlength="100"/>
           <span class="blue"> ������ʹ��,һ��Ϊ��������</span>
            </td>
        </tr>
        <tr>
        	<td class="one">�ֹ�����</td>
            <td><input type="text" value="{$data.alias_name}" id="region_alias_call_val" name="alias_name" class="w350" /></td>
        </tr>
        <tr>
        	<td class="one">�ֹݱ�־λ</td>
            <td><input type="text" value="{$data.sign}" name="sign" class="w350"  /><input type="button" onclick="window.parent.get_pinyin($('#region_alias_call_val').val(),$(this).prev());" class="form_submit" value="��ȡ�ֹ�ƴ��" />
            </td>
        </tr>
        <tr>
        <td class="one">����</td>
        <td><input type="text" value="{$data.sort|default:0}" name="sort" class="w350" /></td>
        </tr>
        <tr>
        <td class="one">��ʾģʽ</td>
        <td>
        	<select  name="display_model" class="w350">
            	<option value="goods_list" {if $data.display_model eq 'goods_list'} selected="selected"{/if}>����Ʒ�б�ģʽ(Ĭ��)</option>
            	<option value="goods_pannel" {if $data.display_model eq 'goods_pannel'} selected="selected"{/if}>��ר��ʹ��(�޷�ҳ)</option>
            </select>
        </td>
        </tr>
        <tr>
        <td class="one">�������</td>
        <td>
			<input type="checkbox" value="1" name="special_region" {if $data.special_region eq '1'} checked="checked"{/if} />
            <span class="blue">����ֱϽ��,�۰�̨</span>
        </td>
        </tr>
        <tr>
        	<td class="one">�Զ���ģ��</td>
            <td><input type="text" class="w350" name="template_file" value="{$data.template_file}" /></td>
        </tr>
        <tr>
        	<td class="one">�Ƿ�ͨ</td>
            <td>
            <select name="html_extend[is_open_site]" class="w350">
            	<option value="1" {if $html_extend.is_open_site neq '0'} selected="selected"{/if}>��ͨ</option>
                <option value="0" {if $html_extend.is_open_site eq '0'} selected="selected"{/if}>����ͨ</option>
            </select></td>
        </tr>
    </table>
   	  </div>
</div>
    <div class="table_item" id="cfg_pics">
	<h1 class="c_bar">����ͼ</h1>
	    <div class="c_content">
    <table class="table_common">
        <tr>
        <td class="one">�ϴ�����ͼ</td>
        <td><div class="tb"><span id="region_picture"></span></div>  {if $action eq 'edit' && $data.thumb}
        <div class="tb">
            <input type="button" value="ɾ��ͼƬ"  onclick="delete_pic(this);"  rid="{$data.region_id}"  class="form_submit form_btn"/></div>
            {/if}</td>
    </tr>
    <tr>
        <td colspan="3" id="call_imgs" align="center" class="no_border">
            {if $data.thumb}
                <img src="../picture.php?s={$data.thumb}&w=755&h=230" />
            {/if}
        </td>
    </tr>
    </table>
   	  </div>
    </div>
    <div class="table_item" id="cfg_htmls">
    	<h1 class="c_bar">HTML����</h1>
		    <div class="c_content">
                <table class="table_common">
                    <tr>
                      <td class="no_border">{include file="widget/set_html.php"}</td>
                    </tr>
                </table>
        	</div>
    </div>
    <div class="table_item" id="cfg_seo">
	<h1 class="c_bar">SEO����</h1>
   		 <div class="c_content">
        <table class="table_common">
           <tr>
                <td class="one">����</td>
                <td><textarea  value=""  class="seo_set" name="seo[title]">{$data.seo.title}</textarea></td>
          </tr>
            <tr>
                <td class="one">meta->title</td>
                <td><textarea   class="seo_set" name="seo[meta_title]">{$data.seo.meta_title}</textarea></td>
            </tr>
            <tr>
                <td class="one">ҳ��ؼ���</td>
                <td><textarea name="seo[keywords]"  class="seo_set">{$data.seo.keywords}</textarea></td>
            </tr>
            <tr>
                <td class="one">ҳ������</td>
                <td><textarea name="seo[description]" class="seo_set">{$data.seo.description}</textarea></td>
            </tr>
        </table>
   	  </div>
    </div>
<div class="clear"></div>
<table class="table_common">
	<tr>
    	<td class="one"></td>
        <td class="white" style="background-color:#FFF;"><input type="submit" value="����" class="form_submit" style="display:none;" />
<a href="javascript:;" onclick="submit_form('do_region_options');" class="block_button form_btn">�� ��</a></td>
    </tr>
</table>
</div><!--#end table_item_base-->
<input type="hidden" value="{$action}"  name="do_action"/>
<input type="hidden" value="{$data.id}" id="curent_do_id" />
<input type="hidden" value="{$data.region_name}"  name="old_name" />
<input type="hidden" value="{$data.thumb}" name="thumb" id="thumbs_files" />
</form>
{/if}
