<?php exit('die'); ?>
{if !$is_ajax}{include file="frame_header.php"}{/if}
{if $action eq 'templ_list'}
	{include file="system/messenger/messenger_tpl_list.php"}
{/if}
{if $action eq 'aedittemplate'}
	{include file="system/messenger/do_messenger.php"}
{/if}

{if $action eq 'mail_config' || $action eq 'test_mail_config'}
	{include file="system/messenger/config.php"}
{/if}
{if $action eq 'smsset' || $action eq 'testSendMobile'}
	{include file="system/messenger/smsset.php"}
{/if}
{if $action eq 'toadminconfig'}
	{include file="system/messenger/toadminconfig.php"}
{/if}
{if $action eq 'mailqueue' || $action eq 'ajax_call_send_detail'}
	{include file="system/messenger/mailqueue.php"}
{/if}
{if !$is_ajax}{include file="frame_footer.php"}{/if}