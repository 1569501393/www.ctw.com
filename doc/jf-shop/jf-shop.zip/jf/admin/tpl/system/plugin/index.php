{include file="frame_header.php"}
<!--#plugin_list-->
{if $action eq 'plugin_list'}
<div id="php_right_main_content"> {if $data}
  <script type="text/javascript">
	function _do_plugin(obj,tag,name){
		if($(obj).attr('rel')=='true'){
			alert('�����ǹٷ���Ȩ�û�,����ϵ�ͷ���ȡ��ز��!');
			return false;
		}
		if(tag=='pluginuninstall' && !confirm('ȷ��ж����,�˲������ɻָ�!'))return false;
		$.get('index.php',{m:'system/plugin',a:tag,name:name},function(data){
			switch(data){
				case 'HAS_EXIST':
					window.parent.showNotice('�Ѵ�����ͬ�Ĳ�����ܰ�װ!');
				break;
				case 'CONFIG_NOT_EXIST':
					window.parent.showNotice('ȱ�ٲ�������ļ�!');
				break;
				case 'NOT_EXIST_THIS_PLUGIN':
					window.parent.showNotice('�����ڴ˲��!');
				break;
				case 'EMPTY':
					window.parent.showNotice('��������!');
				break;
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					if(tag=='plugininstall' && confirm('�Ƿ�����?')){
						return window.location.href='index.php?m=system/plugin&a=pluginconfig&name='+name;		
					}
					window.location.reload();
				break;
				default:alert(data);
			}
		});
	}
</script>
  <table class="table_list">
    <tr>
      <th>���</th>
      <th>����</th>
      <th>״̬</th>
      <th>�汾</th>
      <th>����</th>
      <th>����</th>
      <th>����</th>
    </tr>
    {foreach from=$data item='list' key=key}
    <tr>
      <td align="center">{$key+1}</td>
      <td align="center">{$list.fullname}</td>
      <td align="center">{if $list.status eq '1'}<samp class="blue">����</samp>{else}<samp class="red">����</samp>{/if}</td>
      <td align="center">{$list.version}</td>
      <td align="center">{$list.author}</td>
      <td>{$list.desc}</td>
      <td align="center">{if $list.installed eq '1'}
      {if $can_uninstall}<a href="javascript:;" rel="{$list.alert}" onclick="_do_plugin(this,'pluginuninstall','{$list.name}');">ж��</a>{/if}{if $can_config} <a href="index.php?m=system/plugin&a=pluginconfig&name={$list.name}">����</a> {/if}{else}{if $can_install}<a href="javascript:;" onclick="_do_plugin(this,'plugininstall','{$list.name}');" rel="{$list.alert}">��װ</a> {/if}{/if} </td>
    </tr>
    {/foreach}
  </table>
  {else}
  <div class="notice_msg">�޿��ò��!</div>
  {/if} </div>
{/if}
<!--#end plugin_list-->
{if $action eq 'config_plugin'}
<form method="post" action="index.php?m=system/plugin&a=pluginconfig" id="config_plugin" autocomplete="off">
  <input type="hidden" value="{$plugin_name}"  name="name"/>
  <div id="php_top_bar" class="php_bot_bar"> <a href="javascript:;" onclick="window.location.reload();" class="block_button form_btn">ˢ��</a> <a href="index.php?m=system/plugin&a=pluginList" class="block_button form_btn">����</a> <a href="javascript:;" onclick="submit_form('config_plugin');" class="block_button form_btn">����</a> </div>
  <div id="php_right_main_content">
    <div class="table_item_base">
      <h1 class="c_bar">����״̬</h1>
      <div class="c_content">
        <table class="table_common">
          <tr>
            <td class="one">״̬</td>
            <td><select class="w300" name="status">
                <option value="0" {if $data.status neq '1'} selected="selected" {/if}>����</option>
                <option value="1" {if $data.status eq '1'} selected="selected" {/if}>����</option>
              </select></td>
          </tr>
        </table>
      </div>
      <h1 class="c_bar">�������</h1>
      <div class="c_content"> {include file=$plugin_file}
        <div class="clear"></div>
      </div>
    </div>
  </div>
</form>
<script type="text/javascript">
	$(function(){
		$("#config_plugin").submit(function(){
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'EMPTY':
					window.parent.showNotice('�����������!');
					break;
					case 'OK':
						window.parent.showNotice('�����ɹ�!');
					break;
					default:alert(data);	
				}
			});
			return false;
		});
	});
</script>
{/if}
{include file="frame_footer.php"}