<?php exit('die'); ?>
<form method="post" action="index.php?m=system/plugin&a=test&name=express_inquiry" id="do_post_action" autocomplete="off">
<table class="table_common">
	<tr>
    	<td class="one">��ݹ�˾����</td>
        <td><input type="text" value="{$cpno}" class="muct_fill_call" name="cpno"/> <a href="{$xmldata.desc_full_link}" target="_blank" class="red b">֧�ֵĿ�ݹ�˾</a></td>
    </tr>
	<tr>
    	<td class="one">Ҫ��ѯ�Ŀ�ݵ���</td>
        <td><input type="text" value="{$no}" class="muct_fill_call" name="no"/></td>
    </tr>
    <tr>
    	<td class="one"></td>
        <td><input type="submit" value="" style="display:none;" /><a href="javascript:;" onclick="submit_form('do_post_action');" class="block_button form_btn">�� ѯ</a></td>
    </tr>
</table>
<div class="clear"></div>
<div class="notice_msg" id="call_back_test" style="display:none;"></div>
</form>
<script type="text/javascript">
	$(function(){
		$("#do_post_action").submit(function(){
			if(!check_form_is_empty('muct_fill_call')){
				window.parent.showNotice('����д������!');
				return false;	
			}
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'EMPTY':
						window.parent.shwoNotice('����д������!');
					break;
					case 'NOT_INSTALL_THIS_PLUGIN':
						window.parent.shwoNotice('δ��װ�˲��!');
					break;
					default:
					 	$("#call_back_test").show().html(data);			
				}
			});
			return false;
		});
		{if $autodo}
			submit_form('do_post_action');
		{/if}
	});
</script>