<?php exit('die'); ?>
<div class="notice_msg">
������http://www.kuaidi100.com/openapi/  <a href="{$xmldata.desc_full_link}" target="_blank" class="red b">֧�ֵĿ�ݹ�˾</a>
</div>
<table class="table_common">
	<tr>
    	<td class="one">��Ȩ�ܳ�</td>
        <td>
        <div class="tb"><input  class="w300" type="text" value="{$data.config.key}" name="config[key]" /> </div>
        <div class="tb"><a href="javascript:;" onclick="window.parent.showWindow('����','index.php?m=system/plugin&a=test&name={$plugin_name}',750,300);" class="block_button form_btn">����</a></div>
        </td>
    </tr>
</table>