<?php exit('region_locate'); ?>
{if $action eq 'list'}
{include file="frame_header.php"}
<script type="text/javascript">
	function do_delte(id){
		if(!confirm("ȷ��Ҫɾ����?�˲������ɻָ�!"))return false;
		$.get('index.php?m=system/deliveryregion&a=regionLocale&task=delete&id='+id,function(data){
			switch($.trim(data)){
				case 'OK':
					$('.re_tag_'+id).remove();
					if(!$(".all_locate").length)window.location.reload();
				break;
				default:alert(data);
			}
		});
	}
</script>
<div id="php_top_bar">
    <div class="top_bar_pannel">
    <a class="block_button form_btn" onclick="window.parent.showWindow($(this).html(),'index.php?m=system/deliveryregion&a=regionLocale&task=add',750,400);">��������</a></div>
</div>
<div id="php_right_main_content">
{if $data}
<table class="table_list">
	<tr>
        <th>����</th>
        <th>����</th>
        <th>��������</th>
        <th>����</th>
    </tr>
{foreach from=$data item='list' key=key}
<tr class="re_tag_{$list.id} all_locate" >
    <td width="40" align="center"><a href="javascript:;" title="�༭" onclick="window.parent.showWindow($(this).attr('title'),'index.php?m=system/deliveryregion&a=regionLocale&task=edit&id={$list.id}',800,400)">��</a> <a href="javascript:;" onclick="do_delte('{$list.id}');">ɾ</a></td>
    <td>{$list.region_main_name}</td>
    <td>{$list.son_area}</td>
    <td align="center">{$list.sort}</td>
</tr>
{/foreach}
</table>
{else}
<div class="notice_msg">�޿�������!</div>
{/if}
</div>
{include file="frame_footer.php"}
{/if}
{if $action eq 'add' || $action eq 'edit'}
{if !$is_ajax}{include file="frame_header.php"}{/if}
<script type="text/javascript">
$(function(){
	var empty_vals = "�����ϱ�����!";
	var has_exist_this_item = "������ͬ������!";
	$("#location_form").submit(function(){
		if(!check_form_is_empty('must_fill_in_loc')){
			window.parent.showNotice(empty_vals);
			return false;	
		}
		$(this).ajaxSubmit(function(data){
			switch($.trim(data)){
				case 'OK':
					window.parent.showNotice(php_do_ok);
					close_window();
					window.parent['rightFrame'].location.reload();
					return ;
				break;
				case 'HAS_EXIST':
					window.parent.showNotice(has_exist_this_item);
				break;
				case 'EMPTY':
				 return window.parent.showNotice(empty_vals);
				break;
				default:alert(data);
			}
		});
		return false;
	});
});
</script>
<div class="notice_msg" style="display:none;">
	��ɫ������ʹ��,��ɫ����δʹ��,��ɫ������ǰ!
</div>
<form method="post" action="index.php?m=system/deliveryregion&a=regionLocale" autocomplete="off" id="location_form">
<input type="hidden" value="{$action}" name="action" />
<div class="table_item_base">
	<h1 class="c_bar">������</h1>
	<div class="c_content">

<table class="table_common" style="margin:0px; padding:0px;">
	<tr>
    	<td class="one">��������</td>
        <td><input type="text" value="{$data.region_main_name}"  size="30" class="must_fill_in_loc" name="name"/> <font class="blue"> * </font></td>
    </tr>
	<tr>
    	<td class="one">����</td>
        <td><input type="text" value="{$data.sort}"  size="30" name="sort"/></td>
    </tr>
	<tr>
    	<td class="one">��������</td>
        <td>
        <div id="son_alias">
        	{foreach from=$son_areas item='list'}
<label><input  type="checkbox" value="{$list.region_id}" {if $list.checked eq '1'} checked="checked"{/if}  name="extend_data[son][]"/>&nbsp;{if $list.checked eq '1'}<font class="blue">{$list.alias_name}</font>{elseif $list.checked eq '2'}<font style="color:#B1B1B1;">{$list.alias_name}</font>{else}{$list.alias_name}{/if}  </label>{/foreach}
            </div>
        </td>
    </tr>
    <tr>
		<td class="one"></td>
        <td><input type="submit" value="�� ��" class="form_submit form_btn" style="display: none;" />
        	<a href="javascript:;" onclick="submit_form('location_form');" class="block_button form_btn">�� ��</a>
        </td>
    </tr>
</table>
	</div>
</div>
</form>
{if !$is_ajax}{include file="frame_footer.php"}{/if}
{/if}