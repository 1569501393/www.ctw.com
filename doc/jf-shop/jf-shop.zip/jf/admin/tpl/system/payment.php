<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{if $action eq 'edit' || $action eq 'list'}
    {include file="frame_header.php"}
    <script type="text/javascript">
    {foreach from=$lang.payment.js_html key=key item=item}
        var {$key} = "{$item}";
    {/foreach}
    </script>
{/if}
{if $action eq 'list'}
<script  type="text/javascript">
$(function(){
	close_open_helper('open_pay_helper','show_helper');
});
function install_pay(obj,name){
	var a = $(obj).attr('rel');
	if(a=='true'){
		alert('�����ǹٷ���Ȩ�û�,����ϵ�ͷ���ȡ��ز��!');
		return false;	
	}
	$.get('index.php?m=system/payment&a=install',{name:name},function(callback){
		callback = callback.split('|');
		var data = callback[0];
		var e = callback[1];
		switch(data){
			case 'EMPTY':
				window.parent.showNotice('��������!');
			break;
			case 'HAS_EXIST':
				window.parent.showNotice('�Ѵ��ڴ�֧����ʽ!');
				return false;
			break;
			case 'NOT_EXIST_CONFIG_FILE':
				window.parent.showNotice('ȱ�����������ļ�!');
			break;
			case 'EMPTY_CONFIG':
				window.parent.showNotice('�����ļ�ȱ�ٱ�Ҫ�Ĳ���!');
			break;
			case 'OK':
				if(confirm('��װ�ɹ�,��Ҫ������?')){
					window.location.href=e;	
				}else{
					window.location.reload();	
				}
			break;
			default:alert(data);
		}
	});
}
function uninstall_pay(obj){
	if(!confirm('ȷ��Ҫж����?\r\nж�غ��Ӧ��������Ϣ��ɾ��!'))return false;
	$.get('index.php?m=system/payment&a=uninstall',{name:$(obj).attr('ename')},function(data){
		switch(data){
			case 'EMPTY':
				window.parent.showNotice('��������!');
			break;
			case 'NOT_EXIST':
				window.parent.showNotice('�����ڴ�֧����ʽ!');
			break;
			case 'OK':
				window.parent.showNotice('�����ɹ�!');
				window.location.reload();
			break;
			default:alert(data);
		}
	});
}
</script>
<div id="php_right_main_content">
    <table class='table_list'>
    <tr>
        <th>����</th>
        <th>�汾</th>
        <th>����</th>
        <th>��ַ</th>
<!--    <th>�������</th>-->
        <th>״̬</th>
        <th>����</th>
    </tr>
    {foreach from=$pay item=pa}
    <tr>
        <td>{$pa.payname}</td>
        <td align='center'>{$pa.version}</td>
        <td align="center">{$pa.author}</td>
        <td align="center">{$pa.authorLink}</td>
   <!-- <td align="center">{$pa.pay_extend_fee|default:'-'}</td>-->        
        <td align='center'>{if $pa.installed eq '1'}{if $pa.pay_public==1}<samp class="green">��</samp>{else}<samp class="red">��</samp>{/if}{else}-{/if}</td>
        <td align='center'>
        {if $pa.installed eq '1'}
	        <a href="index.php?m=system/payment&a=edit&pay_id={$pa.pay_id}">�༭</a>&nbsp;<a href="javascript:;" ename="{$pa.name}" eid="{$pa.pay_id}" onclick="uninstall_pay(this);">ж��</a>
        {/if}
        {if $pa.installed eq '0'}&nbsp;<a href="javascript:;" rel="{$pa.alert}" onclick="install_pay(this,'{$pa.name}');"> ��װ</a>
        {/if}
        </td>
    </tr>
    {/foreach}
    </table>
    </div>
{/if}
<!--����actionΪedit �Ĵ���-->

<!--��ʼ�༭����-->
{if $action eq 'edit'}
<script  type="text/javascript">
$(function(){
	$("#do_payment_form").submit(function(){
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok); window.location.href='index.php?m=system/payment';
				break;
				default:alert(data);
			}
		});
		return false;
	});
	close_open_helper('pay_help_pannel','pay_msg_id');
});
</script>
<form id='do_payment_form' action="index.php?m=system/payment&a=edit" method='post'>
<div id="php_top_bar" class="php_bot_bar">
    <div class="top_bar_pannel">
        <a href="javascript:;" onclick="window.location.reload();" class="block_button">ˢ��</a>
       {if $info} <a href="javascript:;" id="pay_help_pannel" class="block_button">�򿪰���</a>{/if}
        <a href="javascript:;" onclick="submit_form('do_payment_form');" class="block_button">����</a>
    </div>
</div>
<div id="php_right_main_content">
<input type="submit" value=""  style="display:none;"/>
    {if $info}<div class="notice_msg" id="pay_msg_id" style="margin:3px auto; display:none;">{$info}</div>{/if}
<div class="table_item_base">
	<h1 class="c_bar">{$pay.pay_name}����</h1>
        <div class="c_content">
        <table class='table_common'>
        <tr>
            <td class='one'>֧����ʽ����</td><td>{$pay.pay_name}</td>
        </tr>
        <tr>
            <td class="one">״̬</td>
            <td>
            <select name="pay_public"  class="w350">
                <option value="1" {if $pay.pay_public eq '1'} selected="selected"{/if}>����</option>
                <option value="0" {if $pay.pay_public eq '0'} selected="selected"{/if}>����</option>
            </select>
            </td>
        </tr>
        {if $pay.pay_code eq 'cash_delivery'}
            <tr>
                <td class="one">����֧�ֵĵ���</td>
                <td>
                <script type="text/javascript">
                    function _set_val_tags(key,text){
                        $("#set_support_area").val(key);
                        $("#text_regions").html(text).show();
                    }
                </script>
                <input type="hidden" value="{$pay.support_area}" name="support_area" id="set_support_area" />
    
    <table>
        <tr>
            <td valign="middle"  align="center"  style="border-bottom:none" nowrap="nowrap">
                <a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=system/payment&a=setarea',400,500)" class="block_button form_btn">����֧�ֵĵ���</a></td>
            <td style="border:none;">
             <div id="text_regions"> {foreach from=$pay.region_suport_area item='list'} {$list.region_name} {/foreach}</div>
            </td>
        </tr>
    </table>
                </td>
            </tr>
        {/if}
        <tr>
            <td class='one'>ͼƬ</td>
            <td>
            <div class="tb"><input type='text' name="pay_pic" class="w350" value="{$pay.pay_pic}" id="pay_pic_dom"/></div>
            <div class="tb"><a href="javascript:;" class="form_btn block_button" onclick="showDialog(document.getElementById('pay_pic_dom'),'index.php?m=file&type=default')">ѡ��ͼƬ</a>
            </div>            
            {if $pay.pay_pic}
            <div class="tb"><img src="{$pay.pay_pic}" /></div>
            {/if}
            </td>
        </tr>
<!--        <tr>
        	<td class="one">�������</td>
            <td><input type='text' name="pay_extend_fee" class="w350" value="{$pay.pay_extend_fee|default:'0'}"/></td>
        </tr>-->
        <tr>
            <td class='one'>����</td><td><input type='text' name="pay_seq" class="w350" value="{$pay.pay_seq}"/></td>
        </tr>
        <tr>
            <td class='one'>����</td><td><input type='text'  class="w350" name="pay_fee" value="{$pay.pay_fee}"/><span class="blue"> % ���������,��������Ա�鿴</span></td>
        </tr>
        {foreach from=$account item=fs key=k}
        {if $fs.type eq "text"}
        <tr>
            <td class='one'>{$fs.name}</td><td><input type='text' name="{$k}" class="w350" value="{$fs.value}"/></td>
        </tr>
        {/if}
        {if $fs.type eq "select"}
        <tr>
            <td class='one'>{$fs.name}</td>
        <td>
        <select class="w350" name="{$k}">
        {foreach from=$fs.value item=f key=fk}
        <option value="{$fk}" {if $fk eq $fs.sel} selected="selected"{/if}>{$f}</option>
        {/foreach}
        </select>
        </td>
        </tr>
        {/if}
        {if $fs.type eq 'mofiled'}
            {foreach from=$fs.value item='item'}
                <tr>
                    <td class="one">{$item.name} </td>
                    <td>
                    <select  class="w350"name="{$item.key_name}">
                        {foreach from=$item.value key=key item='val'}
                        <option value="{$key}" {if $key eq $item.sel}selected='true'{/if}>{$val}</option>
                        {/foreach}
                        </select>
                    </td>
                </tr>
                {/foreach}
            {/if}
        {/foreach}
        <tr>
            <td class='one'>����</td><td><textarea  class="seo_set w350" name="pay_desc">{$pay.pay_desc}</textarea></td>
        </tr>
        </table> 
    </div>
</div><!--#table_item_base-->
</div>
   </form>
{/if}

{if $action eq 'edit' || $action eq 'list'}
	{include file="frame_footer.php"}
{/if}

{if $action eq 'set_pay_areas'}
<script type="text/javascript">
	function set_son(obj,cv){
		var attr = $(obj).attr('checked');
		var f = attr==true?false:true;
		$(".set_sons_"+cv).each(function(){
			$(this).attr({"checked":attr,"disabled":f});
		});
		if(attr==false){
			$(obj).attr({"checked":false,"disabled":false});		
		}
	}
	function save_tags(){
		var str = $('.load_tag').map(function(){
			if($(this).attr('checked'))return $(this).val();
		}).get().join();
		var text = $('.load_tag').map(function(){
			if($(this).attr('checked'))return $(this).attr('text');
		}).get().join(' ');
		_close_window_one();
		window.frames['rightFrame']._set_val_tags(str,text);
		str=text = '';
	}
</script>
<div class="spacer"></div>
<div class="tb"><a  href="javascript:;" class="block_button form_btn" onclick="save_tags(this);">����</a></div>
<input  type="hidden" value="" id="eeee" />
<div class="clear"></div>
<hr />
<table>
	{foreach from=$data item='list' key=k}
    	<tr>
        	<td style="padding-left:{$list.level*15}px;">
<label><input type="checkbox" class="set_sons_{$list.region_id} load_tag"  text="{$list.region_name}" {if $list.sec eq '1'} checked="checked"{/if} {if $list.level neq '1' && $list.sec neq '1'}  disabled="disabled" {/if}  spceial="{$list.special_region}"  value="{$list.region_id}" onclick="set_son(this,'{$list.region_id}');" parent_id="{$list.parent_id}" />   |-{$list.region_name}</label></td>
        </tr>
        {if $list.childrens}
        {foreach from=$list.childrens item='son'}
    	<tr>
        	<td style="padding-left:{$son.level*15}px;">
<label><input type="checkbox"  class="set_sons_{$list.region_id} set_sons_{$son.region_id} load_tag"  {if $son.sec eq '1'} checked="checked"{/if} text="{$son.region_name}" {if $son.level neq '1' && $son.sec neq '1'}  disabled="disabled"{/if}  spceial="{$son.special_region}"  value="{$son.region_id}" onclick="set_son(this,'{$son.region_id}');"  parent_id="{$son.parent_id}" />    |-{$son.region_name}
</label>
</td>
        </tr>
                {if $son.childrens}
                    {foreach from=$son.childrens item='sonss'}
                       <tr>
                            <td style="padding-left:{$sonss.level*15}px;">
<label><input type="checkbox"  class="set_sons_{$list.region_id} set_sons_{$son.region_id} load_tag"  {if $sonss.sec eq '1'} checked="checked" {/if} text="{$sonss.region_name}" {if $sonss.sec neq '1' &&  $son.level neq '1'}  disabled="disabled" {/if}  value="{$sonss.region_id}"  parent_id="{$sonss.parent_id}" />        |-{$sonss.region_name}
</label>
</td>
                        </tr>
                    {/foreach}
                {/if}
        {/foreach}
        {/if}
    {/foreach}
</table>
{/if}