<?php exit('die'); ?>
{if $action eq 'toadminconfig'}
<form method="post" action="index.php?m=system/messenger&a=toadminconfig" id="toadminconfig" autocomplete="off">
<div id="php_top_bar" class="php_bot_bar">
    <div class="top_bar_pannel">
        <a href="javascript:;" onclick="submit_form('toadminconfig');" class="block_button"><% _e('����');%></a>
    </div>
</div>
    <div id="php_right_main_content">
     {include file="system/messenger/menu.php"}
        <div class="table_item_base">
            <h1 class="c_bar">����Ա��������</h1>
                <div class="c_content">
            <table class="table_common">
                <tr>
                    <td class="one"  nowrap="nowrap"><% _e('ϵͳ����Ա���������ַ');%></td>
                    <td><input type="text" value="{$data.admin_email}" size="40" name="data[admin_email]"  /></td>
                </tr>
                <tr>
                    <td class="one"><% _e('ϵͳ����Ա�����ֻ�����');%></td>
                    <td>
                        <input type="text" value="{$data.admin_mobile}" name="data[admin_mobile]"  size="40"/>
                    </td>
                </tr>
            </table>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript">
	$(function(){
		$("#toadminconfig").submit(function(){
			$(this).ajaxSubmit(function(data){
				switch(data){
					case 'OK':window.parent.showNotice(php_do_ok);break;	
					default:alert(data);
				}
			});
			return false;
		});
	});
</script>
{/if}