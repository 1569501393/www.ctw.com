<?php exit('die'); ?>
<div class="table_scroll">
    <ul class="menu">
      <li {if $curent_app eq 'showlisttemplate'} class="wintable_curent"{/if}><a href="index.php?m=system/messenger&a=showlisttemplate">ģ������</a></li>
      <li {if $curent_app eq 'showmailconfig'} class="wintable_curent"{/if}><a href="index.php?m=system/messenger&a=showmailconfig">�ʼ�����</a></li>
      <li {if $curent_app eq 'smsset'} class="wintable_curent"{/if}><a href="index.php?m=system/messenger&a=smsset">�ֻ���������</a></li>
      <li {if $curent_app eq 'toadminconfig'} class="wintable_curent"{/if}><a href="index.php?m=system/messenger&a=toadminconfig">����Ա��������</a></li>
      <li {if $curent_app eq 'mailqueue'} class="wintable_curent"{/if}><a href="index.php?m=system/messenger&a=mailqueue">�ʼ�����</a></li>
    </ul>
</div>