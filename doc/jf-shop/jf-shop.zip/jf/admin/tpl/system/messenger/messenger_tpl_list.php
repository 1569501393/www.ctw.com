<?php exit('die'); ?>
<div id="php_top_bar" class="php_bot_bar">
  <div class="top_bar_pannel"> <a  href="javascript:;" onclick="submit_form('table_list_msgtemplate');" class="block_button form_btn">��������</a> </div>
</div>
<div id="php_right_main_content"> {include file="system/messenger/menu.php"}
  <script type="text/javascript">
$(function(){
	$("#table_list_msgtemplate").submit(function(data){
		$(this).ajaxSubmit(function(data){
			switch(data){
				case "OK":
				window.parent.showNotice(php_do_ok);
				break;
				default:alert(data);
			}
		});
		return false;
	});
});
function _check_all(obj,cls){ $('.'+cls).attr('checked',$(obj).attr('checked')); }
</script>
  <form autocomplete="off" action="index.php?m=system/messenger&a=showlisttemplate" method="post" id="table_list_msgtemplate" >
    <table class="table_list table_list_common" cellpadding="0" cellspacing="0">
      <tr>
        <th align="left">����</th>
        <th align="left"><input type="checkbox" value="" onclick="_check_all(this,'e_mail');" />
          �ʼ�</th>
        <th align="left"><input type="checkbox" value="" onclick="_check_all(this,'e_sms');"  />
          վ����</th>
        <th align="left"><input type="checkbox" value="" onclick="_check_all(this,'e_mobile');" />
          �ֻ�����</th>
        <th align="left"><input type="checkbox" value="" onclick="_check_all(this,'e_a_mail');"  />
          ����Ա(�ʼ�)</th>
        <th align="left"><input type="checkbox" value="" onclick="_check_all(this,'e_a_mobile');" />
          ����Ա(����)</th>
      </tr>
      {foreach from=$res item=item}
      <tr align="center">
        <td align="left">{$item.0.desc}</td>
        <td><input class="e_mail" type="checkbox" value="{$item.0.id}" name='msgtemplate[]' {if $item.0.disbled == 1 }checked="true"{/if} />
          &nbsp;<a href="index.php?m=system/messenger&a=aedittemplate&id={$item.0.id}" class="aedit_temp loading" >{$lang.messenger.html_edit_template}</a></td>
        <!-- �༭ģ�� -->
        <td><input class="e_sms" type="checkbox" value="{$item.1.id}" name='msgtemplate[]' {if $item.1.disbled == 1 }checked="true"{/if} />
          &nbsp;<a  href="index.php?m=system/messenger&a=aedittemplate&id={$item.1.id}" class="aedit_temp loading" >{$lang.messenger.html_edit_template}</a></td>
        <!-- �༭ģ�� -->
        <td><input class="e_mobile" type="checkbox" value="{$item.2.id}" name='msgtemplate[]' {if $item.2.disbled == 1 }checked="true"{/if} />
          &nbsp;<a  href="index.php?m=system/messenger&a=aedittemplate&id={$item.2.id}&type=mobile" class="aedit_temp" >{$lang.messenger.html_edit_template}</a></td>
        <!-- �༭ģ�� -->
        <td><input class="e_a_mail" type="checkbox" value="{$item.3.id}" name='msgtemplate[]' {if $item.3.disbled == 1 }checked="true"{/if} />
          <a href="index.php?m=system/messenger&a=aedittemplate&id={$item.3.id}">{$lang.messenger.html_edit_template}</a></td>
        <td><input class="e_a_mobile" type="checkbox" value="{$item.4.id}" name='msgtemplate[]' {if $item.4.disbled == 1 }checked="true"{/if} />
          <a href="index.php?m=system/messenger&a=aedittemplate&id={$item.4.id}&type=mobile">{$lang.messenger.html_edit_template}</a></td>
      </tr>
      {/foreach}
    </table>
  </form>
</div>