<?php exit('die'); ?>
<form action="index.php?m=system/messenger&a=aedittemplate" method="post" id="fmupdatetemp" autocomplete="off">
<div id="php_top_bar" class="php_bot_bar">
    <a href="index.php?m=system/messenger" class="block_button form_btn">�� ��</a>
    <a href="javascript:;" onclick="submit_form('fmupdatetemp');" class="block_button form_btn">�� ��</a>
</div>
<script type="text/javascript">
$(function(){
	$("#fmupdatetemp").submit(function(){
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'OK':
					window.parent.showNotice('�����ɹ�!');
					window.location.href='index.php?m=system/messenger&a=messenger';
				break;
				case 'EMPTY':
					window.parent.showNotice('����д������!');
				break;
				default:alert(data);
			}
		});
		return false;
	});
});
</script>
<div id="php_right_main_content">
{include file="system/messenger/menu.php"}
<div class="table_item_base">
	<h1 class="c_bar">��ǩ����</h1>
    <div class="c_content">
    <table class="table_common">
        <tr>
            <td class="one">������ǩ</td><!-- ������ǩ�� -->
            <td>{$temp.label}</td>
        </tr>
        <tr>
            <td class="one">������Ŀ</td><!-- �ʼ����⣺ -->
            <td>{$temp.desc}</td>
        </tr>
    </table>
   </div>
<h1 class="c_bar">����ģ������</h1>
    <div class="c_content c_no_border">
        <table class="table_common">
        <tr {if $fckeditor == '' } style="display:none" {/if}>
            <td class="one" nowrap="nowrap">�ʼ�����</td><!-- �ʼ����⣺ -->
            <td><input size="40" maxlength="50" name="title" type="text" value="{$temp.title}" class="form_input" /></td>
        </tr>
        <tr>
            <td colspan="2" class="no_border">
                {if $fckeditor != '' }
                    {$fckeditor}
                    <input type="hidden" value="fck" name="temptype" id="temptype" />
                {else}
                    <textarea style="width:450px; height:100px;" name="pagecontent">{$temp.detail}</textarea>
                    <p>
                    <span class="blue">{$lang.messenger.html_mobile_advice}</span><!-- ���飺���ֻ��Ϸ��͵����ֲ�Ҫ���࣡ -->
                    </p>
                    <input type="hidden" value="mobile" name="temptype" id="temptype"/>
                {/if}
            </td>
        </tr>
        </table>
          <input type="hidden" value="{$temp.id}" name="tempid" />
    </div>
</div><!--#end table_item_base-->
</div><!--#end php_right_main_content-->
</form>
