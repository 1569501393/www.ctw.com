<?php  exit('die');?>
{if $action eq 'mailqueue'}
<form method="post" action="index.php?m=system/messenger&a=mailqueue" id="submit_mail_list" autocomplete="off">
{if $data.total>0}
<div id="php_top_bar"  class="php_bot_bar">
    <div class="top_bar_pannel">
         <a href="javascript:;" onclick="sent_mail_list(this);" class="block_button form_btn"><% _e('���·�����ѡ����');%></a>
         <a href="javascript:;" onclick="delete_mail_list(this);" class="block_button form_btn">{$lang.mail_quee.delete_select_mail}</a>
    </div>
</div>
{/if}
<div id="php_right_main_content">
 {include file="system/messenger/menu.php"}
{if $data.total>0}
<script type="text/javascript">
var send_mail_ok = '{$lang.mail_quee.send_mail_ok}';
$(function(){
	checkAllFormData('select_mail_type','click_all');
	$("#submit_mail_list").submit(function(){
		$(this).ajaxSubmit({success:send_email});
		return false;
	})	
});
function _send(url){
	if(empty(url)){alert('error');return false;
	}
	$.get(url,send_email);
}
function send_email(data){
	switch(data){
		case 'EMPTY':
			 return window.parent.showNotice(php_empty_select);
		break;
		case 'OK':
			window.parent.showNotice(php_save_ok);window.location.reload();
		break;
		case 'ERROR':alert('error');break;
		case 'SEND_OK':
			window.parent.showNotice(php_do_ok);//'���ųɹ�!'
			window.location.reload();
		break;
		default:
		var items = data.split('||');
		 $("#show_call_msg").show().html(items[0]+'<img src="images/zoomloader.gif" />');
		 if(items[1]){
			_send(items[1]);
		 }else{
			alert(data);return false;	 
		 }
	}
}
function delete_mail_list(obj){
	var sec = get_checkbox_val('click_all');
	if(!sec)return window.parent.showNotice(php_empty_select);
	if(!confirm(php_delete_confirm))return false;
	var opt = {"action":'delete','mail_ids':sec};
	$.post('index.php?m=system/messenger&a=mailqueue',opt,send_email);
}
function sent_mail_list(obj){
	$("#mail_list_opt").val('send');
	var sec = get_checkbox_val('click_all');
	if(!sec)return window.parent.showNotice(php_empty_select);
	$("#submit_mail_list").submit();
}
function show_mail_detail(obj){
	return window.parent.showWindow($(obj).html(),$(obj).attr('rel'),750,300);
}
</script>
<div class="spacer"></div>
<div id="show_call_msg" class="notice_msg" style="display:none;"></div>
<input type="hidden" value="" id="mail_list_opt"  name="action"/>
<table class="table_list">
    <tr>
        <th class="center"><input type="checkbox" value="" id="select_mail_type" /></th>
        <th><!--����-->{$lang.mail_quee.title}</th>
        <th><!--����ʱ��-->{$lang.mail_quee.send_mail_time}</th>
        <th><!--������-->{$lang.mail_quee.sender}</th>
        <th><!--����-->{$lang.mail_quee.type}</th>
        <th><% _e('��־');%></th>
        <th><!--����-->{$lang.mail_quee.detail}</th>
    </tr>
    {foreach from=$data.data item='list'}
    	<tr>
        <td class="center"><input type="checkbox" value="{$list.id}"  name="mail_ids[]" class="click_all" /></td>
        	<td class="center" align="center">{$list.title}</td>
            <td class="center">{$list.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
            <td class="center">{$list.reciver}</td>
            <td class="center">{if $list.type eq '1'}{$lang.mail_quee.email}<!--�ʼ�-->{elseif $list.type eq '2'}<!--����-->{$lang.mobile.duanxin}{else}N/A{/if}</td>
            <td>{$list.error}</td>
            <td class="center"><a href="javascript:;" onclick="show_mail_detail(this);" rel="index.php?m=system/messenger&a=mailqueue&do=detail&id={$list.id}">{$lang.mail_quee.detail}</a></td>
            <!--����-->
        </tr>
        {/foreach}
</table>
<div class="clear"></div>
<div class="d_page">{$data.page}</div>
{else}
    <div class="notice_msg">{$lang.php_nodata}</div>
{/if}
</div>
</form>
{/if}
<!--ajax �ص���ʾ �ʼ������������-->
{if $action eq 'ajax_call_send_detail'}
<div class="mail_config_all">
	<div class="tt"><b class="blue">{$lang.mail_quee.title}��</b>{$data.title}</div>
	<div class="tt"><b class="blue"><!--ʱ��-->{$lang.mail_quee.send_mail_time}��</b>{$data.time|date_format:"%Y-%m-%d %H:%M:%S"}</div>
	<div class="tt"><b class="blue"><!--������-->{$lang.mail_quee.sender}��</b>{$data.reciver}</div>
    <div class="tt"><b class="blue"><% _e('������־');%></b>��{$data.error}</div>
	<hr />
	<div class="tt"><b><!--�ʼ�����-->{$lang.mail_quee.mail_body}��</b></div>
    <hr />
    {$data.content}
</div>
{/if}
