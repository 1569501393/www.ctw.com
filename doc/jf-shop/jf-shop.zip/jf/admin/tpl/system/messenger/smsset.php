<?php exit('die'); ?>
{if $action eq 'smsset'}
<form method="post" action="index.php?m=system/messenger&a=smsset" id="save_mobile_info" autocomplete='off'>
<div id="php_top_bar"  class="php_bot_bar">
    <div class="top_bar_pannel">
        <a href="javascript:;" onclick="test_sent_mobile_info(this);" class="block_button form_btn">����</a>
        <a href="javascript:;" onclick="submit_form('save_mobile_info');" class="block_button form_btn">����</a>
    </div>
</div>
<div id="php_right_main_content">
 {include file="system/messenger/menu.php"}
<div class="notice_msg" id="call_sms_dom"><!--����Ҫ���ŷ���,����ϵ�ٷ������˺�!-->{$lang.mobile.mobile_msg_help_info}</div>
    <div class="table_item_base">
    <!--#��������-->
        <h1 class="c_bar">�ֻ���������</h1>
            <div class="c_content">
        <script type="text/javascript">
            $(function(){
                $("#save_mobile_info").submit(function(){
                    $(this).ajaxSubmit(function(data){
                        switch(data){
                            case 'OK':
                                return window.parent.showNotice(php_save_ok);
                            break;
                            default:alert(data);
                        }
                    });
                    return false;
                });
                close_open_helper('open_msm_msg','call_sms_dom');
            });
            function test_sent_mobile_info(obj){
                var data = $("#save_mobile_info").formToArray();
                var url = 'index.php?m=system/messenger&a=testSendMobile&';
                var c = '';
                for(var i = 0; i < data.length; i++){url = url + c + data[i].name + "=" + data[i].value;c = '&';}
                window.parent.showWindow($(obj).html(),url,600,300);
            }
        </script>
        <table class="table_common">
            <tr>
                <td class="one"><!--��ҵ����-->{$lang.mobile.ms_qiye_daima}</td>
                <td><input type="text" value="{$data.sms_cpcode}" name="mail[sms_cpcode]" class="form_input must_fill_in"  maxlength="50"/><font class="blue">*</font></td>
            </tr>
            <tr>
                <td class="one"><!--�����ʺ�-->{$lang.mobile.ms_account}</td>
                <td><input type="text" value="{$data.sms_id}" name="mail[sms_id]" class="form_input must_fill_in" maxlength="50"/><font class="blue">*</font></td>
            </tr>
            <tr>
                <td class="one"><!--��������-->{$lang.mobile.ms_pass}</td>
                <td><input type="text" value="{$data.sms_pass}" name="mail[sms_pass]" maxlength="50" class="form_input must_fill_in" /><font class="blue">*</font></td>
            </tr>
        </table>
        </div>
    </div>
</div>
</form>
{/if}
{if $action eq 'testSendMobile'}
<script type="text/javascript">
var send_mobile_ok = '���ͳɹ�';
var send_mobile_failed = "<% _e('����ʧ��,������������Ƿ���ȷ,ͬʱ�������˻��Ƿ������!');%>";
var check_mobile_is_ok = '{$lang.mobile.check_mobile_is_ok}';
$(function(){
	$("#sms_test_submit").submit(function(){
	 if(!check_form_is_empty('must_fill_in_test'))return false;
	 $(this).ajaxSubmit(function(data){
			var app = $("#show_call_back_msg");
			data = data.split('|');
			switch(data[0]){
				case 'OK':
					$(".must_fill_in_test").val('');
					$(app).html(send_mobile_ok).show();
					return true;
				break;
				case 'EMPTY':
					$(app).html(send_mobile_failed).show();
					return false;
				break;
				case 'FAILED':
					$(app).html(data[1]).show();$(".must_fill_in_test").val('');
					return false;
				break;
				case 'ERROR_MOBILE':
				/*����绰�����Ƿ���ȷ!*/
					$(app).html(check_mobile_is_ok).show();$("#sms_mobile").val('');
					return false;
				break;
				default:alert(data);
			}	
	 });
	 return false;
});
});
</script>
<div class="table_item_base">
<h1 class="c_bar">���Է���</h1>
<div class="c_content">
    <div id="send_mobile_info" style="padding:0px; margin:0px;">
        <form method="post" action="index.php?m=system/messenger&a=testSendMobile" id="sms_test_submit" autocomplete="off">
    <table class="table_common">
        <tr>
            <td class="one"><!--�ֻ�����-->{$lang.mobile.mobile_number}��</td>
            <td><input type="text" value=""  id="sms_mobile" name="mobile"  class="form_input must_fill_in_test w200"/></td>
        </tr>
        <tr>
            <td class="one"><!--��������-->{$lang.mobile.mobile_contents}��</td>
            <td><textarea  name="content" id="sms_content" class="form_textarea must_fill_in_test seo_set"></textarea></td>
        </tr>
        <tr>
            <td class="one"></td>
            <td colspan="2"> 
             <a href="javascript:;" onclick="submit_form('sms_test_submit');" class="block_button form_btn">����</a>
            </td>
        </tr>
    </table>
        </form>
    </div>
    <div class="blue" id="show_call_back_msg" style="display:none; padding:2px 8px;"></div>
    </div>
</div>
{/if}