<?php exit('die'); ?>
{if $action eq 'mail_config'}
<form method="post" action="" id="mail_config" autocomplete="off">
  <div id="php_top_bar" class="php_bot_bar">
    <div class="top_bar_pannel"> <a href="javascript:;"  id='test_mail_config' class="block_button">{$lang.messenger.button_test_mail}</a> <a href="javascript:;" id="save_mail_config" class="block_button">�� ��</a> </div>
  </div>
  <div id="php_right_main_content"> {include file="system/messenger/menu.php"}
    <script type="text/javascript">
	<!--���ʼ����Ͳ����ύ���ݵ���������-->
	$(document).ready(function(){
		$("#test_mail_config").click(function(){
			var data = $("#mail_config").formToArray();
			var url = 'index.php?m=system/messenger&a=testSendMail&';
			var c = '';
			for(var i = 0; i < data.length; i++){url = url + c + data[i].name + "=" + data[i].value;c = '&';}
			window.parent.showWindow($(this).html(),url,600,300);
		}) ;
		$("#save_mail_config").click(function(){
			$("#action").val('save');
			$("#mail_config").submit();
		});
		$("#mail_config").submit(function(){
			$(this).ajaxSubmit({
				url:'index.php?m=system/messenger&a=setMailConfig',
				success:function(d){
						var e = d.split('|');
						if(e[0]=='1'){
							window.parent.showNotice(e[1]);return ;
						}
					}
			});return false;	
		});
		$("#smtp_set").click(function(){
			$('.smtp').show();$(this).find('input').attr('checked',true);
		})
		$(".mail_set").click(function(){
			$('.smtp').hide();$(this).find('input').attr('checked',true);
		});
		var smtp_checked  = $("#smtp_set").attr('checked');
		smtp_checked==true?$('.smtp').show():$('.smtp').hide();
	});
</script>
    {if $mail.mail_send_type eq 'smtp'}
    <script type="text/javascript">
    $(document).ready(function(){
        $('.smtp').show();	
    });
</script>
    {/if}
    <div class="table_item_base">
      <h1 class="c_bar">�ʼ�����</h1>
      <div class="c_content">
        <table cellpadding="0" cellspacing="0" class="table_common">
          <tr>
            <td class="one" style="text-align:right;" width="150">�ʼ����ͷ�ʽ</td>
            <!-- �ʼ����ͷ�ʽ�� -->
            <td colspan="2"><p class="mail_set" style="cursor:pointer">
                <input type="radio"  value="mail" name="mail_send_type"  checked="checked" />
                &nbsp; ʹ��mail����(����������Ϊ�������ʼ�)</p>
              <!-- ʹ��mail���� -->
              <p class="mail_set">
                <input type="radio" value="sendmail"  {if $mail.mail_send_type eq 'sendmail'} checked="checked"{/if} name="mail_send_type"  />
                &nbsp;ʹ��sendmail����(�ʺ���linux�ں��Ұ�װ��sendmail�ķ�����)</p>
              <!-- ʹ��sendmail����,���������������sendmail����(��linux�ȷ�win������ʹ��) -->
              <p id="smtp_set" style="cursor:pointer" >
                <input type="radio" id="smtp_set"  value="smtp" {if $mail.mail_send_type eq 'smtp'} checked="checked"{/if}  name="mail_send_type"  />
                &nbsp; {$lang.messenger.html_us_smtp}</p>
              <!-- ʹ���ⲿSMTP���� --></td>
          </tr>
          <tr>
            <td class="one" align="right" style="text-align:right;" >������</td>
            <!-- ���������䣺  -->
            <td width="260"><input type="text" value="{$mail.sender}" class="w_200"  name="sender"/></td>
            <td></td>
          </tr>
          <tr class="smtp">
            <td class="one" align="right" style="text-align:right;">��������ַ</td>
            <!-- smtp��������ַ�� -->
            <td><input type="text" value="{$mail.smtp_host}"  class="w_200"  name="smtp_host"/></td>
            <td>{$lang.messenger.html_smtp_server_address_description}</td>
            <!-- ����163��smtp��������ַΪsmtp.163.com -->
          </tr>
          <tr class="smtp">
            <td class="one" align="right" style="text-align:right;">�������˿�</td>
            <!-- smtp�������˿�: -->
            <td><input type="text" value="{if $mail.smtp_port}{$mail.smtp_port}{else}25{/if}"   class="w_200" name="smtp_port"/></td>
            <td>{$lang.messenger.html_smtp_server_port_descript}</td>
            <!-- һ�㶼Ϊ25  -->
          </tr>
          <tr class="smtp">
            <td class="one" align="right" style="text-align:right;">��½�û���</td>
            <!-- smtp�û����� -->
            <td><input type="text" value="{$mail.smtp_user}"  class="w_200"  name="smtp_user"/></td>
            <td>{$lang.messenger.html_smtp_username_description}</td>
            <!-- һ��Ϊ�������ȫ�̱���xxx@163.com -->
          </tr>
          <tr class="smtp">
            <td class="one" align="right" style="text-align:right;">��½����</td>
            <!-- smtp���룺 -->
            <td><input  type="password" value="{$mail.smtp_pass}"   class="w_200" name="smtp_pass"/></td>
            <td>{$lang.messenger.html_smtp_password_description}</td>
            <!-- ����������� -->
          </tr>
        </table>
        <input type="hidden" value="test" id="action" name="action" />
      </div>
    </div>
  </div>
</form>
{/if}

{if $action eq 'test_mail_config'}
<script type="text/javascript">
$(function(){
	$("#test_mail").submit(function(){
		var a = check_form_is_empty('must_fill_test_mail');
		if(!a)return false;
		$(this).ajaxSubmit({
				url:'index.php?m=system/messenger&a=testSendMail',
				success:function(d){
					$("#show_send_mail_mag").html(d);
				}
		});
		return false;
	});
});
</script>
<div class="spacer"></div>
<div style="margin-left:10px;">
  <form method="post" action="" id="test_mail" autocomplete="off">
    <p>{$lang.messenger.html_please_write_mail_address}
      <!-- ��д�Ͻ��յ������ַ��  -->
      <input  type="text" value="" name="to" class="must_fill_test_mail"/>
    </p>
    <a href="javascript:;" id="test_send_btn" onclick="submit_form('test_mail');" class="block_button form_btn">{$lang.messenger.button_test_mail}</a>
  </form>
  <div id="show_send_mail_mag" style="padding:5px; color:#F00"></div>
</div>
{/if}