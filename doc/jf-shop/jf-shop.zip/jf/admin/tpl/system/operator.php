<?php if( !defined('PHP_TEMPLATE') )exit(); /*����Ա�޸��û����� �Զ���Ȩ�޲˵�����Ϣ*/?>
{if !$is_ajax}
{include file="frame_header.php"}
<form method="post" id="ajax_change_pass" action="index.php?m=default&a=operator">
<div id="php_top_bar" class="php_bot_bar">
	<div class="top_bar_pannel"><a href="javascript:;" onclick="submit_form('ajax_change_pass');" class="block_button form_btn">�� ��</a></div>
</div>
<div id="php_right_main_content">
{else}
<form method="post" id="ajax_change_pass" action="index.php?m=default&a=operator">
{/if}
<script type="text/javascript">
$(function(){
	$("#ajax_change_pass").submit(function(){
		if(!check_form_is_empty('se'))return false;
		$(this).ajaxSubmit(function(data){
			var call = data.split('|');
			var m = call[1];
			switch(call[0]){
				case '1':
					return showNotice(m);	
				break;
				case '2':
					alert(m);$(".se").val('');window.location.reload();
				break;
				default:alert(data);
			}
		});
		return false;
	});
});
</script>
<div class="table_item_base">
	<h1 class="c_bar">�˻�����</h1>
    <div class="c_content">
    <table class="table_common">
    <tr>
        <td class="one w100">{$lang.m.o.u_name}</td>
        <td>{$manager_info.manager_name}</td>
    </tr>
    <tr>
        <td class="one w100">������</td>
        <td>{$manager_info.group_name}</td>
    </tr>
    <tr>
        <td class="one w100">��&nbsp;&nbsp;��</td>
        <td>
            {$manager_info.manager_serial_number}
        </td>
    </tr>
    <tr>
        <td class="one w100">��&nbsp;&nbsp;ע</td>
        <td>
            {$manager_info.group_desc}
        </td>
    </tr>
</table>

  <table class="table_common" id="change_pass_table">
    <tr>
        <td class="one">{$lang.m.o.old_pass}<!--������-->:</td>
        <td><input type="password" value="" class="se" name="old_pass" id="c_old_pass"/></td>
    </tr>
    <tr>
        <td class="one"><!--������-->{$lang.m.o.new_pass}:</td>
        <td><input  type="password" value="" name="new_pass" class="se input_notice" title="{$lang.m.o.pass_length}" id="c_new_pass" /></td>
    </tr>
    <tr>
        <td class="one w100"><!--ȷ��������-->{$lang.m.o.confirm_new_pass}:</td>
        <td><input type="password" name="new_confirm_pass" value="" class="se" id="c_new_pass_confirm"></td>
    </tr>
</table>
</div>
</div>
<input type="hidden" value="change_pass"  name="action"/>
<!--end-->
{if !$is_ajax}
</div>
</form>
	{include file="frame_footer.php"}
{else}
</form>
{/if}