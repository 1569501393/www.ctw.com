<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{if $action eq 'productsPic'}
{include file="frame_header.php"}
{include file="part.js.php"}
<script type="text/javascript">
 	$(function(){
		$(".review").click(function(){
			var w_h = get_w_h($(this).parents('tr'));
			var uri = 'index.php?m=system/picset&a=viewPic&w_h='+w_h[0]+'_'+w_h[1];
			 var tt = pic_review+w_h[0]+'*'+w_h[1];
			 window.parent.showWindow(tt,uri,700,600);
		});
		<!--ajax upload-->
		function check_pic_w_h_set(){
			var flag = true;
			$(".pic_w_h_set").each(function(i){
				$(this).blur(function(){
					var v = $(this).val();
					if(v<=0){
						$(this).css({"background-color":"#F66","color":"#333"});
						$("#sub_pic_set").attr("disabled",true);
						flag = false;
					}else{
						$(this).removeAttr("style")
						$("#sub_pic_set").attr("disabled",false);	
					}				  
				})
			})
			return flag;
		}
		check_pic_w_h_set();
		$("#save_pic_thumb").submit(function(){
			$(this).ajaxSubmit(function(d){
				var c = d.split('|');
				return window.parent.showNotice(c[1]);
			});
			return false;
		});
	});
	function get_w_h (obj){
		var e = new Array();$(obj).find('input').each(function(){e.push($(this).val());});return e;
	} 
	function ajax_upload_pic(id,names){
		$("#"+id).upload({
			filename:names,
			post_params:{'sid':session_id,'upload_name':names,'file_name':names+'.jpg'},
			url:'index.php?m=system/picset&a=uploadPic',
			sucess:function(file,response){
			var c = response.split('|');
				var e = c[1];
				var hidden_val = c[2];
				switch(c[0]){
					case '1':
						return window.parent.showNotice(e);
					break;
					case '2':
					$("#"+id).parents('td').append('<input type="hidden" name="'+names+'" value="'+hidden_val+'"/>');
					$("#"+id).parents('td').next().find('a').attr({'href':e,"target":'_blank'});
						window.parent.showNotice(upload_defaul_pic_ok);<!--�ϴ��ɹ�,���ԱߵĲ鿴�ɿ��������ϴ���ͼƬ.-->
						return true;
					break;
					default:alert(!empty(call)?call:System_overtime);return false;
				}
			}
		});
	}
</script>
<div id="php_right_main_content">
<div class="table_item_base">
<form method="post" id="save_pic_thumb" action="index.php?m=system/picset&a=saveData" autocomplete="off">
<h1 class="c_bar">ͼƬ����ͼ�ߴ�����</h1>
    <div class="c_content">
            <table class="table_common">
            	<tr>
                <td class="one" style="width:100px;">{$lang.pictureset.pic_list_ablum}                  <!--�б�ҳ����ͼ--></td>
                <td width="100">{$lang.pictureset.pic_w}��<input type="text"   name="list_thumb_w" value="{if $pic_set_data.list_thumb.w}{$pic_set_data.list_thumb.w}{else}140{/if}" class="pic_w_h_set" onkeyup="this.value=this.value.replace(/\D/g,'')" /></td>
                <td width="90" nowrap="nowrap"> {$lang.pictureset.pic_h}<!--�߶�-->��<input type="text" name="list_thumb_h"  value="{if $pic_set_data.list_thumb.h}{$pic_set_data.list_thumb.h}{else}105{/if}" class="pic_w_h_set"  onkeyup="this.value=this.value.replace(/\D/g,'')"  /></td>
                <td width="30"><a  href="javascript:;" class="review">{$lang.pictureset.privew}<!--Ԥ��--></a></td>
                <td class="one" style="width:100px; overflow: hidden;">{$lang.pictureset.default_pic}<!--ȱʡͼ--></td>
                <td width="100" align="right"><!--<input type="file"  id="goods_list_pic"  />--><span id="goods_list_pic"></span><input type="hidden" value="shopdata/site/goods_list_pic.jpg" name="goods_list_list_default" /></td>
                <td><a  href="javascript:;" onclick="this.href='{$siteurl}shopdata/site/goods_list_pic.jpg?rand='+Math.random()" target="_blank" class="thumb_review">{$lang.pictureset.view}<!--�鿴--></a></td>
                </tr>
                 <tr>
                <td class="one" style="width:100px;">{$lang.pictureset.goods_detail_pic}<!--��Ʒҳ��ϸͼ--></td>
                <td >{$lang.pictureset.pic_w}��<input type="text" value="{if $pic_set_data.goods_detail_pic.w}{$pic_set_data.goods_detail_pic.w}{else}420{/if}" name="goods_detail_pic_w" class="pic_w_h_set"  onkeyup="this.value=this.value.replace(/\D/g,'')" /></td>
                <td nowrap="nowrap"> {$lang.pictureset.pic_h}<!--�߶�-->��<input type="text" name="goods_detail_pic_h"  value="{if $pic_set_data.goods_detail_pic.h}{$pic_set_data.goods_detail_pic.h}{else}510{/if}" class="pic_w_h_set" onkeyup="this.value=this.value.replace(/\D/g,'')" /></td>
                <td><a  href="javascript:;" class="review">{$lang.pictureset.privew}<!--Ԥ��--></a></td>
                <td class="one" style="width:100px;">{$lang.pictureset.default_pic}<!--ȱʡͼ--></td>
                <td align="right"><!--<input type="file" id="goods_detail_pic" />--><span id="goods_detail_pic"></span><input type="hidden" value="shopdata/site/goods_detail_pic.jpg"  name="goods_detail_pic_default"/></td>
                <td><a  href="javascript:;" onclick="this.href='{$siteurl}shopdata/site/goods_detail_pic.jpg?rand='+Math.random()"  target="_blank"  class="thumb_review">{$lang.pictureset.view}<!--�鿴--></a></td>
                </tr>
                  <tr>
                <td class="one" style="width:100px;">{$lang.pictureset.goods_album_pic}</td>
                <td> {$lang.pictureset.pic_w}��<input type="text"  name="goods_album_w" value="{if $pic_set_data.goods_album.w}{$pic_set_data.goods_album.w}{else}620{/if}" class="pic_w_h_set"  onkeyup="this.value=this.value.replace(/\D/g,'')" /></td>
                <td > {$lang.pictureset.pic_h}��<input type="text"  value="{if $pic_set_data.goods_album.h}{$pic_set_data.goods_album.h}{else}620{/if}" name="goods_album_h" class="pic_w_h_set" onkeyup="this.value=this.value.replace(/\D/g,'')" /></td>
                <td><a  href="javascript:;" class="review">{$lang.pictureset.privew}</a></td>
                <td class="one" style="width:100px;">{$lang.pictureset.default_pic}</td>
                <td width="100" align="right"><!--<input type="file"  id="goods_album_pic"/>--><span id="goods_album_pic"></span><input type="hidden" value="shopdata/site/goods_album_pic.jpg" name="goods_album_pic_default"/></td>
                <td><a href="javascript:;" onclick="this.href='{$siteurl}shopdata/site/goods_album_pic.jpg?rand='+Math.random()"  target="_blank" class="thumb_review">{$lang.pictureset.view}</a></td>
                </tr>
                  <tr>
                <td class="one" style="width:100px;">{$lang.pictureset.goods_other_pic}</td>
                <td> {$lang.pictureset.pic_w}��<input type="text" value="{if $pic_set_data.pic_other.w}{$pic_set_data.pic_other.w}{else}120{/if}" name="pic_other_w" class="pic_w_h_set"  onkeyup="this.value=this.value.replace(/\D/g,'')" /></td>
                <td> {$lang.pictureset.pic_h}��<input type="text"  value="{if $pic_set_data.pic_other.h}{$pic_set_data.pic_other.h}{else}120{/if}" class="pic_w_h_set" name="pic_other_h"  onkeyup="this.value=this.value.replace(/\D/g,'')" /></td>
                <td><a  href="javascript:;" class="review">{$lang.pictureset.privew}</a></td>
                <td class="one" width="100" style="width:100px; overflow:hidden;">{$lang.pictureset.default_pic}</td>
                <td align="right"><!--<input type="file" id="shop_other_pic"/>--><span id="shop_other_pic"></span><input type="hidden" value="shopdata/site/shop_other_pic.jpg"  name="shop_other_pic_default"/></td>
                <td><a  href="javascript:" 
                 onclick="this.href='{$siteurl}shopdata/site/shop_other_pic.jpg?rand='+Math.random()" target="_blank" class="thumb_review">{$lang.pictureset.view}</a></td>
                </tr>
</table>
              <div style="text-align:center; padding:5px;">
            <input type="hidden" value="save_pic_thumb" name="action" />
            <input type="submit" value="{$lang.php_save}" id="sub_pic_set" class="block_button form_btn" style="display:none;"/>
            <a href="javascript:;" id="sub_pic_set" class="block_button form_btn" onclick="submit_form('save_pic_thumb');">����</a>
             </div>

        </div>
</form><!--#end ͼƬ����ͼ�ߴ����� -->
{insert_scripts files='js/colorselect.js'}
<script type="text/javascript">
function show_window(contents){
	window.parent.open_new_window({
		content:contents,
		windowTitle:pic_review,
		width:750,
		height:550,
		draggable:true,
		showLayer:true
	});
}
$(function(){
	$("#water_pic_form").submit(function(){
		$(this).ajaxSubmit(function(d){
			 var c = d.split('|');
				switch(c[0]){
					case '1':
						return window.parent.showNotice(c[1]);
					break;
					case '2':
						return window.parent.showNotice(c[1]);
					break;
					case '3':
						return show_window(c[1]);
					break;
					default:alert(d);return false;
				}
		 });
		return false;
	});
	/*end form submit*/
	$("#select_color").selectColor();
	$("#water_pic_upload_field").upload({
		filename:'water_pic',
		post_params:{'sid':session_id},
		url:'index.php?m=system/picset&a=uploadWaterPic',
		sucess:function(file,response){
			var c = response.split('|');
			var e = c[1];
			switch(c[0]){
				case '1':
					return window.parent.showNotice(e);
				break;
				case '2':
				return $("#water_pic_thumb").html('<img  width="130" height="55" src="'+e+'?rand='+Math.random()+'" />');
				break;
				default:alert(!empty(call)?call:System_overtime);return false;
			}
		}
	});
	ajax_upload_pic('goods_list_pic','goods_list_pic');
	ajax_upload_pic('goods_album_pic','goods_album_pic');
	ajax_upload_pic('shop_other_pic','shop_other_pic');
	ajax_upload_pic('goods_detail_pic','goods_detail_pic');
});
function _reset_data(obj){
	var v = $(obj).val();
	var cc = $("#yulan_pic");
	if(v=='close'){
		cc.hide();
		$(".need_hide_set").hide();
		$("#need_show_pos").hide();
		return false;
	}
	$(".need_hide_set").hide();
	$("#need_show_pos").show();
	$('#'+v+'_water_set_dom').show();
	cc.show();
	return false;
}
function do_form(o){
	$("#hidden_action").val(o);	
	$("#water_pic_form").submit();	
}
</script>
 <form method="post" id="water_pic_form" action="index.php?m=system/picset&a=saveData" autocomplete="off"> 
 <input type="hidden" value="save_pic_water_set" name="action" id="hidden_action" />
   <h1 class="c_bar">ˮӡ����</h1>
    <div class="c_content">
        <table class="table_common">
            <tr>
                <td class="one">ˮӡ����</td>
                <td>
              	<select class="w300" name="water_set" onchange="_reset_data(this);">
                    <option value="close" {if $pic_water_set.water_set eq 'close'} selected="selected" {/if}>������ˮӡ</option>
                    <option value="pic" {if $pic_water_set.water_set eq 'pic'} selected="selected" {/if}>ͼƬˮӡ</option>
                    <option value="text" {if $pic_water_set.water_set eq 'text'} selected="selected" {/if}>����ˮӡ</option>
                </select>
                </td>
            </tr>
        </table>
    </div>
    <div id="pic_water_set_dom" class="need_hide_set" style="{if $pic_water_set.water_set neq 'pic'}display:none;{/if}">
    <h1 class="c_bar">ͼƬˮӡ����</h1>
    <div class="c_content">
    <table class="table_common">
        <tr>
            <td class="one">{$lang.pictureset.pic_watermark_default}<!--ͼƬˮӡͼƬ--></td>
            <td>
            <div style="float:left;padding-top:10px; padding-right:65px;"><input type="file"  id="water_pic_upload_field"  size="20"  /> </div>
            <div id="water_pic_thumb" style="float:left;"><img  width="130" height="55" src="{$siteurl}shopdata/site/default_water.png?rand=<% echo mt_rand();%>" /></div>
            </td>
        </tr>
        <tr>
            <td class="one">{$lang.pictureset.pic_watermark_fade}          <!--͸����--></td>
            <td colspan="2"><input type="text"   size="20" title="{$lang.pictureset.pic_watermark_fade_desc}" class="input_notice w300"   value="{if $pic_water_set.font_app}{$pic_water_set.font_app}{else}80{/if}" name="font_app"/></td>
        </tr>
    </table>
    </div>
    </div><!--#����ͼƬˮӡ-->
<!--#��ʼ����ˮӡ-->
    <div id="text_water_set_dom" class="need_hide_set" style="{if $pic_water_set.water_set neq 'text'}display:none;{/if}">
    	<h1 class="c_bar">����ˮӡ����</h1>
        <div class="c_content">
            	<table class="table_common">
                	<tr>
                	<td class="one">{$lang.pictureset.text_watermark}</td>
                    <td><input type="text"  size="20"  value="{if $pic_water_set.water_font_text}{$pic_water_set.water_font_text}{else}{$lang.php_shop}{/if}"  name="water_font_text" title="{$lang.pictureset.water_font_set}" class="w300"/></td>
                	</tr>
                    <tr>
                	<td class="one">{$lang.pictureset.watermark_text_fade}</td>
                    <td ><input type="text"  class="w300" size="20"  value="{if $pic_water_set.font_app}{$pic_water_set.font_app}{else}80{/if}"  name=" font_app"/></td>
                	</tr>
                    <tr>
                	<td class="one">{$lang.pictureset.watermark_font}</td>
                    <td title="Ԥ����ʱ������ѡ������">
                  <select name="water_font" class="w300">
                    	<option value="0" selected="selected">{$lang.pictureset.please_select_font}</option>
                        {if $fonts}
                        	{foreach from=$fonts item=font}
            <option value="{$font.realname}" {if $pic_water_set.water_font eq $font.realname } selected="selected"{/if}>{$font.realname}</option>
                            {/foreach}
                        {/if}	
                    </select>
                    </td>
                	</tr>
                    <tr>
                    	<td class="one">{$lang.pictureset.font_size}</td>
                  <td><input type="text" value="{if $pic_water_set.font_size}{$pic_water_set.font_size}{else}10{/if}" name="font_size"  class="w300"   size="20" /></td>
              </tr>
                    <tr>
                    	<td class="one">{$lang.pictureset.font_color}</td>
                        <td><input type="text" value="{if $pic_water_set.font_color}{$pic_water_set.font_color}{else}#000000{/if}" name="font_color"  class="w300" size="20" id="select_color" /></td>
                    </tr>
                </table>
        </div>
    </div>
<div class="need_hide_set_pos"  id="need_show_pos" style="{if $pic_water_set.water_set eq 'close'}display:none;{/if}">

    <div class="c_content">
<table class="table_common">
	<tr>
    <td class="one">ˮӡͼλ��</td>
    <td colspan="10">
            <table class="table_common_ta">
                <tr>
                  <td>
                  <label><input name="water_position"  id="posta" {if $pic_water_set.water_position eq 'left_top'} checked="checked"{else}{/if}  value="left_top" type="radio">��������</label></td>
                 <td><label><input name="water_position" {if $pic_water_set.water_position eq 'top_center'} checked="checked"{/if}  value="top_center" type="radio">��������</label></td>
                  <td><label><input name="water_position" {if $pic_water_set.water_position eq 'right_top'} checked="checked"{/if} value="right_top" type="radio">��������</label></td>
                 </tr>
                    <tr>
                 <td><label><input name="water_position" {if $pic_water_set.water_position eq 'left_center'} checked="checked"{/if}  value="left_center" type="radio">�󲿾���</label></td>
                 <td><label><input name="water_position"  {if $pic_water_set.water_position eq 'center'} checked="checked"{/if}  value="center" type="radio">ͼƬ����</label></td>
                 <td><label><input name="water_position" {if $pic_water_set.water_position eq 'right_center'} checked="checked"{/if}  value="right_center" type="radio">�Ҳ�����</label></td>
                            </tr>
                            <tr>
                                <td><label><input name="water_position" {if $pic_water_set.water_position eq 'left_bottom'} checked="checked"{/if}  value="left_bottom" type="radio">�ײ�����</label></td>
                                <td><label><input name="water_position" {if $pic_water_set.water_position eq 'bottom_center'} checked="checked"{/if}  value="bottom_center" type="radio">�ײ�����</label></td>
                                <td><label><input name="water_position"  {if $pic_water_set.water_position eq 'bottom_right'} checked="checked"{/if}  value="bottom_right" type="radio" >�ײ�����</label></td>
                </tr>
            </table> 
    </td>
    </tr>
</table>

    </div>
</div>
<!--#end pic-->

        <div class="c_content">
        <table class="table_common">
        <tr>
            <td class="one"></td>
            <td>
                <input  type="button" onclick="do_form('save_pic_water_set');" value="�� ��"  class="block_button form_btn" style="display:none;"/>
                <a onclick="do_form('pic_review');" {if $pic_water_set.water_set eq 'close'} style="display:none"{/if} class="block_button" id="yulan_pic">Ԥ��</a>
               <a href="javascript:;" onclick="do_form('save_pic_water_set');"  class="block_button form_btn" >�� ��</a>    
            </td>
        </tr>
        </table>
        </div>
 </form>
 </div>

 
{include file="frame_footer.php"}
{/if}


{if $action eq 'viewpic'}
{include file="part.js.php"}
	<script type="text/javascript">
		$("#review_pic").upload({
			filename:'review_pic',
			post_params:{'sid':session_id},
			url:'index.php?m=system/picset&a=uploadPic',
			sucess:function(file,response){
				window.parent.closeLoading();
					var c = response.split('|');
					var e = c[1];
					switch(c[0]){
						case '1':
							return window.parent.showNotice(e);
						break;
						case '2':
							return $("#pic__view").attr({"src":e+'?rand='+Math.random()})
						break;
						default:alert(!empty(call)?call:System_overtime);return false;
					}
			}
		});
    </script>
<div class="center" style="line-height:35px; clear:both; margin:5px;">{$lang.pictureset.selete_pic_to_view}<!--���û��Ԥ��ͼ���������ϴ�һ��ͼƬ��ΪԤ��.-->
<input type="file"  id="review_pic"/></div>
<div style="text-align:center; margin:0px auto; padding:0px; background-color:#FAFAFA;" id="pic_review">
	<img src="{$pic_url}"  id="pic__view" width="{$w}" height="{$h}" style=" border:2px solid #900;"/>
</div>
{/if}