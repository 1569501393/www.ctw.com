<?php if( !defined('PHP_TEMPLATE') )exit(); ?>
{if $action eq 'clear_test_data'}
{include file="frame_header.php"}
<script type="text/javascript">
	$(document).ready(function(){
		$("#clear_all_site_data").submit(function(){
			if(!check_form_is_empty('must_in'))return false;
			if(!confirm("�˲�����ɾ�����еĲ�������,����ͼƬ��������Ϣ!\r\nɾ���󽫲��ָܻ�!\r\nȷ��Ҫɾ����?"))return false;
				var admin_dom = $("#admin_pass");
				var pass = $(admin_dom).val();
				if(empty(pass)){window.parent.showNotice(empty_admin_clear_pass);return false;}
				$(this).ajaxSubmit(function(data){
					switch(data){
						case 'OK':
							window.parent.showNotice(clear_test_data_ok);
							$(admin_dom).val('');
						break;
						case 'NO_AUTH':
							window.parent.showNotice(you_are_not_has_auth);
							$(admin_dom).val('');
						break;
						case 'ERROR_PASS':
							window.parent.showNotice(admin_pass_error);
							$(admin_dom).val('');
						break;
						case 'EMPTY_PASS':
							window.parent.showNotice(empty_admin_pass);
							$(admin_dom).val('');
						break;
						default:alert(data);
					}
				});
				return false;
		});
	});
</script>
<form method="post" action="index.php?m=system/manager&a=clearTestData" id="clear_all_site_data">
<div id="php_top_bar" class="">
	<div class="top_bar_pannel">
<a href="javascript:;" onclick="submit_form('clear_all_site_data');" class="block_button form_btn">ִ�����</a>
    </div>
</div>
<div id="php_right_main_content">
    <div class="table_item_base">
        <h1 class="c_bar">�����������</h1>
            <div class="c_content">
            <div class="notice_msg">�ر�����:�˲�����ɾ����վ������Ա����ϵͳĬ�������������������,һ��ɾ�������ɻָ�,������!</div>
            <table class="table_common">
                <tr>
                    <td class="one">�����봴ʼ������</td>    	
                    <td><input type="password" class="bg_input must_in" value=""  name="pass" id="admin_pass"/> </td>
                </tr>
            </table>
            </div>
    </div>
</div>
<input  class="form_submit" type="submit" value="ִ��ɾ��"  style="display:none;"/>
</form>
{include file="frame_footer.php"}	
{/if}
{if $action eq 'list'}
{include file="frame_header.php"}
<div id="php_top_bar" class="">
    <div class="top_bar_pannel">
        <a  href="javascript:;" onclick="do_manager(this,'index.php?m=system/manager&a=addManager');" class="block_button form_btn">{$lang.manager.add_manager}</a>
    <a class="block_button form_btn" id="do" onclick="delete_manager();">{$lang.manager.delete_select}</a>
     </div>
</div>
<script type="text/javascript">
$(function(){
	checkAllFormData('select_all','del');
	$(".edit_info").click(function(){
		var id = $(this).parent('tr').attr('id').split('_').pop();
		return do_manager(this,'index.php?m=system/manager&a=editManager&id='+id,edit_admin_info);
	})
});
function do_manager(obj,url,title){
	title = !title?$(obj).html():title;
	window.parent.showWindow(title,url,780,350);
}
function delete_manager(){
	var val = get_checkbox_val('del');
	if(!val){
		window.parent.showNotice('��ѡ��Ҫɾ��������!'); return false;	
	}
	var php_delete_confirm_msg  ='ɾ��������ǰ��ɾ�û������ݽ����ָܻ�!\r\nϵͳ������ǿ������Է�����!\r\nȷ��ɾ����?';
	if(!confirm(php_delete_confirm_msg))return false;
	$.post('index.php?m=system/manager&a=deleteManager',{manager:val},function(data){
		switch(data){
			case 'OK':
			window.parent.showNotice(php_do_ok);
			var jj = val.split(',');
			$(jj).each(function(i){
				$("#tag_"+jj[i]).remove();
			});
			break;
			default:alert(data);
		}
	});
}
</script>
<div id="php_right_main_content">
    {if $admin_list}
    <table class="table_list">
        <th><input type="checkbox" id="select_all"  ></th>
        <th>{$lang.manager.uid}</th>
        <th>{$lang.manager.realyname}</th>
        <th>{$lang.manager.grant_group}</th>
        <th><!--��������-->{$lang.manager.department}</th>
          <th width="100">{$lang.manager.is_disabled}</th>
     {foreach from=$admin_list item=admin}
        <tr class="tr" id="tag_{$admin.manager_id}">
            <td style="cursor:pointer;"  class="center delete_form">
            <input type="checkbox" class="del" value="{$admin.manager_id}"  {if $admin.is_orgin=='1'} disabled="disabled" {/if}/></td>
            <td style="cursor:pointer;"  class="center edit_info">{$admin.manager_name}{if $admin.is_orgin eq '1'}[{$lang.manager.system_orgin}]{/if}</td>
            <td  style="cursor:pointer;"  class="center edit_info">{$admin.manager_real_name}</td>
            <td style="cursor:pointer;"  class="center edit_info">{$admin.group_name}</td>
            <td style="cursor:pointer;"  class="center edit_info">{$admin.department}</td>
            <td style="cursor:pointer;"  class="center input edit_info">{if $admin.disabled=='1'}<b style="color:#F00">{$lang.manager.disabled}</b>{else}{$lang.manager.normal}{/if}</td>

        </tr>
        {/foreach}
    </table>	
    {/if}
</div>
{include file="frame_footer.php"}
 {/if}<!--��������Ա�б�����-->
{if $action eq 'addManager' || $action eq 'editManager'}
<script type="text/javascript">
$("#m_form").submit(function(){
	$(this).ajaxSubmit(function(data){
		switch($.trim(data)){
			case 'EMPTY_GROUP':
				window.parent.showNotice('��ѡ�����!');
			break;
			case 'EMPTY_NAME':
				window.parent.showNotice('����д����Ա����');
			break;
			case 'EMPTY_PASS':
				window.parent.showNotice('����д����Ա����');
			break;
			case 'HAS_EXIST':
				window.parent.showNotice('�Ѵ�����ͬ����Ա��������');
			break;
			case 'SYSTEM_NAME':
				alert('Ϊ�˱����������\r\n�벻Ҫʹ��ϵͳ���ù���Աsystem\r\n���˻�Ϊ�Զ�ִ��ʱ��¼��־ʹ��!');
			break;
			case 'OK':
				window.parent.showNotice(php_do_ok);
				_close_window_one();
				window.frames['rightFrame'].location.reload();
				break;
			default:alert(data);
		}
	});
	return false;
});
</script>
<form method="post" action="{if $action eq 'addManager'}index.php?m=system/manager&a=addManager{else}index.php?m=system/manager&a=editManager{/if}" id="m_form" autocomplete="off">
    <table class="table_common">
    	<tr>
        	<td class="one">{$lang.manager.user_id}:</td>
            <td><input type="text" style="width:200px;" value="{$manager.manager_name}" {if $action eq 'editManager'} disabled="disabled" readonly="readonly" {/if} name="name" class="bg_input form_text {if $action eq 'addManager'}check_is_empy{/if}"/><span class="msg_notice"></span></td>
        </tr>
        <tr>
        	<td class="one">{$lang.manager.pass}:</td>
            <td><input  type="password" value="" name="pass" style="width:200px;"  class="bg_input form_text  {if $action eq 'addManager'}check_is_empy{/if}" /><span class="msg_notice"></span></td>
        </tr>
        <tr>
        	<td class="one">{$lang.manager.group}:</td>
            <td><select name="group_id" style="width:200px;"  class="group_manager">
        <option value="0">{$lang.manager.emptygroup}</option>
        	{foreach from=$admin_group item=group}
<option value="{$group.group_id}" {if $group.group_id==$manager.group_id} selected="selected"{/if}>{$group.group_name}</option>
            {/foreach}
        </select></td>
        </tr>
        <tr>
        	<td class="one">{$lang.manager.name}:</td>
            <td><input type="text" style="width:200px;"  value="{$manager.manager_real_name}" name="realy_name" class="bg_input form_text" /></td>
        </tr>
        <tr>
        	<td class="one">{$lang.manager.close}:</td>
            <td><select name="disable" style="width:200px;" >
        	<option  value="0" {if $manager.disabled=='0'} selected="selected"{/if}>{$lang.manager.open}</option>
            <option value="1" {if $manager.disabled== '1'} selected="selected"{/if}>{$lang.manager.close}</option>
        </select></td>
        </tr>
        <tr>
        	<td class="one">{$lang.manager.department}<!--��������-->:</td>
            <td><input type="text" class="bg_input" style="width:200px;"  value="{$manager.department}"  name="department"/></td>
        </tr>
        <tr>
        	<td class="one">{$lang.manager.beizhu}:</td>
            <td><textarea style="height:50px; width:300px;" class="form_textarea" name="manager_desc">{if $manager.manager_desc neq 'NULL' || $manager.manager_desc neq '' }{$manager.manager_desc}{/if}</textarea></p>{if $action eq 'editManager'}
        <input type="hidden"  value="{$manager.manager_id}" name="manager_id"/>
        {/if}</td>
        </tr>
        <tr>
        	<td class="one"></td>
        	<td colspan="2"><a href="javascript:;" onclick="submit_form('m_form');" class="block_button form_btn">{$lang.php_save}</a></td>
        </tr>
    </table>
</form>
{/if}