<?Php if(!defined('PHP_TEMPLATE'))exit();?>
{include file="frame_header.php"}
{if $action eq 'closeSite'}
<script type="text/javascript">
	function  submitForm(options){
		var	options = options || {};
		var openedSite = '';
		var contents;
		if(options.opened=='open'){<!--����վ��-->
			openedSite = options.opened;
		}
		if(options.opened=='close' || options.opened=='update'){<!--�ر�վ�� ���¹�����Ϣ-->
			openedSite = options.opened;	
		}
		$("#status_info").val(openedSite);
		$("#open_site").submit();
	}
</script>
<div style="padding:8px 0px;">
<form method="post" id="open_site" action="index.php?m=system/sitetool&a=closeSite">
<table  class="table_common">
	<tr>
    	<td style="width:70px;" class="one">{$lang.sitetool.site_curent_status}</td>
        <td><b style="color:#060;">{$status_msg}</b></td>
    </tr>
    	<tr>
        <td colspan="2">{$editor}</td>
    </tr>
</table>
<div class="clear"></div>
<input type="hidden" value=""  name="opensite" id="status_info"/>
<div align="center"  style="padding-top:5px;">
	{if $status eq 'closed'}<!--�ѹر�-->
<input class="form_submit"  type="button" onclick="{literal}submitForm({opened:'update'}){/literal}" value="{$lang.sitetool.update_site_notice}" /><!--����ͣҵ����-->
<input class="form_submit" type="button" onclick="{literal}submitForm({opened:'open'}){/literal}"  value="{$lang.sitetool.open_site}" />
{else if $status eq 'opened'}
<input class="form_submit"  type="button"  onclick="{literal}submitForm({opened:'close'}){/literal}" value="{$lang.sitetool.close_site}"  />
	{/if}
</div>
</form>
</div>
{/if}<!--end action of closesite-->
{include file="frame_footer.php"}