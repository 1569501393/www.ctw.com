<?php  exit('msg');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title>��ʾ��Ϣ</title>
<link href="style/layout.css" rel="stylesheet" type="text/css"/>
<link href="style/{$__default_skin__}.css" id="call_css_tag_frame" rel="stylesheet" type="text/css" media="screen"/>
</head>
<body>
<div class="showMsg">
	<h5><samp>��ʾ��Ϣ</samp></h5>
    <div class="guery"><samp>{$msg}</samp></div>
    <div class="bottom">
    	<a href="{$url}">������������û���Զ���ת����������</a>
		 <script type="text/javascript">window.setTimeout("window.location.replace('{$url}');", 1*1000);</script>
	 </div>
</div>
</body>
</html>