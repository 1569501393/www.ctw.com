<?php exit('die'); ?>
 	<div class="left_bar_top"></div>
    {foreach from=$auth_menu key=key item=left_menu}
     <div  id="parent_id_{$left_menu.id}_model" style="{if $key eq '0'}display:block;{else}display:none;{/if}" class="need_hidden">
  {foreach from=$left_menu.childrens item=left_menu}
    <div class="php_ajax_tree">
    <ul onClick="_set_menu_click(this);"><span class="switch on">&nbsp;</span>{$left_menu.name}</ul>
    <div class="slide_menu">
    	{foreach from=$left_menu.childrens item=children_menu key=key name='tag'}
<li {if $smarty.foreach.tag.first} etag='1'{else}etag='0'{/if}><a onClick="showLoadingPage(this);"  is_ajax="{$children_menu.ajax_call|default:'0'}" onFocus="this.blur();" target="rightFrame" {if $children_menu.ajax_call eq '1'} w="{$children_menu.width}" h="{$children_menu.height}" rel="{$children_menu.link}" href="javascript:;"  rel_name="{$children_menu.name}"{else} href="{$children_menu.link}" {/if}   model="{$children_menu.model}">{$children_menu.name}</a></li>
   		 {/foreach}
         </div>
    </div>
    	{/foreach}
    </div>
{/foreach}