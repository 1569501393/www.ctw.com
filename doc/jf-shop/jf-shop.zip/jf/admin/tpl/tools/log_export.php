<?php exit('die'); ?><head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" /><style>td{vnd.ms-excel.numberformat:@}</style></head>

<table width="100%" border="1">
	{if $logtype == 'filelogs'}
	<tr>
		<th filter=all>{$lang.logs.th_operating_time}</th><!-- ����ʱ�� -->
		<th  filter=all>{$lang.logs.th_ipaddress}</th><!-- ip ��ַ -->
		<th  filter=all>{$lang.logs.th_errorpath}</th><!--�������·�� -->
		<th  filter=all>{$lang.logs.th_cause}</th><!--ԭ�� -->
		<th  filter=all>{$lang.logs.th_exec_statement}</th><!-- ִ����� -->
	</tr>
        {foreach from=$logs item=log}
        <tr>
            <td align="center" nowrap="nowrap">{$log.1}</td>
            <td>{$log.2}</td>
            <td >{$log.3}</td>
            <td >{$log[4]}</td>
            <td >
            <div class='hid'>{$log.5}</div>
            </td>
        </tr>
        {/foreach}
    {else}
	<tr>
		<th>{$lang.logs.th_who}</th> <!-- ����Ա -->
		<th >{$lang.logs.th_detail}</th><!-- ��־���� -->
		<th>{$lang.logs.th_operating_time}</th><!-- ʱ�� -->
		<th>{$lang.logs.th_ipaddress}</th><!-- ip��ַ  -->
		{if $actiontype != 'notshow'}
			<th>{$lang.logs.th_login_pass}</th><!-- ��¼���� -->
			<th>{$lang.logs.th_login_name}</th><!-- ��¼�� -->
		{/if}
	</tr>
	{foreach from=$logs item=log}
	<tr>
		<td align="center">{$log.who}</td>
		<td><div  >{$log.detail}</div></td>
		<td align="center">{$log.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
		<td align="center">{$log.ip}</td>
		{if $actiontype != 'notshow'}
			<td align="center">{$log.login_pass}</td>
			<td align="center">{$log.login_name}</td>
		{/if}
	</tr>
	{/foreach}
     {/if}
</table>
