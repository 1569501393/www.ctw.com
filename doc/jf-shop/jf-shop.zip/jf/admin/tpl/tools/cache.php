<?Php if(!defined('PHP_TEMPLATE'))exit(); ?>
{include file="frame_header.php"}
<form method="post" id="do_cache_config"  action="index.php?m=tools&a=saveCacheConfig">
<div id="php_top_bar"  class="php_bot_bar">
    <div class="top_bar_pannel">
     <a  href="javascript:;" onclick="window.location.reload();" class="block_button">ˢ ��</a>
    {if $can_config_cache} <a  href="javascript:;" onclick="submit_form('do_cache_config');" class="block_button form_btn">�� ��</a> {/if}
    </div>
</div>
<div id="php_right_main_content">
<script type="text/javascript">
function clearCache(opt){
	var url = 'index.php?m=tools&a=clearCache&task='+opt;
	$.get(url,function(data){
		switch(data){
			case 'OK':
			window.parent.showNotice(php_do_ok);return false;
			break;
			default:alert(data);return false;
		}
	});
}
function update_cates(){
	$.get('index.php?m=goods/goodsCategory&a=updateCatsCount',function(data){
		switch(data){
			case 'OK':window.parent.showNotice(php_do_ok);
			break;
			default:alert(data);
		}
	});	
}
$(function(){
	var tags = {if $can_config_cache}'cfg_cache'{else}'cfg_cache_count'{/if};
	$.table_bars($("#site_cache_config .menu li"),tags);
	
	$("#do_cache_config").submit(function(){
		$(this).ajaxSubmit(function(data){
			 switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
				break;
				default:alert(data);
			 }
		});
		return false;
	});
});
</script>
<div id="site_cache_config" class="table_scroll">
<div class="menu">
	<ul>
    	<li name="cfg_all">ȫ��</li>
       {if $can_config_cache} <li name="cfg_cache" class="wintable_curent">��������</li>{/if}
        <li name="cfg_cache_count" {if !$can_config_cache} class="wintable_curent" {/if}>����ͳ��</li>
        <li name="cfg_cache_clear">��������</li>
    </ul>
</div>
</div>

<div class="table_item_base">
{if $can_config_cache}
<div class="table_item" id="cfg_cache">
	<h1 class="c_bar">��������</h1>
    <div class="c_content">
    <div class="notice_msg no_margin"><% _e('�ڷǿ���ģʽʱ,ϵͳ�Ỻ������ҳ��������Լӿ�����ٶ�!<br />�������ý��ڷǿ���ģʽ������! ��λ��Ϊ��,������Ϊ����ģʽ���php.config.php �ҵ� DEV_TYPE ����Ϊ true ��');%></div>
            <div class="clear"></div>
	<table class="table_common">
    	<tr>
        	<td class="one"><% _e('ģ�建������');%></td>
            <td ><input  type="text" value="{$config.cache.tpl_cache|default:'3600'}" name="cache[tpl_cache]" /> <% _e('��');%>
            </td>
        </tr>
    	<tr>
        	<td class="one"><% _e('��̬��������');%></td>
            <td><input  type="text" value="{$config.cache.static_cache|default:'3600'}" name="cache[static_cache]" /> <% _e('��');%></td>
        </tr>
    	<tr>
        	<td class="one"><% _e('������Ʒ����ҳ����');%></td>
            <td >
<input type="checkbox" value="1" {if $config.cache.open_goods_detail_static_cache eq '1'} checked="checked"{/if} name="cache[open_goods_detail_static_cache]"  onclick="ddd_click(this);"/> <span style="{if $config.cache.open_goods_detail_static_cache neq '1'}display:none;{/if}">��������Ϊ <input  type="text" value="{$config.cache.goods_detail_static_cache|default:'3600'}" name="cache[goods_detail_static_cache]" /> <% _e('��');%></span></td>
        </tr>
        <tr>
        	<td class="one"><% _e('������ҳ');%></td>
            <td ><input type="text" value="{$config.cache.index_static_cache|default:'3600'}"  name="cache[index_static_cache]"/> <% _e('��');%></td>
        </tr>
        <tr>
        	<td class="one"><% _e('������ҳ');%></td>
            <td ><input type="text" value="{$config.cache.region_index_static_cache|default:'3600'}"  name="cache[region_index_static_cache]"/> <% _e('��');%></td>
        </tr>
        <tr>
        	<td class="one"><% _e('Ʒ����ҳ');%></td>
            <td ><input type="text" value="{$config.cache.goods_brands_index_static_cache|default:'3600'}"  name="cache[goods_brands_index_static_cache]"/> <% _e('��');%></td>
        </tr>
        <tr>
        	<td class="one"><% _e('Ʒ������ҳ');%></td>
            <td><input type="text" value="{$config.cache.goods_brands_detail_static_cache|default:'3600'}"  name="cache[goods_brands_detail_static_cache]"/> <% _e('��');%></td>
        </tr>
        <tr>
        	<td class="one"><% _e('�����ؼ�������');%></td>
            <td ><input type="text" value="{$config.cache.search_tag_static_cache|default:'3600'}"  name="cache[search_tag_static_cache]"/> <% _e('��');%></td>
        </tr>
        <tr>
        	<td class="one"><% _e('��Ʒ��������');%></td>
            <td ><input type="text" value="{$config.cache.goods_category_detail_static_cache|default:'3600'}"  name="cache[goods_category_detail_static_cache]"/> <% _e('��');%></td>
        </tr>
        <tr>
        	<td class="one"><% _e('����������ҳ');%></td>
            <td ><input type="text" value="{$config.cache.help_index_static_cache|default:'3600'}"  name="cache[help_index_static_cache]"/> <% _e('��');%></td>
        </tr>
    </table>
</div>
</div>
{/if}

<div class="table_item" id="cfg_cache_count">
	<h1 class="c_bar">����ͳ��</h1>
    <div class="c_content">
        <table class="table_common">
            <tr>
                <td class="one"><!--����ģʽ-->{$lang.cache.cache_model}</td>
                <td ><div class="float_left" style="line-height:40px; height:40px; font-weight:bold;">{$data.cache_model}</div>{if $data.cache_model eq 'file'} <a  href="javascript:;" class="block_button" onclick="load_cache_data();" >{$lang.cache.call_cache_status}</a>
                <!--���ػ���ͳ����Ϣ-->
                    <script type="text/javascript">
                        function load_cache_data(){
                            $.getJSON('index.php?m=tools&a=loadFileCache&jsoncallback=?',function(json){
                                $("#cache_file_number").html(json.total_file);
                                $("#cache_size").html(json.total_size);
                            });	
                        }
                    </script>{/if}
                </td>
            </tr>
            {if $data.server}
                <tr>
                    <td  class="one">{$lang.cache.mem_server}</td>
                    <td >
                    {foreach from=$data.server item='item'}
                     {$item} &nbsp;
                    {/foreach}
                    </td>
                </tr>
            {/if}
            {if $data.total_writen}
                <tr>
                    <td  class="one">{$lang.cache.mem_server_total_writen}</td>
                    <td >
                    {$data.total_writen}
                    </td>
                </tr>
            {/if}
            <tr>
                <td  class="one">ϵͳ�������ļ�</td>
                <td align="left" ><span id="cache_file_number">{if $cache_type neq 'file'}{$data.total_file}{$lang.cache.ge}{/if}</span></td>
            </tr>
                <tr>
                <td  class="one"><!--{$lang.cache.cache_total_size}--><% _e('��ʹ���ܿռ�')%></td>
                <td align="left"><span id="cache_size">{$data.total_size}</span></td>
            </tr>
            {if $cache_type neq 'file'}
                <tr>
                <td  class="one"><!--{$lang.cache.cache_total_size}--><% _e('�����ܿռ�')%></td>
                <td align="left" ><span id="cache_size">{$data.total_limit}</span></td>
            </tr>
            {/if}
            <tr>
                <td  class="one">��������</td>
                <td align="left" >{$data.cache_time}{$lang.cache.time}</td>
            </tr>
        </table>
	</div>
</div>

        <div class="table_item" id="cfg_cache_clear">
            <h1 class="c_bar">��������</h1>
                <div class="c_content">
                <a href="javascript:;" class="block_button" onclick="clearCache('all');"><% _e('ɾ�����л���');%></a>
                <a href="javascript:;" class="block_button" onclick="clearCache('static');"><% _e('ɾ����̬�ļ�����');%></a>
                {if $session_model eq 'file'}
                <a href="javascript:;" class="block_button" onclick="clearCache('session');"><% _e('ɾ��Session�ļ�');%></a>
                {/if}
                <a href="javascript:;" class="block_button" onclick="clearCache('all_tpl_cache');"><% _e('ɾ��ģ�建��');%></a>
                <a href="javascript:;" class="block_button" onclick="clearCache('temp_picture');"><% _e('ɾ����̬ͼƬ�ļ�');%></a>
                <div class="clear"></div>
                </div>
            </div>
    </div>
</div>
</div>
{include file="frame_footer.php"}