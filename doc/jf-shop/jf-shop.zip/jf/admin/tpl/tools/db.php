<?php  if(!defined('PHP_TEMPLATE'))exit();?>
{include file="frame_header.php"}
<script language="javascript" >
	{foreach from=$lang.db.js_html key=key item=item}
		var {$key} = "{$item}";
	{/foreach}
</script>
{if $action == 'showindex'}
<div id="php_right_main_content">
<script type="text/javascript">
$(document).ready(function(){
$("input[name='dbbaktype']").click(function(){
	var typevalue = $("input[name='dbbaktype'][checked]").val();
	if('dbdata' == typevalue){
		$("#dbdata").show();
	}else{
		$("#dbdata").hide();
	}
});
$("#dbsize").keyup(function(e){
	var value = 1;
	if(e.keyCode >= 49 && e.keyCode<= 57){
		value = e.keyCode - 48;
	}else if(e.keyCode >= 97 && e.keyCode<= 105){
		value = e.keyCode - 96;
	}else{
		value = 1;
	}
	$(this).val(value);
});
$("#phpdatabasebak").submit(function(){
	if(!confirm(ok_backup)){<!-- ȷ��Ҫ������ -->
		return false;
	}
	var url = "index.php?m=tools/db&a=dbbak&type=bak";
	<!-- �õ� Ҫ �ύ�� ���� -->
	var typevalue = $("input[name='dbbaktype'][checked]").val();
	$(this).attr("action", url);
	var op = {
			success:dababak
			}
	$("#phpdatabasebak").ajaxSubmit(op);
	$("#ing").show();
	$(".form_submit").attr("disabled", true);
	return false;
});
function dababak(data){
	switch($.trim(data)){
		case 'a': <!--�ɹ� -->
			showNotice(backdata_success);<!--�������ݳɹ� -->
			$("#load_imgs").hide();
			$("#ing").hide();
			$("#juanmumber").html("1");
			$(".form_submit").attr("disabled", false);
			break;
		case 'b':<!-- ���� -->
			showNotice(unknown_error_restart_backup);<!-- ����δ֪���������±��� -->
			$("#ing").hide();
			$("#juanmumber").html("1");
			$(".form_submit").attr("disabled", false);
			break;
		default: <!-- �������� -->
			<!-- ����ַ��� -->
			var item = data.split('|');
			$("#juanmumber").html(parseInt(item[0]) + 1);
			ajaxbak(item[1]);
			break
	}
}
function ajaxbak(url){
	$.get(url, dababak);
}
});
</script>
<div id="php_top_bar" class="php_bot_bar">
	<div class="top_bar_pannel">
		<div class="tb">
        <input type="submit"  class="form_submit form_btn" value="{$lang.db.html_beginning_backup_data}"  style="display:none;"/><!-- ��ʼ�������� -->
        <a href="javascript:;" class="form_btn block_button" onclick="submit_form('phpdatabasebak');">��ʼ��������</a>
        </div>
    </div>
</div>
<div id="php_right_main_content">
    <div class="table_item_base">
        <h1 class="c_bar">��������</h1>
            <div class="c_content">
            <form action="" method="post" id="phpdatabasebak">
                <table class="table_common">
                    <tr id="dbdata">
                        <td  class="one">{$lang.db.html_file_size_each_subvolume}</td><!-- ÿ���־��ļ���С -->
                        <td>
                            <input style="ime-mode: disabled;"  id="dbsize" type="text" value="1" name="dbsize"  maxlength="1" size="4"  onafterpaste="this.value=this.value.replace(/\D/g,'1')"/> M
                            <span class="blue">{$lang.db.html_file_size_each_subvolume_descipt}</span><!-- ֻ������1-9M -->
                        </td>
                    </tr>
                    <tr id="ing" style="display:none;">
                        <td colspan="2" align="center" class="no_border"><span id="load_imgs"><img src="images/zoomloader.gif" /> </span>{$lang.db.html_backup_before}<strong class="blue" id="juanmumber">1</strong>{$lang.db.html_backup_end}</td><!--��ʼ���ݵ� & �����벻Ҫ����������������ᷢ������  -->
                    </tr>
                </table>
            </form>
            </div>
        </div>
</div>
    {/if}
{if $action == 'datarestore'}
		<script type="text/javascript" >
		$(document).ready(function(){
			$("#checkall").click(function(){
				$(".selectop").attr("checked", $(this).attr("checked"));
			});
			$(".deletea").click(function(){
				if(!confirm(ok_delete))return false;
				var url = "index.php?m=tools/db&a=dbrevert&dirname=" + $(this).attr("name") + "&type=delete";
				var obj = $(this).parent().parent();
				$.get(url, function(data){
					switch($.trim(data)){
						case '1':
							window.parent.showNotice(not_file);<!-- û�д��ļ� -->
							break;
						case '0':
							window.parent.showNotice(delete_success);<!-- ɾ���ɹ� -->
							obj.remove();
							break;
						default:
							window.parent.showNotice(delete_fail);<!-- ɾ��ʧ�� -->
							break;
					}
				});
				return false;
			});
			$(".reverta").click(function(){
				if(!confirm(ok_restore)){<!-- ȷ��Ҫ��ԭ�� -->
					return false;
				}
				var url = "index.php?m=tools/db&a=dbrevert&dirname=" + $(this).attr("name") + "&type=revert";
				$.get(url, reverdata);
				$("#showrever").show();
				$("a").attr("disabled", true);
				$("#phpbatchdeletediv").attr("disabled", true);
				return false;
			});
			function reverdata(data){
				switch($.trim(data)){
					case "1":
						window.parent.showNotice(restore_success);<!-- ���ݻ�ԭ�ɹ� -->
						$("#showrever").hide();
						$("a").attr("disabled", false);
						$("#phpbatchdeletediv").attr("disabled", false);
						break;
					case "2":
						window.parent.showNotice(restore_fail_have_can_lose_file);<!-- ��������ʧ�ܣ��п���ȱʧ����ȷ -->
						$("#showrever").hide();
						$("a").attr("disabled", false);
						$("#phpbatchdeletediv").attr("disabled", false);
						break;
					default:
						<!-- ������ת���� -->
						var itemop = data.split("|");
						$("#showrevernumber").html(parseInt(itemop[0]) + 1);
						reverajax(itemop[1]);
						break;
				}
			}
			function reverajax(url){
				$.get(url, reverdata);
			}
			$("#phpbatchdeletediv").click(function(){
				if(!get_checkbox_val("selectop")){
					window.parent.showNotice('��ѡ��Ҫ����������!');
					return false;
				}
				if(!confirm(ok_delete))return false;
				$("#phpbatabase").attr("action", "index.php?m=tools/db&a=dbrevert");
				$("#phpbatabase").ajaxSubmit(function(data){
						switch($.trim(data)){
							case "2":
								window.parent.showNotice(data_submit_incorrect);<!-- ���ύ�����ݲ���ȷ -->
								break;
							case "1":
								window.parent.showNotice(delete_fail_hava_can_lose_file);<!-- ɾ��ʧ�ܣ��п���ȱ��ɾ�����ļ� -->
								break;
							case "0":
								window.parent.showNotice(delete_success);<!-- ɾ���ɹ� -->
								$(".all_select_tags").each(function(){
									if($(this).attr("checked") == true){
										$(this).parent().parent().remove();
									}
								});
								if($(".list_bak_db_info").size()<=0){
									window.location.reload();	
								}
								break;
							default:
								window.parent.showNotice(delete_fail);<!-- ɾ��ʧ�� -->
								break;
						}
				});
				return false;
			});
	});
		</script>
{if $filesname}
<div id="php_top_bar" class="php_bot_bar">
<div class="top_bar_pannel"><a class="block_button form_btn"  href="javascript:;" id="phpbatchdeletediv">{$lang.db.html_batch_delete}</a><!-- ����ɾ�� --></div>
</div>
{/if}
	<div id="php_right_main_content" >
			{if $filesname}
					<form  method="post" action="" id="phpbatabase">
						<table id="table_list" class="table_list">
							<tr>
								<th width="30"><input id="checkall" type="checkbox" value="" class="form_checkbox" /></th><!-- ȫѡ -->
								<th>{$lang.db.th_backup_time}</th><!-- ����ʱ�� -->
								<th>{$lang.db.th_total_size}</th><!-- �ܴ�С(M) -->
								<th>{$lang.db.th_volume}</th><!-- ���� -->
								<th>{$lang.db.th_delete}</th><!-- ɾ�� -->
								<th nowrap="nowrap">{$lang.db.th_restore}</th><!-- ��ԭ  -->
							</tr>
							{foreach from=$filesname item=file}
								<tr align="center" style="text-align: center;" class="list_bak_db_info">
									<td><input type="checkbox" class="form_checkbox selectop all_select_tags" value="{$file.name}" name="filename[]" /></td>
									<td>{$file.name|date_format:"%Y-%m-%d %H:%M:%S"}</td>
									<td>{$file.size}</td>
									<td>{$file.count}</td>
									<td align="center" style="text-align: center">
										<a class="deletea" title="{$lang.db.html_delete}" style="cursor:pointer" name="{$file.name}">{$lang.db.html_delete}</a><!-- ɾ�� -->
									</td>
									<td align="center" style="text-align: center">
										<a class="reverta" title="{$lang.db.html_restore}" style="cursor:pointer" name="{$file.name}&filename={$file.filename}&count={$file.count}&roll=1">{$lang.db.html_restore}</a><!-- ��ԭ -->
									</td>
								</tr>
							{/foreach}
							<tr id="showrever" style="display:none">
								<td colspan="6" align="center" style="text-align: center;">
									{$lang.db.html_restore_before}<strong id="showrevernumber">1</strong>{$lang.db.html_restore_end}
									<!-- ���ڻ�ԭ��  & �����벻Ҫ����������������ᶪʧ����-->
								</td>
							</tr>
						</table>
					</form>
			{else}
				<div class="notice_msg">
					{$lang.db.html_not_hava_restor_data_description}<!-- û�пɻ�ԭ������ -->
				</div>
			{/if}
	</div>
{elseif $action == 'recovery'}
	{literal}
		<script type="text/javascript" >
		$(function(){
			$("#phptabelupdate").submit(function(){
			$("#phptableupdatetype").val($("#fixed_val_select").val());
				$(this).ajaxSubmit(function(data){
					switch($.trim(data)){
						case "1":
							window.parent.showNotice(not_select_item_operate);<!-- ��û��ѡ��Ҫ�������� -->
							break
						case "2":
							window.parent.showNotice(please_select_type_operation);<!-- ��ѡ��Ҫ���������� -->
							break;
						case "0":
							window.parent.showNotice(operation_success);<!-- �����ɹ� -->
							window.location.reload();
							break;
						default:
							window.parent.showNotice(operation_fail);<!-- ����ʧ�� -->
							break;
					}
				});
				return false;
			});
			check_all('form_checkbox','form_checkbox');
		});
	</script>
{/literal}
	<div id="php_top_bar" class="php_bot_bar" style="text-align: left;">
    	<div class="tb">
        	<select name="tableupdate"  id="fixed_val_select" style="display:inline-block; margin-left:10px;">
             	<option value="optimization">�Ż�</option>
                <option value="repair">�޸�</option>
             </select>
		</div>
        <div class="tb">
             <a href="javascript:;"  onclick="submit_form('phptabelupdate')" type="submit" class="block_button form_btn">ִ��</a>
       </div>
	</div>
	<div  id="php_right_main_content">
        {if $tables}
			<form action="index.php?m=tools/db&a=dbrepair" id="phptabelupdate" method="post">
				<table class="table_list table_list_hover">
					<tr>
						<th><input type="checkbox" class="form_checkbox" checked="checked"  id="form_checkbox" /></th>
						<th>{$lang.db.th_table_name}</th><!-- ���� -->
						<th>{$lang.db.th_table_rows}</th><!-- ��¼�� -->
						<th>{$lang.db.th_data_length}</th><!-- ���� -->
						<th>{$lang.db.th_data_free}</th><!-- ��Ƭ -->
						<th>{$lang.db.th_update_time}</th><!-- �ϴθ���ʱ�� -->
						<th>{$lang.db.th_collation}</th><!-- �ַ��� -->
					</tr>
					{foreach from=$tables item=table}
						<tr>
							<td width="30" align="center"><input class="form_checkbox"  type="checkbox" checked="checked" name="tablenames[]" value="{$table.Name}" /></td>
							<td>{$table.Name}</td>
							<td width="60" align="right">{$table.Rows}</td>
							<td width="60" align="right" >{$table.Data_length}</td>
							<td align="right" class="data_free">{$table.Data_free}</td>
							<td align="center">{$table.Update_time}</td>
							<td>{$table.Collation}</td>
						</tr>
					{/foreach}
				</table>
				<input type="hidden" value=""  id="phptableupdatetype" name="tableupdatetype" />
			</form>
            {else}
            <div class="notice_msg">{$lang.php_nodata}</div>
            {/if}
	</div>
{/if}   
{include file="frame_footer.php"}