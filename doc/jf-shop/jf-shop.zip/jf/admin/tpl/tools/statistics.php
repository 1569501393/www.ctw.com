<?php if(!defined('IN_SYS'))exit('php'); ?>
{include file="frame_header.php"}
{include file="frame_js.php"}

{if $action  eq 'spider'}
<script type="text/javascript">
function deleteSpider(task){
	var u = 'index.php?m=tools/statistics&a=delete';
	if(confirm('ȷ��Ҫɾ����?�˲��������Իָ�!')){
		$.get(u,{task:task},function(data){
			if(data!='OK'){
				alert(data);return false;	
			}else{
				window.parent.showNotice('�����ɹ�!');window.location.reload();
			}
		});
	}
}
</script>
    <div id="php_top_bar">
        <div class="tb"><a  href="javascript:;"  class="block_button " onclick="deleteSpider('save')">{$lang.tools.sava1000}</a></div>
        <div class="tb"><a href="javascript:;" class="block_button" onclick="deleteSpider('all');">{$lang.tools.delect_all}</a></div>
        {if $spider}
        <div class="tb"><select onchange="window.location.href='index.php?m=tools/statistics&a=spider&spider='+$(this).val();"><option value=""><% _e('��ѡ��...');%></option>{foreach from=$spider item='s'}<option value="{$s.spider}" {if $cdata eq $s.spider} selected="selected"{/if}>{$s.spider}</option>{/foreach}
        </select></div>
        {/if}
    </div>
<div id="php_right_main_content">
    {if $data.total>0}
        <style type="text/css">
        .table_list td{ line-height:normal; padding:3px 5px;}
        .table_list .cc{ width:250px; overflow:hidden;}
        </style>
        <table class="table_list">
            <th>id</th>
            <th>spider</th>
            <th>ip</th>
            <th>agent</th>
            <th>page</th>
            <th>time</th>
            {foreach from=$data.data item='item'}
                <tr>
                    <td nowrap="nowrap" align="center" class="c">{$item.id}</td>
                    <td>{if $item.spider}<a href="index.php?m=tools/statistics&a=spider&spider={$item.spider}">{/if}{$item.spider|default:'unknow'}{if $item.spider}</a>{/if}</td>
                    <td nowrap="nowrap"><a href="index.php?m=tools/statistics&a=spider&ip={$item.ip}">{$item.ip}</a></td>
                    <td><div class="cc">{$item.agent}</div></td>
                    <td><div class="cc"><a href="{$item.vist_page}" target="_blank">{$item.vist_page}</a></div></td>
                    <td nowrap="nowrap">{$item.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
                </tr>
                {/foreach}
        </table>
        {$data.page}
    {else}
     <div class="notice_msg">�޿�������!</div>
    {/if}
    </div>
{/if}

{if $action eq 'spiderTypes'}
<form method="post" action="index.php?m=tools/statistics&a=spiderType" id="spider_type">
<div id="php_top_bar" class="php_bot_bar">
	<div class="tb"><a href="javascript:;" onclick="submit_form('spider_type');" class="block_button form_btn">�� ��</a></div>
</div>
<div id="php_right_main_content">
<div class="table_item_base">
    <h1 class="c_bar">֩����������</h1>
        <div class="c_content">
<textarea  name="spiler_list" class="input_notice" title="һ��һ�� ���� google:::google,feedfetcher-google,www.google.com,googlebot<br />��������˼Ϊ ֩������Ϊ google ,��Ӧ����ȡ�ؼ���Ϊ google,feedfetcher-google,www.google.com,googlebot ����ؼ����� , �ֿ�!���õĹؼ��ֲ��������� , �ַ�"   style="width:90%; margin-left:5px; height:300px; font-size:13px; line-height:18px;">{foreach from=$data item='list' key=key}
{$key}:::{$list.spider_key} 
{/foreach}
</textarea>
   </div>
 </div>
</div>
</form>
<script type="text/javascript">
	$(function(){
		$("#spider_type").submit(function(){

			 $(this).ajaxSubmit(function(data){
				  switch(data){
						case 'OK':
							window.parent.showNotice(php_do_ok);
						break;
						default:alert(data);
				  }
			});
			 return false;
		});
	});
</script>
{/if}

{if $action eq 'seoinfo'}
<div id="php_right_main_content">
<div class="notice_msg" id="reload_msg_tag" style="display:none;">
��������GoogleXml��ͼ����������robots.txt�ļ�,�����Ķ��˸��ļ����������޸�rss.php�ļ��µĴ���.<br />
ͬʱ��ȷ������վ�ĸ�Ŀ¼��д.ϵͳ���ڸ�Ŀ¼�´���sitemap�ļ��в������е�xml�ļ���������.
</div>
<div class="table_item_base">
 <h1 class="c_bar">վ���ͼ</h1>
 <div class="c_content">
	<a href="{$google_link}" class="block_button form_btn" target="_blank">����Google��ͼ</a>
    <a href="javascript:;" class="block_button" id="click_help_dom">�򿪰���</a>
    <div class="clear"></div>
</div>
<h1 class="c_bar">��½���</h1>
<div class="c_content">
        <div class="seo_info_page">
            <div class="d">
                  <a href="http://www.baidu.com/search/url_submit.html" target="_blank">�ٶ�baidu��վ��¼���</a> | 
                  <a href="http://www.google.com/addurl/" target="_blank">Google�ȸ���վ��¼���</a> |   <a href="http://directory.google.com/Top/World/Chinese_Simplified/" target="_blank">Dmoz��ҳĿ¼��½</a> | 
                  <a href="http://search.help.cn.yahoo.com/h4_4.html" target="_blank">Yahoo�Ż���վ��¼���</a> | 
                  <a href="http://siteexplorer.search.yahoo.com/submit" target="_blank">yahooӢ����վ��½���</a> | 
                  <a href="http://cn.bing.com/docs/submit.aspx" target="_blank">Bing��Ӧ��վ��¼���</a> | 
                  <a href="http://www.coodir.com/accounts/addsite.asp" target="_blank">Coodir��վĿ¼��¼���</a> | 
                  <a href="http://www.alexa.com/help/webmasters" target="_blank">Alexa��վ��¼���</a> | 
                  <a href="http://www.sogou.com/feedback/urlfeedback.php" target="_blank">Sogou�ѹ���վ��½���</a> | 
                  <a href="http://tellbot.youdao.com/report?keyFrom=help" target="_blank">�е�youdao��վ��½���</a> | 
                  <a href="http://www.soso.com/help/usb/urlsubmit.shtml" target="_blank">����SOSO��վ��½���</a></div>
            </div>
        </div>
  </div>
</div>
<script type="text/javascript">
	$(function(){
		close_open_helper('click_help_dom','reload_msg_tag');
	});
</script>
{/if}
{if $action eq 'spliter_flash'}
<div  id="php_top_bar" >
<form method="post" action="index.php?m=tools/statistics&a=spiderlocus" id="addvace_search_form" autocomplete="off">
<div class="tb">ʱ��:</div>
<div class="tb"><input type="text" name="start" id="start" onfocus="show_date(this);"  class="date date_input" value="{$start|date_format:'%Y-%m-%d'}"/></div>
<div class="tb">-</div>
<div class="tb"><input type="text" id="stop" name="stop" onfocus="show_date(this);"  class="date date_input" value="{$stop|date_format:'%Y-%m-%d'}"/></div>
<div class="tb">֩������</div>
<div class="tb">
<select  name="spider" id='spider'><option  value="">����</option>{if $spider_type}{foreach from=$spider_type item=item name=name}<option value="{$item.spider}"{if $spider eq $item.spider}selected{/if}>{$item.spider}</option>{/foreach}{/if}</select></div><div class="tb"><input type="submit" value="�鿴" class="form_submit" /></div>
</form>   
</div>
<div id="php_right_main_content">
<script type="text/javascript" src="js/swfobject.js"></script>
<script type="text/javascript">
$(function(){
	$("#addvace_search_form").submit(function(){			
		window.location.href=_s(this);	
		return false;
	});	   
});
</script>
{if $flash_lineurl}
<div style="text-align:left; z-index:-99999999999;" id="lineurl"></div>
<div style="text-align:left; z-index:-99999999999;">
<script type="text/javascript">
var so = new SWFObject("swf/char.swf?data={$flash_lineurl}", "lineurl", "100%", "230", "9", "#FFFFFF");
so.addParam("allowScriptAccess", "sameDomain");
so.addParam('wmode','opaque');
so.write("lineurl");
</script>
</div>
{/if} 
{if $flash_pieurl}
<div id="pieurl" style="text-align:left; z-index:-9999999999999;"></div>   
<div style="text-align:left; z-index:-99999999999999;">
<script type="text/javascript">
var so = new SWFObject("swf/char.swf?data={$flash_pieurl}", "pieurl", "100%", "230", "9", "#FFFFFF");
so.addParam("allowScriptAccess", "sameDomain");
so.addParam('wmode','opaque');
so.write("pieurl");
</script>
</div>
{/if}
</div>
{/if}
{include file="frame_footer.php"}