<?php  if(!defined('PHP_TEMPLATE'))exit();?>
{include file="frame_header.php"}
<script language="JavaScript">
{foreach from=$lang.logs.js_html key=key item=item} var {$key} = "{$item}"; {/foreach}
</script>
<script language='javascript'>
function deleteLogs(url){
	if(document.getElementById('logcount').value <= 100){
		return window.parent.showNotice(only_over_100_message);
	}
	if(confirm('ϵͳ�ᱣ��ǰ1000����־��¼.\r\nȷ��Ҫɾ����?�˲������ɻָ�!')){
		window.parent.showNotice(php_save_ok);window.location.href=url;
	}
	return false;
}
function export_do_log(obj){
	var opt = $("#do_submit_form");
	var du = _s(opt)+'&calltag=export';
	window.open(du);
}
$(function(){
	$("#do_submit_form").submit(function(){
		var u = _s($(this));
		window.location.href=u;
		return false;
	});
});

</script>
<form class='sub_com' method="post" action="index.php?m=tools/logs" id="do_submit_form" autocomplete="off"> 
<input type="hidden" value="{$logtype}" name="a" />
<div id="php_top_bar"> 
{if $logtype neq 'filelogs'}
    <div class="tb">�û�����</div>
    <div class="tb"><input type="text" value="{$search_tag.user}" name="user"  style="width:100px" /></div>
    <div class="tb">IP��</div>
    <div class="tb"><input type="text" value="{$search_tag.ip}" name="ip"  style="width:100px" /></div>
    <div class="tb">ʱ�䷶Χ��</div>
    <div class="tb"><input type="text" value="{$search_tag.start}"  onfocus="show_date(this);" class="date date_input" name="start" style="width:100px;" /></div>
    <div class="tb">-</div>
    <div class="tb"><input type="text" value="{$search_tag.end}" onfocus="show_date(this);" class="date date_input" name="end"  style="width:100px;"/></div>
    <div class="tb"><input type="submit" value="����" class="form_submit"  style="display:none"/>
    	<a href="javascript:;" onclick="submit_form('do_submit_form');" class="block_button form_btn">����</a>
    </div>
    <div class="tb"><a href="javascript:;" onclick="export_do_log(this)";  class="block_button form_btn">����</a></div>
{else}
    <div class="tb"><a href="index.php?m=tools/logs&a=dberrorlog&calltag=export" target="_blank" class="block_button form_btn">����</a></div>

{/if}
<div class="tb"><a href="javascript:;"  onclick="deleteLogs('{$dellogurl}')" class="block_button form_btn">ɾ��������־</a></div>
<input type='hidden' id='logcount' name='logcount' value='{$logcount}' />
</div>
</form>
<div id="php_right_main_content">
{if $logs.total>0}
<table class='table_list' width="100%">
	{if $logtype == 'filelogs'}<!--#�ļ���־-->
        <tr>
            <th>{$lang.logs.th_operating_time}</th><!-- ����ʱ�� -->
            <th>{$lang.logs.th_ipaddress}</th><!-- ip ��ַ -->
            <th>{$lang.logs.th_errorpath}</th><!--�������·�� -->
            <th>{$lang.logs.th_cause}</th><!--ԭ�� -->
            <th nowrap="nowrap">{$lang.logs.th_exec_statement}</th><!-- ִ����� -->
        </tr>
        {foreach from=$logs.data item=log}
        <tr>
            <td align="center" nowrap="nowrap">{$log.1}</td>
            <td>{$log.2}</td>
            <td class="hid">{$log.3}</td>
            <td class="hid">{$log[4]}</td>
            <td class="hid">
            <div class='hid'>{$log.5}</div>
            </td>
        </tr>
        {/foreach}
    {else}
	<tr> <!--#���ݿ���־�͵�¼��־-->
		<th>{$lang.logs.th_who}</th> <!-- ����Ա -->
		<th >{$lang.logs.th_detail}</th><!-- ��־���� -->
		<th>{$lang.logs.th_operating_time}</th><!-- ʱ�� -->
		<th>{$lang.logs.th_ipaddress}</th><!-- ip��ַ  -->
		{if $actiontype != 'notshow'}
			<th>{$lang.logs.th_login_pass}</th><!-- ��¼���� -->
			<th>{$lang.logs.th_login_name}</th><!-- ��¼�� -->
		{/if}
	</tr>
        {foreach from=$logs.data item=log}
        <tr>
            <td align="center">{$log.who}</td>
            <td><div  class="hid">{$log.detail}</div></td>
            <td align="center">{$log.time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
            <td align="center">{$log.ip}</td>
            {if $actiontype != 'notshow'}
                <td align="center">{$log.login_pass}</td>
                <td align="center">{$log.login_name}</td>
            {/if}
        </tr>
        {/foreach}
     {/if}
</table>
<div class="clear"></div>
 {$logs.page}
{else}
<div class="notice_msg">{$lang.php_nodata}</div>
{/if}
</div>
{include file="frame_footer.php"}