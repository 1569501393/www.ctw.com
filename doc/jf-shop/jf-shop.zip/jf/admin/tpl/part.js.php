<?php  exit('php');?>
{insert_scripts files='js/swfupload.js'}