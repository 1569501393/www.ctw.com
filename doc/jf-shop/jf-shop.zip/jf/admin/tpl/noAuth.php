<script type="text/javascript">try{window.parent.document.getElementById('ajax_show_msg').style.display='none';}catch(e){};</script>
<?php 
	echo $this->_noAuthMsg;
?>