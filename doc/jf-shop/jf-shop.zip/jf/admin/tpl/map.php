<?php exit('die'); ?>
<!--#��̨����Ա�˵���ʼ-->
<div id="show_admin_panel_menu">
<div class="top_menu"><div class="left"><!--�� �� ESC �� ��չ�� / �رմ˲˵�-->{$lang.m.esc}</div><div class="clear"></div></div>
<hr />
<!--Ȩ�޲˵�չ��-->
<div class="panel_main">
{foreach from=$auth_menu item=menu}
	<div class="tree_left">
    	<h1>{$menu.name}</h1>
        {foreach from=$menu.childrens  item=chi}
    <div class="nav">
    	��<b>{$chi.name}</b>
		<div class="children">  
        	{foreach from=$chi.childrens item=c}     
<P><a onFocus="this.blur();" title="{$c.desc}" target="rightFrame" is_ajax="{$c.ajax_call|default:'0'}" {if $c.ajax_call eq '1'} w="{$c.width}" h="{$c.height}" rel="{$c.link}" href="javascript:;"  rel_name="{$c.name}"{else} href="{$c.link}" {/if}  onClick="go_page(this);">|��{$c.name}</a></P>
        {/foreach}
        </div>
    </div>
    {/foreach}
</div>
{/foreach}
</div>
 <div class="clear"></div>
</div>