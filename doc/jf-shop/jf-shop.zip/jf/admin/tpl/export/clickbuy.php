<?php if (! defined ( 'PHP_TEMPLATE' ))exit ();?>
<!--�������񱨱���XLS-->
{if $action eq 'extract_clickbuy'}
<head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" />{literal}<style>td{vnd.ms-excel.numberformat:@}</style>{/literal}</head><table width="100%" border="1"><tr><th filter=all>{$lang.f.goods_name}</th><th filter=all>{$lang.f.clicknum}</th><th filter=all>{$lang.f.buynum}</th><th filter=all> {$lang.f.clickbuy}</th></tr>{foreach from=$data item=d}
<tr><td>{$d.mem_username}</td><td>{$d.date|date_format:"%Y-%m-%d %H:%M:%S"}</td><td>{$d.manager_name}{$lang.f.daichongzhi}</td><td>{$d.current_money}</td></tr>{/foreach}
<tr>
	<td colspan="11" align="right">{$lang.f.curent_has} {$other.total} <!--��,��ת��-->{$lang.f.curent_has_1} {$other.total_add}<!--Ԫ-->{$lang.php_yuan} ,<!--��ת��-->{$lang.f.total_zhuanchu} {$other.total_cut} {$lang.php_yuan}<!--Ԫ-->      {$lang.f.zongjine} <!--�����-->: {$other.over_all_total} <!--Ԫ-->{$lang.php_yuan}</td>
</tr>
</table>
{/if}