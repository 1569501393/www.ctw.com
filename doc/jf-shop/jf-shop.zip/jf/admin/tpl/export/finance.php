<?php if (! defined ( 'PHP_TEMPLATE' ))exit ();?>
<!--�������񱨱���XLS-->
{if $action eq 'export_xls'}
<head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" />{literal}<style>td{vnd.ms-excel.numberformat:@}</style>{/literal}</head><table width="100%" border="1"><tr><th filter=all>{$lang.f.user}</th><th filter=all>{$lang.f.jiaoyitime}</th><th filter=all>{$lang.f.yewuzhaiyao}</th><th filter=all> {$lang.f.curent_moneys}</th><th filter=all>{$lang.f.save_moneys_num}</th><th filter=all>{$lang.f.out_moneys_num}</th><th filter=all>{$lang.f.dangqian_yue}</th><th filter=all>{$lang.f.pay_method}</th><th filter=all>{$lang.f.pay_danhao}</th><th filter=all>{$lang.f.order_nos}</th><th filter=all>{$lang.f.guanlibeizhu}</th></tr>{foreach from=$data item=d}
<tr><td>{$d.mem_username}</td><td>{$d.date|date_format:"%Y-%m-%d %H:%M:%S"}</td><td>{$d.manager_name}{$lang.f.daichongzhi}</td><td>{$d.current_money}</td><td>{$d.add_money|default:'-'}</td><td>{$d.cut_money|default:'-'}</td><td>{$d.result_money}</td><td>{$d.pay_name|default:'-'}</td><td>{$d.waterline_no|default:'-'}</td><td>{$d.order_sn|default:'-'}</td><td>{$d.desc}</td></tr>{/foreach}
<tr>
	<td colspan="11" align="right">{$lang.f.curent_has} {$other.total} <!--��,��ת��-->{$lang.f.curent_has_1} {$other.total_add}<!--Ԫ-->{$lang.php_yuan} ,<!--��ת��-->{$lang.f.total_zhuanchu} {$other.total_cut} {$lang.php_yuan}<!--Ԫ-->      {$lang.f.zongjine} <!--�����-->: {$other.over_all_total} <!--Ԫ-->{$lang.php_yuan}</td>
</tr>
</table>
{/if}


{if $action eq 'extract_clickbuy'}
<head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" />{literal}<style>td{vnd.ms-excel.numberformat:@}</style>{/literal}</head><table width="100%" border="1"><tr><th filter=all>{$lang.f.goods_name}</th><th filter=all>{$lang.f.clicknum}</th><th filter=all>{$lang.f.buynum}</th><th filter=all> {$lang.f.clickbuy}</th></tr>{foreach from=$data item=d name=name}
{if $d.ratio}
<tr><td>{$d.gname}</td><td>{$d.clicknum}</td><td>{$d.c}</td><td>{$d.ratio}</td></tr>
{/if}
{/foreach}

</table>
{/if}

{if $action eq 'salemoney_export'}
<head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" />{literal}<style>td{vnd.ms-excel.numberformat:@}</style>{/literal}</head><table width="100%" border="1"><tr><th filter=all>{$lang.f.date}</th><th filter=all>{$lang.f.clicknum}</th><th filter=all>{$lang.f.buynum}</th></tr>{foreach from=$data item=d}
<tr><td>{$d.date}</td><td>{$d.ordernum}</td><td>{$d.value_ration}%</td></tr>{/foreach}
<tr><td colspan="3">�ܼ�{$count} ��ֵ:{$maxorder.ordernum}</td></tr>
</table>
{/if}