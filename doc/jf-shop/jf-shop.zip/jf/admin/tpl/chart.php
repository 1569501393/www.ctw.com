<?php exit('die'); ?>
{if $action eq 'month' || $action eq 'year' || $action eq 'day' || $action eq 'show_char'}
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="{$width|default:'100%'}" height="{$height|default:'180'}"  align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="wmode" value="opaque" />
<param name="scale" value="noscale" />
<param name="movie" value="swf/char.swf?data={$flash_chart_url}" />
<param name="quality" value="high" />
<param name="quality" value="high" />
<param name="bgcolor" value="#FFFFFF" />
<embed src="swf/char.swf?data={$flash_chart_url}" quality="high" bgcolor="#FFFFFF" width="{$width|default:'100%'}" height="{$height|default:'180'}"  align="middle" allowScriptAccess="sameDomain" wmode="opaque"  scale="noscale" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"/>
</object>
{/if}