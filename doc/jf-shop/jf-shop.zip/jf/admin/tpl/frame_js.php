<?php exit('c');?>
<script language="JavaScript">
var google_map_key = '{$google_map_api_keys}';
var check_upload_pass;
var admin_root = '{$admin_root_url}';
var bar_right = true;
var session_id = '{$session_id}';
{foreach from=$lang.common.js_languages key=key item=item}var {$key} = "{$item}";{/foreach}
</script>