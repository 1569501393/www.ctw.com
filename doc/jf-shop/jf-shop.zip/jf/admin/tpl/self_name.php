<?php exit('die'); ?>
      <tr>
   	<td class="one">���ɾ�̬���ļ���</td>
    <td>
<input class="input_notice w300" title="{$lang.self_for_html}" type="text" value="{$html_extend.self_url}" maxlength="255"  name="html_extend[self_url]" /></td>
   </tr>