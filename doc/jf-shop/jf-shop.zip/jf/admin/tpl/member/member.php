<?php if (! defined ( 'PHP_TEMPLATE' ))exit (); ?>
{if $actiontitle eq 'actiontitle'}
	{include file='frame_header.php'}
	<script type="text/javascript">
	{foreach from=$lang.member.js_html key=key item=item}
		var {$key} = "{$item}";
	{/foreach}
var qurl = "index.php?m=member/member";
	function member_export(obj,tag){
		switch(tag){
			case 'phone':
				window.open('index.php?m=member&a=export&type=mobile');
			break;
			case 'mail':
				window.open('index.php?m=member&a=export&type=mail');
			break;
			default:
				var ids = get_checkbox_val('form_checkbox_val');
				window.parent.showWindow($(obj).html(),'index.php?m=member&a=export'+'&select_id='+ids,600,300);
				return false;
		}
	}
	function show_member_detail(o){
			var id = $(o).attr('name');
			var _this = $(o);
			var o = $('.show_member_detail_'+id);
			if(_this.attr("has_load")==1){
				$(o).hide();
				_this.attr({"has_load":'0'});
			}else if(_this.attr("has_load")==0){
				$(o).show();
				_this.attr({"has_load":'1'});
			}else{
				$.get("index.php?m=member&a=detail&memid=" + id, function(data){
					_this.attr({"has_load":'1'});
					_this.parent().parent().after(data);
				});
			}
			return false;
	}
	function show_all_detail(){
		$(".show_member_detail_info").each(function(){
			show_member_detail($(this));
		});	
	}
	$(function(){
		
		$("#search_memebr").submit(function(){
			var u = _s($(this));
			window.location.href=u;
			return false;
		});
		$("#number_send_email").click(function(){
			$("#qsendemail").show();
		});
	});
function butch_search_data(obj){
	var tag = $("#subsearch");
	var none = $(tag).css('display').toLowerCase()=='none'?true:false;
	if(none){
		var off = $(obj).offset();
		var tw = $(tag).width();
		var th = $(tag).height();
		var left = off.left-(tw/2)+75;
		var h = $(obj).height();
		var top = off.top+28;
		$(tag).css({"left":left+'px',"top":top+'px'}).fadeIn();	
	}else{
		$(tag).fadeOut();	
	}
}
$(function(){
	$("#search_memebr_advance").submit(function(){
		var u = _s($(this));
		window.location.href = u;
		return false;		
	});
});
</script>
<form method="post" action="index.php?m=member&a=memberList" id="search_memebr" autocomplete="off">
<div id="php_top_bar" {if $action eq 'adduser'} class="php_bot_bar"{/if}>
    <div class="top_bar_pannel">
    {if $action neq 'adduser'}
     <div class="tb">�û��� ��</div>
    <div class="tb"><input type="text" value="{$eget.key}" style="width:100px; height:18px;"  class="form_input" name="key"/></div>
    <div class="tb"><a href="javascript:;" onclick="submit_form('search_memebr');" class="block_button form_btn">����</a></div>
    <div class="tb"><a href="javascript:;"  onclick="butch_search_data(this);" class="block_button">�߼�����</a></div>
    
    <div class="tb"><a href="javascript:;"  onclick="member_export(this);" class="block_button" >��������</a></div>
    <div class="tb"><a href="javascript:;" onclick="member_export(this,'mail');" class="block_button">�û����䵼��</a></div>
    <div class="tb"><a href="javascript:;" onclick="member_export(this,'phone');" class="block_button">�û��ֻ��ŵ���</a></div>
    <div class="tb"><a id="number_send_email" href="#qsendemail" class="block_button">������Ϣ</a></div>
    <div class="tb" style="float:right;"><a href="javascript:;" onclick="show_all_detail();" class="block_button form_btn">ȫ������</a></div>
    {else}
    <div class="tb"><a href="javascript:;" onclick="window.location.reload();" class="block_button" />ˢ��</a></div>
    <div class="tb"><a href="javascript:;"  class="block_button" onclick="submit_form('phpregister');">�� ��</a></div>
    {/if} 
    </div>
</div>
</form>
<script type="text/javascript" charset="GBK" src="js/jscal2.js"></script>
<form method="post" action="index.php?m=member&a=memberList" id="search_memebr_advance" autocomplete="off">
<div id="subsearch">
<table cellpadding="2" cellspacing="2">
	<tr>
    	<td nowrap="nowrap">�� �� ����</td>
        <td><input type="text" value="{$eget.key}" name="key"  style="width:135px;"/></td>
		<td>��&nbsp;&nbsp;&nbsp;&nbsp;����</td>
        <td><select name="levelpoint" style="width:140px;"><option value="">{$lang.member.html_all}</option>{foreach from=$memlevelnames item=item}<option value="{$item.level_point}" {if $eget.levelpoint == $item.level_point} selected="selected"{/if}>{$item.level_name}</option>{/foreach}</select></td>
    </tr>
    <tr>
    	<td>״&nbsp;&nbsp;&nbsp;&nbsp;̬��</td>
        <td><select name="memstate" style="width:140px;">
         	<option value="0">{$lang.member.html_all}</option>
            <option value="1" {if $eget.memstate == "1"} selected="selected"{/if}>{$lang.member.html_open}</option>
            <option value="2" {if $eget.memstate == "2"} selected="selected"{/if}>{$lang.member.html_disable}</option>
         </select></td>
        <td  nowrap="nowrap">��&nbsp;&nbsp;&nbsp;&nbsp;�飺</td>
        <td><select name="groupid" style="width:140px;"><option value="0">��ѡ��</option>{foreach from=$memgroups item='group'}<option {if $eget.groupid eq $group.group_id} selected="selected"{/if} value="{$group.group_id}">{$group.group_name}</option>{/foreach}</select>
</td>
    </tr>
    <tr>
    	<td nowrap="nowrap">ע��ʱ�䣺</td>
        <td><input type="text" value="{$eget.start}" onfocus="show_date(this);" class="date date_input w150" name="start"  style="width:135px;"/></td>
        <td nowrap="nowrap">����ʱ�䣺</td>
        <td><input value="{$eget.end}"  onfocus="show_date(this);" class="date date_input w150"  name="end" type="text" style="width:135px" /></td>
    </tr>
    <tr>
    	<td>��&nbsp;&nbsp;&nbsp;&nbsp;�䣺</td>
        <td><input type="text" value="{$eget.email}"  name="email" style="width:135px;"/></td>
        <td>��&nbsp;&nbsp;&nbsp;&nbsp;����</td>
        <td><input type="text" value="{$eget.mobile}"  name="mobile"  style="width:135px;"/></td>
    </tr>
    <tr>
    	<td colspan="4">
        <input  value="����"  type="submit" class="form_submit"/>  
         <input  value="�ر�"  type="button" onclick="$('#subsearch').hide();" class="form_submit"/>
        </td>
    </tr>
</table>
</div>
</form>

	<div class="clear"></div>
{/if}

{if $action == ''}
    {if $showdata}
            <div id="php_right_main_content">
            	{if $members}
			            <form action="" method="post" id="frmmember">
			                <table class = "table_list table_list_hover" >
			                    <tr>
			                        <th nowrap="nowrap"><input type="checkbox" id="select_all_member"/></th><!-- ȫѡ -->
                                     <th>{$lang.member.th_opertion}</th><!-- ���� -->
                                     <th>{$lang.member.th_usertype}</th>
			                        <th>{$lang.member.th_username}</th><!-- �û��� -->
			                        <th>{$lang.member.th_email}</th><!-- ���� -->
			                      
			                        <th>{$lang.member.th_mobile}</th><!-- �ֻ� -->
			<!--                        <th>{$lang.member.th_group}</th> �û��� -->
			                        <th>{$lang.member.th_level}</th><!-- �ȼ� -->
                                     <th>����</th><!-- �ȼ� -->
			                        <th nowrap="nowrap">{$lang.member.th_state}</th><!-- ״̬ -->
			                        <th>{$lang.member.th_login_last_time}</th><!-- ����½ʱ�� -->
			                       
			                    </tr>
			                    {foreach from=$members item=mem}
			                    	<tr id="memddd_{$mem.mem_id}" class="ssss">
			                        	<td align="center"><input type="checkbox" value="{$mem.mem_id}" id='check{$mem.mem_id}' class="form_checkbox form_checkbox_val" name="memoperate[]" /></td>
           <td align="center" nowrap="nowrap" width="65">{if $deletemember}<a class="delete_a" name="{$mem.mem_id}" title="{$lang.member.html_delete}" style="cursor:pointer">ɾ</a>{/if} {if $editmember} <a  href="index.php?m=member&a=editmember&memid={$mem.mem_id}">��</a>{/if}  <a onclick="show_member_detail(this);" class="show_member_detail_info" href="javascript:;" name="{$mem.mem_id}" title="{$lang.member.html_detail}">��</a>
			                            </td>
			                        	<td>{$mem.mem_username}</td>
			                            <td>{$mem.mem_email}</td>
			                            
			                            <td align="center" nowrap="nowrap">{$mem.mem_mobile}</td>
			<!--                            <td>{$mem.group_name}</td>-->
			                            <td nowrap="nowrap" align="center">{$mem.mem_level_name}</td>
                                         <td nowrap="nowrap" align="center"><a href="index.php?m=member&a=memberList&groupid={$mem.mem_group}">{$mem.mem_group_name}</a></td>
			                            <td align="center" nowrap="nowrap">{if $mem.mem_state == 2}<a href="index.php?m=member/member&a=memberList&memstate=2"><span class="red">��</span></a>{else}<a href="index.php?m=member/member&a=memberList&page=1&memstate=1"><span class="green">��</span></a>{/if}</td><!-- ����  ���� -->
			                            <td align="center" nowrap="nowrap">{$mem.mem_lasttime|date_format:"%Y-%m-%d %H:%M:%S"}</td>
			                 
			                        </tr>
			                    {/foreach}
			                </table>
                            <div class="clear"></div>
                        <div id="memberpageurl">
			               {$pageurl}
			             </div>
			                 <textarea id="textareapagecontent" style="display:none" name="textareapagecontent"></textarea>
			                 <input type="hidden" name="sendmailtitle" id="sendmailtitle"  value="" />
			                 <input type="hidden" name="sendmailmode" id="sendmailmode" value=""  />
			            </form>
			    {else}
			    	<div align="center" class="notice_msg" >{$lang.member.html_no_data_temporarily}</div><!-- ���޴����� -->
			    {/if}
    			<div id="qsendemail" style="display:none;">

    	<script type="text/javascript">
    		$(document).ready(function(){
				checkAllFormData('select_all_member','form_checkbox_val');
				$("#ajax_send_messages").submit(function(){
					var t = $.trim($("#emailtitle").val());
					if(empty(t))return window.parent.showNotice(email_title_not_null);
					var type = get_checkbox_val('send_input');
					if(!type)return window.parent.showNotice(sendmode_than_choose_one);
					var is_all = $("#check_all_members").attr("checked");
					if(!is_all){
						var select_val = get_checkbox_val('form_checkbox_val');
						if(empty(select_val))return window.parent.showNotice(not_hava_chonse_options_item);
					}
					$(this).append('<input type="hiden" value='+select_val+'  name="memoperate_ids"/>');
					$(this).ajaxSubmit(function(data){
						var e = data.split('|');
						switch(e[0]){
							case '1':
							window.parent.showNotice(e[1]);
							return false;
							break;
							case '0':
							window.parent.showNotice(e[1]);
							$("#qsendemail").hide();
							break;
							default:
							alert(data);
						}
					});return false;
				})
				<!-- ��� ���� �ʼ� -->
				$("#mailsubmit").click(function(){
					$("#ajax_send_messages").submit();
				});
$(".delete_a").click(function(){
	if(!confirm("ȷ��Ҫɾ���𣿴˲������ɻָ�!\r\n��ɾ��������ɾ�����Ա��ص���������,������Ա��������Ϣ,�ʽ���Ϣ,������Ϣ��"))return false;
	var id = $(this).attr("name");
	var url = "index.php?m=member&a=deletemember&memid=" + id;
	$.get(url,function(data){
		switch(data){
			case "OK":
				window.parent.showNotice(php_do_ok);
				$("#memddd_"+id).remove();
				if($('.ssss').length<1)window.location.reload();
				break;
			case 'EMPTY_USER':
				window.parent.showNotice('�޴��û�!');
				break;
			case 'HAS_MONEY':
				window.parent.showNotice('���û��´����ʽ�,����ɾ��!');
			break;
			case 'HAS_ORDER':
				window.parent.showNotice('���û��´��ڶ���,����ɾ��!');
			break;
			default:
			alert(data);
		}
	});
});
    		});
			function cancelsendmail(){$("#qsendemail").hide();}
        </script>

	<div class="main_content">
    <form method="post" id="ajax_send_messages" action="index.php?m=member&a=mumber_send_email">
		<fieldset>
			<legend>{$lang.member.js_html.send_message}</legend><!-- ������Ϣ -->
	        <table class="table_common">
	            <tr>
	                <td class="one">{$lang.member.td_email_title}</td><!-- �ʼ����� -->
	                <td>
	                	<span style="float:left">
	                		<input type="text" id="emailtitle" name="sendmailtitle" style="float:left" class="form_input" />
	                        <span class="blue">*</span>
	                    </span>
	                    <span class="block_button" id="mailsubmit" style="float:right">{$lang.member.html_send}</span><!-- ���� -->
	                    <span class="block_button" onclick="cancelsendmail()" style="float:right" ><!--ȡ��-->{$lang.php_cache}</span>
	                </td>
	            </tr>
                <tr>
                	<td class="one"><!--�����л�Ա����-->{$lang.member.send_all_message}</td>
                    <td><input  type="checkbox" value="ok"  id="check_all_members" name="all_members" /> <!--��ѡ�˴�����������û�����.ע��:�˲������û���������.-->{$lang.member.send_all_message_info}</td>
                </tr>
	            <tr>
	            	<td class="one">{$lang.member.td_send_mode}</td><!-- ���ͷ�ʽ -->
	                <td>
	                	<input type="checkbox" name="sendmode[]" class="send_input" value="email" />{$lang.member.html_send_email}&nbsp;<!-- email���� -->
	                    <input type="checkbox" name="sendmode[]" class="send_input" value="sms" />{$lang.member.html_send_sms}&nbsp;<!-- վ����Ϣ���� -->
<!--	                    <input type="checkbox" name="sendmode" value="mobile" />{$lang.member.html_send_mobile}&nbsp; �ֻ����� -->
<!--	                    <span class="blue">{$lang.member.html_send_description}</span> ����ѡ��һ��,�ֻ�ֻ֧�ִ��ı�,����ᷢ��δ֪�Ĵ��� -->
	                </td>
	            </tr>
	            <tr>
	                <td colspan="2" style="padding:5px 0px; border-bottom:none;">
	                    {$editor}
	                </td>
	            </tr>
	        </table>
        </fieldset></form>
    </div>

                </div>
            </div>
    {/if}
    <input  type="hidden" value="{$showdata}" id="showdata" />
	{include file='frame_footer.php'}
{/if}

{if $action == 'adduser'}
<form action="" id="phpregister" autocomplete="off" method="post"  >
	<div id="php_right_main_content">
            	<script type="text/javascript" >
					$(document).ready(function(){
						<!-- �� �� -->
						$("#php_member_info_reset").click(function(){
							var id = $(this).attr("name");
							var url = qurl + "&a=editmember&memid=" + id + "&page=" + $("#curpage").val();
							location.href = url;
						});
						<!-- ����û� -->
						$("#username").blur(function(){
							checkUserName();
						});
						<!-- ������� -->
						$("#password").blur(function(){
							checkPassWord();
						});
						<!-- ��� ȷ�� ���� -->
						$("#repass").blur(function(){
							checkRePass();
						});
						<!-- ��� ����  �Ƿ� ���� Ҫ�� -->
						$("#email").blur(function(){
							checkEmail();
						});
						$("#mobile").blur(function(){
							checkMobile();
						});
						
						<!-- �������ύ�¼� -->
						$("#phpregister").submit(function(){
							<!-- �ж� �� �޸� ���� ���� -->
							var memedittype = $("#memedittype").val();
							if(memedittype != 'memedittype'){
								<!--���� ����û����� -->
								if(!checkUserName()){
									window.parent.showNotice(username_falseness);<!-- �û�������ȷ -->
									$("#username").focus();
									return false;
								}
							}
							{/literal}
							{if $action_add eq 'add_user'}
							{literal}
							<!-- ��� ���� -->
							if(!checkPassWord()){
								showNotice(please_check_pass);<!-- �������� -->
								$("#password").focus();
								return false;
							}
							<!-- ��� ȷ������ -->
							if(!checkRePass()){
								showNotice(please_check_pass);<!-- �������� -->
								$("#repass").focus();
								return false;
							}
							{/literal}
							{/if}
							{literal}
							<!-- ��� email -->
							if(!checkEmail()){
								$("#email").focus();
								showNotice(please_check_email);<!-- �������� -->
								return false;
							}
							<!-- ѡ����� ע�� -->
							if(!checkMobile()){
								showNotice(mobile_falseness);<!-- �ֻ����벻��ȷ -->
								$("#mobile").focus();
								return false;
							}
							<!-- ��ʼ ��� ���� �Ƿ���д -->
							var flg = true;
							var type;
							$("#phpregister").find("span[name='require']").each(function(i){
								var obj = $(this).prev();
								<!-- �������-->
								type = $(obj).attr("type");
								if(type == "text/javascript"){
									obj = $(obj).prev();
									<!-- ������� -->
									type = $(obj).attr("type");
								}
								var val = "";
								<!-- �õ� ֵ -->
								if(type == "checkbox" || type == "radio"){
									var name  = $(obj).attr("name");
									var val = "";
									$("[name='"+name+"']").each(function(){
										if($(this).attr("checked")){
											val = "ok";
										}
									});
								}else{
									val = $(obj).val();
								}
								<!-- �ж�ֵ -->
								if(empty(val)){
									$(this).html(the_item_required);<!-- ������� -->
									flg = false;
								}else{$(this).html("*");}
							});
							<!-- ����б����û����д �� ���� -->
							if(!flg){
								showNotice(have_required_are_not_required);<!-- �б�����û����д -->
								return false;
							}
							<!-- ajax �ύ ���� -->
							var option={
								success:memberitem
							}
							
							var url = qurl + "&a=adduser";
							var memedittype = $("#memedittype").val();
							<!-- ��� �� �޸�  ���޸� �ύ�ĵ�ַ -->
							if(memedittype == "memedittype"){
								url = qurl + "&a=editmember";
							}
							<!-- ���� ���� �ύ -->
							$(this).attr("action", url);
							$(this).ajaxSubmit(option);
							return false;
						});
					});
					function memberitem(data){
						var op = data.split("|");
						switch($.trim(op[0])){
							case "1":
								window.parent.showNotice(op[1]);
								break;
							case '0':			
								window.parent.showNotice(op[1]);
								var durl = op[2];
								if(!durl)durl = 'index.php?m=member';
								window.location.href=durl;
							break;
							default:
								alert(data);
								break;
						}
					}
					
					<!-- ��� �û��� -->
					function checkUserName(){
						var name = $.trim($("#username").val());
						var unlen = name.replace(/[^\x00-\xff]/g, "**").length;
						if(empty(name)){
							$("#username").next().html(username_not_null);<!-- �û�������Ϊ�� -->
							return false;
						}
						if(unlen < 4){
							$("#username").next().html(username_length_not_smaller_4);<!-- �û������Ȳ���С��4λ -->
							return false;
						}
						if(!chkstr(name)){
							$("#username").next().html(not_allowed_special_characters);<!-- ���������������ַ� -->
							return false;
						}
						var u = qurl + "&a=checkusername&username=" + name;
						<!-- �滻 ���� -->
						var call = $.ajax({url:u,async: false,
							cache:false});
						call = call.responseText;
						var flg = true;
						switch($.trim(call)){
							case "1":
								$("#username").next().html(hava_username);<!-- �û����Ѵ��� -->
								flg = false;
								break;
							case "2":
								flg = false;
								$("#username").next().html(not_null);<!-- ����Ϊ�� -->
								break;
							case "3":
								flg = false;
								$("#username").next().html(username_can_not_registered);<!-- ����ע����û��� -->
								break;
							default:
								flg = true;
								$("#username").next().html("");
								break;
						}
						return flg;
					}
					<!-- ���� ��� -->
					function checkPassWord(){
						var password = $("#password").val();
						if(empty(password)){
							$("#password").next().html(password_not_null);<!-- ���ܲ���Ϊ�� -->
							return false;
						}
						if(password.length < 6){
							$("#password").next().html(password_can_not_less_6);<!-- ���벻��С��6λ -->
							return false;
						}
					
						$("#password").next().html("");
						return true;
					}
					<!-- ��� ȷ�� ���� -->
					function checkRePass(){
						var repass = $("#repass").val();
						if(empty(repass)){
							$("#repass").next().html(repass_not_null);<!-- ȷ�����벻��Ϊ�� -->
							return false;
						}
						var password = $("#password").val();
						if(password != repass){
							$("#repass").next().html(not_enter_the_password_twice);<!-- �����������벻һ�� -->
							return false;
						}
						$("#repass").next().html("");
						return true;
					}
					<!-- ��� ���� -->
					function checkEmail(){
						var email = $("#email").val();
						
						if(empty(email)){
							$("#email").next().html(not_null);<!-- ����Ϊ�� -->
							return false;
						} 
			            if(!checkemail(email)){ 
			            	$("#email").next().html(email_falseness);<!-- email����ȷ -->
			            	return false;
			            }
						<!-- �鿴 �Ƿ�Ϊ�޸� ����� �Ƿ� �� ��ǰ�� ������һ�� -->
						var oldemail = $("#oldemail").val();
						if(oldemail == email){
							return true;
						}
			            <!-- ��� ���� �Ƿ���� -->
			            var u = qurl + "&a=checkemail&email=" + email;
			            var call = $.ajax({
				            				url:u,
				            				async:false,
				            				cache:false
				            			});
			            call = call.responseText;
			            switch($.trim(call)){
							case "1":
								$("#email").next().html(have_email);<!-- ���������Ѵ��� -->
								return false;
								break;
							case "2":
								$("#email").next().html(not_null);<!-- ����Ϊ�� -->
								return false;
								break;
							default:
								$("#email").next().html("");
								return true;
								break;
						}
			            return true;
					}
					<!-- ѡ���� -->
					function checkMobile(){
						var mobile = $("#mobile").val();
						if(mobile == ""){
							return true;
						}
						if(!is_mobile(mobile)){
							$("#mobile").next().html(mobile_falseness);<!-- �ֻ����벻��ȷ -->
							return false;
						}
						<!-- ������޸� �鿴 �Ƿ� ���޸��� -->
						var oldmobile = $("#mobile").val();
						if(oldmobile == mobile){
							return true;
						}
						<!-- �ж�  �Ƿ� ����-->
						var u = qurl + "&a=checkmobile&mobile=" + mobile;
						var call = $.ajax({url:u,async:false,cache:false});
						call = call.responseText;
						switch($.trim(call)){
							case "1":
								$("#mobile").next().html(hava_mobile);<!-- �Ѵ��ڴ��ֻ����� -->
								return false;
							case "2":
								$("#mobile").next().html(please_check_mobile);//�����ֻ����� 
								return false;
							default:
								$("#mobile").next().html("");
							    return true;
						}
						$("#mobile").next().html("");
						return  true;
					}
					<!-- ����  ѡ�� �¼� --> 
					function areaselect(self){
						$(self).nextAll().remove("select");
						//��� ֵ Ϊ '' �� ������������ ȫ������
						if($(self).find('option:selected').attr("value") == ""){
							return false;
						}
						var id = $(self).find('option:selected').attr("id");
						var node = $(self).find('option:selected').attr("hasNode");
						<!-- �ж� �Ƿ�  ��  �¼����� -->
						if(node == "false")return false;
						<!-- ���� �� �ж�  �Ƿ� ���� �� ��� ����ֵ-->
						var optext = $("#area_" + id).html();
						var name = $(self).attr("id");
						<!-- ��ͷ -->
						var str = '<select width="130" class="form_select"  onchange="areaselect(this)" id="' + name + '" name="' + name + '[]">';
						str += '<option name="" value="">'+ please_choose +'</option>';<!-- ��ѡ�� -->
						if(optext != null && optext != "" ){
							<!-- option ���� -->
							str += $("#area_" + id).find("select").html();
							<!-- ���� -->
							str += '</select>';
							<!-- ���� �� �����ĺ�� -->
							$(self).after(str);
							return false;
						}
						<!-- ��ʼ �� ������ ajax ����  ����  -->
						var url = qurl + "&a=getarea&nodeid=" + id + "&name=" + name;
						$.get(url, function(data){
							if(empty(data)){
								$(self).find('option:selected').attr("hasNode", "false");
								return false;
							}
							str += data;
							str += '</select>';							
							$(self).after(str);
							data = "<select>" + data + "</select>"
							$("#area_show_sava").append("<div id='area_" + id + "' style='display:none'>" + data + "</div>");
							return false;
						});
						return true;
					}
		$(function(){
			$.table_bars($("#do_member_pannel .menu li"));
		});
                </script>
<div id="area_show_sava" style="display: none"><!-- ���� -->
     {if $memedittype == 'memedittype'}
            {foreach from=$areaarray item=item}
                {$item}
            {/foreach}
        {/if}
   </div>
<div id="do_member_pannel" class="table_scroll">
    <div class="menu">
         <ul>
            <li name="cfg_all">ȫ��</li>
            <li name="cfg_base" class="wintable_curent">������Ϣ</li>
            <li name="cfg_extend">��չ��Ϣ</li>
        </ul>
    </div>
</div>
<div class="table_item_base">
<div class="table_item" id="cfg_base">
	<h1 class="c_bar">��Ա������Ϣ</h1>
    <div class="c_content">
<table class="table_common">
<tr>
  <td class="one">{$lang.member.td_username}</td><!-- �û����� -->
  <td>
    {if $memedittype == 'memedittype'}
    {$mem.mem_username}
    {if $mem.mem_state == '2'}&nbsp;&nbsp;<strong class="red">�ȴ�����Ա����</strong>{/if}
    {else}
    <input id="username" type="text" class="form_input w300" name="username" />
    <span class="blue"></span><span class="blue">*</span>
    {/if}
  </td>
  <td rowspan="8" width="160">
    
  <script type="text/javascript">
    function check_user_up_pic(obj){
        var ary = new Array('jpg','gif','png');
        var ext = $(obj).val().split('.').pop();
        if($.inArray(ext,ary)=='-1'){
            alert("��ѡ��ϵͳ������ʽ��ͼƬ!");	
            cleanFile('upload_member_file');
            return false;
        }
    }
  </script>
  <div style="width:141px;margin:5px auto;padding:10px;float:right;border:1px solid #EBEBEB;overflow:hidden;">
  <h2>�û�ͷ��</h2>
    <div class="thumb_pic"> <img src="../picture.php?s={$mem.thumb}&w=120&h=150" /> </div>
    <div class="thumb_upload">
      <p id="h_upload"><input type="file" value="" name="thumb" id="upload_member_file" class="w100" onchange="check_user_up_pic(this);" /></p>
        <p id="h_upload_txt">���ѡ���ϴ��ļ�</p>
      <br /><br>
      <font class="blue">(jpg,gif,png,500k��)</font> </div>
    <input type="hidden" value="{$mem.thumb}"   name="u_thumb" />
  </div></td>
</tr>
<tr>
  <td class="one">{$lang.member.td_password}</td><!-- ���룺 -->
  <td>
    <input {if $action_add eq 'add_user'}id="password"{/if}  class="w300 form_input" type="password" value=""  name="password" />
    <span class="blue"></span><span class="blue"></span>
  </td>
  </tr>
<tr>
    <td class="one">{$lang.member.td_confirm_password}</td><!-- ȷ������ -->
    <td>
      <!--$mem.mem_password-->
      <input {if $action_add eq 'add_user'}id="repass"{/if} class="w300 form_input" type="password"  value=""  name="repass" />
      <span class="blue"></span><span class="blue"></span>
    </td>
    </tr>
<tr>
    <td class="one">{$lang.member.td_eamil}</td><!-- email -->
    <td>
      <input id="email" value="{$mem.mem_email}" style="ime-mode: disabled;"  type="text"  class="w300 form_input input_notice" title="{$lang.member.td_eamil_description}" name="email" />
      <span class="blue"></span><span class="blue">* </span><!-- ��������������½ -->
    </td>
    </tr>
<!-- �û����û��֣� -->
<tr>
    <td class="one">{$lang.member.td_point}</td>
    <td>
      <script type="text/javascript">   //��ʾ��Ա����
            function showMemberPointLogs(id,obj){
                return window.parent.showWindow($(obj).attr('name'),'index.php?m=member&a=viewPointLogs&id='+id,890,350);
            }
            function alertMemberPoint(id,obj){
                return window.parent.showWindow($(obj).attr('name'),'index.php?m=member&a=changePointLogs&id='+id,700,350);
            }</script>
      {/literal}
      <input id="member_points" title="�û�����,�����޸ģ�" value="{$member_points|default:0}" style="ime-mode: disabled;"  type="text"  class="w300 form_input input_notice" name="member_points" /> {if $member_points} <a href="javascript:;" class="blue"  onclick="showMemberPointLogs('{$mem.mem_id}',this);" name="{$mem.mem_username}-{$lang.member.point_logs_desc}"><b>������־</b></a> &nbsp;<a href="javascript:;" onclick="alertMemberPoint('{$mem.mem_id}',this);" id="{$mem.mem_id}" name="{$mem.mem_username}-{$lang.member.change_accunt_point}"><b class="blue"><!--�����˻�-->{$lang.member.change_accunt_point}</b></a> 
      {/if}
      
    </td>
    </tr>
<tr>
    <td  class="one">{$lang.member.td_level}</td><!-- �û��ȼ��� -->
    <td>
      <select name="level" id="level" class="w300">
            {foreach from=$memlevelnames item=level} 
                <option value="{$level.level_point}">{$level.level_name}</option>
            {/foreach}
        </select>
      <!-- �� js ��ѡ�� �û��� ������ �Ǹ��ȼ��� -->
      {if $memedittype == 'memedittype'}
      <input type="hidden" value="{$mem.mem_level_name}" class="mem_level_name" name="{$mem.mem_levelpoint}" />
      {literal}
      <script type="text/javascript">
                    <!-- ��ʼ ѡ�� �û��ȼ� -->
                    <!-- �õ� �û��ȼ�����  �� ���� �Ա� ��ֵ -->
                    var levelname = $(".mem_level_name").val();
                    $("#level").val(levelname);
                    $("#level option:selected").attr("value",$(".mem_level_name").attr("name"));
                </script>
      {/literal}
      {/if}
    </td>
    </tr>
<tr>
    <td class="one">�û���</td><!-- �û��飺 -->
    <td>
      <select name="group" id="group" class="w300">
        <!--                            	<option value="">{$lang.member.js_html.please_choose}</option>-->
            {foreach from=$memgroups item=group}
                <option value="{$group.group_id}" {if $group.group_id eq '1'} selected="selected"{/if} {if $mem.mem_group == $group.group_id} selected="selected"{/if}>{$group.group_name}</option>
            {/foreach}
        </select>
    </td>
    </tr>
<tr>
    <td class="one">{$lang.member.td_state}</td><!-- �Ƿ����û��� -->
    <td>
      <input  type="radio" value="1" checked="checked" name="state" />{$lang.member.html_open}&nbsp;&nbsp;<!-- ���� -->
      <input type="radio" value="2" name="state" {if $mem.mem_state == '2'} checked="checked"{/if} />{$lang.member.html_disable}<!-- ���� -->
    </td>
    </tr>
</table>
</div>
</div>
<!--#������������-->

<div class="table_item" id="cfg_extend">
	<h1 class="c_bar">��Ա��չ��Ϣ</h1>
    <div class="c_content">
<table class="table_common">
<tr>
    <td class="one">{$lang.member.td_mobile}</td><!-- �ֻ��� -->
    <td>
        <input id="mobile"  type="text" value="{$mem.mem_mobile}" name="mobile" style="ime-mode: disabled;" class="form_input w300" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')" />  <span class="blue"></span>
    </td>
</tr>
					{foreach from=$regitem item=attr}
						<tr>
							<td class="one">
								{$attr.attr_name}
							</td>
							<td>
								<!-- ��ͨ���ı��� -->
								{if $attr.attr_type == 'text'}
									<input  value="{$attr.value_name}" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"  class="form_input w300"  />
								<!-- ֻ���������� -->
								{elseif $attr.attr_type == 'textnumber'}
									<input  value="{$attr.value_name}" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"  class="form_input w300"  onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')"/>
								<!-- ֻ�� �������ֺ��ַ� -->
								{elseif $attr.attr_type == 'textcharnumber' }
									<input  value="{$attr.value_name}" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"  maxlength="50" class="form_input w300" style="ime-mode: disabled;" />
								<!-- ֻ�� ���� �ַ� -->
								{elseif $attr.attr_type == 'textchar'}
									<input value="{$attr.value_name}"{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"    class="form_input w300" style="ime-mode: disabled;" onkeyup="this.value=this.value.replace(/[^a-zA-Z]/g,'')"/>
								<!-- ���ı� -->
								{elseif $attr.attr_type == 'textarea'}
									<textarea  class="form_input w300" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} type="text"  row="20" cols="40" >{$attr.value_name}</textarea>
								<!-- �Ա� -->
								{elseif $attr.attr_type == 'sex'}
									<input type="radio" class="form_radio" value="1"{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if}   checked="true"  />&nbsp;{$lang.member.td_man}&nbsp;&nbsp;&nbsp;&nbsp;<!-- �� -->
									<input type="radio" {if $mem.mem_sex == '2'} checked="checked"{/if} class="form_radio" value="2"{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if}  />&nbsp;{$lang.member.td_woman}<!-- Ů -->
								<!-- ���� -->
								{elseif $attr.attr_type == 'date'}
									<input type="text" class="date date_input w300" value='{$attr.value_name|date_format:"%Y-%m-%d"}'{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if}  
									onfocus="show_date(this);"  /><!-- ����ѡ���� -->
								<!-- ��ͨ ������ -->
								{elseif $attr.attr_type == 'select'}
									<select class="form_select"{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if}  class="w300">
										<option value="">{$lang.member.js_html.please_choose}</option><!-- --��ѡ��-- -->
										{foreach from=$attr.attr_option  item=item}
											<option value="{$item}" {if $item == $attr.value_name} selected="selected"{/if}>{$item}</option>
										{/foreach}
									</select>
								<!-- ����  -->
								{elseif $attr.attr_type == 'area'}
									<select class="form_select" style="width:130px;" onchange="areaselect(this)" {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}[]"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}[]" {/if}>
										<option name="" value="">{$lang.member.js_html.please_choose}</option><!-- --��ѡ��-- -->
										{foreach from=$attr.attr_option item=item}
											<option value="{$item.region_id}" id="{$item.region_id}" >{$item.region_name}</option>
										{/foreach}
									</select>
									{if $memedittype == 'memedittype'}
                                        	<input type="hidden" value="{$attr.value_name}" id="areaval" />
                                        	<input type="hidden" id="areavalname" value="{if $attr.attr_typename != 'system'}registerreg{$attr.attr_id}{else}{$attr.attr_valname}{/if}"  />
											{literal}
									        	<script type="text/javascript">
													var val = $("#areaval").val();
													var names = $.trim($("#areavalname").val());
													var oop = val.split("-");
													var str = '<select width="130" class="form_select"  onchange="areaselect(this)" id="' + names + '" name="' + names + '[]">';
													str += '<option name="" value="">'+please_choose+'</option>';<!-- ��ѡ�� -->
													var count = oop.length;
													var obj = $("select[name='"+names+"[]']");
													for(var i = 0; i < count; ++i){
														<!-- �õ� id ����ѡ�е�ֵ ����ʾ����һ�� -->
														<!--�趨�� ��ѡ��ֵ-->
														obj.val(oop[i]);
														<!-- �õ��ı������� -->
														var optext = $("#area_" + oop[i]).find("select").html();
														if(optext == null || optext == ''){
															continue;
														}
														obj.after( str + optext + "</select>");
														<!-- ʹ���� ���� ��һ��  select ��ǩ -->
														obj = obj.next();
														<!-- ȥ�� ����� select �� name �� id-->
													}
													
													<!-- ɾ�� ������ input ��ǩ -->
													$("#areaval").remove();
													$("#areavalname").remove();              
												</script>
											{/literal}
                                         {/if}
								<!-- ��ѡ -->
								{elseif $attr.attr_type == 'radio'}
									{foreach from=$attr.attr_option item=item}
										<input type="radio" class="form_radio" {if $item == $attr.value_name} checked="checked" {/if} {if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}" {/if} value="{$item}" />{$item}
									{/foreach}
								<!-- ��ѡ -->
								{elseif $attr.attr_type == 'checkbox'}
									{foreach from=$attr.attr_option item=item}
										 <input type="checkbox"{if $attr.attr_typename != 'system'}id="registerreg{$attr.attr_id}" name="registerreg{$attr.attr_id}[]"{else} id="{$attr.attr_valname}" name="{$attr.attr_valname}[]" {/if} class="form_checkbox" value="{$item}"/>{$item}
									{/foreach}
									{if $memedittype == 'memedittype'}
	                                    <input type="hidden" value="{$attr.value_name}"  id="checkboxval" />
	                                    <input type="hidden"  id="checkboxvalname" value="{if $attr.attr_typename != 'system'}registerreg{$attr.attr_id}{else} {$attr.attr_valname} {/if}" />
	                                         <script type="text/javascript">
											 	var val = $("#checkboxval").val();
												var oop = val.split("-");
												var count = oop.length;
												var name = $.trim($("#checkboxvalname").val()) + "[]";
												for(var i = 0; i < count; i++){
													$("input[name='" + name + "'][value='"+ oop[i] + "']").attr("checked", true);
												}
												$("#checkboxval").remove();
												$("#checkboxvalname").remove();
	                                   	     </script>
	                                   {/if}
								{/if}
								<!-- ��� ���� ��ʾ  -->
								{if $attr.attr_required == '1'}
									<span name="require" class="blue">*</span>
								{/if}
							</td>
						</tr>
					{/foreach}
                </table>
                <input type="hidden" id="memedittype"  value="{$memedittype}" />
                <input type="hidden" id="oldemail" name="oldemail" value="{$mem.mem_email}"  />
                <input type="hidden" name="memid" value="{$mem.mem_id}" />
                <input type="hidden" id="oldmobile" name="oldmobile" value="{$mem.mem_mobile}" />
</div>
</div>
</div>
<input style=" display:none;" type="submit" value="{$lang.member.btn_save}"  class="form_submit"/><!-- �� �� -->
 </div>
</form>
{include file='frame_footer.php'}
{/if}