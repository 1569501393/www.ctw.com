<?php if (! defined ( 'PHP_TEMPLATE' ))exit (); ?>
{if !$is_ajax_call}
{include file='frame_header.php'}
{/if}
<script type="text/javascript">
	{foreach from=$lang.level.js_html key=key item=item}
		var {$key} = "{$item}";
	{/foreach}
</script>
{if $actiontitle == 'actiontitle'}
<div id="php_top_bar">
        <div class="top_bar_pannel">
            <div class="tb"><a href="javascript:;" class="block_button form_btn" onclick="window.parent.showWindow($(this).html(),'index.php?m=member/level&a=do',800,300);">���ӻ�Ա�ȼ�</a></div>
        </div>
	</div>
{/if}
	{if $action == ''}
<script type="text/javascript">
function show_pannel(obj,url){ window.parent.showWindow($(obj).attr('rel'),url,750,250); }
function delete_level(id){
	if(confirm('��ȷ��Ҫɾ�˵ȼ���?�˲������ɻָ�!')){
		$.get('index.php?m=member/level&a=delete',{id:id},function(data){
			 $('#__tag_'+id).remove();
		});
	}
}
</script>
	<div id="php_right_main_content" >
			<table class="table_list">
				<tr>
					<th>{$lang.level.th_level_name}</th><!-- �ȼ����� -->
					<th>{$lang.level.th_member_type}</th><!-- ��Ա���� -->
					<th>{$lang.level.th_required_options}</th><!-- ������� -->
					<th>{$lang.level.th_description_info}</th><!-- ������Ϣ -->
					<th>{$lang.level.th_operation}</th><!-- ���� -->
				</tr>
				{foreach from=$levels item=level}
					<tr id="__tag_{$level.level_id}">
						<td>{$level.level_name}</td>
						<!-- ��ʾ ��  ����% -->
						<td align="center">{if $level.level_default == 0}{$lang.level.system_default_type}{else}{$lang.level.since_definition_type}{/if}</td><!-- ϵͳĬ�� --><!-- �Զ������� -->
						<td align="center">{$level.level_point}</td>
						<td align="center">{$level.level_description}</td>
						<td align="center">
							{if $level.level_default != 0}
								<a  href="javascript:;" rel="�༭��Ա�ȼ�����->{$level.level_name}" onclick="show_pannel(this,'index.php?m=member/level&a=do&id={$level.level_id}');">��</a> <a href="javascript:;" onclick="delete_level('{$level.level_id}');">ɾ</a><!-- �޸� | ɾ�� -->
                                {else}
                                <a  href="javascript:;" rel="�༭��Ա�ȼ�����->{$level.level_name}" onclick="show_pannel(this,'index.php?m=member/level&a=do&id={$level.level_id}');">��</a>
							{/if}
						</td>
					</tr>
				{/foreach}
			</table>
</div>
{/if}
{if $action eq 'add_level_modify_pannel'}
    <script type="text/javascript">
		$("#form_level").submit(function(){
			if(!check_form_is_empty('must_fill_level'))return false;
			$(this).ajaxSubmit(function(data){
				 switch(data){
				 	case 'OK':
						window.parent.showNotice('�����ɹ�!');
						window.parent.frames['rightFrame'].location.reload();
						_close_window_one();
					break;
					case 'EMPTY':
						window.parent.showNotice('����д������!');
					break;
					case 'HAS_EXIST':
						window.parent.showNotice('�Ѵ�����ͬ�ȼ�!');
					break;
					case 'HAS_EXIST_POINT':
						window.parent.showNotice('�Ѵ�����ͬ�Ļ�Ա����ֵ!');
					break;
					case 'EMPTY_POINT':
						window.parent.showNotice('���ֱ������0!');
					break;
					default:alert(data);
				 }
			});
			return false;
		});
    </script>
    <form action="index.php?m=member/level&a=do" method="post" id="form_level" autocomplete="off">
		<input  type="hidden" value="{$do_flag}" name="do_flag" />
            <table class="table_common">
                <tr>
                    <td class="one">�ȼ�����</td><!-- ��Ա�ȼ����� -->
                    <td>
                        <input id="levelname" name="levelname" type="text" value="{$level.level_name}" maxlength="25" class="form_input must_fill_level"/> 
                        <span class="setfont"></span><span class="blue">*</span>
                    </td>
                </tr>

                <tr>
                    <td class="one">��������</td><!-- ������� -->
                    <td>
                        <input id="levelpoint" name="levelpoint" type="text" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')"  style="ime-mode: disabled;" value="{$level.level_point}" maxlength="10" class="form_input must_fill_level"  />
                        <span class="setfont"></span><span class="blue">*</span>
                    </td>
                </tr>
                <tr>
                    <td class="one">�������</td><!-- ���� -->
                    <td><textarea name="leveldescription" class="seo_set form_textarea">{$level.level_description}</textarea></td>
                </tr>
                <tr>
                	<td class="one"></td>
                    <td>
					<a href="javascript:;"  onclick="submit_form('form_level');" class="block_button form_btn">����</a>
                    </td>
                </tr>
            </table>
    </form>
{/if}
{if !$is_ajax_call}
{include file='frame_footer.php'}
{/if}