<?php if (! defined ( 'PHP_TEMPLATE' ))exit ();?>
{if $actiontitle == 'actiontitle'}
{include file='frame_header.php'}
<script language="JavaScript" type="text/javascript">
{foreach from=$lang.register.js_html key=key item=item}
var {$key} = "{$item}";
{/foreach}
var qurl = "index.php?m=member/register";
function refurbish(){
	var url = qurl + '&a=registerAttr';location.href=url;
}
$(document).ready(function(){
	$("#refurbish_page").click(function(){
		refurbish();
		$(this).hide();
	});
});
    </script>
    <div id="php_top_bar">
        <div class="top_bar_pannel">
        <div class="tb"><a onclick="window.parent.showWindow($(this).html(),'index.php?m=member/register&a=register_item',550,250);" class="block_button form_btn">{$lang.register.html_add_options}</a></div>
        <div class="tb"><a onclick="window.location.reload();" class="block_button">ˢ��</a></div>
        </div>
    </div>
{/if}
{if $action == ''}
<div id="php_right_main_content">
	<div id="register_list" >
			<script type="text/javascript">
				$(document).ready(function(){
					 table_color("table_list");
					$(".re_show").attr("disabled","true");
					$(".re_show").css("background-color","#FFFFFF");
					<!-- ��ʾ ˳��� ��� �뿪 �¼� -->
					$(".attr_order").change(function(){
						<!-- �õ�ֵ -->
						var order = $.trim($(this).val());
						<!-- �� �ж� �� �Ƿ�Ϊ�� -->
						if(empty(order)){
							$(this).val($(this).attr("name"));
							return false;
						}
						<!-- �ж� �� �Ƿ���һ������ -->
						if(isNaN(order)){
							$(this).val($(this).attr("name"));
							return false;
						}
						<!-- �޸�  ֵ-->
						var url = qurl + "&a=updateshoworder&id=" + $(this).attr("id") + "&value=" + $(this).val();
						var self = $(this);
						$.ajax({
							 type: "GET",
							 url: url,
							 success:function(msg){
							 	if($.trim(msg) == "1"){
							 		$(self).attr("name", $(self).val());
							 	}else{
								 	showNotice(update_register_fail);<!--  �޸�ʧ�� -->
							 	}
							 }
					    });
					});
					$(".double_click_update_show").click(function(){
						 var value = $(this).attr("value");
						 var id = $(this).attr("name");
						 var url = qurl +  "&a=updateisshow&id=" + id + "&value=" + value;
						 var self = $(this);
						 window.parent.showLoading();
						 $.ajax({
							 type: "GET",
							 url: url,
							 success:function(msg){
								 window.parent.closeLoading();
							 	if($.trim(msg) == "1"){
							 		$(self).html(quired_show);<!-- �� -->
							 		$(self).attr("value", "1");
							 	}else if($.trim(msg)=="0"){
							 		$(self).html(quired_not_show); <!-- �� -->
							 		$(self).attr("value", "0");
							 	}else{
							 		showNotice(update_register_fail);<!-- �޸�ʧ�� -->
							 	}
							 }
					    });
					});
	
					<!-- a ��ǩ����� ɾ�� �¼� -->
					$(".delete_a").click(function(){
						if(!confirm(delete_ok)){ <!-- ȷ��Ҫɾ����? -->
							return false;
						}
						var id = $(this).attr("name");
						var url = qurl + "&a=deleteregister&id=" + id;
						var obj = $(this).parent().parent();
						$.get(url, function(data){
							switch($.trim(data)){
								case "1":
									showNotice(delete_register_fail);<!-- �޸�ʧ�� -->
									break;
								case "2":
									showNotice(operation_error);<!-- �������� -->
									break;
								default:
									window.parent.showNotice(delete_register_success);<!-- ɾ���ɹ� -->
									obj.remove();
									break;
							}
						});
						return false;
					});
					<!-- �޸����Ƶ�˫���¼� -->
					$(".update_name").dblclick(function(){
						<!-- �õ� id �� ���� -->
						var name = $(this).attr("id");
						var id = $(this).attr("name");
						var str = '<input type="text" value="'+name+'" id="editname'+id+'" class="form_input" size="12" maxlength="40" />';
						str += "&nbsp;<a onclick='updateattrname(this)' id='"+name+"' name='editname" + id + "' style='cursor:pointer' title='" + a_ok + "' >" + a_ok + "</a>&nbsp;";
						str += "<a onclick='cancelupdate(this)' id='"+name+"' name='editname" + id + "' style='cursor:pointer' title='"+ a_cancel +"'>" + a_cancel + "</a>";
						$(this).html(str);
					});
				});
				<!-- ֻ �������� -->
				function updateattrname(self){
					<!-- �õ� id �� ֵ -->
					var name = $(self).attr("id");
					var id = $(self).attr("name");
					<!-- ͨ�� id �õ� input �޸ĵ� ������ -->
					var newname = $.trim($("#" + id).val());
					<!-- �ж� �Ƿ�Ϊ�� -->
					if(empty(newname)){
						showNotice(not_null);<!-- ����Ϊ�� -->
						return false;
					}
					obj = $(self).parent();
					<!-- �ж� �Ƿ��޸������� -->
					if(newname == name){
						obj.html(name);
						return false;
					}
					<!-- �õ�  Ҫ�޸ĵ�id -->
					var attrid = obj.attr("name");
					var url = qurl + "&a=updateattrname&attrid=" + attrid + "&attrname=" + newname;

					<!-- ajax �ύ���� -->
					$.get(url, function(data){
						var op = data.split('|');
						showNotice(op[1]);
						switch($.trim(op[0])){
							case "1":
								break;
							default:
								obj.html(newname);
								obj.attr("id", newname);
								break;
						}
					});
					return false
				}
				<!-- ȡ�� �������� -->
				function cancelupdate(self){
					var name = $(self).attr("id");
					obj = $(self).parent();
					obj.html(name);
				}
				
			</script>
			<table class="table_list">
				<tr>
					<th>{$lang.register.th_show_order}</th><!-- ��ʾ˳�� -->	
					<th>{$lang.register.th_options_name}</th><!--ע��������  -->
					<th>{$lang.register.th_options_type}</th><!-- ע�������� -->
					<th>{$lang.register.th_options_update}</th><!-- �޸� -->
					<th>{$lang.register.th_options_delete}</th><!-- ɾ�� -->
					<th>{$lang.register.th_options_show}</th><!-- ��ʾ  -->
				</tr>
				{foreach from=$attrs item=attr}
					<tr align="center">
						<td>
							<input class="attr_order" type="text" size="6" name="{$attr.attr_order}" id="{$attr.attr_id}" style="text-align:center;ime-mode: disabled;" value="{$attr.attr_order}" maxlength="4" />
						</td>
						<td  align="left" >
							<div name="{$attr.attr_id}" id="{$attr.attr_name}" class="update_name" title="{$lang.register.html_double_click_name}" style="cursor:pointer;overflow: hidden; width:150px; float:left; white-space: nowrap;">{$attr.attr_name}</div>
							<div readonly="readonly" enabled="true" disabled="true" style="float:left;" >
								{if $attr.attr_type == 'text' || $attr.attr_type == 'textcharnumber' || $attr.attr_type == 'textchar' || $attr.attr_type == 'textnumber'}
									<input type="text" class="re_show form_input form_input"/>
								{elseif $attr.attr_type == 'textarea'}
									<input type="text" class="re_show form_textarea"  />
								{elseif $attr.attr_type == 'sex'}
									<input type="radio" class="re_show" value="{$lang.register.html_sex_man}" name="{$attr.attr_valname}"   checked="true"  />&nbsp;{$lang.register.html_sex_man}&nbsp;&nbsp;&nbsp;&nbsp;<!-- �� -->
									<input type="radio" class="re_show" value="{$lang.register.html_sex_woman}" name="{$attr.attr_valname}"   />&nbsp;{$lang.register.html_sex_woman}<!-- Ů -->
								{elseif $attr.attr_type == 'date'}
									<input  type="text" value="{$lang.register.html_date_selector}" class="re_show Wdate" /><!-- ����ѡ���� -->
								{elseif $attr.attr_type == 'select'}
									<select class="form_select" style="width:130px">
										{foreach from=$attr.attr_option item=item}
											<option >{$item}</option>
										{/foreach}
									</select>
								{elseif $attr.attr_type == 'area'}
									<select class="re_show form_select" >
										<option>{$lang.register.html_please_choose}</option><!-- ��ѡ�� -->
									</select>
								{elseif $attr.attr_type == 'radio'}
									{foreach from=$attr.attr_option item=item}
										<input type="radio" class="re_show form_radio" name="{$attr.attr_valname}" value="{$item}" />{$item}
									{/foreach}
								{elseif $attr.attr_type == 'checkbox'}
									{foreach from=$attr.attr_option item=item}
										 <input type="checkbox" class="re_show form_radio" value="{$item}"/>{$item}
									{/foreach}
								{/if}
								{if $attr.attr_required == 1}
									*
								{else}
								{/if}	
							</div>
						</td>
						{if $attr.attr_typename == 'system'}
							<td>
								{$lang.register.html_system_default}<!-- ϵͳĬ�ϵ� -->
							</td>
							<td></td>
							<td></td>
						{else}
							<td>
								{$attr.attr_typename}
							</td>
							<td>
								<a href="javascript:;" onclick="window.parent.showWindow($(this).attr('rel'),'index.php?m=member/register&a=updateregister&id={$attr.attr_id}',500,250);">{$lang.register.th_options_update}</a><!-- ɾ�� -->
							</td>
							<td>
								<a style="cursor:pointer;" name="{$attr.attr_id}" class="delete_a">{$lang.register.th_options_delete}</a><!-- �޸� -->
							</td>
						{/if}
						<td title="{$lang.register.html_double_click_update_isshow}" value="{$attr.attr_show}" name="{$attr.attr_id}" class="double_click_update_show" style="cursor:pointer;color:#0066CC">{if $attr.attr_show == '1'}{$lang.register.js_html.quired_show}{else}<span style="color:#333;">{$lang.register.js_html.quired_not_show}</span>{/if}</td>
						<!-- ˫���޸��Ƿ���ʾ --><!-- �� --><!-- �� -->
					<tr>
				{/foreach}
			</table>
	</div>
</div>
{include file='frame_footer.php'}<!-- �ײ� -->
{/if}

{if $action == 'register_item'}
			<script type="text/javascript">
{foreach from=$lang.register.js_html key=key item=item}
var {$key} = "{$item}";
{/foreach}
var qurl = "index.php?m=member/register";
<!--  ע��������  �� ֵ  ����뿪�¼�-->
				$("#attrname").blur(function(){
					<!-- ���� -->
					//checkAttrName();
				});
				<!-- ��֤	 ע�������� -->
				function checkAttrName(){
					var attrname = $.trim($("#attrname").val());
					if(empty(attrname)){
						$("#attrname").next().html(not_null);<!-- ����Ϊ�� -->
						return false;
					}else{
						var oldname =$("#oldname").val();
						if(oldname == attrname){
							$("#attrname").next().html("");
							return true;
						}
						return checkNamePub($("#attrname"), attrname);
					}
				}
				function checkNamePub(self, value){
					var flg = false;
					var des = "";
					var call = $.trim(getData(qurl +  "&a=checkname&name=" + value));
					switch(call){
						case "1":
							des = hava_name_not_repeat;<!-- �Ѵ��ڴ�����,�����ظ�-->
							break;
						case "2":
							showNotice(operation_error);<!-- �������� -->
							des = operation_error;<!-- �������� -->
							break;
						default:
							flg = true;
							break;
					}
					self.next().html(des);
					return flg;
				}
				$("#register_item").submit(function(){
					var url = qurl;
					if($.trim($("#attrid").val()) == ""){
						url = qurl + "&a=addregisteritem";
					}else{
						url = qurl + "&a=updateregister";
					}
					$("#register_item").attr("action", url);
					$(this).ajaxSubmit(function(data){
						var op = data.split("|");
						var oo = $.trim(op[0]);
						switch(oo){
							case "0":
								window.parent.showNotice('�����ɹ�!');
								_close_window_one();
								window.frames["rightFrame"].location.reload();
								break;
							case '1':
								window.parent.showNotice(op[1]);
								break;
							default:alert(data);
						}
					});
					return false;
				});
				var showhide = false;
				$("#attrtype").change(function(){
					var value = $("#attrtype option:selected").val();
					var text = $("#attrtype option:selected").text();
					$("#attrtypename").attr("value", $.trim(text));
					var item = $("#attrtype option:selected").attr("class");
					$(".additem").remove();
					if(item == 'item'){
						showhide = true;
						$("#attritem").val("true");
						$(".hiddenitem").show();
						var parent = $(this).parent().parent();
						$(parent).after(getTrContent());
						
					}else{
						showhide = false;
						$("#attritem").val("false");
						$(".hiddenitem").hide();
					}
				});
				$("#additem").click(function(){
					var parent = $(this).parent().parent();
					$(parent).before(getTrContent());
				});
				function getTrContent(){
					var content = "<tr class='additem' >";
					content += "<td class='one' >&nbsp;";
					content += "</td>";
					content += "<td>";
					content += "<input type='text' name='manyitem[]' onblur='ablurnul(this);'  class='form_input'/>";
					content += "<span class='setfont'>*</span><a onclick='adeleteself(this);' style='cursor:pointer'>&nbsp;&nbsp;&nbsp;"+td_delete_options+"</a>";
					content += "</td>";
					content += "</tr>";
					return content; 
				}
				<!-- ѡ��ֵ ����Ϊ�յ� �ж� -->
				function checkManyItem(){
					if(!showhide)return true;
					var flg = true;
					$("#register_item").find("input[name='manyitem[]']").each(function(i){
						if(empty($(this).attr("value"))){
							flg = false;
							return;
						}
					});
					return flg;
				}
				<!-- ɾ�� һ�� ѡ�� -->
				function adeleteself(self){
					<!-- �ж� �Ƿ����ɾ�� -->
					var leng = $("input[name='manyitem[]']").length;
					if(leng == 1){
						alert(least_one_options);<!-- ����Ҫ��һ��ѡ�� -->
						return false;
					}
					var parent = $(self).parent().parent();
					$(parent).remove();
				}
				<!-- ɾ�� һ�� ѡ�� -->
				$("#deleteitem").click(function(){
					<!-- �ж� �Ƿ����ɾ�� -->
					var leng = $("input[name='manyitem[]']").length;
					if(leng == 1){
						alert(least_one_options);<!--����Ҫ��һ��ѡ��  -->
						return false;
					}
					var parent = $(this).parent().parent();
					var obj = $(parent).prev();
					$(obj).remove();
				});
				<!-- �ж� ѡ��ֵ �Ƿ�Ϊ��          ����뿪ʱ���� -->
				function ablurnul(self){
					if(empty($(self).val())){
						$(self).next().html(not_null);<!-- ����Ϊ�� -->
					}else{
						$(self).next().html("*");
					}
				}
				<!-- ȥ���س��¼� -->	
				removeEnter();
			</script>
			<form action="" method="post" autocomplete="off" id="register_item">
				<table id="table_common" class="table_common">
					<tr>
						<td class="one">{$lang.register.td_options_name}</td><!-- ע�������ƣ� -->
						<td>
							<input id="attrname" type="text" value="{$attr.attr_name}" name="attrname" class="form_input" maxlength="40"/>
							<span class="setfont"></span>
							<span class="setfont">*</span>
						</td>
					</tr>
					<tr>
						<td class="one">{$lang.register.td_isnot_require}</td><!-- �Ƿ��� -->
						<td><input type="checkbox" value="1" name="attrrequired" class="form_input" {if $attr.attr_required == '1'} checked='true'{/if} /></td>
					</tr>
					<tr>
						<td class="one">{$lang.register.td_show_order}</td><!-- ��ʾ˳�� -->
						<td><input type="text" {if $itemtype == 'update'}value="{$attr.attr_order}"{else}value="20"{/if} name="attrorder" class="form_input" size="6" style="ime-mode: disabled;" maxlength="4" /></td>
					</tr>
					<tr>
						<td class="one">{$lang.register.td_options_type}</td><!-- ���ͣ� -->
						<td>
							<select id = "attrtype" class="form_option" name="attrtype"  >
								<optgroup label="{$lang.register.select_input}"><!-- ������ -->
								    <option value="text">{$lang.register.select_input_content_not_restricted}</option><!-- �������ݲ����� -->
								    <option value="textnumber">{$lang.register.select_input_only_number}</option>	<!-- ������������ -->
								    <option value="textchar">{$lang.register.select_input_only_char}</option>	<!-- ���������ַ� -->
								    <option value="textcharnumber">{$lang.register.select_input_only_number_char}</option><!-- �����������ֺ��ַ� -->
								    <option value="textarea">{$lang.register.select_input_many_input}</option><!-- �ı������ -->
								</optgroup>
								<optgroup label="{$lang.register.select_options}"><!-- ѡ���� -->
								    <option value="radio" class="item">{$lang.register.select_options_radio}</option><!-- ��ѡ�� -->
								    <option value="checkbox" class="item">{$lang.register.select_options_checkbox}</option><!-- ��ѡ�� -->
								    <option value="select" class="item">{$lang.register.select_options_select}</option><!-- ������ -->
								</optgroup>
								<optgroup label="{$lang.register.select_other}"><!-- ������ -->
									<option value="date">{$lang.register.select_other_date}</option><!-- ����(������) -->
									<option value="area">{$lang.register.select_other_area}</option><!-- ���� -->
								</optgroup>
							</select>
							<input type="hidden" name="attrtypename" {if $itemtype == 'update'}value="{$attr.attr_typename}"{else}value="{$lang.register.select_input_content_not_restricted}"{/if} id="attrtypename" /><!-- �������ݲ����� -->
							<input type="hidden" id="oldname" name="oldname" value="{$attr.attr_name}" />
							<input type="hidden" id="oldvalname" name="oldvalname" value="{$attr.attr_valname}" />
							<input type="hidden" id="oldtype" name="oldtype" value="{$attr.attr_type}" />
							<input type="hidden" name="attritem" value="false" id="attritem" />
							<input type="hidden" name="attrid" value="{$attr.attr_id}" id="attrid" />
						</td>
					</tr>
					{if $itemtype == 'update'}
						{literal}
							<script type="text/javascript">
								var attrtype =$("#oldtype").val();
								$("#attrtype").val(attrtype);
								<!-- �ж� attrtype ���������� -->
								if(attrtype =='checkbox' || attrtype == 'radio' || attrtype == 'select'){
									showhide = true;
									$("#attritem").val("true");
									$(".hiddenitem").show();
								}
								function btnreset(){
									var id = $("#attrid").attr("value");
									$.get(qurl + '&a=updateregister&id='+ id , function(data){
										$("#register_list").html(data);
									});
									return false;
								}
							</script>
						{/literal}
						<!--  �������  �г� ѡ������ -->
						{if $attr.attr_option != ''}
							{foreach from=$attr.attr_option item=op}
								<tr class="additem" id="add_item" >
									<td class="one" >&nbsp;</td>
									<td>
										<input type="text" name="manyitem[]" value="{$op}" onblur="ablurnul(this);"  class="form_input"/>
										<span class="setfont">*</span><a onclick="adeleteself(this);" style="cursor:pointer" >&nbsp;&nbsp;&nbsp;{$lang.register.js_html.td_delete_options}</a><!-- ɾ������ -->
									</td>
								</tr>
							{/foreach}
						{/if}
					{/if}
					<tr class="hiddenitem" style="display:none;">
						<td class="one">&nbsp;</td>
						<td>
							<a id="additem" style="cursor:pointer">{$lang.register.td_add_options}</a><!-- ����ѡ�� -->
								&nbsp;&nbsp;&nbsp;&nbsp;
							<a id="deleteitem" style="cursor:pointer">{$lang.register.td_reduce_options}</a><!-- ����ѡ�� -->
						</td>
					</tr>
				</table>
				<div style="text-align: center; clear:both; display:block; padding-top:10px;">
					<input type="submit" value="{$lang.register.btn_sava}" class="form_submit" style="display:none;" /><!-- �������� -->
                    <a href="javascript:;" onclick="submit_form('register_item');" class="block_button form_btn">����</a>
					{if $itemtype == 'update'}
						<input type="button" onclick="btnreset()"  value="{$lang.register.btn_reset}" class="block_button" /><!-- �������� -->
					{/if}
				</div>
			</form>
	{/if}