<?php if (! defined ( 'PHP_TEMPLATE' ))exit (); ?>
{include file='frame_header.php'}
<script style="text/javascript">
	{foreach from=$lang.feedback.js_html key=key item=item}
		var {$key} = "{$item}";
	{/foreach}
	{literal}
		var qurl = "index.php?m=member/feedback";
		function refurbish(){
			var url = qurl + "&a=feedbacklist&page=" + $("#curpage").val() + "&feedbackstate=" +$("#feedbacktype").val() + "&feedbacktype=" + $("#feedbackstate").val();
			location.href=url;
		}
	{/literal}
</script>
<div id="php_top_bar"><!-- top_bar star -->
<div class="top_bar_pannel">
<div class="tb">{$lang.feedback.html_feedback_type}</div>
<div class="tb"><select class="feedbackselect form_select" name="feedbacktype" id="feedbacktype"><!-- �������� -->
    <option value="0">{$lang.feedback.html_feedback_all}</option><!-- --ȫ��-- -->
    <option value="1" {if $smarty.get.feedbacktype == '1'} selected="selected" {/if}>{$lang.feedback.html_feedback_mes}</option><!-- ���� -->
    <option value="2" {if $smarty.get.feedbacktype == '2'} selected="selected" {/if}>{$lang.feedback.html_feedback_complaints}</option><!-- Ͷ�� -->
    <option value="3" {if $smarty.get.feedbacktype == '3'} selected="selected" {/if}>{$lang.feedback.html_feedback_ask}</option><!-- ѯ�� -->
    <option value="4" {if $smarty.get.feedbacktype == '4'} selected="selected" {/if}>{$lang.feedback.html_feedback_aftermarket}</option><!-- �ۺ� -->
    <option value="5" {if $smarty.get.feedbacktype == '5'} selected="selected" {/if}>{$lang.feedback.html_feedback_buy}</option><!-- �� -->
</select></div>
<div class="tb">{$lang.feedback.html_feedback_state}</div>
<div class="tb">
<select class="feedbackselect form_select" name="feedbackstate" id="feedbackstate"><!-- ״̬�� -->
    <option value="0">{$lang.feedback.html_feedback_all}</option><!-- --ȫ��-- -->
    <option value="1" {if $smarty.get.feedbackstate == '1'} selected="selected" {/if}>{$lang.feedback.html_feedback_newmessage}</option><!-- ������ -->
    <option value="2" {if $smarty.get.feedbackstate == '2'} selected="selected" {/if}>{$lang.feedback.html_feedback_hasreturned}</option><!-- �ѻظ� -->
    <option value="3" {if $smarty.get.feedbackstate == '3'} selected="selected" {/if}>{$lang.feedback.html_feedback_newquestions}</option><!-- ������ -->
</select></div>
<div class="tb"><a onclick="refurbish();" href="javascript:;" id="phprefurbish" class="block_button form_btn">����</a></div>
{if $feedbacks && $action neq 'replymessage'}
<div class="tb"><a id="batchdelete"  href="javascript:;" class="block_button">ɾ����ѡ</a></div>
{/if}
<div class="tb"><a href="javascript:;" onclick="window.location.reload();" class="block_button">ˢ��</a></div>
</div>
</div><!-- top_bar end -->
<input type="hidden" value="{$curpage}" name="curpage" id="curpage"/><!-- ���浫ǰҳ�� -->
	<div id="php_right_main_content" class="php_content_feedback">
		{if $action == ''}
<script type="text/javascript" >
		$(document).ready(function(){
			<!-- a �Ļظ� -->
			$(".replya").click(function(){
				var url ="index.php?m=member/feedback&a=replymessage&fbid=" + $(this).attr("name") + "&page=" + $("#curpage").val() +  "&feedbackstate=" + $("#feedbackstate [selected]").val() + "&feedbacktype=" +  $("#feedbacktype [selected]").val();;
				location.href=url;
			});
			<!-- a ��ɾ�� -->
			$(".deletea").click(function(){
				if(!confirm(delete_ok)){ <!-- ȷ��Ҫɾ���� -->
					return false;
				}
				var url = qurl + "&a=deletefeedback&fbid=" + $(this).attr("name");
				$.get(url,deletefeedback);
				return false;
			});
			$("#batchdelete").click(function(){
				if(!get_checkbox_val("form_checkbox_val")){
					window.parent.showNotice("<% _e('��ѡ��Ҫ����������!');%>");
					return false;
				}
				if(!confirm(batch_delete_ok)){<!--ȷ��Ҫ����ɾ���� -->
					return false;
				}
				var url = qurl + "&a=deletefeedback";
				$("#phpfeedbacklist").attr("action",url);
				var op = {
						success:deletefeedback
						}
				$("#phpfeedbacklist").ajaxSubmit(op);
				return false;
			});
			function deletefeedback(data){
				switch($.trim(data)){
					case "1":
						window.parent.showNotice(delete_success);<!-- ɾ���ɹ� -->
						refurbish();
						break;
					case "2":
						showNotice(operation_error);<!-- �������� -->
						break;
					case "3":
						showNotice(delete_data_not_hava); <!-- ɾ�������ݲ����� -->
						break;
					default:
						showNotice(delete_fail);<!-- ɾ��ʧ�� -->
						break;
				}
			}
			$(".check_all").click(function(){
				$(".form_checkbox_val").attr("checked",$(this).attr("checked"));
			});
		});
</script>
			{if $feedbacks}
			    	<form id="phpfeedbacklist" action="" method="post">
			        	<table class="table_list">
			        		<tr>
			        			<th><input type="checkbox" class="check_all form_checkbox" /></th><!-- ȫѡ -->
			        			<th>{$lang.feedback.th_message_from}</th><!-- ������ -->
			        			<th>{$lang.feedback.th_message_title}</th><!-- ���Ա��� -->
			        			<th>{$lang.feedback.th_message_type}</th><!-- ���� -->
			        			<th>{$lang.feedback.th_message_time}</th><!-- ����ʱ�� -->
			        			<th>{$lang.feedback.th_message_state}</th><!-- ״̬  -->
			        			<th>{$lang.feedback.th_message_operation}</th><!-- ���� -->
			        		</tr>
			        		{foreach from=$feedbacks item=fb}
			        			<tr>
			        				<td align="center"><input type="checkbox" class="form_checkbox form_checkbox_val" name="feedbackids[]" value="{$fb.feedback_id}"/></td>
			        				<td align="center">{$fb.mem_username}</td>
			        				<td align="center">{$fb.feedback_title}</td>
			        				<td align="center">{$fb.feedback_type}</td>
			        				<td align="center">{$fb.feedback_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
			        				<td align="center">{$fb.feedback_state}</td>
			        				<td align="center">
			        					<a class="replya" name="{$fb.feedback_id}" style="cursor:pointer" rel="{$fb.feedback_id}" >{$lang.feedback.html_feedback_reply}</a><!-- �ظ� -->&nbsp;<a class="deletea" name="{$fb.feedback_id}" style="cursor:pointer" rel="{$fb.feedback_id}">{$lang.feedback.html_feedback_delete}</a><!-- ɾ�� -->
			        				</td>
			        			</tr>
			        		{/foreach}
			        	</table>
		        	</form>
                <div id="feedbackpageurl">{$pageurl}</div>
			{else}
				<div class="notice_msg" style="text-algin:center" align="center">{$lang.php_nodata}</div><!-- �������� -->
			{/if}
            
            {/if}

		{if $action == 'replymessage'}

		<script type="text/javascript" >
			$(document).ready(function(){
				<!-- �ظ������ύ -->
				$("#phpfeedback").submit(function(){
					var value = $("#feedbackcontent").val();
					if(empty(value)){
						showNotice(refeedback_content_not_null);<!-- �ظ����ݲ���Ϊ�� -->
						return false;
					}
					$("#phpfeedback").attr("action", "index.php?m=member/feedback&a=replymessage");
					$("#phpfeedback").ajaxSubmit(function(data){
						switch($.trim(data)){
						case "1":
							window.parent.showNotice(add_success);<!-- ���ӳɹ� -->
							window.location.reload();
							break;
						case "2":
							showNotice(operation_error);<!-- �������� -->
							break;
						case "3":
							showNotice(refeedback_content_not_null);<!-- �ظ����ݲ���Ϊ�� -->
							break;
						default:
							showNotice(add_fail);<!-- ����ʧ�� -->
							break;
						}
					});
					return false;
				});
			});
		</script>

			<div id="memssage_contents">
                    	{foreach from=$feedbacks item=fb}
                      	{if $feedbackid == $fb.feedback_id}
									<p  style="padding:8px 5px; border-bottom:1px solid #CDCDCD;"><strong>{$lang.feedback.html_feedback_type}</strong>{$fb.feedback_type} &nbsp;&nbsp;<strong>{$lang.feedback.html_feedback_title}</strong>{$fb.feedback_title} &nbsp;&nbsp;<span style="color:#666666;">{$fb.feedback_time|date_format:"%Y-%m-%d %H:%M:%S"}</span></p>
								{/if}<!-- �������ͣ� ���Ա���:-->
                                
                      <div class="message">
                      {if !$fb.admin_name}
                    	<div class="usr_ct_list">
                    	<span class="message_user"><strong>{$fb.mem_username}</strong> {$fb.feedback_time|date_format:"%Y-%m-%d %H:%M:%S"}</span>
                      	<div class="user_content">{$fb.feedback_content}
                        {if $fb.feedback_rar}<br /><a href="../{$fb.feedback_rar}" target="_blank">{$lang.feedback.html_download_rar}</a>{/if}
                        </div>
                        </div>
                        {else}
                        <div class="admin_cp_list">
                       	<span class="message_admin">{$lang.feedback.html_admin} {$fb.admin_name} : {$fb.feedback_time|date_format:"%Y-%m-%d %H:%M:%S"}</span>
                        <div class="admin_content">{$fb.feedback_content}</div>
                        </div>
                        {/if}
                    </div>
						{/foreach}
			</div>
			<div class="clear"></div>
            <div style="height:5px;"></div>
            <div class="table_item_base">
            	<h1 class="c_bar">�ظ�</h1>
   			 <div class="c_content">
			<form id="phpfeedback" action="" method="post" autocomplete="off" enctype="multipart/form-data">
				<table  class="table_common">
					<tr>
						<td class="one">{$lang.feedback.html_return_content}</td><!-- >�ظ����ݣ� -->
						<td>
							<textarea class="form_textarea" id="feedbackcontent" name="feedbackcontent" rows="5" cols="70"></textarea>
						</td>
					</tr>
					<tr>
                    <td class="one"></td>
						<td>
<a href="javascript:;" onclick="submit_form('phpfeedback');" class="block_button form_btn">�ύ</a>
<a href="index.php?m=member/feedback&a=feedbacklist" class="block_button">����</a>
						</td>
					</tr>
					<input type="hidden" value="{$fb.mem_id}" name="memid" />
					<input type="hidden" value="{$fb.mem_username}" name="memusername" />
					<input type="hidden" value="{$feedbackid}" name="feedbackid" />
				</table>
			</form>
			<input id="curpage" value="{$curpage}" type="hidden" name="curpage"/>
            </div>
            </div>
		{/if}
	</div>

{include file='frame_footer.php'}