<?php exit('die'); ?>
{if $action eq 'export_xls'}
<head><meta http-equiv="Content-Type" content="text/html; charset=gb2312" /><style>td{vnd.ms-excel.numberformat:@}</style></head>
<table width="100%" border="1">
<tr>
{foreach from=$default item='menu'}
<th filter=all>{$menu.name}</th>
{/foreach}
</tr>
{foreach from=$data item=list}
	<tr>
	{foreach from=$default item='set'}
    	<td align="center">
        {foreach from=$list item='li' key=key}
        	{if $key eq $set.key}
                {if $key eq 'mem_group'}
					{$list.mem_group_name}
				{elseif $key eq 'mem_levelpoint'}
                	{$list.mem_level_name}
                {elseif $key eq 'mem_sex'}
                	{if $list.mem_sex eq '1'}<% _e('��');%>{elseif $list.mem_sex eq '2'}<% _e('Ů');%>{else} - {/if}
                {elseif $key eq 'mem_state'}
                	{if $list.mem_state eq '1'}<% _e('����');%>{else}<% _e('����');%>{/if}
              	  {else}
               		{$li}
                    {/if}
            {/if}
        {/foreach}
        </td>
    {/foreach}
        </tr>
 {/foreach}
</table>
{/if}
<!--#����-->
{if $action eq 'export_member_data'}
<script type="text/javascript">
	$(function(){
		$("#submit_menu_form").submit(function(){
			if(!get_checkbox_val('etag_val')){
				window.parent.showNotice('��ѡ������һ��!');return false;
			}
		});
	});
	function set_export(v){
		$("#export_type").val(v);
		$("#submit_menu_form").submit();
	}
</script>

<form method="post" action="index.php?m=member&a=export" id="submit_menu_form"  target="_blank">
<input type="hidden" value="" name="export_type" id="export_type" />
	<div class="set_menu_main">
        <div class="set_menus">
        <h1>��������</h1>
        <ul>
        {foreach from=$data item='item'}
        	<li><label><input  type="checkbox" class="etag_val" value="{$item.key}__{$item.name}" {if $item.sec eq '1'} checked="checked"{/if} name="set[]" /> 
            {$item.name}</label></li>
        {/foreach}
        <div class="clear"></div>
        </ul>
      {*}  <h1>ѡ�񵼳�����</h1>
        <ul>
        	<li><input  type="radio"  checked="checked"  name="fetch_type" value="xls" />Excel</li> <li><input type="radio" name="fetch_type" value="txt" /> ���ı�</li>
        </ul>
        {*}
<div class="set_sub"><input type="button" onclick="set_export('');" value="<% _e('�����������');%>"  class="form_submit"/> <input type="button" class="form_submit" onclick="set_export('only_select');" value="ֻ������ѡ��Ա" /></div>
        </div>
    </div>
</form>
{/if}