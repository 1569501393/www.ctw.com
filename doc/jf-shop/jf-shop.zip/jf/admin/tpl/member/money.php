<?php if(!defined('PHP_TEMPLATE'))exit(); ?>
{if $action eq 'logs'}
{include file="frame_header.php"}
	<script type="text/javascript">
	{foreach from=$lang.money.js_html key=key item=item}
		var {$key} = "{$item}";
	{/foreach}
	function showAlertMoney(mem_id){
		var url = "index.php?m=member/money&a=alertmoney&id="+mem_id;
		window.parent.showWindow(alert_mem_money,url,500,250);
	}
	function showMoney(obj){
		return window.parent.showWindow($(obj).html(),$(obj).attr('rel'),890,350);
	}
	</script>
	{/literal}
<div id="php_right_main_content">
{if $data.total>0}
	<table class="table_list table_list_common">
	<tr>
	<th>{$lang.money.option}<!--����--></th>
	<th width="100">{$lang.money.mem_name}<!--��Ա����--></th>
	<th>{$lang.money.curr_money}<!--��ǰ�ʽ�--></th>
	</tr>
	{foreach from=$data.data item=m}
	<tr>
	<td align='center' width='380px'>
    {if $can_view}
	<a  href="javascript:;" onclick="showMoney(this)"  rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$m.mem_id}&type=1">{$lang.money.agent_payment1}<!--���۷�--></a> <a  href="javascript:void(1);"  onclick="showMoney(this)" rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$m.mem_id}&type=2">{$lang.money.agent_payment2}<!--����ֵ--></a> <a  href="javascript:void(1);"  onclick="showMoney(this)" rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$m.mem_id}&type=3">{$lang.money.agent_payment3}<!--���߳�ֵ--></a> <a  href="javascript:void(1);" onclick="showMoney(this)"  rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$m.mem_id}&type=4">{$lang.money.agent_payment4}<!--Ԥ���֧��--></a> <a  href="javascript:void(1);"  onclick="showMoney(this)" rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$m.mem_id}">{$lang.money.agent_payment5}<!--ȫ����־--></a> {/if}
    {if $can_edit}  <a href='javascript:void(0)' onclick="showAlertMoney({$m.mem_id})">{$lang.money.agent_payment6}<!--�޸��ʽ�--></a>
    {/if}
	</td>
	<td align='center'>
<a href="javascript:;" onclick="window.parent.showWindow($(this).html(),'index.php?m=member&a=detail&memid={$m.mem_id}&noborder=true',750,250);">{$m.mem_username}</a></td>
	<td align='center'>{$m.result_money}</td>
	</tr>
	{/foreach}
	</table>
    <div class="clear"></div>
    <div id="money_log_page">{$data.page}</div>
    {else}
    <div class="notice_msg">
    	{$lang.php_nodata}
    </div>
{/if}
</div>
{include file="frame_footer.php"}
<!--end action for logs-->
{/if}