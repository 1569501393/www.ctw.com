<?php if (! defined ( 'PHP_TEMPLATE' ))exit (); ?>
{if $action eq 'change'}
<!--ajax call action-->
<div style="padding:3px;">
{literal}
	<script type="text/javascript">
    	$(document).ready(function(){
			$("#change_money").submit(function(){
				if(!check_form_is_empty('c'))return false;
				$(this).ajaxSubmit({success:function(data){
					var u= 'index.php?m=member/money&a=money';
					var d = data.split('|');
					var e = $.trim(d[0]);
					var m = $.trim(d[1]);
					switch(e){
						case '1':
							window.parent.showNotice(php_save_ok);
							//window.parent.$("#right_frame").attr({"src":u});
							window.parent.hidenLayer();
						break;
						case '2':window.parent.showNotice(m);break;
						default:alert(data);
					}
				}});
				return false;
			});
		});
    </script>
{/literal}
	<form method="post" id="change_money" action="index.php?m=member/money&a=alertmoney" autocomplete="off">
    	<input type="hidden" value="{$mem_id}" name="mem_id" />
        <table class="table_common">
        	<tr>
            	<td width="100" class="one" nowrap="nowrap"><!--�ʽ�䶯ԭ��-->{$lang.money.money_channge_reson}:</td>
                <td width="490">
                	<textarea name="desc" class="c" id="reson" style="height:50px; width:250px;"></textarea> <span class="blue">*</span>
                </td>
            </tr>
            <tr>
            	<td class="one"><!--����-->{$lang.money.modify_mondy_type}��</td>
                <td><select name="item"  style="width:150px;">
                    <option value="+"><!--����-->{$lang.money.money_add}</option>
                    <option value="-"><!--����-->{$lang.money.money_cut}</option>
                </select></td>
            </tr>
            <tr>
            	<td class="one" nowrap="nowrap">
                <!--�����ʽ��˻�-->{$lang.money.can_use_money}:
                  </td>
            	<td><input type="text" value="" class="c" style="width:150px;" name="change_money" /> <!--Ԫ-->{$lang.money.yuan} &nbsp;<!--��ǰ�����ʽ�--><p>{$lang.money.curent_can_use_money}:{$result_money|default:'0.00'}<!--Ԫ-->{$lang.money.yuan}</p>
                </td>
            </tr>
            <tr>
	            <td  align="center" colspan="2">
                		<input type="submit" value="{$lang.php_save}" class="form_submit" />
                </td>
            </tr>
        </table>
    </form>
    </div>
{/if}

{if $action eq 'log_detail'}
{if $opt neq 'not_show_header'}<!--ajax call data-->
{include file="frame_header.php"}
{/if}
{if $data.total>0}
    {if $opt neq 'not_show_header'}
        <div  id="php_top_bar">
            <a class="block_button"  href="index.php?m=member/money&a=money">{$lang.php_return}</a>
        </div>
        <div class="clear"></div>
        <div id="php_right_main_content">
    {/if}
	<table class="table_list">
        <tr>
            <th style='width:80px'>{$lang.money.summary}<!--ҵ��ժҪ--></th>
            <th  nowrap="nowrap">{$lang.money.time_money}<!--��ʱ���--></th>
            <th nowrap="nowrap">{$lang.money.store_money}<!--������--></th>
            <th nowrap="nowrap">{$lang.money.pay_money}<!--֧�����--></th>
            <th  nowrap="nowrap">{$lang.money.overage_money}<!--��ǰ���--></th>
            <th nowrap="nowrap">{$lang.money.payment_name}<!--֧����ʽ--></th>
            <th  nowrap>{$lang.money.waterline_no}<!--֧������--></th>
            <th nowrap>{$lang.money.order_sn}<!--������--></th>   
            <th nowrap="nowrap">{$lang.money.alert_date}<!--�޸�����--></th>
            <th  nowrap="nowrap">{$lang.money.alert_because}<!--�޸�ԭ��--></th>
            </tr>
        {foreach from=$data.data item=m}
        <tr>
            <td align='center' nowrap="nowrap">
            {if $m.type eq 1}<b>{$m.manager_name}</b> {$lang.money.agent_reduce}<!--���۷�-->{/if}
            {if $m.type eq 2}<b>{$m.manager_name}</b> {$lang.money.agent_increase}<!--����ֵ-->{/if}
            {if $m.type eq 3}{$lang.money.advance_increase}<!--Ԥ����ֵ-->{/if}
            {if $m.type eq 4}{$lang.money.advance_reduce}<!--Ԥ���֧��-->{/if}
            </td>
            <td align='center' nowrap="nowrap">{$m.current_money_f}</td>
            <td align='center' nowrap="nowrap">{if $m.add_money neq '0.000'}{$m.add_money_f}{else}-{/if}</td>
            <td align='center' nowrap="nowrap">{if $m.cut_money neq '0.000'}{$m.cut_money_f}{else}-{/if}</td>
            <td align='center' nowrap="nowrap">{$m.result_money_f}</td>
            <td align='center' nowrap="nowrap">{$m.pay_name|default:'-'}</td>
            <td align='center' nowrap="nowrap">{$m.waterline_no|default:'-'}</td>
            <td align='center' nowrap="nowrap">{$m.order_sn|default:'-'}</td>
            <td align='center' nowrap="nowrap">{$m.date|date_format:"%Y-%m-%d %H:%M:%S"}</td>
            <td align="left" >{$m.desc}</td>
        </tr>
        {/foreach}
        <tr>
            <td colspan="10" align="right" style="padding-right:10px;">
{if !$type}
<a href="javascript:;" onclick="showMoney(this)" class="block_button" rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$id}&type=1">���۷�</a>
<a href="javascript:;" onclick="showMoney(this)" class="block_button" rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$id}&type=2">����ֵ</a>
<a href="javascript:;" onclick="showMoney(this)" class="block_button" rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$id}&type=3">���߳�ֵ</a> 
<a href="javascript:;" onclick="showMoney(this)" class="block_button" rel="index.php?m=member/money&a=moneylog&opt=not_show_header&id={$id}&type=4">Ԥ���֧��</a>  
{/if}
<!--��ǰ��Ա�ʽ����Ϊ-->{$lang.money.curent_member_money_leave}: {$total_money} </td>

        </tr>
	</table>
<script type="text/javascript">
function showMoney(obj){
	window.parent.showWindow($(obj).html(),$(obj).attr('rel'),890,350);
}
</script>
    <div class="clear"></div>
	<div id="do_pages_money_log">{$data.page}</div>
{if $opt neq 'not_show_header'} </div> {else}
    <script  type="text/javascript">
	$(document).ready(function(){page_function('do_pages_money_log',find_window_class(),'.');})
</script>
    {/if}
{else}
    {if $opt neq 'not_show_header'}
        <div  id="php_top_bar">
            <a class="block_button" href="index.php?m=member/money&a=money">{$lang.php_return}</a>
        </div>
        <div class="clear"></div>
        <div id="php_right_main_content">
        <div class="spacer"></div>
        <div class="clear"></div>
    {/if}
	<div class="notice_msg"> {$lang.money.no_log}<!--����־--> </div>
    {if $opt neq 'not_show_header'}</div>{/if}
{/if} 
    {if $opt neq 'not_show_header'} {include file="frame_footer.php"}{/if}
{/if}