<?php exit('die'); ?>
{if $action eq 'group_list'}
{include file="frame_header.php"}
<script type="text/javascript">
function _do_group(obj,title,type){
	window.parent.showWindow(title,'index.php?m=member/group&a=call&type='+type,800,300);	
}
function delete_group(obj,id){
	if(!confirm("ȷ��ɾ����?���˷��������û�,��÷����µ��û��Զ��鵽Ĭ�Ϸ���!"))return false;
	$.get('index.php?m=member/group&a=call&type=delete',{id:id},function(data){
		switch(data){
			case 'OK':
				window.parent.showNotice(php_do_ok);
				$("#ddd_"+id).remove();
			break;
			default:alert(data);
		}
	});
}
</script>
<div id="php_top_bar">
    <div class="top_bar_pannel">
        <div class="tb"><a href="javascript:;"  class="block_button form_btn"  onclick="window.parent.showWindow($(this).html(),'index.php?m=member/group&a=call&type=add',800,300);">���ӷ���</a>
        </div>
    </div>
</div>
<div id="php_right_main_content">
	<table class="table_list table_list_common">
    	<tr>
        	<th>��������</th>
            <th>�ۿ�</th>
            <th>����</th>
            <th>����</th>
        </tr>
        {foreach from=$data item='group'}
    	<tr id="ddd_{$group.group_id}" class="etet">
        	<td align="center"><a href="index.php?m=member&a=memberList&groupid={$group.group_id}">{$group.group_name}</a><font class="blue"> ({$group.total|default:0})</font></td>
            <td align="center">{if $group.discount eq '1'}���ۿ�{else}{$group.discount*10} ��{/if}</td>
            <td align="center">{$group.group_desc}</td>
            <td align="center"><a href="javascript:;" rel="�༭�û�����->{$group.group_name}" onclick="window.parent.showWindow($(this).attr('rel'),'index.php?m=member/group&a=call&type=edit&id={$group.group_id}',800,300);">��</a> {if $group.is_system neq '1'} <a href="javascript:;" onclick="delete_group(this,'{$group.group_id}');">ɾ</a>{/if}</td>
        </tr>
        {/foreach}
    </table>
</div>
{include file="frame_footer.php"}
{/if}
{if $action eq 'edit' || $action eq 'add'}
<script type="text/javascript">
$(function(){
	$("#do_group_action").submit(function(){
		if(!check_form_is_empty('group_input'))return false;
		$(this).ajaxSubmit(function(data){			
			switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
					close_window();
					window.frames['rightFrame'].location.reload();
				break;
				case 'ERROR_DISC':
					window.parent.showNotice("�ۿ۷�Χ����!");
					$("#group_disc_e").val('');
				break;
				case 'HAS_EXIST':
					window.parent.showNotice("������ͬ�ķ�������!");$("#group_name_e").val('');
				break;
				default:alert(data);
			}
		});
		return false;
	});
});
</script>
<form method="post" action="index.php?m=member/group&a=call" id="do_group_action" autocomplete="off">
<input type="hidden" value="{$action}"  name="action"/>
	<table class="table_common">
    	<tr>
        	<td class="one">��������</td>
            <td><input type="text" value="{$data.group_name}" class="group_input" maxlength="20"  id="group_name_e" name="group_name"/></td>
        </tr>
    	<tr>
        	<td class="one">�������ۿ�</td>
            <td><input type="text" value="{$data.discount_format|default:'100'}"  class="group_input" id="group_disc_e" name="group_disc"/>%(��Χ:1-100)</td>
        </tr>
        
    	<tr>
        	<td class="one">�������</td>
            <td><textarea name="short_desc" class="seo_set">{$data.group_desc}</textarea></td>
        </tr>
        <tr>
	        <td class="one"></td>
            <td><a href="javascript:;" onclick="submit_form('do_group_action');" class="block_button form_btn">�� ��</a></td>
        </tr>
    </table>
    </form>
{/if}