<?php exit('die'); ?>
{if $action eq 'changePointLogs'}
	<!--������Ա��־-->
    {literal}
    	<script type="text/javascript">
        	$(document).ready(function(){
				$("#change_points").submit(function(){
					if(!check_form_is_empty('cc'))return false;	
					var dom = $("#aaaa");
					$(dom).attr("disabled",true);
					$(this).ajaxSubmit({success:function(data){
							$(dom).attr("disabled",false);
							var d = data.split('|');
							switch(d[0]){
								case '1':
									return window.parent.showNotice(d[1]);
								break;
								case '2':
									window.parent.showNotice(d[1]);
									window.parent.hidenLayer();
									return ;
								break;
								default:alert(data);
							}
					}})
					return false;
				})
			})
        </script>
    {/literal}
    <form method="post" action="index.php?m=member&a=changePointLogs"  id="change_points" autocomplete="off">
    <input type="hidden" value="{$mem_id}"  name="mem_id"/>
    	<table class="table_common">
        <tr>
        	<td  class="one"><!--��ǰ���û���-->{$lang.member.point.curent_order_point}</td>
            <td>{$total_point}</td>
        </tr>
        <tr>
        	<td class="one">��������</td>
            <td><select  name="type" style="width:300px;">
                	<option  value="add">{$lang.member.point.add}</option><!--����-->
                    <option value="dec">{$lang.member.point.decline}</option>
                </select></td>
        </tr>
        <tr>
        	<td class="one">��������
            </td>
            <td>
            	<input type="text" class="cc" value=""  style="width:300px;" name="point"/>
            </td>
        </tr>
        <tr>
        	<td class="one"><!--������ע-->{$lang.member.point.guanlibeizhu}</td>
            <td><textarea style="width:300px; height:100px;"  name="desc" class="cc"></textarea> <!--����10����-->
            <br />
            {$lang.member.point.the_limit_text_length}</td>
        </tr>
        <tr>
        	<td colspan="2">
            	<input type="submit" value="{$lang.php_save}" class="form_submit" id="aaaa" />
            </td>
        </tr>
        </table>
    </form>
{/if}
{if $action eq 'view_point_logs'}
<!--��Ա������־-->
{if $data.total>0}
<div id="view_member_point_log">
	<table class="table_list">
        	<tr>
            <th><!--״̬-->{$lang.member.point.status}</th>
            <th><!--����-->{$lang.member.point.point}</th>
            <th><!--����ʱ��-->{$lang.member.point.opt_time}</th>
            <th><!--ҵ��ժҪ-->{$lang.member.point.yewuzhaiyao}</th>
            <th><!--������Ա-->{$lang.member.point.opter}</th>
            <th><!--������-->{$lang.member.point.order_sn}</th>
            </tr>
        {foreach from=$data.data item=log}
        	<tr>
            	 <td class="center" nowrap="nowrap">{if $log.status eq '+'}<!--����-->{$lang.member.point.add}{else}<!--����-->{$lang.member.point.decline}{/if}</td>
                 <td class="center">{$log.point|default:'-'}</td>
                <td class="center">{if $log.time}{$log.time|date_format:"%Y-%m-%d %H:%M:%S"}{else} - {/if}</td>
                <td>{$log.msg}</td>
                <td class="center">{$log.operator}</td>
                <td class="center">{$log.order_sn|default:'-'}</td>
            </tr>
           {/foreach}
    </table>
    <div align="right" style="padding:5px;"><!--��ǰ���û���-->{$lang.member.point.curent_order_point}:{$total_point}</div>
<div id="point_logs">{$data.page}</div>
<script  type="text/javascript">
	$(document).ready(function(){page_function('point_logs',find_window_class(),'.');})
</script>
    {else}
    <div class="notice_msg">{$lang.php_nodata}</div>
    {/if}
</div>
{/if}