<?php exit('die'); ?>
{if $action eq 'view_recive_addr'}
    {if !$is_ajax}
    {include file="frame_header.php"}
<form method="post"  id="sub_form_deliery" action="index.php?m=member&a=reciveadddr" autocomplete="off">
  <div id="php_top_bar">
  <div class="tb">�ջ��ˣ�</div>
  <div class="tb"><input type="text" value="{$get.receive_realname}" name="receive_realname" style="width:100px;" /></div>
  <div class="tb"><a href="javascript:;" onclick="submit_form('sub_form_deliery');"  class="block_button form_btn">����</a></div>
  {if $data.total>0}<div class="tb"><a href="javascript:;" onclick="butch_delete_info(this);" class="block_button form_btn">����ɾ��</a></div>{/if}
  </div>
</form>
<script type="text/javascript">
$(function(){
	$("#sub_form_deliery").submit(function(){
		var c = _s($(this));
		window.location.href=c;
		return false;
	});
});
</script>
   {/if}
{if !$is_ajax}
<div id="php_right_main_content">
{/if}
{if $data.total>0}
<script type="text/javascript" src="index.php?m=default&a=loadRegionJsonJoin"></script>
<script type="text/javascript">
$(function(){
	check_all('check_all','check_all');
	$(".earea").each(function(){
		if($(this).attr('append')!='1'){
			var v = $(this).html().split(',');
			var str = '';
			var tag = '';
			$(v).each(function(jj){
				str+=tag+php_region_json_join_data[v[jj]];
				tag = '-';
			});
			$(this).html(str).attr({'append':'1'});
		}
	});
});
function edit_deliery_name(obj){
	var id = $(obj).attr('rid');
	window.parent.showWindow($(obj).html(),'index.php?m=member&a=reciveadddr&task=edit&id='+id,950,350);
}
function butch_delete_info(){
	var c = get_checkbox_val('check_all');
	if(!c){
		window.parent.showNotice('��ѡ��Ҫ����������!');
		return false;
	}
	if(!confirm('ȷ��Ҫɾ����?�˲������ɻָ�!'))return false;
	$.post('index.php?m=member&a=reciveadddr',{task:'delete',ids:c},function(data){
		switch(data){
			case 'OK':
				var jj = c.split(',');
				$(jj).each(function(i){
					$(".eee_"+jj[i]).remove();
				});
				if(!$('.ecall_data').size())window.location.reload();
				window.parent.showNotice('�����ɹ�!');
			break;
			default:
			alert(data);
		}
	});
}
</script>
    <table class="table_list table_list_hover">
        <tr>
        	{if !$is_ajax}<th><input type="checkbox" value=""  id="check_all"/></th>{/if}
            <th>�ջ���</th>
            <th>��������</th>
            <th>���͵�ַ</th>
            <th>�ʱ�</th>
            <th>�绰</th>
            <th>�ֻ�</th>
            <th>����</th>  
			<th>����ʱ��</th>
            <th>����</th>
        </tr>
        {foreach from=$data.data item='tag'}
            <tr class="eee_{$tag.receive_id} ecall_data">
            	{if !$is_ajax}<td align="center"><input type="checkbox" class="check_all" value="{$tag.receive_id}" /></td>{/if}
                <td align="center">{$tag.receive_realname}</td>
                <td class="earea">{$tag.receive_area}</td>
                <td align="center">{$tag.receive_address}</td>
                <td align="center">{$tag.receive_postno}</td>
                <td align="center">{$tag.receive_phone}</td>
                <td align="center">{$tag.receive_mobile}</td>
                <td align="center">{$tag.receive_email}</td>
                <td align="center">{$tag.receive_time|date_format:"%Y-%m-%d"}</td>
                <td align="center"><a href="javascript:;" rid="{$tag.receive_id}" onclick="edit_deliery_name(this);">�༭</a></td>
            </tr>
        {/foreach}
    </table>
    <div class="clear"></div>
    {$data.page}
    {else}
    <div class="notice_msg">�޿�������!</div>
    {/if}

{if !$is_ajax}</div>{/if}

    {if !$is_ajax}
    {include file="frame_footer.php"}
    {/if}
{/if}

{if $action eq 'add_recive' || $action eq 'edit_recive'}
<script type="text/javascript" src="index.php?m=default&a=loadRegionJson"></script>
<script type="text/javascript">
function getRegionChild(obj){
	var pid = $(obj).val();
	pid = !pid?0:pid;
	var temp = php_region_json_data[pid];
	if(temp){
		var str = '';
		var option = '<option value="">��ѡ��...</option>';
		str += option;
		$(temp).each(function(j){
			str+='<option value="'+temp[j].id+'">'+temp[j].name+'</option>';
		});
		$(obj).parents('span').nextAll().find('select').html(option);
		$(obj).parents('span').next().find('select').html(str);
	}
}
$(function(){
	$("#submit_recive").submit(function(){
		var tag = false;
		$(".need_remove_node select").each(function(){
			var v = $(this).val();
			if(empty(v)){
				tag = true;
				$(this).addClass('empty_input_val');
			}else{
				tag = false;
				$(this).removeClass('empty_input_val');
			}
		});
		if(!check_form_is_empty('must_fill_in') || tag)return false;
		var mail = $("#rel_email").val();
		if(!is_email(mail) && !empty(mail)){
			window.parent.showNotice('�����ʽ����!');
			return false;
		}
		$(this).ajaxSubmit(function(data){
			switch(data){
				case 'OK':
					_close_window_one();
					_reload_frame();
					window.parent.showNotice('�����ɹ�!');
				break;
				default:alert(data);
			}
		});
		return false;
	});
});
</script>
    <form  id="submit_recive" method="post"  action="index.php?m=member&a=reciveadddr">
<input type="hidden"  value="{$task}" name="task" />
	<input type="hidden" value="{$data.receive_id}"  name="receive_id"/>
      <table class="table_common">
      	<tr>
        	<td class="one">�� �� ��</td> 
            <td><input type="text"  value="{$data.receive_realname}" name="receive_realname" class="form_input must_fill_in"/> <font class="red"> * </font></td>
        </tr>
        <tr>
        	<td class="one">��������</td>
            <td>         
            {if $task eq 'add'}
            {foreach from=$region item=item}
                <span class='need_remove_node'>
                <select class="get_all_node_all_adress" name="receive_area[]" onchange="getRegionChild(this)">
                 <option  value=''>��ѡ��...</option>
 				   {if $item.region_id}
		           	<option value="{$item.region_id}">{$item.region_name}</option>
	    		   {/if}
                </select>
                </span>
            {/foreach}
            {else}
            {$region}
            {/if}
            </td>
        </tr>
        <tr>
        	<td class="one">���͵�ַ</td>
            <td><input type="text" value="{$data.receive_address}"  name="data[receive_address]" class="form_input must_fill_in"/>
            <font class="red"> * </font></td>
        </tr>
        <tr>
        	<td class="one">��ϵ����</td>
            <td><input type="text" id="rel_email"  value="{$data.receive_email}" name="data[receive_email]"  class="form_input must_fill_in"/><font class="red"> * </font></td>
        </tr>
        <tr>
        	<td class="one">��ϵ�ʱ�</td>
            <td><input type="text" value="{$data.receive_postno}" class="form_input" name="data[receive_postno]" /></td>
        </tr>
        <tr>
        	<td class="one">��ϵ�绰</td>
            <td><input type="text" value="{$data.receive_phone}" name="data[receive_phone]"  class="form_input"/></td>
        </tr>
        <tr>
        	<td class="one">��ϵ�ֻ�</td>
            <td><input type="text" value="{$data.receive_mobile}"  name="data[receive_mobile]"  class="form_input"/></td>
        </tr>
        <tr>
        	<td class="one"></td>
            <td><input type="submit" value="�� ��" class="form_submit"  style="display: none;"/>
            	<a href="javascript:;" onclick="submit_form('submit_recive');" class="form_btn block_button">����</a>
            </td>
        </tr>
      </table>
    </form>
{/if}