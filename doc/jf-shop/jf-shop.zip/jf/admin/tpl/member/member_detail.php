<?php exit('die'); ?>
{if $action eq  'detail'}
{if $call_header neq 'true'}
	<tr  class="show_member_detail  show_member_detail_{$mem.mem_id}">
		<td colspan="10">
        {/if}
            	<script type="text/javascript">
				var alert_mem_money = '{$lang.php_alert_mem_money}';
				function showAlertMoney(mem_id){
					window.parent.showWindow(alert_mem_money,"index.php?m=member/money&a=alertmoney&id="+mem_id,600,300);
				}
				function showMoney(id,obj){
					window.parent.showWindow($(obj).attr('name'),'index.php?m=member/money&a=moneylog&opt=not_show_header&id='+id,970,400);
				}
				function showMemberPointLogs(id,obj){
					window.parent.showWindow($(obj).attr('name'),'index.php?m=member&a=viewPointLogs&id='+id,900,400);
				}
				function alertMemberPoint(id,obj){
					window.parent.showWindow($(obj).attr('name'),'index.php?m=member&a=changePointLogs&id='+id,600,300);
				}
                </script>
			{if $call_header neq 'true'}
        		<fieldset><legend>{$lang.member.html_userinfo}</legend><!-- �û�������Ϣ -->
            {else}
            	<div style="padding:5px;">
            {/if}
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_username}:</div><!-- �û��� -->
					{$mem.mem_username}
				</div>
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_email}:</div><!-- �������� -->
					{$mem.mem_email}
				</div>
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_mobile}:</div><!-- �ֻ� -->
					{$mem.mem_mobile}
				</div>
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_state}:</div><!-- �û�״̬ -->
					{if $mem.mem_state == '1'}{$lang.member.html_open}{else}{$lang.member.html_disable}{/if}<!-- ���� ����-->
				</div>
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_level}:</div><!-- �û��ȼ� -->
					{$mem.mem_level_name}
				</div>
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_point}:</div><!-- �û����� -->
					{$member_points} 
                    {if $can_view_point_log}
                    <a href="javascript:;" class="blue"  onclick="showMemberPointLogs('{$mem.mem_id}',this);" name="{$mem.mem_username}-{$lang.member.point_logs_desc}"><b>������־</b></a> &nbsp; {/if} {if $can_edit_point} <a href="javascript:;" onclick="alertMemberPoint('{$mem.mem_id}',this);" id="{$mem.mem_id}" name="{$mem.mem_username}-{$lang.member.change_accunt_point}"><b class="blue"><!--�����˻�-->
                    ���ڻ���</b></a> {/if}
				</div>
                <!--�û��鿪ʼ-->
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_group}:</div>
					{$mem.group_name}<span class="blue">({if $mem.group_zkou<1}{$mem.group_zkou}��{else}���ۿ�{/if})</span>
				</div>
                <!--�û������-->
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_money}:</div>
					<!-- �û���� -->
					{$mem.mem_money} {if $can_edit_money_log}<a href="javascript:;" class="blue" onclick="showAlertMoney('{$mem.mem_id}');"><b><!--���ڻ�Ա�ʽ�-->
					�����ʽ�</b></a> {/if}  {if $can_view_money_log}<a onclick="showMoney('{$mem.mem_id}',this);" href="javascript:;" class="blue" name="{$mem.mem_username}-{$lang.member.member_account_log}"><!--�˻���־--><b>�ʽ���־</b><!--��־--></a> {/if}
				</div>
				{foreach from=$regitems item=attr}
					<div class="member_detail_info_div" >
						<div class="member_detail_info">{$attr.attr_name}:</div>
						{$attr.value_name}
					</div>
				{/foreach}
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_loginip}:</div><!-- ע��ip -->
					{$mem.mem_reg_ip}
				</div>
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_last_landingip}:</div><!-- ����½ip -->
					{$mem.mem_last_login_ip}
				</div>
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_logintime}:</div><!-- ע��ʱ�� -->
					{$mem.mem_register_time|date_format:"%Y-%m-%d %H:%M:%S"}
				</div>
				<div class="member_detail_info_div" >
					<div class="member_detail_info">{$lang.member.html_user_landingtime}:</div><!-- ����½ʱ�� -->
					{$mem.mem_last_login_time|date_format:"%Y-%m-%d %H:%M:%S"}
				</div>
                <div class="member_detail_info_div" >
					<div class="member_detail_info">�ջ���ַ:</div><!-- ����½ʱ�� -->
					<a href="javascript:;" onclick="window.parent.showWindow('�ջ���ַ','index.php?m=member&a=viewreciveadddr&id={$mem.mem_id}',900,300);"><b class="blue">�鿴�༭�ջ���ַ</b></a>
				</div>
                <div class="member_detail_info_div" >
					<div class="member_detail_info">TA�Ķ���:</div><!-- ����½ʱ�� -->
					<a href="javascript:;" onclick="window.parent.showWindow('��{$mem.mem_name}���Ķ���','index.php?m=order&a=searchOrder&member_name={$mem.mem_username}',970,400);"><b class="blue">��{$total_order|default:'0'}������ </b></a>
				</div>
                
                
		{if $call_header neq 'true'}
            </fieldset>
            	</td>
			</tr>
   		 {else}
  		  </div>
    {/if}
{/if}