<?php exit('HTML');?>
    <table class="table_common">
    	{if $is_region_info}<tr>
        	<td align="right" class="one">������</td>
            <td>
            	<input type="text" value="{$html_extend.doman_data}" class="bg_input" name="html_extend[doman_data]" style="width:250px;"/> 
                <p>����д�������ɵľ�̬ҳ������������!Ĭ��Ϊ��!</p>
            </td>
        </tr>
        {/if}
        {if !$is_region_info}
        <tr>
            <td class="one"><% _e('�ļ�����Ŀ¼');%></td>
            <td>
            <script  type="text/javascript">
            	function set_category_type(obj){
					var a =$(obj).attr("checked");
					var tag = $("#category_main_path");
					if(a){
						tag.attr({"disabled":'disabled'});
						$(tag).hide();
					}else{
						tag.removeAttr('disabled');
						$(tag).show();
					}
				}
            </script>
<input style="width:250px; {if $html_extend.main_path eq ''}display:none; {/if}" type="text" id="category_main_path"  value="{$html_extend.main_path}"  class="bg_input" name="html_extend[main_path]" />
<label><input type="checkbox" id="is_use_pinyin" value="1" {if $html_extend.main_path eq ''} checked="checked" {/if} name="html_extend[main_path_type]" onclick="set_category_type(this);"/> <%_e('ʹ��ƴ��');%></label>
            </td>
        </tr>
        <tr>
        	<td class="one"><% _e('Ŀ¼�������');%></td>
            <td>
 <input  type="radio" value="system" {if $html_extend.path_position neq 'root' && $html_extend.path_position neq 'parent'} checked="checked"{/if} name="html_extend[path_position]"/> <% _e('ϵͳԤ��Ŀ¼');%> 
 <input  name="html_extend[path_position]" type="radio" value="root"  {if $html_extend.path_position eq 'root'} checked="checked"{/if} /><% _e('��վ��Ŀ¼');%>
<!-- <input  type="radio" value="parent" {if $html_extend.path_position eq 'parent'} checked="checked"{/if} name="html_extend[path_position]"/> �̳и���Ŀ¼ -->
            </td>
        </tr>
        <tr>
            <td class="one"><% _e('�ļ���������');%></td>
            <td><input type="text" value="{$html_extend.name_space}" name="html_extend[name_space]" class="bg_input" style="width:250px;" />
<p><% _e('��ѡ����:{id}����ID<br />�Զ����Ŀ¼���� (���ܳ��ֲ���ϵͳ����ʶ����ַ�,����\)');%>  </p>
            </td>
        </tr>
        {/if}
    </table>