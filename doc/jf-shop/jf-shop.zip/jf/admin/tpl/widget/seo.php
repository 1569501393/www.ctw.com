<?php exit('exit'); ?>
<table class="table_common">
<tr>
    <td  class="one">meta->title</td>
    <td><textarea   name="seo[meta_title]"  class="seo_set">{$data.seo_info.meta_title}</textarea></td>
</tr>

    <tr>
        <td class="one"><% _e('ҳ�����');%></td>
        <td><textarea  name="seo[title]" class="seo_set">{$data.seo_info.title}</textarea></td>
    </tr>
   <tr>
        <td class="one">�ؼ���</td>
        <td><textarea   class="seo_set" name="seo[keywords]" >{$data.seo_info.keywords}</textarea></td>
    </tr>
   <tr>
        <td class="one">ҳ������</td>
        <td><textarea  class="seo_set" name="seo[description]">{$data.seo_info.description}</textarea></td>
    </tr>
</table>