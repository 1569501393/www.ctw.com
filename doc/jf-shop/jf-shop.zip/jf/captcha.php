<?php 
	error_reporting(0);
	require dirname(__FILE__).'/init.php';
	import('@.core.captcha');
	$w = intval(empty($_GET['w'])?100:$_GET['w']);
	$h = intval(empty($_GET['h'])?20:$_GET['h']);
	$hash = $_GET['hash']=='0'?false:true;
	$num = intval(empty($_GET['num'])?4:$_GET['num']);
	Captcha::getInstance(false,$h,$w,$num,$hash)->outPutImg();
?>