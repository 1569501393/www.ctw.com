<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZ',
    'name' => 'Discuz! Board',
    'url' => 'http://wms.com/dz72',
    'ip' => '127.0.0.1',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => '',
    'recvnote' => '1',
  ),
  2 => 
  array (
    'appid' => '2',
    'type' => 'OTHER',
    'name' => 'UC1.5����',
    'url' => 'http://yijing.com',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc15.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://wms.com/dz72/uc_server',
);
