<?php exit(); ?>
DELETE FROM `##__core_setting`  WHERE `s_name` = 'tuangou_all_config';
DELETE FROM `##__core_auth_list`  WHERE `model` = 'components' AND `extend`='tuangou';
DROP TABLE IF EXISTS `##__tuangou_category`;
DROP TABLE IF EXISTS `##__tuangou_goods`;
DROP TABLE IF EXISTS `##__tuangou_order`;
DROP TABLE IF EXISTS `##__tuangou_order_remark`;
DROP TABLE IF EXISTS `##__tuangou_pay_log`;
DROP TABLE IF EXISTS `##__tuangou_region_goods`;
DROP TABLE IF EXISTS `##__tuangou_subscribe`;