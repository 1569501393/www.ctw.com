<?php exit('die'); ?>
DROP TABLE IF EXISTS `##__tuangou_category`;
CREATE TABLE `##__tuangou_category` (
  `id` int(11) NOT NULL auto_increment,
  `sort` int(3) default '0' ,
  `name` varchar(100) default NULL ,
  `group_name` varchar(50) default NULL,
  `en_name` varchar(100) default NULL ,
  `en_first` varchar(5) default NULL ,
  `desc` text ,
  `seo` text ,
  `tpl` varchar(200) default NULL ,
  `type` tinyint(2) default '1' ,
  `add_time` int(10) default NULL ,
  `edit_time` int(10) default NULL ,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk;

DROP TABLE IF EXISTS `##__tuangou_goods`;
CREATE TABLE `##__tuangou_goods` (
  `id` int(10) NOT NULL auto_increment,
  `cate_id` int(10) default NULL ,
  `project_name` varchar(255) default NULL ,
  `seo` text ,
  `tpl` varchar(200) default NULL ,
  `type` tinyint(2) default '1' ,
  `add_time` int(10) default NULL ,
  `edit_time` int(10) default NULL ,
  `conduser` varchar(2) default 'Y' ,
  `buyonce` varchar(2) default 'Y' ,
  `sort` int(6) default NULL ,
  `market_price` decimal(20,2) default '0.00' ,
  `shop_price` decimal(20,2) default '0.00' ,
  `pre_number` int(10) default NULL ,
  `start_time` int(10) default NULL ,
  `end_time` int(10) default NULL ,
  `min_number` int(10) default NULL ,
  `max_number` int(10) default NULL ,
  `per_buy_number` int(10) default NULL ,
  `min_buy_number` int(10) default NULL ,
  `short_desc` text ,
  `spec_content` text ,
  `goods_name` varchar(255) default NULL ,
  `goods_extend_prefix` text ,
  `pic1` varchar(255) default NULL ,
  `pic2` varchar(255) default NULL ,
  `pic3` varchar(255) default NULL ,
  `pic4` varchar(255) default NULL ,
  `flv` varchar(255) default NULL ,
  `goods_detail` text ,
  `member_dianpin` text ,
  `mian_dan_num` tinyint(4) default NULL ,
  `peisong_desc` text ,
  `peisong_fee` decimal(20,2) default '0.00' ,
  `is_recomand` tinyint(2) default '0' ,
  `visted` int(10) default NULL ,
  PRIMARY KEY  (`id`),
  KEY `cate_id` (`cate_id`),
  KEY `start_time` (`start_time`),
  KEY `end_time` (`end_time`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

DROP TABLE IF EXISTS `##__tuangou_order`;
CREATE TABLE `##__tuangou_order` (
  `order_id` int(11) NOT NULL auto_increment ,
  `order_sn` varchar(60) default NULL ,
  `tuan_id` int(11) default NULL ,
  `project_name` varchar(255) default NULL ,
  `goods_name` varchar(255) default NULL ,
  `count` int(11) default NULL ,
  `cate_id` int(11) default NULL ,
  `add_time` int(10) default NULL ,
  `extend_data` text ,
  `mem_id` int(10) default NULL ,
  `re_name` varchar(50) default NULL ,
  `re_phone` varchar(20) default NULL ,
  `re_address` varchar(255) default NULL,
  `re_zip` varchar(10) default NULL,
  `re_order_type` text ,
  `re_extend` text ,
  `total_delivery_fee` float(20,2) default '0.00' ,
  `delivery_fee` float(20,2) default '0.00' ,
  `goods_money` float(20,2) default '0.00' ,
  `total_goods_money` float(20,2) default '0.00' ,
  `total_order_fee` float(20,2) default '0.00' ,
  `pay_status` tinyint(2) default '0' ,
  `pay_time` int(11) default NULL ,
  `wuliu_sn` varchar(100) default NULL ,
  `wuliu_name` varchar(150) default NULL ,
  `order_remark` text ,
  PRIMARY KEY  (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

DROP TABLE IF EXISTS `##__tuangou_order_remark`;
CREATE TABLE `##__tuangou_order_remark` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `order_id` int(10) default NULL ,
  `who` varchar(50) default NULL ,
  `time` int(11) default NULL ,
  `desc` text ,
  `extend_data` text,
  PRIMARY KEY  (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM   DEFAULT CHARSET=gbk;

DROP TABLE IF EXISTS `##__tuangou_pay_log`;
CREATE TABLE `##__tuangou_pay_log` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `order_id` int(11) default NULL ,
  `pay_time` int(11) default NULL ,
  `pay_sn` varchar(200) default NULL ,
  `mem_id` int(11) default NULL ,
  `money` float(20,2) default '0.00' ,
  `pay_method` varchar(50) default NULL ,
  `extend_data` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM   DEFAULT CHARSET=gbk;

DROP TABLE IF EXISTS `##__tuangou_region_goods`;
CREATE TABLE `##__tuangou_region_goods` (
  `region_id` int(11) default NULL,
  `tuan_id` int(11) default NULL,
  KEY `region_id` (`region_id`),
  KEY `tuan_id` (`tuan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

DROP TABLE IF EXISTS `##__tuangou_subscribe`;
CREATE TABLE `##__tuangou_subscribe` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `mail` varchar(150) default NULL,
  `time` int(11) default NULL,
  `region_id` int(11) default NULL,
  `region_name` varchar(50) default NULL,
  `phone` varchar(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk;