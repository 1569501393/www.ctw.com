<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=<?php echo $this->_tpl_var['outPutChar']; ?>" />

<title><?php echo $this->_tpl_var['lang']['common']['site_admin_title']; ?></title>
<link href="style/layout.css" rel="stylesheet" type="text/css"/>
<link href="style/<?php echo $this->_tpl_var['__default_skin__']; ?>.css" id="call_css_tag_frame" rel="stylesheet" type="text/css" media="screen"/>
<?php echo '<script type="text/javascript" charset="GBK" src="js/jquery-1.4.min.js"></script>
' ?>
<?php echo $this->_tpl_var['editor_js']; ?>
<?php  $this->display('frame_js.php'); ?>
<?php if ($this->_tpl_var['calendar']){ ?>
<script type="text/javascript" charset="gbk" src="js/jscal2.js"></script>
<?php } ?>
</head>