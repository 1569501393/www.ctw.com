<div class="clear"></div>
</div>
<div class="clear"></div>
<div id="php_footer" style="display:none;">
<?php echo sys_debug_info_for_admin(array ( "show_log" => "false",)); ?>
</div>
</div>
<?php  $this->display('footer_common.php'); ?>