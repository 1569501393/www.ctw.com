<?php  $this->display('skin.php'); ?>
<script type="text/javascript">
function show_window_for_editor(obj,ajaxCallUrl){return window.parent.show_window_for_editor(obj,ajaxCallUrl);}
function _change_skin(a){
	var append_css = 'style/'+a+'.css'
	$("#call_css_tag_frame").attr({"href":append_css});
	curent_skin = a;
	curent_skin_hover = skin_set[curent_skin].hover;
	curent_skin_default = skin_set[curent_skin].defaults;
	curent_skin_selected = skin_set[curent_skin].selected;
	loading_show_color = skin_set[curent_skin].loading;
	window.parent.loading_show_color = loading_show_color;
}
$(function(){
	$('.input_notice').poshytip();
	if($('.table_list_hover')){
		table_color('table_list_hover');fix_table_select('table_list_hover');fix_input('table_list_hover');		
	}
	if($('.table_list_common')){table_color('table_list_common');}
	if($('.table_list_hover').size()<1 && $('.table_list_common').size()<1 && $('.table_list').size()>0){
		table_color('table_list');
	}
	$(this).keypress(function(e){
		if(e.keyCode==27)window.parent.bind_map_key();
	});
	
	function _set_main_height(){
		var a = $("#php_right_main_content").size();
		var b = $("#php_top_bar").size();
		var cc = $('.php_bot_bar').size();
		var wj = parseInt($("#php_top_bar").height()+8);
		if(a>0 && b>0 && cc==0){
			$("#php_right_main_content").css({"margin-top":wj+"px"});
		}
		if(cc>0 && a>0 &&b>0){
			$("#php_right_main_content").css({"margin-bottom":wj+"px"});
		}
		return ;
		//margin-bottom:45px;
		var ooo = $(".top_bar_pannel");
		if(ooo.size()>0){
			var ww = $(this).width();
			var w = $(ooo).width();
			var wt = (w)/2;
			$(ooo).css({"padding-left":wt+"px"});
		}
	}
	_set_main_height();
	//window.parent._call_footer($("#php_footer").html());
	if($.browser.msie){$('.form_submit').focus(function(){$(this).blur();});}
	try{
		$(".table_common tr:last").find('td').css({"border":"none"});
		window.parent.set_curent_nav('<?php echo $this->_tpl_var['php_curent_model']; ?>','<?php echo $this->_tpl_var['php_curent_action']; ?>');
		
	}catch(e){}
});
</script>
<?php echo '<script type="text/javascript" charset="GBK" src="js/global.js"></script>
<script type="text/javascript" charset="GBK" src="js/jquery.poshytip.min.js"></script>
' ?>
<link href="<?php echo $this->_tpl_var['call_auto_url']; ?>" rel="stylesheet" type="text/css" media="screen"/>
</body>
</html>