<?php  $this->display('frame_header.php'); ?>
<form method="post" id="do_cache_config"  action="index.php?m=tools&a=saveCacheConfig">
<div id="php_top_bar"  class="php_bot_bar">
    <div class="top_bar_pannel">
     <a  href="javascript:;" onclick="window.location.reload();" class="block_button">ˢ ��</a>
    <?php if ($this->_tpl_var['can_config_cache']){ ?> <a  href="javascript:;" onclick="submit_form('do_cache_config');" class="block_button form_btn">�� ��</a> <?php } ?>
    </div>
</div>
<div id="php_right_main_content">
<script type="text/javascript">
function clearCache(opt){
	var url = 'index.php?m=tools&a=clearCache&task='+opt;
	$.get(url,function(data){
		switch(data){
			case 'OK':
			window.parent.showNotice(php_do_ok);return false;
			break;
			default:alert(data);return false;
		}
	});
}
function update_cates(){
	$.get('index.php?m=goods/goodsCategory&a=updateCatsCount',function(data){
		switch(data){
			case 'OK':window.parent.showNotice(php_do_ok);
			break;
			default:alert(data);
		}
	});	
}
$(function(){
	var tags = <?php if ($this->_tpl_var['can_config_cache']){ ?>'cfg_cache'<?php  }else{ ?>'cfg_cache_count'<?php } ?>;
	$.table_bars($("#site_cache_config .menu li"),tags);
	
	$("#do_cache_config").submit(function(){
		$(this).ajaxSubmit(function(data){
			 switch(data){
				case 'OK':
					window.parent.showNotice(php_do_ok);
				break;
				default:alert(data);
			 }
		});
		return false;
	});
});
</script>
<div id="site_cache_config" class="table_scroll">
<div class="menu">
	<ul>
    	<li name="cfg_all">ȫ��</li>
       <?php if ($this->_tpl_var['can_config_cache']){ ?> <li name="cfg_cache" class="wintable_curent">��������</li><?php } ?>
        <li name="cfg_cache_count" <?php if (! $this->_tpl_var['can_config_cache']){ ?> class="wintable_curent" <?php } ?>>����ͳ��</li>
        <li name="cfg_cache_clear">��������</li>
    </ul>
</div>
</div>

<div class="table_item_base">
<?php if ($this->_tpl_var['can_config_cache']){ ?>
<div class="table_item" id="cfg_cache">
	<h1 class="c_bar">��������</h1>
    <div class="c_content">
    <div class="notice_msg no_margin"><?php  _e('�ڷǿ���ģʽʱ,ϵͳ�Ỻ������ҳ��������Լӿ�����ٶ�!<br />�������ý��ڷǿ���ģʽ������! ��λ��Ϊ��,������Ϊ����ģʽ���php.config.php �ҵ� DEV_TYPE ����Ϊ true ��'); ?></div>
            <div class="clear"></div>
	<table class="table_common">
    	<tr>
        	<td class="one"><?php  _e('ģ�建������'); ?></td>
            <td ><input  type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['tpl_cache']) ? '3600' : $this->_tpl_var['config']['cache']['tpl_cache']; ?>" name="cache[tpl_cache]" /> <?php  _e('��'); ?>
            </td>
        </tr>
    	<tr>
        	<td class="one"><?php  _e('��̬��������'); ?></td>
            <td><input  type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['static_cache']; ?>" name="cache[static_cache]" /> <?php  _e('��'); ?></td>
        </tr>
    	<tr>
        	<td class="one"><?php  _e('������Ʒ����ҳ����'); ?></td>
            <td >
<input type="checkbox" value="1" <?php if ($this->_tpl_var['config']['cache']['open_goods_detail_static_cache'] == '1'){ ?> checked="checked"<?php } ?> name="cache[open_goods_detail_static_cache]"  onclick="ddd_click(this);"/> <span style="<?php if ($this->_tpl_var['config']['cache']['open_goods_detail_static_cache'] != '1'){ ?>display:none;<?php } ?>">��������Ϊ <input  type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['goods_detail_static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['goods_detail_static_cache']; ?>" name="cache[goods_detail_static_cache]" /> <?php  _e('��'); ?></span></td>
        </tr>
        <tr>
        	<td class="one"><?php  _e('������ҳ'); ?></td>
            <td ><input type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['index_static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['index_static_cache']; ?>"  name="cache[index_static_cache]"/> <?php  _e('��'); ?></td>
        </tr>
        <tr>
        	<td class="one"><?php  _e('������ҳ'); ?></td>
            <td ><input type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['region_index_static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['region_index_static_cache']; ?>"  name="cache[region_index_static_cache]"/> <?php  _e('��'); ?></td>
        </tr>
        <tr>
        	<td class="one"><?php  _e('Ʒ����ҳ'); ?></td>
            <td ><input type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['goods_brands_index_static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['goods_brands_index_static_cache']; ?>"  name="cache[goods_brands_index_static_cache]"/> <?php  _e('��'); ?></td>
        </tr>
        <tr>
        	<td class="one"><?php  _e('Ʒ������ҳ'); ?></td>
            <td><input type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['goods_brands_detail_static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['goods_brands_detail_static_cache']; ?>"  name="cache[goods_brands_detail_static_cache]"/> <?php  _e('��'); ?></td>
        </tr>
        <tr>
        	<td class="one"><?php  _e('�����ؼ�������'); ?></td>
            <td ><input type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['search_tag_static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['search_tag_static_cache']; ?>"  name="cache[search_tag_static_cache]"/> <?php  _e('��'); ?></td>
        </tr>
        <tr>
        	<td class="one"><?php  _e('��Ʒ��������'); ?></td>
            <td ><input type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['goods_category_detail_static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['goods_category_detail_static_cache']; ?>"  name="cache[goods_category_detail_static_cache]"/> <?php  _e('��'); ?></td>
        </tr>
        <tr>
        	<td class="one"><?php  _e('����������ҳ'); ?></td>
            <td ><input type="text" value="<?php echo empty($this->_tpl_var['config']['cache']['help_index_static_cache']) ? '3600' : $this->_tpl_var['config']['cache']['help_index_static_cache']; ?>"  name="cache[help_index_static_cache]"/> <?php  _e('��'); ?></td>
        </tr>
    </table>
</div>
</div>
<?php } ?>

<div class="table_item" id="cfg_cache_count">
	<h1 class="c_bar">����ͳ��</h1>
    <div class="c_content">
        <table class="table_common">
            <tr>
                <td class="one"><?php echo $this->_tpl_var['lang']['cache']['cache_model']; ?></td>
                <td ><div class="float_left" style="line-height:40px; height:40px; font-weight:bold;"><?php echo $this->_tpl_var['data']['cache_model']; ?></div><?php if ($this->_tpl_var['data']['cache_model'] == 'file'){ ?> <a  href="javascript:;" class="block_button" onclick="load_cache_data();" ><?php echo $this->_tpl_var['lang']['cache']['call_cache_status']; ?></a>
                
                    <script type="text/javascript">
                        function load_cache_data(){
                            $.getJSON('index.php?m=tools&a=loadFileCache&jsoncallback=?',function(json){
                                $("#cache_file_number").html(json.total_file);
                                $("#cache_size").html(json.total_size);
                            });	
                        }
                    </script><?php } ?>
                </td>
            </tr>
            <?php if ($this->_tpl_var['data']['server']){ ?>
                <tr>
                    <td  class="one"><?php echo $this->_tpl_var['lang']['cache']['mem_server']; ?></td>
                    <td >
                    <?php $_from = $this->_tpl_var['data']['server']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->_push_vars('', 'item');if (count($_from)){
    foreach ($_from AS $this->_tpl_var['item']){
?>
                     <?php echo $this->_tpl_var['item']; ?> &nbsp;
                    <?php };
 }; unset($_from); ?><?php $this->_pop_vars();?>
                    </td>
                </tr>
            <?php } ?>
            <?php if ($this->_tpl_var['data']['total_writen']){ ?>
                <tr>
                    <td  class="one"><?php echo $this->_tpl_var['lang']['cache']['mem_server_total_writen']; ?></td>
                    <td >
                    <?php echo $this->_tpl_var['data']['total_writen']; ?>
                    </td>
                </tr>
            <?php } ?>
            <tr>
                <td  class="one">ϵͳ�������ļ�</td>
                <td align="left" ><span id="cache_file_number"><?php if ($this->_tpl_var['cache_type'] != 'file'){ ?><?php echo $this->_tpl_var['data']['total_file']; ?><?php echo $this->_tpl_var['lang']['cache']['ge']; ?><?php } ?></span></td>
            </tr>
                <tr>
                <td  class="one"><?php  _e('��ʹ���ܿռ�') ?></td>
                <td align="left"><span id="cache_size"><?php echo $this->_tpl_var['data']['total_size']; ?></span></td>
            </tr>
            <?php if ($this->_tpl_var['cache_type'] != 'file'){ ?>
                <tr>
                <td  class="one"><?php  _e('�����ܿռ�') ?></td>
                <td align="left" ><span id="cache_size"><?php echo $this->_tpl_var['data']['total_limit']; ?></span></td>
            </tr>
            <?php } ?>
            <tr>
                <td  class="one">��������</td>
                <td align="left" ><?php echo $this->_tpl_var['data']['cache_time']; ?><?php echo $this->_tpl_var['lang']['cache']['time']; ?></td>
            </tr>
        </table>
	</div>
</div>

        <div class="table_item" id="cfg_cache_clear">
            <h1 class="c_bar">��������</h1>
                <div class="c_content">
                <a href="javascript:;" class="block_button" onclick="clearCache('all');"><?php  _e('ɾ�����л���'); ?></a>
                <a href="javascript:;" class="block_button" onclick="clearCache('static');"><?php  _e('ɾ����̬�ļ�����'); ?></a>
                <?php if ($this->_tpl_var['session_model'] == 'file'){ ?>
                <a href="javascript:;" class="block_button" onclick="clearCache('session');"><?php  _e('ɾ��Session�ļ�'); ?></a>
                <?php } ?>
                <a href="javascript:;" class="block_button" onclick="clearCache('all_tpl_cache');"><?php  _e('ɾ��ģ�建��'); ?></a>
                <a href="javascript:;" class="block_button" onclick="clearCache('temp_picture');"><?php  _e('ɾ����̬ͼƬ�ļ�'); ?></a>
                <div class="clear"></div>
                </div>
            </div>
    </div>
</div>
</div>
<?php  $this->display('frame_footer.php'); ?>