<script language="JavaScript">
var google_map_key = '<?php echo $this->_tpl_var['google_map_api_keys']; ?>';
var check_upload_pass;
var admin_root = '<?php echo $this->_tpl_var['admin_root_url']; ?>';
var bar_right = true;
var session_id = '<?php echo $this->_tpl_var['session_id']; ?>';
<?php $_from = $this->_tpl_var['lang']['common']['js_languages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->_push_vars('key', 'item');if (count($_from)){
    foreach ($_from AS $this->_tpl_var['key'] => $this->_tpl_var['item']){
?>var <?php echo $this->_tpl_var['key']; ?> = "<?php echo $this->_tpl_var['item']; ?>";<?php };
 }; unset($_from); ?><?php $this->_pop_vars();?>
</script>