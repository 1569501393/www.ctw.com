<script type="text/javascript">

var curent_skin = '<?php echo $this->_tpl_var['__default_skin__']; ?>';
var skin_set = {
		blue:{
				hover:'#F2F9FD',
				defaults:'#FFFFFF',
				selected:'#FBF1C4',
				loading:'#3C86C5'
			},
		black:{
				hover:'#FAFAFA',
				defaults:'#FFFFFF',
				selected:'#00000',
				loading:'#8C8C8C'
			},
		green:{
				hover:'#F4FDF2',
				defaults:'#FFFFFF',
				selected:'#E1ECDD',
				loading:'#4b9925'
			},
		yellow:{
				hover:'#FDF3EA',
				defaults:'#FFFFFF',
				selected:'#FBF1C4',
				loading:'#E77912'
			}
	};
var loading_show_color = skin_set[curent_skin].loading;
var curent_skin_hover = skin_set[curent_skin].hover;
var curent_skin_default = skin_set[curent_skin].defaults;
var curent_skin_selected = skin_set[curent_skin].selected;
</script>