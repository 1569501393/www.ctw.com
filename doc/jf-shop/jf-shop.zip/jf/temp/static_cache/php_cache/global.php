<?php 
 if(!defined('INC_PHP'))exit('php.cm');
$GLOBALS['PHP_SITE_CACHE'] = array (
  'html' => 
  array (
    'url_sufix' => '.html',
    'html_global_path' => '/a/',
    'html_region_main_path' => '/region/',
    'html_goods_category_rule' => '{global_path}/p/{self_config}',
    'html_goods_content_rule' => 'b/{Y}{M}/{md5time}',
    'html_goods_brand_rule' => '{global_path}/b/{self_config}',
    'html_brands_index' => '{global_path}/b/index',
    'article_domain' => '',
    'article_name_space' => '����Ƶ��',
    'html_article_main_path' => '/article/',
    'html_article_category_rule' => '{article_global_path}/c/{self_config}',
    'html_article_content_rule' => '{article_global_path}/a/{Y}{M}/{md5time}',
    'help_domain' => '',
    'help_name_space' => '��������',
    'helper_center_main_path' => '/help/',
    'help_article_category_rule' => '{help_global_path}/c/{self_config}',
    'help_article_content_rule' => '{help_global_path}/a/{md5time}',
  ),
  'integration' => 'phpmember',
  'integration_phpmember' => 
  array (
    'appname' => 'phpmember',
    'enable' => '1',
  ),
  'integration_ucenter' => 
  array (
    'appname' => 'ucenter',
    'enable' => '0',
    'config' => 
    array (
      'uc_api' => '',
      'uc_se_key' => '',
      'uc_app_id' => '',
      'uc_ip' => '',
      'uc_db_char' => 'gbk',
      'uc_char' => 'gbk',
      'uc_db_host' => '',
      'uc_db_name' => '',
      'uc_user_name' => '',
      'uc_db_pass' => '',
      'uc_db_prefix' => '',
    ),
  ),
  'member_register_argeement_content' => '��Աע��Э��,�뵽����-&amp;gt;��Ա����-&amp;gt;���޸�&lt;br /&gt;',
  'php_core_spilder_set' => 
  array (
    'baiduspider' => 
    array (
      0 => 'baidu ',
    ),
    'google' => 
    array (
      0 => 'google',
      1 => 'feedfetcher-google',
      2 => 'www.google.com',
      3 => 'googlebot ',
    ),
    'sosospider' => 
    array (
      0 => 'sosospider ',
    ),
    'sogou' => 
    array (
      0 => 'sogou web spider',
      1 => 'sogou inst spider',
      2 => 'sogou orion spider',
      3 => 'sogou ',
    ),
    'msn-bing' => 
    array (
      0 => 'msrabot ',
    ),
    'slurp-yahoo' => 
    array (
      0 => 'slurp',
      1 => 'yahoo',
      2 => 'yahoo! slurp ',
    ),
    'sohu' => 
    array (
      0 => 'sohu ',
    ),
    'Alexa' => 
    array (
      0 => 'ia_archiver',
      1 => 'iaarchiver ',
    ),
    'lycos' => 
    array (
      0 => 'lycos ',
    ),
    'qihoo' => 
    array (
      0 => 'qihoo ',
    ),
    'robozilla' => 
    array (
      0 => 'robozilla ',
    ),
    'youdaobot' => 
    array (
      0 => 'youdaobot ',
    ),
    'mj12bot' => 
    array (
      0 => 'mj12',
      1 => 'mj12bot ',
    ),
    'geohasher' => 
    array (
      0 => 'geohasher ',
    ),
    'webmastercoffee' => 
    array (
      0 => 'webmastercoffee ',
    ),
    'page2rss' => 
    array (
      0 => 'page2rss ',
    ),
    'gigabot' => 
    array (
      0 => 'gigabot ',
    ),
    'huaweisymantecspider' => 
    array (
      0 => 'huaweisymantecspider ',
    ),
    'sitebot' => 
    array (
      0 => 'sitebot ',
    ),
    'speedy' => 
    array (
      0 => 'speedy spider ',
    ),
    'unknow' => 
    array (
      0 => 'spider',
      1 => 'robot',
      2 => 'bot*',
    ),
  ),
  'php_memeber_not_register_username' => 
  array (
    'nousername' => 
    array (
      0 => 'admin',
      1 => '����Ա',
    ),
    'issendmail' => NULL,
    'findpassmode' => 'question',
    'auditingcomment' => 'no',
    'logincomment' => 'no',
    'is_open_member_regiser' => 'open',
  ),
  'siteBase' => 
  array (
    'logo_hidden' => '',
    'sitename' => 'php',
    'site_alias_name' => '',
    'shop_show_name' => '��ҳ',
    'siteurl' => 'http://127.0.0.3/',
    'goods_sn_sufix' => 'TYS_',
    'goods_currency_set' => '��%sԪ',
    'icp' => '',
    'url_suffix' => '.html',
    'allow_upload_fix' => 'gif,jpg,png,7z,gz,tar,rar,zip,txt,xls,doc,pdf,swf,flv',
    'goods_detail_pic_setting' => 'thumb_has_water',
    'address' => '�������������Ļ���·82�Ž𳤰�����A��703',
    'tel' => '010-87875188',
    'zipcode' => '100075',
    'kefupostion' => 'left',
    'kefutime' => '����9:00-����8:00',
    'webtaobao' => 
    array (
      0 => 
      array (
        'num' => '899898',
        'desc' => '����',
        'order' => '2',
      ),
      1 => 
      array (
        'num' => '789092',
        'desc' => 'С��',
        'order' => '2',
      ),
    ),
    'web_tb' => '2',
    'webmsn' => 
    array (
      0 => 
      array (
        'num' => '434656',
        'desc' => '����',
        'order' => '3',
      ),
      'NaN' => 
      array (
        'num' => '324355',
        'desc' => '����',
        'order' => '4',
      ),
    ),
    'web_msn' => '2',
    'webqq' => 
    array (
      0 => 
      array (
        'num' => '16317111',
        'desc' => 'justdoit',
        'order' => '1',
      ),
      'NaN' => 
      array (
        'num' => '66951176',
        'desc' => 'С��è',
        'order' => '6',
      ),
    ),
    'web_qq' => '2',
    'footer_info' => '<p>�Ϸʵ�ַ������ʡ�Ϸ����������Ĺ㳡8��1��2301</p>
<p>����QQ 407288675 &nbsp;��Ʒ����QQ��617825365</p>
<p>******************************************************************</p>
<p>������ַ����������������·70�����ش���D��706</p>
<p>�������ߣ�400-999-0518 &nbsp; &nbsp;&nbsp; Email��xie@php.cm<br />
CopyRight @2008-2010 All right reserved &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;��ICP��09020607�� </p>',
    'is_use_site_name' => '1',
    'description' => '�̳�ϵͳ,����ϵͳ,����ϵͳ,�����̳�ϵͳ,PHP188,PHP�̳�ϵͳ,����������',
    'keywords' => 'PHP�̳�ϵͳ�ǹ��ڹ�������������̳�ϵͳ,����ϵͳ,����ϵͳ,�ṩ�������,�ж������ģ��,ǿ��ĺ�̨��������,רҵ�������̳�ϵͳ�������,���ٽ�վ���Ϸ�װ�̳ǡ������̳ǡ��ֻ��̳ǡ��칫��Ʒ�̳ǵ�PHP�̳�ϵͳ�������ѡ���ֵ�������Ļ��-����������',
    'site_close_payement' => 'use',
    'site_goods_stock_reduce_method' => 'to_fahuo',
    'is_use_member_remain_money_pay' => 'unuse',
    'goods_buy_step' => 'use_login',
    'fapiao_set' => 
    array (
      'goods_order_fapiao_info' => '',
      'fapiao_data_info_val' => 0,
    ),
    'promotion_config' => 
    array (
      'free_delivery_fee_config' => '',
      're_to_money' => '500',
      're_to_money_end' => '0',
      'deliver_pay_total_money' => '0',
      'deliver_pay' => '',
    ),
    'delivery_method_config' => 'use_region',
    'order_all_set' => 
    array (
      'allow_cancel_order' => 'allow',
      'allow_tuikuan' => 'now_allow',
      'allow_tuihuo' => 'now_allow',
      'allow_tuihuo_day' => '1',
    ),
    'goods_order_number_format' => 'YmdHisRAND',
    'auto_command_time' => '3',
    'category_filter' => 
    array (
      'display_pannel' => 
      array (
        'show' => '1',
        'tag_name' => 'display_pannel',
        'sort' => '1',
        'model' => 'plate',
      ),
      'price_bettwen' => 
      array (
        'show' => '1',
        'tag_name' => 'price_bettwen',
        'sort' => '2',
        'model' => 'plate',
      ),
      'limit_set' => 
      array (
        'show' => '1',
        'tag_name' => 'limit_set',
        'sort' => '3',
        'model' => 'select',
      ),
      'goods_tags' => 
      array (
        'show' => '1',
        'tag_name' => 'goods_tags',
        'sort' => '4',
        'model' => 'plate',
      ),
      'goods_brand' => 
      array (
        'show' => '1',
        'tag_name' => 'goods_brand',
        'sort' => '8',
        'model' => 'plate',
      ),
      'goods_category' => 
      array (
        'show' => '1',
        'tag_name' => 'goods_category',
        'sort' => '0',
        'model' => 'plate',
      ),
      'goods_region' => 
      array (
        'show' => '1',
        'tag_name' => 'goods_region',
        'sort' => '0',
        'model' => 'plate',
      ),
      'goods_origin' => 
      array (
        'show' => '1',
        'tag_name' => 'goods_origin',
        'sort' => '0',
        'model' => 'plate',
      ),
      'display_sort' => 
      array (
        'show' => '1',
        'tag_name' => 'display_sort',
        'sort' => '0',
        'model' => 'select',
      ),
    ),
    'admin_pannel_goods_display_type' => 'closed',
    'goods_default_list_show_number' => '20',
    'goods_stock_notice_number' => '5',
    'recommend' => 
    array (
      'is_close' => 'close',
      're_to_point' => '5',
      're_to_money' => '0.5',
      'recommend_money_limit' => '50',
    ),
    'site_use_development_type' => 'use',
    'site_out_replace_space' => 'replace',
    'site_category_brand_cache' => 'enable',
    'url_rewrite' => '0',
    'is_use_html' => '0',
    'gzip' => 'unopen',
    'is_debug' => '0',
    'send_mail_use_queue' => 'use',
    'send_mail_use_queue_number' => '5',
    'public_ip_filer_text' => 'you ip does not allow access!',
    'public_ip_filer' => '',
    'admin_ip_filer' => '',
    'rate_point' => 
    array (
      'buy_goods_song_jifeng_model' => 'order_finished',
      'user_chongzhi_song_jifen' => 'close',
      'is_open_point' => 'close',
      'php_point_rates' => '100',
      'php_point_small_point' => '1000',
      'point_do_rules' => 'close',
      'point_do_rules_time' => '06-19 17:45:00',
    ),
    'register_set_point' => 0,
    'login_set_point' => 0,
    'auto_do_processing_frequency' => '0',
    'order' => 
    array (
      'auto_delete_unpay_day' => '0',
      'auto_set_has_send_to_finished' => '0',
      'auto_to_stock_number' => '50',
      'auto_delete_expired_sitebox_time' => '20',
    ),
    'xml' => 
    array (
      'auto_do_time' => '3600',
    ),
    'close_site_editor' => '',
    'logo' => '/shopdata/site/default_logo.png',
    'member_register_content' => NULL,
  ),
  'site_article_config' => 
  array (
    'articlesort' => '5',
    'maxpage' => '20',
    'comment' => '1',
    'checkcomment' => '1',
    'validate' => '1',
    'maxcomment' => '30',
  ),
  'site_close_config' => NULL,
  'site_mail_cfg' => 
  array (
    'mail_send_type' => 'smtp',
    'sender' => 'PHP�̳�ϵͳ',
    'smtp_host' => 'smtp.exmail.qq.com',
    'smtp_port' => '25',
    'smtp_user' => 'xie@php.cm',
    'smtp_pass' => 'changdunxiaoxue',
  ),
  'site_mobile_config' => 
  array (
    'sms_cpcode' => '',
    'sms_id' => '',
    'sms_pass' => '',
  ),
  'site_pic_set' => 
  array (
    'list_thumb' => 
    array (
      'w' => '150',
      'h' => '190',
      'default' => 'shopdata/site/goods_list_pic.jpg',
    ),
    'goods_detail_pic' => 
    array (
      'w' => '347',
      'h' => '348',
      'default' => 'shopdata/site/goods_detail_pic.jpg',
    ),
    'goods_album' => 
    array (
      'w' => '500',
      'h' => '500',
      'default' => 'shopdata/site/goods_album_pic.jpg',
    ),
    'pic_other' => 
    array (
      'w' => '172',
      'h' => '183',
      'default' => 'shopdata/site/shop_other_pic.jpg',
    ),
  ),
  'site_search_config' => '�޿�������,�볢��������ʽ����!',
  'site_search_price_set' => 
  array (
    'temp_string' => '',
    'set_data' => 
    array (
    ),
    'is_use_auto' => '1',
  ),
  'site_template' => 'attire',
  'site_water_set' => 
  array (
    'water_set' => 'text',
    'font_app' => '50',
    'water_font_text' => 'www.php.cm',
    'water_font' => 'tahoma.ttf',
    'font_size' => '18',
    'font_color' => '#3366CC',
    'water_position' => 'center',
  ),
  'toadmin' => 
  array (
    'admin_email' => '16317111@163.com',
    'admin_mobile' => '13956021021',
  ),
  'trygoods' => 
  array (
    'is_close' => '0',
    'free_number' => '2',
    'short_info' => '���Ǽ�̽���',
  ),
  'user_attention' => 
  array (
    'is_use_attention_send_mail' => '0',
    'max_live_num' => '50',
    'send_mail_number' => '30',
    'rand_goods_num' => '5',
  ),
);

?>