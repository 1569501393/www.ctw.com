<?php 
/**
 * ==============================================================================================================
  * [PHP] 2011-2021 �������������缼�����޹�˾
  * http://www.php.cm
  * ��������         : 86+010-87875188
  * �ۺ�������� : 86+010-87875088
  * �ⲻ��һ���������,ʹ������չٷ���Ȩ����Э��,�κ��˲����ƽ⼰���ηַ�
  * ==============================================================================================================
  * ȫվ���������ļ�
  * $Id: init.php 2009-05-19 03:28:45  $
  * ==============================================================================================================
 */
date_default_timezone_set("Asia/Shanghai");/*phpversion >=5.1*/
define('INC_PHP',TRUE);
define('PHP_TEMPLATE',TRUE);
define('PHP_ROOT',strtr(dirname(__FILE__).'/',array('\\'=>'/')));
/*���Ŀ�*/
define('PHP_MAIN_PATH',PHP_ROOT.'php/');
define('PHP_FUNCTION_PATH',PHP_MAIN_PATH.'function/');//����ģ�Ϳ�
define('PHP_LIB_PATH',PHP_MAIN_PATH.'core/');//���
define('PHP_MODEL_PATH',PHP_MAIN_PATH.'public/model/');#ģ�Ϳ� ��Ŀ¼
define('PHP_TEMPLATE_PATH',PHP_ROOT.'template/');
/*���*/
define('PHP_PLUGIN_MAIN_PATH',PHP_MAIN_PATH.'plugin/');
/*������Ŀ¼*/
define('PHP_TEMP_MAIN_PATH',PHP_ROOT.'temp/');
/*�ļ��ϴ�����Ŀ¼*/
define('PHP_UPLOAD_TEMP_PATH',PHP_TEMP_MAIN_PATH.'upload_temp/');
/*��̬���汣���·��*/
define('STATC_CACHE_PATH',PHP_TEMP_MAIN_PATH.'static_cache/');
/*�ļ�Ĭ���ϴ���·��*/
define('PHP_UPLOAD_MAIN_PATH',PHP_ROOT.'attachment/');
function required_file($file = '',$check = true,$only_log = false){
	static $_requred_files = array();
	$file = str_replace('\\','/',$file);
	if(empty($file))return $_requred_files;
	if(in_array($file,$_requred_files))return false;
	if($check && !is_file($file))exit('Not exist file  =>'.$file);
	$_requred_files[] = $file;
	$_LANG = array();
	if($only_log)return true;
	require $file;	
}
define('PAGE_NUM',20);/*��ҳ*/
unset($GLOBALS);
required_file(PHP_ROOT.'php/version.php');
required_file(PHP_ROOT.'php.config.php');
required_file(PHP_MAIN_PATH.'php.common.php');
$GLOBALS['starttime'] = microtime_float();
!defined('OUTPUT_ENCODING')?define('OUTPUT_ENCODING','GBK'):'';
/*config common session file*/
!defined('SESSION_FILE_SAVE_PATH')?define('SESSION_FILE_SAVE_PATH',PHP_ROOT.'/session/'):'';
@ini_set('memory_limit',          '256M');
!defined('DEBUG')?define('DEBUG', false):'';
error_reporting((DEBUG?E_ALL:E_ERROR));
define('SHOP_DATA_PATH',PHP_ROOT.'shopdata/');
define('LANG_PATH',SHOP_DATA_PATH.'language/'.LANG.'/');
/**
 * config session model info
 * @param $cookies_path  session�����cookie·��
 * @param $session_path  session������ļ�·�� ֻsession����ģʽΪfileʱ��Ч
 * @param $hash �Ƿ����ü��ܻ��� Ŀǰֻд���ļ�ģʽʱʹ�ü��ܻ���
 */
function _setSession($cookies_path = '/',$is_pub = true){
	import('@.core.session');
	$model = !defined('SESSION_SAVE_MODEL')?'file':SESSION_SAVE_MODEL;
	session_name($is_pub?'____PHP_PUB____' : '____PHP_CP____');
	$model = empty($model)?'file':$model;
	PHPsession::getInstance($model)->load();
	switch ($model){
		case 'memcache':
			@ini_set('session.save_handler','memcache');
			$mem_server = $GLOBALS['MEMCACHE']['SERVERS'];
			if(empty($mem_server))exit('not set the memecached server!');
			$server_list = '';
			foreach ($mem_server as &$t)$t = 'tcp://'.$t;
			$mem_server_list = join(',',$mem_server);
			@ini_set('session.save_path',$mem_server_list);
		break;
		case 'file':
		case 'db':
		default:
			$ext = $is_pub?'public/':'admin/';
			$session_path = SESSION_FILE_SAVE_PATH.$ext;
			$GLOBALS['_SESSION_']['CONFIG']['FILE']['PATH'] = $session_path;
			define('ADMIN_SESSION_PATH',$session_path);
			@ini_set('session.save_path', $session_path);/*SESSION����·��*/
	}
	if($is_pub){
		/*���Ƶ�¼��*/
		/*
		$e = get_cache(array('siteBase','siteurl'));
		$e = parse_url($e);
		$domain = '.'.$e['host'];
		@ini_set('session.cookie_domain',$domain);
		*/
	}
	@ini_set('session.cookie_path',$cookies_path);
	@ini_set('session.cache_expire',  180);
	$max_time = !defined('SESSION_EXP_TIME')?3600:SESSION_EXP_TIME;
	@ini_set("session.gc_maxlifetime", $max_time);/*���ʱ�Զ�ɾ�� ������ʱ����̿����������üӴ� ԽС������ʱ��Խ��*/ 
	@ini_set('session.use_trans_sid', 0);
	@ini_set('session.use_cookies',   1);
	@ini_set('session.use_only_cookies',1);
	@ini_set('session.cookie_httponly',true);
	$session_name   = 'session'.ucwords($model);
	$phpsession = new $session_name();
	session_set_save_handler(
		array(&$phpsession,"open"),array(&$phpsession,"close"),array(&$phpsession,"read"),array(&$phpsession,"write"),array(&$phpsession,"destroy"),array(&$phpsession,"gc")
	);
	register_shutdown_function("session_write_close");
	unset($phpsession);
}
define('SHOW_PAGE_TIME',false);/*�Ƿ���ʾģ��ִ��ʱ��*/
/*�滻�հ�*/
$is_replace = get_cache(array('siteBase','site_out_replace_space'));
$is_use_replace = $is_replace!='unreplace'?true:false;
define('REPLACE_SPACE',$is_use_replace);
$use_develop = get_cache(array('siteBase','site_use_development_type'));
/*����ģʽ����*/
$is_use_develop = $use_develop=='use'?true:false;
define('DEV_TYPE',$is_use_develop);
/*ѹ�����*/
if(!defined('CREATE_HTML_ACTION')){
	$gzip = get_cache(array('siteBase','gzip'))!='close'?true:false;
	if($gzip && function_exists('ob_gzhandler')){
		@ob_start("ob_gzhandler");
		@ob_start("compress");
		define('ENABLE_GZIP',TRUE);
	}else{
		define('ENABLE_GZIP',false);
		@ob_start();
	}	
}else{
	ob_start();
}
$core = array(
	'@.core.helper.array',
	'@.core.helper.file',
	'@.core.helper.string',
	'@.core.db',
	'@.core.controler',
	'@.core.template',
	'@.fun.template',
	'@.core.fileCache',
	'@.core.requests',
	'@.core.base',
	'@.core.cart'
);
foreach ($core as $c)import($c);
setHeader();
?>