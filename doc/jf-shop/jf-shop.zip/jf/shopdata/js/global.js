jQuery.cookies = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options = $.extend({}, options); // clone object since it's unexpected behavior if the expired property were changed
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};
function hideShow(a,b,c,d){
	//������ʽ
	var _set = function(obj){
		$(obj).each(function(){
			$(this).css({"cursor":'pointer'});
		});	
	};
	_set("."+a);
	var _remove = function (){
		$('.'+a).each(function(){
			if($(this).hasClass(b))$(this).hide();
		});
	};
	var _hide = function(obj,items){
		$(obj).hide();$(items).css({"display":'block'});
	};
	return $('.'+c).each(function(i){
		_set(this);
		if(i==0)_hide(this,"#"+d+i);
		$(this).mouseover(function(){
			_remove();
			$("."+c).css({"display":'block'});
			_hide(this,"#"+d+i);
		});
	});
}
function block_a(){
	$("a").focus(function(){$(this).blur();});	
}
/*
 * ���һ���ַ����Ƿ�Ϊ��
*/
function empty (string){
	return $.trim(string)==''?true:false;
}
function getData(urls){
	var obj = $.ajax({
		url: urls+'&rand='+Math.random(),
		async: false,
		cache:false
	});
return obj.responseText;
}
/*
 * ��ҳjs����
*/
function page_function(page_dom_id,append_data_id){
		$("#"+page_dom_id).find('a').each(function(i){
			$(this).click(function(){
				$.get($(this).attr('href'),function(data){
					$("#"+append_data_id).html(data);
					return false;
				});
				return false;
			});
		});
		$("input[name='custompage']").bind('keydown',function(e){
			var k = e.keyCode;
			if(k==13){
				$("#"+append_data_id).html(getData($(this).attr('alt')+parseInt($.trim($(this).val()))));
				return false;
			}
		});
	}
/** 
 * ��� �Ƿ� ���� �����ַ� 
 *���� ���� false û�з��� true 
 **/
 function chkstr(str){
	for (var i = 0; i < str.length; i++){
	   if (str.charCodeAt(i) < 127 && !str.substr(i,1).match(/^\w+$/ig)){
		   return false;
	   }
	}
	return true;
}
/**
 * ��� �Ƿ� ���� email ����Ĺ淶  ���� true ������ false
 * @param email string
 * @return boolean
 */
function checkemail(email){
	var   pattern   =   /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/; 
    if(!pattern.test(email)){ 
    	return false;
    }
    return true;
}
function is_email(email){
	return checkemail(email);	
}
/**
 * �Ƿ� �� һ�� ��ȷ���ֻ���  �� true ���� false
 * ֧�� 13 150 151
 * @param int mobile
 * @return boolean
 */
function is_mobile(mobile){
	var reg =/^1(3[0-9]|5[0,1,2,3,6,8,9]|8[6,8,9])[0-9]{8}$/;
    if(!reg.test(mobile)){
        return false;
    }else{
        return true;
    }
}
function get_data(urls){
	var obj = $.ajax({
		url: urls+'&rand='+Math.random(),
		async: false,
		cache:false
	});
	return $.trim(obj.responseText);
}
function inArray(v,ary){
	if(!$.isArray(array))return false;
	for(k in ary){
		if(ary[k]==v)return true;
	}
	return false;
}
function checkAllFormData(ids,classes){
	$("#"+ids).click(function(){
		$("."+classes).attr('checked',$("#"+ids).attr('checked'));
	});
}
function get_checkbox_val(c){
	var checked = $("."+c).map(function(){
		if($(this).attr('checked'))return $(this).val();
	}).get().join(',');
	return $.trim(checked)==''? false:checked;
}
function isIe6(){return $.browser.version==6.0?true:false;}
(function($){$.toJSON=function(o)
{if(typeof(JSON)=='object'&&JSON.stringify)
return JSON.stringify(o);var type=typeof(o);if(o===null)
return"null";if(type=="undefined")
return undefined;if(type=="number"||type=="boolean")
return o+"";if(type=="string")
return $.quoteString(o);if(type=='object')
{if(typeof o.toJSON=="function")
return $.toJSON(o.toJSON());if(o.constructor===Date)
{var month=o.getUTCMonth()+1;if(month<10)month='0'+month;var day=o.getUTCDate();if(day<10)day='0'+day;var year=o.getUTCFullYear();var hours=o.getUTCHours();if(hours<10)hours='0'+hours;var minutes=o.getUTCMinutes();if(minutes<10)minutes='0'+minutes;var seconds=o.getUTCSeconds();if(seconds<10)seconds='0'+seconds;var milli=o.getUTCMilliseconds();if(milli<100)milli='0'+milli;if(milli<10)milli='0'+milli;return'"'+year+'-'+month+'-'+day+'T'+
hours+':'+minutes+':'+seconds+'.'+milli+'Z"';}
if(o.constructor===Array)
{var ret=[];for(var i=0;i<o.length;i++)
ret.push($.toJSON(o[i])||"null");return"["+ret.join(",")+"]";}
var pairs=[];for(var k in o){var name;var type=typeof k;if(type=="number")
name='"'+k+'"';else if(type=="string")
name=$.quoteString(k);else
continue;if(typeof o[k]=="function")
continue;var val=$.toJSON(o[k]);pairs.push(name+":"+val);}
return"{"+pairs.join(", ")+"}";}};$.evalJSON=function(src)
{if(typeof(JSON)=='object'&&JSON.parse)
return JSON.parse(src);return eval("("+src+")");};$.secureEvalJSON=function(src)
{if(typeof(JSON)=='object'&&JSON.parse)
return JSON.parse(src);var filtered=src;filtered=filtered.replace(/\\["\\\/bfnrtu]/g,'@');filtered=filtered.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,']');filtered=filtered.replace(/(?:^|:|,)(?:\s*\[)+/g,'');if(/^[\],:{}\s]*$/.test(filtered))
return eval("("+src+")");else
throw new SyntaxError("Error parsing JSON, source is not valid.");};$.quoteString=function(string)
{if(string.match(_escapeable))
{return'"'+string.replace(_escapeable,function(a)
{var c=_meta[a];if(typeof c==='string')return c;c=a.charCodeAt();return'\\u00'+Math.floor(c/16).toString(16)+(c%16).toString(16);})+'"';}
return'"'+string+'"';};var _escapeable=/["\\\x00-\x1f\x7f-\x9f]/g;var _meta={'\b':'\\b','\t':'\\t','\n':'\\n','\f':'\\f','\r':'\\r','"':'\\"','\\':'\\\\'};})(jQuery);
/*��Ʒ�ղ�*/
function php_goods_collect(obj,id){
	/* �õ� url */
	var url = $(obj).attr("name");
	$.get(url,function(data){
		switch($.trim(data)){
			case "1":
				showNotice("����û�е�½,���ȵ�¼.");
				return false;
				break;
			case "2":
				showNotice("��ѡ����Ҫ�ղص���Ʒ.");
				return false;
				break;
			case "3":
				showNotice("���Ѿ��ղ��˴���Ʒ.�����ظ��ղ�.");
				return false;
				break;
			case "4":
				showNotice("�ղ���Ʒʧ��.");
				return false;
				break;
			case "5":
				showNotice("�ղش���Ʒ�ɹ�.");
				return false;
				break;
			default:
				showNotice("�ղ���Ʒʧ��.");
				return false;
				break;
		}			   
	});
}
/*�û��Զ���ɸѡ��Ʒ*/
function filter_goods_for_user(){
	var display_filter = $("#php_goods_selector :selected").val();
	var display_num = $("#goods_show_num :selected").val();
	var call_url = $("#php_cate_filter_goods_url").val();
	var display_model;
	if($('#goods_display_model_selected').size()>0){
		display_model = $("#goods_display_model_selected").attr('name');
	}else{
		display_model = 'picture_text';	
	}
	var end_string = call_url+'code='+display_model+'------'+display_filter+'------'+display_num;
		window.location.href = end_string;	
}
/*�û��Զ���ѡ����ʾģʽ*/
function goods_display_model_filter(obj){
	var display_filter = $("#php_goods_selector :selected").val();
	var display_num = $("#goods_show_num :selected").val();
	var display_model = $(obj).attr("name");
	var call_url = $("#php_cate_filter_goods_url").val();
	var end_string = call_url+'code='+display_model+'------'+display_filter+'------'+display_num;
	window.location = end_string;
}
function count(array){
	var k = 0;
	$(array).each(function(i){
		k=i+1;
	});
	return k;
}
function php_goods_tocart(obj,id,append){
	var opt = !empty(append)?{id:id,extend:append}:{id:id};
	$.getJSON(ajax_to_cart,opt,function(data){
		switch(data.status){
			case 'HAS_SPECFICATION':
				if(confirm('����Ʒ�в�ͬ�ͺſ�ѡ�����Ƿ�Ҫ������ת����Ʒ����ѡ���ͺţ�'))window.location.href=data.url;
			break;
			case 'ERROR':
				showNotice('��������!���޸���Ʒ����!');
				return false;
			break;
			case 'NOT_EXIST':
				showNotice('�޿�����Ʒ����!');
				return false;
			break;
			case 'UNDER_STOCK':
				showNotice('��治��!');
			break;
			case 'LOW_STOCK':
				showNotice('��治��,��ඩ��'+data.max_num+'��.');
				return false;
				break;
			case 'OK':
				window.location.href=data.url;
			break;
			default:alert(data);
		}
	});
}
function   getRadioBoxValue(radioName)  
{  
	var obj = document.getElementsByName(radioName); 
    for(i=0;i<obj.length;i++)
	{  
		if(obj[i].checked)
		{
			return   obj[i].value;
		}  
	}          
	return "undefined";
}
function showNotice(msg,width){
	if(typeof(width)=="undefined"){width = '240';}
	$('div').remove('#showAjaxMsg');//��ɾ������
	$("body").append('<div id="showAjaxMsg">'+msg+'</div>');
	var top = $(window).height()/2+$(document).scrollTop()-80+'px';
    $("#showAjaxMsg").css({
								//'border':'2px solid #EEDCDC',
								//'border':'2px solid RGB(34,135,225)',
								//'color':'#FFF',
								//'z-index':'99999999',
								//'text-align':'center',
								//'//position':'absolute',
								//'background-color':'#666',
								//'font-size':'14px',
								'width':width,
								'top':top												
	});
	$("#showAjaxMsg")
		.animate({opacity: "1",height: "40", width: width}, 10)
		.animate({opacity: "1", left: "40%",height: "40", width: width},800)
		.animate({opacity: "1", left: "40%",height: "40", width: width},1000)
		.animate({opacity: "1", left: "40%",height: "40", width: width},1500)
		.animate({opacity: "0", left: "85%",height:"0",width:'0'}, 400);
		return false;
}
function check_form_is_empty(form_class){
		var result = true;
		$("."+form_class).each(function(){
			var val = $(this).val();
			if(empty(val)){
				$(this).addClass('empty_input_val');
				result = false;
			}else{
				$(this).removeClass('empty_input_val');
			}
		});
	return result;
}
function AddFavorite(sURL, sTitle)
{
    try{ window.external.addFavorite(sURL, sTitle);
    } catch (e){
        try{
            window.sidebar.addPanel(sTitle, sURL, '');
        }catch (e){
            alert('�����ղ�ʧ�ܣ���ʹ��Ctrl+D��������');
        }
    }
}
function SetHome(obj,vrl){
        try{obj.style.behavior='url(#default#homepage)';obj.setHomePage(vrl);}
        catch(e){if(window.netscape) {
                        try {
                                netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
                        }
                        catch (e)  {
                                alert("�˲�����������ܾ���\n�����������ַ�����롰about:config�����س�\nȻ�� [signed.applets.codebase_principal_support]����Ϊ'true'");
                        }
						try{
                        var prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);
                        prefs.setCharPref('browser.startup.homepage',vrl);
							}
						catch(e){}
                 }
        }
}
function showLoading(){
		$("body").append('<div id="ajax_set_loading" style="position:absolute;background-color: #900; color: #525252;right:0px; top:0px;color:#FFF; padding:5px 6px; width:100px;">���ݼ�����...</div>');
	 var loading_dom = $("#ajax_set_loading");
	 if($(loading_dom).size()) {
			var init = $(loading_dom).offset();
			var init_top = init.top;
			init_left = 0;
			init_top = parseInt(init_top+0);
			function scrolltop() {
				var pageY = $(window).scrollTop();
				pageY = parseInt(pageY+0);
				if (pageY > init_top){
					 $(loading_dom).css({"top":pageY+'px',"right":init_left+'px'});
				 }else{ 
					$(loading_dom).css({"top":init_top+'px',"right":init_left+'px'});
				}
				window.setTimeout(scrolltop, 1);
			}
			scrolltop();
		}
	}
function closeLoading(){$("#ajax_set_loading").remove();}
$(function(){
	$(".loading").click(function(){showLoading();});
	$(this).ajaxStart(function(){showLoading();});
	$(this).ajaxSuccess(function(){closeLoading();});
});