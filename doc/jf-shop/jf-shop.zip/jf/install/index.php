<?php
@ob_start();
session_start();
error_reporting(E_ERROR);
set_time_limit(0);
if($_GET['action']=='info'){
	phpinfo();
	exit();
}
if(PHP_VERSION<'5.1')exit('require php version >=5.1');
date_default_timezone_set("Asia/Shanghai");//phpversion >=5.1
$c_root = strtr(dirname(__FILE__),array('\\'=>'/'));
define('INSTALL_PATH',$c_root.'/');
if(!function_exists('required_file')){
	function required_file($file = '',$check = true,$only_log = false){
		static $_requred_files = array();
		$file = str_replace('\\','/',$file);
		if(empty($file))return $_requred_files;
		if(in_array($file,$_requred_files))return false;
		if($check && !is_file($file))exit('Not exist file  =>'.$file);
		$_requred_files[] = $file;
		$_LANG = array();
		if($only_log)return true;
		require $file;	
	}
}
require dirname(__FILE__).'/../php/php.common.php';
$curent_root = explode('/',$c_root);
array_pop($curent_root);
if(!defined('ROOT_PATH'))define('ROOT_PATH',strtr(join('/',$curent_root).'/',array('\\'=>'/')));
if(is_file(ROOT_PATH.'shopdata/install.lock') && $_GET['action'] !=='ok')exit('���Ѿ���װ�˱�ϵͳ,��Ҫ���°�װ����ɾ�� shopdata/install.lock �ļ�');
!defined('OUTPUT_ENCODING')?define('OUTPUT_ENCODING','GBK'):'';
$core = array(
	'@.core.helper.array',
	'@.core.helper.file',
	'@.core.helper.string',
	'@.core.db',
	'@.core.template',
	'@.core.fileCache',
);
foreach ($core as $c)import($c);
setHeader();
$site_url = get_site_url();
if(strstr($site_url,'http://localhost'))location(str_replace('localhost','127.0.0.1',$site_url));
function is_post(){
	return $_SERVER['REQUEST_METHOD']==='POST'?true:false;
}
class php188Install{
	private static $_instance = __CLASS__;
	public $tpl = null;
	public static function getInstance(){
		return is_object(self::$_instance)?self::$_instance:new self::$_instance();
	} 
	function __construct(){
		$this->_set_tpl();
	}
	function _set_tpl(){
		$smarty = new Smarty();
		$smarty->template_dir = INSTALL_PATH.'tpl/';
		$smarty->cache_dir = ROOT_PATH.'temp/install/cache/';
		$smarty->compile_dir = ROOT_PATH.'temp/install/cached/';
		$smarty->direct_output = true;
		$smarty->force_compile = true;
		$this->tpl = $smarty;
		unset($smarty);
	}
	function assign($ary){
		foreach ($ary as $key=>$item)$this->tpl->assign($key,$item);
	}
	function _out_flush($msg){
	  ob_flush();
	  flush();
	  echo  "<script type='text/javascript'>show_install_msg('$msg');\n</script>";
      ob_flush();
	  flush();
 	}
 	function _clear(){
		delete_folder(ROOT_PATH.'temp/static_cache/');
 	}
	function _preg_match_sql($query_item,$php188_db_char = 'GBK'){
		/* ��ȡ�������崮�Լ��������������������ִ�Сд��ƥ�任�з�����Ϊ̰��ƥ�� */
		$pattern = '/^\s*(CREATE\s+TABLE[^(]+\(.*\))(.*)$/is';
		$matches = array();
        if (!preg_match($pattern, $query_item, $matches)){
            return $query_item;
        }
        $main = $matches[1];
        $postfix = $matches[2];
        /* �ӱ������������в��ұ������� */
        $pattern = '/.*(?:ENGINE|TYPE)\s*=\s*([a-z]+).*$/is';
        $type = preg_match($pattern, $postfix, $matches) ? $matches[1] : 'MYISAM';
        /* �ӱ������������в���������� */
        $pattern = '/.*(AUTO_INCREMENT\s*=\s*\d+).*$/is';
        $auto_incr = preg_match($pattern, $postfix, $matches) ? $matches[1] : '';
        /* �������ñ����������� */
        $postfix = " ENGINE=$type DEFAULT CHARACTER SET " . $php188_db_char;
        $postfix .= ' ' . $auto_incr;
        /* ���¹��콨����� */
        $sql = $main . $postfix;
		return array($sql);
	}
 function cpdir($old_dir, $aim_dir, $over_write = false) {
		$aim_dir = str_replace('\\', '/', $aim_dir);
		$aim_dir = substr($aim_dir, -1) == '/' ? $aim_dir : $aim_dir.'/';
		$old_dir = str_replace('\\', '/', $old_dir);
		$old_dir = substr($old_dir, -1) == '/' ? $old_dir : $old_dir.'/';
		if (FALSE !== strpos($aim_dir, $old_dir))return false;
		if (!is_dir($old_dir))return false;
		if (!file_exists($aim_dir)){mkdirs($aim_dir);}
		$dir_handle = opendir($old_dir);
		while(false !== ($file = readdir($dir_handle))) {
			if ($file == '.' || $file == '..') {continue;}
			if(!is_dir($old_dir . $file)){
				//$this->_out_flush('���ڸ����ļ� '.$aim_dir.$file);
				cp_file($old_dir . $file, $aim_dir . $file, $over_write);
			}else{
				$this->_out_flush('���ڴ��� '.$aim_dir. ' ��ת������...');
				$this->cpdir($old_dir . $file, $aim_dir . $file, $over_write);	
			}
		}
		closedir($dir_handle);
		return true;
	}
/**
 * �Ƶ���������Ҫ���Ե�����
 */
	private function _move_data(){
        $this->_out_flush('��ʼ���Ʋ�������');
		$path = ROOT_PATH . 'install/data/install_data/';
		$moverpath = ROOT_PATH.'/';
		$this->cpdir($path, $moverpath, true);
		$this->_out_flush('���ݸ��Ƴɹ�..');
	}
	function dir_writeable($dir) {
		$writeable = false;
		if(!is_dir($dir) && @mkdir($dir, 0777))return false;
		if(is_dir($dir)) {
			if(false!=$fp = @fopen("$dir/test.txt", 'w')) {
				@fclose($fp);
				@unlink("$dir/test.txt");
				$writeable = true;
			} else {
				$writeable = false;
			}
		}
		return $writeable;
	}
	function dirfile_check($dirfile_items) {
		$temp = array();
		$flag = true;
		foreach($dirfile_items as $key => $item_path) {
			if(!$this->dir_writeable($item_path)) {
				$temp[] = array(
					'num'=>false,
					'mod'=>false,
					'path'=>str_replace(ROOT_PATH,'../',$item_path),
				);
				$flag = false;
			} else {
				$temp[] = array(
					'num'=>true,
					'mod'=>true,
					'path'=>str_replace(ROOT_PATH,'../',$item_path),
				);
			}
		}
		return array(
			'file'=>$temp,
			'flag'=>$flag
		);
}
	function run(){
		$get = html_encode($_GET);
		$action = $get['action'];
		switch ($action){
			case 'check':
				$need_check_list = array(
					ROOT_PATH,
					ROOT_PATH.'sitemap/',
					ROOT_PATH.'attachment/',
					ROOT_PATH.'temp/',
					ROOT_PATH.'session/',
					ROOT_PATH.'shopdata/',
					ROOT_PATH.'shopdata/backupdata/',
					ROOT_PATH.'shopdata/brands/',
					ROOT_PATH.'shopdata/flashdata/',
					ROOT_PATH.'shopdata/friendlink/',
					ROOT_PATH.'shopdata/logs/',
					ROOT_PATH.'shopdata/site/',
				);
				$function_list = array(
					'mkdir',
					'copy',
					'memory_get_usage',
					'getimagesize',
					'iconv',
					'mysql_connect',
					'file_get_contents',
					'fsockopen',
					'gethostbyname',
					'xml_parser_create',
				);
				$not_allow_extension_model = array(
					'eaccelerator',
					'XCache',
					'APC'
				);
				$temp = array();
				$can_next = true;
				/*����ļ�дȨ��*/
				$temp_check = $this->dirfile_check($need_check_list);
				$temp['file'] = $temp_check['file'];
				if(!$temp_check['flag'])$can_next = false;
				/*��麯��*/
				foreach ($function_list as $fun){
					$exist = function_exists($fun)?true:false;
					if(!$exist)$can_next = false;
					$temp['fun'][] = array(
						'fun'=>$fun,
						'mod'=>$exist,
					);
				}
				/*����ļ�������*/
				foreach ($not_allow_extension_model as $ext){
					$load = extension_loaded($ext);
					if($load)$can_next = false;
					$temp['extension'][] = array(
						'ext'=>$ext,
						'mod'=>$load,
					);
				}
				$this->assign(array(
					'title'=>'ϵͳ�������',
					'can_not_next'=>$can_next,
					'action'=>'check_install',
					'check_list'=>$temp,
				));
				break;
			case 'checkdbconnect':
				$host = $get['db_host'];
				$user = $get['db_user'];
				$pass = $get['db_pass'];
				$port = $get['db_port'];
				$db_name = $get['db_name'];
				if(empty($host) || empty($user) || empty($pass) || empty($port) || empty($db_name))exit('EMPTY');
				$con = @mysql_connect($host.':'.$port,$user,$pass);
				if(!$con)exit('ERROR_CONNECT');
				if(!@mysql_select_db($db_name,$con)){
					if(!@mysql_query("CREATE DATABASE `$db_name`;",$con)){
						exit('ERROR_SELECT');
					}
					if(@mysql_select_db($db_name,$con)){
						exit('OK');
					}else{
						exit('ERROR_SELECT');
					}
				};
				exit('OK');
				break;
			case 'db':
				if(is_post()){
					$_SESSION['temp_post'] = $_POST;
					$_SESSION['temp_do_db'] = $post = html_encode($_POST);
					$memcache_cache = $post['memcache'];
					if(!empty($memcache_cache)){
						foreach ($memcache_cache['host'] as $key=>$item){
							$m_temp[] = array(
								'host'=>$item,
								'port'=>$memcache_cache['port'][$key],
							);
						}
						$_SESSION['etag_memcache'] = $m_temp;
					}else{
						unset($_SESSION['etag_memcache']);
					}
					$url = strtolower($_POST['site']['site_domain']);
					$localhost = false;
					$can_go = true;
					if(strstr($url,'localhost')){
						$localhost = true;
						$can_go = false;
					}
					$temp = array();
					$db_cfg_data = $post['db'];
					$admin_pass = true;
					$admin_pass_length = true;
					$site_domain = true;
					$site_name = true;
					$filled_admin_pass = true;
					$db_host = $db_cfg_data['db_host'];
					$db_user = $db_cfg_data['db_user'];
					$db_pass = $db_cfg_data['db_pass'];
					$db_name = $db_cfg_data['db_name'];
					$db_port = $db_cfg_data['db_port'];
					$con = @mysql_connect($db_host.':'.$db_port,$db_user,$db_pass);
					if($con){
						$select_db = @mysql_select_db($db_name,$con);
						if(!$select_db){
							$create_base = @mysql_query("CREATE DATABASE `$db_name`;",$con);
							if($create_base){
								$select_db = true;
							}else{
								$can_go = true;
							}
						}
					}else{
						$can_go = false;
					}
					$admin = $post['admin'];
					foreach ($admin as $key){
						if(empty($key))$can_go = false;
					}
					if(empty($admin['pass']) || empty($admin['repass'])){
						$filled_admin_pass = false;
						$can_go = false;
					}
					if($admin['pass']!=$admin['repass']){
						$admin_pass = false;
						$can_go = false;
					}
					if(strlen($admin['pass'])<6){
						$admin_pass_length = false;
						$can_go = false;
					}
					$site = $post['site'];
					if(empty($site['site_domain'])){
						$site_domain = false;
						$can_go = false;
					}
					if(empty($site['site_name'])){
						$site_name = false;
						$can_go = false;
					}
					if(!$can_go){
						$this->assign(array(
							'localhost'=>$localhost,
							'db_con'=>$con,
							'filled_admin_pass' => true,
							'db_select_db'=>$select_db,
							'admin_pass'=>$admin_pass,
							'admin_pass_length'=>$admin_pass_length,
							'site_domain'=>$site_domain,
							'site_name'=>$site_name,
							'action'=>'db_check_res',
						));
						$this->tpl->display('index.php');
						exit();
					}else{
						location('index.php?action=install');
					}
				}
				$url = get_site_url(FALSE);
				$site_host = $_SESSION['temp_post']['site']['site_domain'];
				if(empty($site_host)){
					$site_host ='http://'.array_shift(explode('/install/',$url)).'/';
				}
				$this->assign(array(
					'site_host'=>$site_host,
					'data'=>$_SESSION['temp_post'],
					'title'=>'���ݿ�����',
					'action'=>'do_db',
				));
				break;
			case 'ok':/*��ɰ�װ*/
					$this->assign(array(
						'action'=>'install_ok'
					));
				break;
			case 'install':
				ob_flush();
				flush();
				$session_temp = $_SESSION['temp_do_db'];
				$save_model = $session_temp['session_save_model'];
				$save_model = empty($save_model)?'file':$save_model;
				$memcache_cache = $session_temp['memcache'];
				$mem_time = $session_temp['memcached_connect_time'];
				if(empty($session_temp))alert_goto('����д������!', 'index.php?action=db');
				if($save_model=='memcache'){
					$mem_time = empty($mem_time)?100:$mem_time;
					foreach ($memcache_cache['host'] as $e){
						if(empty($e))alert_goto('������memcache������Host!');
					}
					foreach ($memcache_cache['port'] as $e){
						if(empty($e))alert_goto('������memcache�������˿�!');
					}
				}
				$this->assign(array(
					'title'=>'��װ����',
					'action'=>'install_db_data_page'
				));
				$this->tpl->display('index.php');
				ob_flush();
				flush();
				$db_cfg = $session_temp['db'];
				$site_cfg = $session_temp['site'];
				$db_host = $db_cfg['db_host'];
				$db_port = $db_cfg['db_port'];
				$db_user = $db_cfg['db_user'];
				$db_pass = $db_cfg['db_pass'];
				$db_name = $db_cfg['db_name'];
				$db_prefix = $db_cfg['db_prefix'];
				$config_site_name = $site_cfg['site_name'];
				$config_site_domain = $site_cfg['site_domain'];
				$config_site_mail = $site_cfg['admin_re_mail'];
				$config_site_mobile = $site_cfg['admin_re_phpone'];
				$tpl_upload_pass = $site_cfg['tpl_upload_pass'];
				/*����SESSIONĿ¼*/
				if(empty($db_host) || empty($db_port) || empty($db_user) || empty($db_pass) || empty($db_name) || strlen($tpl_upload_pass)<1){
					return alert_goto('������Ϣ����,����!', 'index.php?action=db');	
				}
				$replace_item = array(
					$db_host,
					$db_port,
					$db_user,
					$db_pass,
					$db_name,
					$db_prefix,
					$tpl_upload_pass,
					$save_model
				);
				$is_use_test_data = $session_temp['site']['is_use_test_data'];
				$adminpassword = $session_temp['admin']['repass'];
				$adminname = $session_temp['admin']['user_name'];
				$letters = array(
					'php188_db_host',
					'php188_db_port',
					'php188_db_user',
					'php188_db_password',
					'php188_db_name',
					'php188_db_prefix',
					'php188_template_upload_pass',
					'php188_session_save_model'
				);
				$is_rewrite = $session_temp['site']['is_rewrite'];
				$is_rewrite = $is_rewrite=='1'?true:false;
				$data = str_replace($letters, $replace_item, file_get_contents(INSTALL_PATH.'data/php.config.php'));
				if($save_model=='memcache'){
$estring = '';
$m_temp = array();
foreach ($memcache_cache['host'] as $key=>$item){
	$m_temp[] = "\$GLOBALS['MEMCACHE']['SERVERS'][] = '".$item.':'.$memcache_cache['port'][$key]."';";
}
$estring .= "define('USE_MEMCACHED_CACHE',true);\n";
$estring.=join("\r\n",$m_temp);
$estring.="\n\$GLOBALS['MEMCACHE']['CONNETC_TIME'] =".$mem_time.";";
$data = str_replace('?>',$estring."\n?>",$data);
				}else{
$tstring="define('USE_MEMCACHED_CACHE',false);/*�Ƿ�ʹ��memecached�������  Ĭ�Ϲر�*/
\$GLOBALS['MEMCACHE']['SERVERS'][] = '192.168.1.188:11211';
\$GLOBALS['MEMCACHE']['SERVERS'][] = '192.168.1.7:11211';
\$GLOBALS['MEMCACHE']['CONNETC_TIME'] =100;/*����ʱ��*/";
$data = str_replace('?>',$tstring."\r\n ?>",$data);
				}
				$file = ROOT_PATH.'php.config.php';
				$res = create_file($data,$file);
				$sqldata = @file_get_contents(INSTALL_PATH.'data/sql/structure.sql');
				$sqldata = str_replace(' `php_', ' `'.$db_prefix, $sqldata);
				$sqlarr = array_filter(split(';', $sqldata));
				if(!is_file($file))alert_goto('�����������ļ�,�����Ŀ¼�Ƿ��д!', 'index.php?action=db');
				@include($file);
				$db = phpDb::getInstance();
				foreach ($sqlarr as $query_item){
					if(!empty($query_item)){
			        	$sql = $this->_preg_match_sql($query_item,'GBK');
			        	if(is_array($sql)){
			        		$sql = $sql[0];
			        		$name = preg_replace("~CREATE\\s+TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?(`?)(\\w+)\\1.*~is", "\\2", $sql);
				        	$msg = '���ڴ������ݱ� ' . $name . ' -----�ɹ�';
			        		$this->_out_flush($msg);
			        	}
			        	$sql = trim($sql);
			        	if($sql)$db->query($sql);
					}
				}
        		$msg = '���ݱ������ɹ� , ��ʼ��������';
	        	$this->_out_flush($msg);
				/*����ϵͳĬ������*/
				$sqldata = file_get_contents(INSTALL_PATH . 'data/sql/default_value.sql');
				$sqldata = str_replace(' `php_', ' `'.$db_prefix, $sqldata);
				$sqlarr = array_filter(split(";[\r\n]", $sqldata));
					/*д��ϵͳĬ���Դ�������*/
					foreach ($sqlarr as $query_item){
						$query_item = trim($query_item);
						if(!empty($query_item)){
							$name = preg_replace("~INSERT\\s+INTO\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?(`?)(\\w+)\\1.*~is", "\\2", $query_item);
							$msg = '������ ' . $name . ' ���������� -----�ɹ�';
							$this->_out_flush($msg);
							$db->query($query_item);
						}
					}
			       $this->_out_flush('��ʼ����װ��ɹ�');
					$this->_out_flush('д��ϵͳ������Ϣ');
			        		/* ����������Ϣ��������*/
							$site_config = $db->fetch("SELECT * FROM `##__core_setting` WHERE `s_name` = 'siteBase'",true);
							$default_setting = unserialize_deep($site_config['s_data']);
							$default_setting['siteurl'] = $config_site_domain;
							$default_setting['sitename'] = $config_site_name;
							$default_setting['url_rewrite'] = $is_rewrite?'1':'0';
						/*��ʹ�ò������ݾͲ�д���õײ�������Ϣ��*/
						if(empty($is_use_test_data))$default_setting['footer_info'] = 'ϵͳ�ײ���Ϣ,�뵽��̨->ϵͳ����->�ײ���Ϣ���޸�';
					    $core_setting_data = array(
							's_data'=>serialize_deep($default_setting),
							's_ctime'=>time(),
							's_etime'=>time()
					     );
						$db->update($core_setting_data,'core_setting',array('s_name' => 'siteBase'));
						/*��̬����*/
						$html_set = $db->fetch("SELECT * FROM ##__core_setting WHERE `s_name` = 'html' ",true);
						$html_config = unserialize_deep($html_set['s_data']);
						$html_config['article_domain'] =  '';
						$html_config['help_domain'] = '';
						$html_config_data = array(
								's_data'=>serialize_deep($html_config),
								's_ctime'=>time(),
								's_etime'=>time()
						 );
						$db->update($html_config_data,'core_setting',array('s_name'=>'html'));
						/*������������*/
						/*
						$db->query("UPDATE `##__region` SET `thumb` = '',`alias_name` = '',`sign` = '',`html_extend` = '' ");
						$db->query("UPDATE `##__region_locate` SET `extend_data` = '' ");
						*/
						$db->query("DELETE FROM `##__core_group` WHERE `is_system` != '1'");
						$db->query("ALTER TABLE `##__core_group` AUTO_INCREMENT = 1");
						/*���ù���Ա��������*/
						$to_amdin_set = $db->fetch("SELECT * FROM `##__core_setting` WHERE `s_name` = 'toadmin' ",true);
						$admin_send_set = unserialize_deep($to_amdin_set['s_data']);
						$admin_send_set['admin_email'] = $config_site_mail;
						$admin_send_set['admin_mobile'] = $config_site_mobile;
						$html_send_data = array(
								's_data'=>serialize_deep($admin_send_set),
								's_ctime'=>time(),
								's_etime'=>time()
						 );
						 $db->update($html_send_data,'core_setting',array('s_name'=>'toadmin'));
						 $tpl_data = array(
						 	's_data'=>serialize_deep('attire'),
						 	's_ctime'=>time(),
						 	's_etime'=>time(),
						 );
						 $db->update($tpl_data,'core_setting',array('s_name'=>'site_template'));
						/*���ӹ���Ա*/
						$_SESSION['temp_insall_user'] = array(
							'u'=>$adminname,
							'p'=>$adminpassword
						);
						$adminpassword = md5(trim(str_encode($adminpassword)));
						$sql_data =array(
							'manager_name'=>$adminname,
							'manager_pass'=>$adminpassword,
							'manager_menu'=>'',
							'group_id'=>'1',
							'is_orgin'=>'1',
						);
						$db->insert($sql_data,'core_manager');
					       	/*��װ��������*/
						if(!empty($is_use_test_data)){
				        	$msg = '��ʼװ���������';
				        	$this->_out_flush($msg);
				   			/*��ȡ��ʼ������*/
							$sqldata = file_get_contents(INSTALL_PATH . 'data/sql/test_data.sql');
							$sqldata = str_replace(' `php_', ' `'.$db_prefix, $sqldata);
							$sqlarr = split(";[\r\n]", $sqldata);
							$sqlarr = array_filter($sqlarr);
							foreach ($sqlarr as $query_item){
								$query_item = trim($query_item);
								if(!empty($query_item)){
									$name = preg_replace("~INSERT\\s+INTO\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?(`?)(\\w+)\\1.*~is", "\\2", $query_item);
									$msg = '������ ' . $name . ' ������������� -----�ɹ�';
						        	$this->_out_flush($msg);
						        	$db->query($query_item);
								}
							}
				        	$msg = '�������ݰ�װ�ɹ�';
				        	$this->_out_flush($msg);
				        	/*�ƶ����������ļ�*/
							$this->_move_data();
						}
						/*���� install.lock �ļ�*/
						$lock_file = ROOT_PATH . 'shopdata/install.lock';
						$str  = 'installed at '.date("Y-m-d H:i:s");
						create_file($str,$lock_file);
						$this->_out_flush('��װ��ϣ�ллʹ�ã�����������');
						unset($_SESSION['temp_do_db'],$_SESSION['temp_post'],$_SESSION['etag_memcache']);
			        	$this->_clear();
			        	echo "<script  type='text/javascript'>$('#finished').attr('disabled',false);</script>";
			        	echo "<script  type='text/javascript'>window.location.href='index.php?action=ok'</script>";
						exit();
				break;
			default:
			$cp_data = file(ROOT_PATH.'shopdata/agreement.txt');
			array_shift($cp_data);
			$str = '';
			foreach ($cp_data as $tag){
				$str.='<p>'.$tag.'</p>';
			}
			$cp_data = $str;
			$this->assign(array(
				'title'=>'��ȨЭ��',
				'cp_data'=>$cp_data,
				'action'=>'default_index'
			));
		}
		$this->tpl->display('index.php');
	}
}
php188Install::getInstance()->run();
?>