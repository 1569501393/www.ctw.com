<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>{$title|default:'��װ��'}</title>
<script type="text/javascript" src="../shopdata/js/jquery-1.3.2.min.js"></script>
<style type="text/css">
body{margin:0px;padding:0px;font-size:12px;background-color:#FFF;}
#main{width:980px;background-color:#FFF;margin:0px auto;padding:5px; margin-top:10px;}
.t1{ border-bottom:2px solid #E76B06; margin-bottom:10px;}
.t1 td{ font-size:16px;font-weight:bold; color:#999;}
.t1 td span{color:#333;display:block}
.t2{border:1px solid #CCC;}
.form_input{ background:url(images/bg-input.png) no-repeat scroll left top #FFFFFF; width:250px; padding:2px; border:1px solid #A7A6AA; height:23px; line-height:24px;}
.form_input:focus,textarea:focus,input[type=text]:focus,input[type=password]:focus,.bg_input:focus{ background-color:#FFFFD9;}
#cp{width:965px;height:400px; overflow:hidden;overflow-y:scroll;border:1px solid #CCC; padding:8px;font-size:12px;line-height:160%; background:none; font-size:14px; line-height:160%;}
#cp p{ line-height:20px;text-indent:28px; padding:0px; margin:0px;}
.btn{ height:25px; color:#000;}
.cp_desc{text-align:center;padding:5px;margin:10px;}
.red{ color:#C00; font-size:14px;}
.table_list{ font-size:12px; border-collapse:collapse; width:100%;}
.table_list .a{border-bottom:1px   solid  #CCC; height:25px; line-height:25px; font-size:16px; color:#E76B06; padding-left:40px;}
.table_list td{ border-bottom:1px solid #EDEDED; padding:5px 5px; color:#333; font-size:14px;}
.table_list .one{ font-size:14px;text-align:right;width:200px; padding-right:20px;}
.table_list .green{ font-size:16px; color:#7AAA33; font-family:Verdana, Geneva, sans-serif;}
.table_list .red{font-size:16px; color:#F00;font-family:Verdana, Geneva, sans-serif;}

.form_select{ width:210px;}
.empty_input_val{background-color: #FFFFD9;}
#data_check p{ line-height:20px; font-size:14px; color:#F00;}
#php188_install_msg{ height:200px;width:973px;font-size:12px;}
#install_ok{}
#copyright{width:980px margin:0px auto;text-align:center;margin-top:10px;}
.notice_msg{ border:1px solid  #369; line-height:20px; padding:8px; margin:8px; color:#369; font-size:14px;}
.notice_msg p{ font-size:14px; color:#369; line-height:18px;}
.notice_msg .red{ color:#F00;}
.mem_menu{margin:5px; border:1px solid #D7DEEA; border-left:none; border-right:none; padding:8px; padding-left:250px;}
.mem_menu a{ font-weight:bold;}
a{ color:#333; font-size:13px; text-decoration:none;}
.memcacheed{ clear:both; display:block; height: auto; padding-left:50px; border-bottom:1px solid #D7DEEA;}
.memcacheed .tb{ clear:both; height:30px; line-height:30px;}
.memcacheed span{ float:left; margin:2px 7px;height:30px; line-height:20px;}
.memcacheed .n{ text-align:right; width:140px;}
.memcacheed .s{ padding-left:35px;}
</style>
</head>
<body>
<div id="main">
<!--#default_index start-->
{if $action eq 'default_index'}
	<table width="980" border="0" align="center" cellpadding="0" cellspacing="0" class="t1">
  <tr>
    <td height="39" align="center"><span>1.ע��Э��</span></td>
    <td align="center">2.�������</td>
    <td align="center">3.�������ݿ�</td>
    <td align="center">4.���ݼ����</td>
    <td align="center">5.��װ����</td>
    <td align="center">6.��װ���</td>
    </tr>
</table>
	<div name="cp" id="cp">{$cp_data}</div>
	<div class="cp_desc">
    	<input class="btn" type="button" value="ͬ ��"  onclick="window.location.href='index.php?action=check'" /> <input class="btn" type="button" value="��ͬ��"  onclick="close_window();"/>
    </div>

<script type="text/javascript">
	function close_window(){
		try{
			window.parent.top.close();	
		}catch(e){
			alert(e);	
		}
	}
</script>
{/if}
<!--#default_index end-->

<!--#check_install start-->
{if $action eq 'check_install'}
  <table width="980" border="0" align="center" cellpadding="0" cellspacing="0" class="t1">
  <tr>
    <td height="39" align="center">1.ע��Э��</td>
    <td align="center"><span>2.�������</span></td>
    <td align="center">3.�������ݿ�</td>
    <td align="center">4.���ݼ����</td>
    <td align="center">5.��װ����</td>
    <td align="center">6.��װ���</td>
    </tr>
</table>
  <table class="table_list" cellpadding="4" cellspacing="3" width="100%">
    <tr>
    	<td colspan="4" class="a">�ļ�Ȩ�޼��</td>
    </tr>
    <%
    	$a = array_chunk($this->get_var('check_list.file'),2);
        $this->assign('file',$a);
    %>
    	{foreach from=$file item='list'}
    	<tr>
        	{foreach from=$list item='f'}
        		<td>{$f.path|default:'/'}</td>
          	  	<td>{if $f.num}<samp class="green">�� </samp>{else}<samp class="red">��</samp>{/if}</td>
            {/foreach}
        </tr>
        {/foreach}
       <tr>
       	<td colspan="4" class="a">�������</td>
       </tr>
           <%
    	$a = array_chunk($this->get_var('check_list.fun'),2);
        $this->assign('funs',$a);
    %>
       {foreach from=$funs item='item'}
       		<tr>
            	{foreach from=$item item='fun'}
            	<td>{$fun.fun}</td>
                <td>{if $fun.mod}<samp class="green">��</samp>{else}<samp class="red">��</samp>{/if}</td>
                {/foreach}
            </tr>
       {/foreach}
       <tr>
       	<td colspan="4" class="a">���ܳ�ͻ��ģ��</td>
       </tr>
       {foreach from=$check_list.extension item='item'}
       		<tr>
            	<td>{$item.ext}</td>
                <td colspan="3">{if $item.mod}<samp class="red">��</samp>{else}<samp class="green">��</samp>{/if}</td>
            </tr>
       {/foreach}
    </table>
    <div class="cp_desc">
<input type="button"  class="btn" value="��һ��"  onclick="javascript:history.go(-1);" />
<input class="btn" type="button" value="��һ��" {if $can_not_next} onclick="window.location.href='index.php?action=db'" {else} style="color: #999;"{/if} /> 
    </div>
{/if}
<!--#check_install end-->
<!--action do_db start-->
{if $action eq 'do_db'}
<script  type="text/javascript">
function empty (string){
	return $.trim(string)==''?true:false;
}
function check_form_is_empty(form_class){
		var result = true;
		$("."+form_class).each(function(){
			var val = $(this).val();
			if(empty(val)){
				$(this).addClass('empty_input_val');
				result = false;
			}else{
				$(this).removeClass('empty_input_val');
			}
		});
	return result;
}
	$(function(){
		$("#save_form").submit(function(){
			var flag = check_form_is_empty('must_fill_in');
			if(!flag)return false;
			var pass = $("#admin_pass").val();
			var pass2 = $("#admin_pass2").val();
			if(pass!=pass2){
				$("#admin_pass").addClass('empty_input_val');
				$("#admin_pass2").addClass('empty_input_val');
				alert('�������벻һ��!');return false;
			}else{
				$("#admin_pass").removeClass('empty_input_val');
				$("#admin_pass2").removeClass('empty_input_val');	
			}
			if(pass.length<6){
				alert('����Ա���볤�ȱ�����ڵ���6λ!');
				$("#admin_pass").addClass('empty_input_val');
				$("#admin_pass2").addClass('empty_input_val');
				return false;
			}else{
				$("#admin_pass").removeClass('empty_input_val');
				$("#admin_pass2").removeClass('empty_input_val');		
			}
		});
	});
</script>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0" class="t1">
  <tr>
    <td height="39" align="center">1.ע��Э��</td>
    <td align="center">2.�������</td>
    <td align="center"><span>3.�������ݿ�</span></td>
    <td align="center">4.���ݼ����</td>
    <td align="center">5.��װ����</td>
    <td align="center">6.��װ���</td>
    </tr>
</table>
<form method="post" action="index.php?action=db" id="save_form">
<table  class="table_list" cellpadding="4" cellspacing="3" width="100%">
    	<tr>
        	<td colspan="4" class="a">���ݿ�����</td>
        </tr>
    	<tr>
        	<td class="one">���ݿ������</td>
            <td><input type="text" value="{$data.db.db_host|default:'localhost'}" name="db[db_host]" id="db_host" class="form_input must_fill_in db_must_in"/><samp class="red"> * </samp></td>
        </tr>
    	<tr>
        	<td class="one">���ݿ��û���</td>
            <td><input type="text" value="{$data.db.db_user}"  name="db[db_user]"  id="db_user" class="form_input must_fill_in db_must_in"/><samp class="red"> * </samp></td>
        </tr>
    	<tr>
        	<td class="one">���ݿ�����</td>
            <td><input type="text" value="{$data.db.db_pass}" name="db[db_pass]"  id="db_pass" class="form_input must_fill_in db_must_in"/><samp class="red"> * </samp></td>
        </tr>
    	<tr>
        	<td class="one">���ݿ�����</td>
            <td><input type="text" value="{$data.db.db_name}" name="db[db_name]" id="db_name"  class="form_input must_fill_in db_must_in"/><samp class="red"> * </samp></td>
        </tr>
    	<tr>
        	<td class="one">���ݿ�˿�</td>
            <td><input type="text" value="{$data.db.db_port|default:'3306'}"  id="db_port" name="db[db_port]"  class="form_input must_fill_in db_must_in"/><samp class="red"> * </samp></td>
        </tr>
        <tr>
        	<td class="one">���ݿ����ǰ׺</td>
            <td><input type="text" value="{$data.db.db_prefix|default:'php_'}" class="must_fill_in form_input db_must_in" name="db[db_prefix]"/><samp class="red"> * </samp></td>
        </tr>
        <tr>
            <td colspan="4">
            <script type="text/javascript">
            	function check_db_connect(obj){
					if(!check_form_is_empty('db_must_in'))return false;
					var opt = {
							db_host:$("#db_host").val(),
							db_user:$("#db_user").val(),
							db_pass:$("#db_pass").val(),
							db_port:$("#db_port").val(),
							db_name:$("#db_name").val()
						};
					$.get('?action=checkdbconnect',opt,function(data){
						switch(data){
							case 'OK':
								alert('���ݿ����ӳɹ�!�����Լ�������Ĳ���!');
							break;
							case 'ERROR_CONNECT':
								alert('����д�����ݿ��û������������!����...');
							break;
							case 'ERROR_SELECT':
								alert('����д�����ݿⲻ����,ϵͳ���Դ���ʧ��!');
							break;
							case 'EMPTY':
								alert('����д������!');
							break;
							default:alert(data);
						}
					});
				}
            </script>
           <div style="padding-left:225px;"> <input type="button" value="�������ݿ�����" onclick="check_db_connect(this);" /></div>
            <input type="hidden" value="file" name="session_save_model" />
            </td>
        </tr>
    <!--	<tr>
        	<td colspan="4" class="a">Session��������</td>
        </tr>
       <tr>
        	<td colspan="4">
            <div class="notice_msg">
				������Ӳ�̸�ʽΪfat32,����ʹ�����ݿ�ģʽ����memcachedģʽ.<br />ע��:ʹ��DBģʽ���������ݿ����!
                <br />
                ��ʹ��memcached ��session����ý��,��ϵͳ����Ҳ����memcached����!
           </div></td>
        </tr>
        <tr>
        	<td class="one"><samp class="red"> * </samp>Session����ģʽ</td>
           <td>
           <script type="text/javascript">
           	function set_session_save_model(obj){
				 var val = $(obj).val();
				 if(val=='memcache'){
					$(".memcache_pannel").show().find('input').attr('disabled',false);
					$(".mem_server").addClass('must_fill_in');
				 }else{
					$(".memcache_pannel").hide().find('input').attr('disabled',true);
					$(".mem_server").removeClass('must_fill_in');
				 }
			}
			function add_mem_server(obj){
				var s = $('.memcacheed').size();
				if(s>=3){
					return false;	
				}
				var cc = $(obj).parents('div').next().html();
				var d = '<div class="memcacheed">'+cc+'</div>';
				var p = $(obj).parent().parent('td');
				$(p).append(d).find('input').addClass('must_fill_in');
			}
			function delete_mem_server(obj){
				if($(".memcacheed").length>1){
					$(".memcacheed:last").remove();
				}
			}
           </script>
           <select name="session_save_model" onchange="set_session_save_model(this);">
           		<option value="file" {if $data.session_save_model eq 'file'} selected="selected"{/if}>�ļ�ģʽ</option>
           		<option value="db" {if $data.session_save_model eq 'db'} selected="selected"{/if}>���ݿ�ģʽ</option>	
           		<option value="memcache" {if $data.session_save_model eq 'memcache'} selected="selected"{/if}>memcachedģʽ</option>
           </select>
           </td>
        </tr>
        <tr class="memcache_pannel" style="display:{if $data.session_save_model neq 'memcache'}none{/if};">
        	<td class="one">�������ʱ��:</td>
            <td><input type="text" value="{$data.memcached_connect_time|default:'100'}" name="memcached_connect_time" class="form_input mem_server" /> ��</td>
        </tr>
        <tr class="memcache_pannel" style="display:{if $data.session_save_model neq 'memcache'}none{/if};">
            <td colspan="4">
				 <div class="mem_menu"><a href="javascript:;" onclick="delete_mem_server(this);">ɾ��������</a>  <a href="javascript:;" onclick="add_mem_server(this);">���ӷ�����</a></div>
                 {if $smarty.session.etag_memcache}
                 {foreach from=$smarty.session.etag_memcache item=list}
            	<div class="memcacheed">
					<div class="tb"><span class="n">memcached������:</span><span class="s"><input type="text" value="{$list.host}"  class="form_input mem_server" name="memcache[host][]"/></span></div>
					<div class="tb"><span class="n">memcached�������˿�:</span><span class="s"><input type="text" value="{$list.port|default:'11211'}"  class="form_input mem_server" name="memcache[port][]"/></span></div>
                </div>
                {/foreach}
                {else}
                  <div class="memcacheed">
					<div class="tb"><span class="n">memcached������:</span><span class="s"><input type="text" value=""  class="form_input mem_server" name="memcache[host][]"/></span></div>
					<div class="tb"><span class="n">memcached�������˿�:</span><span class="s"><input type="text" value="11211"  class="form_input mem_server" name="memcache[port][]"/></span></div>
                </div>
                {/if}
            </td>
        </tr>
    	<tr>-->
    	<tr>
        	<td colspan="4" class="a">����Ա����</td>
        </tr>
        <tr>
        	<td class="one">����Ա����</td>
           <td> <input type="text" value="{$data.admin.user_name}" name="admin[user_name]" class="must_fill_in form_input" /><samp class="red"> * </samp> </td>
        </tr>
        <tr>
        	<td class="one">����Ա����</td>
            <td><input type="text" value="{$data.admin.pass}"   id="admin_pass" class="must_fill_in form_input" name="admin[pass]"/> 
            <samp class="red"> * </samp> <span id="admin_notice">����6λ</span></td>
        </tr>
                <tr>
        	<td class="one">�ظ�����Ա����</td>
            <td><input type="text" value="{$data.admin.repass}"   id="admin_pass2" class="must_fill_in form_input" name="admin[repass]"/>
            <samp class="red"> * </samp> <span>����6λ</span></td>
        </tr>
    	<tr>
        	<td colspan="4" class="a">��վ��������</td>
        </tr>
        <tr>
        	<td class="one">��վ����</td>
          <td><input type="text" value="{$site_host}" name="site[site_domain]" class="must_fill_in form_input"/> <samp class="red"> * </samp>�벻Ҫʹ��localhost�ķ�ʽ��װ</td>
        </tr>
          <tr>
        	<td class="one">վ������</td>
            <td>
           	<input type="text" value="{$data.site.site_name}" name="site[site_name]"  class="must_fill_in form_input" /><samp class="red"> * </samp>
            </td>
        </tr>
        <tr>
        	<td class="one">����Ա�����ʼ�</td>
            <td>
           	<input type="text" value="{$data.site.admin_re_mail}" name="site[admin_re_mail]"  class="form_input must_fill_in" /><samp class="red"> * </samp>
            <br />
            <br />
            (��װ�ɹ��������޸��뵽�������->�ʼ���������->�ʼ�����,ϵͳ������һ�����Է��ŵ��˻�,����֤��ʱ��ʹ��)
            </td>
        </tr>
        <tr>
        	<td class="one">����Ա�����ֻ���</td>
          <td>
           	<input type="text" value="{$data.site.admin_re_phpone}" name="site[admin_re_phpone]"  class="form_input" /></td>
        </tr>
        <tr>
        	<td class="one">ģ���ϴ�����</td>
            <td><input type="text" value="{$data.site.tpl_upload_pass|default:'tpl_upload_pass'}" name="site[tpl_upload_pass]"  class="form_input must_fill_in" /><samp class="red"> * </samp></td>
        </tr>
        	<td class="one">�Ƿ�����α��̬</td>
            <td>
            <select name="site[is_rewrite]" class="form_select">
            	<option  value="0" {if $data.site.is_rewrite neq '1'} selected="selected"{/if}>������</option>
                <option value="1" {if $data.site.is_rewrite eq '1'} selected="selected"{/if}>����</option>	
            </select> apache��nginx���鿪��,IIS�����鿪��
            </td>
        </tr>
            <tr>
        	<td class="one">��װ��������</td>
            <td>
             <select name="site[is_use_test_data]" class="form_select">
            	<option  value="1" {if $data.site.is_use_test_data neq '0'} selected="selected"{/if}>ʹ�ò�������</option>
                <option value="0" {if $data.site.is_use_test_data eq '0'} selected="selected"{/if}>��ʹ�ò�������</option>	
            </select>
            </td>
        </tr>
    </table>
    <div class="cp_desc">
<input type="button"  class="btn" value="��һ��"  onclick="window.location.href='index.php?action=check'" />
   <input class="btn" type="submit" value="��һ��"   /> 
    </div>
  </form>
{/if}
<!--action do_db end-->
{if $action eq 'db_check_res'}
	<table width="980" border="0" align="center" cellpadding="0" cellspacing="0" class="t1">
  <tr>
    <td height="39" align="center">1.ע��Э��</td>
    <td align="center">2.�������</td>
    <td align="center">3.�������ݿ�</td>
    <td align="center"><span>4.���ݼ����</span></td>
    <td align="center">5.��װ����</td>
    <td align="center">6.��װ���</td>
    </tr>
</table>
	<div id="data_check">
    	{if $localhost}<p>�벻Ҫʹ��localhost��ʽ��װ,������127.0.0.1����!</p>{/if}
    	{if !$db_con}<p>�������ݿ�ʧ��!</p>{/if}
        {if !$db_select_db}<p>����ѡ�����ݿ�!</p>{/if}
        {if !$filled_admin_pass}<p>����Ա����Ϊ��!</p>{/if}
        {if !$admin_pass}<p>����Ա���벻һ��!</p>{/if}
        {if !$admin_pass_length}<p>����Ա���볤�ȹ���!</p>{/if}
 	    {if !$site_domain}<p>��վ����δ��!</p>{/if}
     	{if !$site_name}<p>��վ����δ��!</p>{/if}
    </div>
    <div class="cp_desc">
<input type="button"  class="btn" value="��������"  onclick="window.location.href='index.php?action=db'" />
    </div>
{/if}
<!--#db_check_res end-->
{if $action eq 'install_db_data_page'}
	<table width="980" border="0" align="center" cellpadding="0" cellspacing="0" class="t1">
  <tr>
    <td height="39" align="center">1.ע��Э��</td>
    <td align="center">2.�������</td>
    <td align="center">3.�������ݿ�</td>
    <td align="center">4.���ݼ����</td>
    <td align="center"><span>5.��װ����</span></td>
    <td align="center">6.��װ���</td>
    </tr>
</table>
    <div id="install_process">
<textarea id="php188_install_msg" style="height:350px;">loading...</textarea>
      <div class="cp_desc">
<input type="button"  class="btn" value="��һ��"  onclick="window.location.href='index.php?action=db'"  style="color:#999;"  disabled="disabled"/>
<input type="button"  class="btn" value="��һ��"  onclick="window.location.href='index.php?action=ok'" id="finished"  style="color:#999;" disabled="disabled"/>
    </div>
    </div>
<script type="text/javascript">
function show_install_msg(data){
	$("#php188_install_msg").val($("#php188_install_msg").val() + data + "\r\n");
}
</script>
{/if}
{if $action eq 'install_ok'}
	<table width="980" border="0" align="center" cellpadding="0" cellspacing="0" class="t1">
  <tr>
    <td height="39" align="center">1.ע��Э��</td>
    <td align="center">2.�������</td>
    <td align="center">3.�������ݿ�</td>
    <td align="center">4.���ݼ����</td>
    <td align="center">5.��װ����</td>
    <td align="center"><span>6.��װ���</span></td>
    </tr>
</table>
    <div id="install_ok" class="cp_desc">
<table width="100%" border="0" cellpadding="3" cellspacing="3" class="t2">
  <tr>
    <td height="26" colspan="2" align="left" style="border-bottom:1px solid #CCC;color:#F00; text-align:center; font-size:13px; line-height:18px;">��ϲ���ѳɹ���װPHP�̳�ϵͳ��������Ϣ�����ĺ�̨��½�ʺţ����μǣ�<br />��װ�ɹ�����ɾ��install�����ļ�����</td>
    </tr>
  <tr>
    <td width="42%" height="13" align="right">�����û����ǣ�</td>
    <td width="58%" align="left">{$smarty.session.temp_insall_user.u}</td>
  </tr>
  <tr>
    <td height="18" align="right">���������ǣ�</td>
    <td height="18" align="left">{$smarty.session.temp_insall_user.p}</td>
  </tr>
</table>
 	<p><input type="button" class="btn"  value="����ǰ̨" onclick="window.open('../')" /> <input type="button" value="���ʺ�̨" onclick="window.open('../admin')"  class="btn" />
      </p>
  </div>
{/if}
</div>
</body>
</html>