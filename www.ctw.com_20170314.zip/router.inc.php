<?php
return array(
		// 首页
		'index/index'=>'index',
		// 专辑
		'album/index'=>'album',
		// 促销活动
		'promo/index'=>'promo',
		//促销活动分类
		'promo/cate'=>'promo',
		// 返现商家
		'seller/index'=>'seller',
		// 返现商家分类
		'seller/cate'=>'seller',
		// 积分商城
		'exchange_goods/index'=>'exchange_goods',
        // 分类
        'cate/index'=>'cate',
       	//商品列表
        'item/index'=>'item',
		//文章详情
		'article/index'=>'article',
		//文章列表
		'articlelist/index'=>'articlelist',
		//标签列表
		'cate/tag'=>'tag',
);
?>