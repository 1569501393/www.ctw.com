<?php
return array ( 0 => 'list_id', 1 => 'cate_id', '_autoinc' => false, ); ?>