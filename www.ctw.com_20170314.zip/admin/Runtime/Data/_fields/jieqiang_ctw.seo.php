<?php
return array ( 0 => 'description', 1 => 'keywords', 2 => 'title', 3 => 'actionname', 4 => 'id', '_autoinc' => true, '_pk' => 'id', ); ?>