<?php
return array ( 0 => 'id', 1 => 'name', 2 => 'title', 3 => 'create_time', 4 => 'update_time', 5 => 'status', 6 => 'sort', '_autoinc' => true, '_pk' => 'id', ); ?>