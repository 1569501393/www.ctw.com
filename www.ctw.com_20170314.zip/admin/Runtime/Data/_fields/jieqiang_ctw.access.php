<?php
return array ( 0 => 'role_id', 1 => 'node_id', '_autoinc' => false, ); ?>