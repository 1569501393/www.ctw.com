<?php
return array ( 0 => 'id', 1 => 'name', 2 => 'status', 3 => 'remark', 4 => 'create_time', 5 => 'update_time', '_autoinc' => true, '_pk' => 'id', ); ?>