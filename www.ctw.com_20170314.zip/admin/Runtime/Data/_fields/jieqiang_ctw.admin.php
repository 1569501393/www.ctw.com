<?php
return array ( 0 => 'id', 1 => 'user_name', 2 => 'password', 3 => 'add_time', 4 => 'last_time', 5 => 'status', 6 => 'role_id', '_autoinc' => true, '_pk' => 'id', ); ?>