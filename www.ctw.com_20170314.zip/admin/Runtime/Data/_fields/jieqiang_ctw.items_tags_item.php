<?php
return array ( 0 => 'item_id', 1 => 'tag_id', '_autoinc' => false, ); ?>