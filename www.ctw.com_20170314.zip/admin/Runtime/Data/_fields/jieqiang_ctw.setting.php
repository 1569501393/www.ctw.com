<?php
return array ( 0 => 'name', 1 => 'data', '_autoinc' => false, ); ?>