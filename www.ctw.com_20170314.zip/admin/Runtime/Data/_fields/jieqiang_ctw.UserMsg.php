<?php
return array ( 0 => 'id', 1 => 'to_user', 2 => 'from_user', 3 => 'title', 4 => 'content', 5 => 'del', 6 => 'date', '_autoinc' => true, '_pk' => 'id', ); ?>