<?php
return array ( 0 => 'id', 1 => 'title', 2 => 'add_time', 3 => 'album_num', 4 => 'sort_order', 5 => 'status', '_autoinc' => true, '_pk' => 'id', ); ?>