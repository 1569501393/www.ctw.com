<?php
return array ( 0 => 'id', 1 => 'name', 2 => 'item_nums', 3 => 'status', 4 => 'seo_title', 5 => 'seo_keys', 6 => 'seo_desc', '_autoinc' => true, '_pk' => 'id', ); ?>