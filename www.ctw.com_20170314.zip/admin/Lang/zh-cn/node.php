<?php
return array(
    'module' => '模型 ',
    'module_name' => '模型名称',	
	'action'=>'操作',
	'action_name'=>'操作名称',
	'auth_type'=>'节点类型',
	'group_id'=>'分组',
	'data'=>'参数',
	'remark'=>'',
	'sort'=>'排序',
	'status'=>'状态',
	'operational'=>'操作',
	'id'=>'ID',
	'remark'=>'描述'
);
?>
