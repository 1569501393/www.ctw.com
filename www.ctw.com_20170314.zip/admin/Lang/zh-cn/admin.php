<?php
return array(
    'user_name' => '用户名',
    'password' => '密码',
    'repassword' => '确认密码',
	'role_id'=>'所属分组',
	'status'=>'审核状态',
	'id'=>'ID',
	'add_time'=>'开通时间',
	'last_time'=>'上次登陆',
	'status'=>'状态',
	'operational'=>'操作'
);
?>
