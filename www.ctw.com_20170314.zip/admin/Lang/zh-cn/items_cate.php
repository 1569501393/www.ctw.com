<?php
return array(
    'pid' => '上级分类',
    'name' => '分类名称',
    'img' => '商品图片 ',	
	'img'=>'分类图片',	
	'ordid'=>'排序值 ',
	'is_hots'=>'首页显示',
	'id'=>'分类ID',
	'keyword'=>'关键字',
	'recommend'=>'热门推荐',
);
?>