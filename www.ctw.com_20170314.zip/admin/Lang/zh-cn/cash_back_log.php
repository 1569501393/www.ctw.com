<?php
$array = array(	
	'username'=>'用户名',
	'shouzhi'=>'收支',
	'after_money'=>'最终剩余(元)',
	'in_money'=>'收入(元)',
	'out_money'=>'支出(元)',
	'info'=>'收支原因',
	'time'=>'时间'
		
);
return $array;
?>