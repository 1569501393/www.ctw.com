<?php
return array(
    'group_title' => '菜单分类名称',
    'group_name' => '分类标识',
    'sort' => '排序',
	'state'=>'审核状态',
	'group_title_require'=>'菜单分类名称不能为空',
	'group_sort_num'=>'排序必须是数字',
	'group_title_exist'=>'菜单分类名称已经存在',
	'no_delete_group'=>'请选择要删除的分类',
);
?>
