<?php
return array(
    'name' => '商家名称',    
    'sort' => '排序',
	'logo'=>'logo',
	'state'=>'状态',
	'url'=>'跳转url',
	'services'=>'services',
	'description'=>'商家描述',	
	'addb2cdata'=>'增加b2c数据',
	'site_logo'=>'本　地Logo',
	'net_logo'=>'网　络Logo',
	'url'=>'跳转URL',
	'recommend'=>'是否推荐',
	'services'=>'特色服务',
	'cash_back_rate'=>'返现率'
);
?>
