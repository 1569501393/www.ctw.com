<?php
return array(
    'id' => 'ID',
    'title' => '名称',  
	'last_time'=>'添加时间',
	'sort_order'=>'排序',	
	'status'=>'状态',
	'album_num'=>'专辑数量',
	'edit'=>'编辑'

);
?>
