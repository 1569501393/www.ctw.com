<?php
return array(
    'name' => '会员名称', 
	'relname'=>'真实姓名',
	'alipay'=>'支付宝账号',   
    'money' => '余额',
	'integral'=>'积分',
	'email'=>'会员邮箱',
	'sex'=>'性别',
	'img'=>'会员头像',
	'blog'=>'个人网址',
	'brithday'=>'出生日期',
	'address'=>'联系地址',
	'info'=>'会员简介',
	'status'=>'会员状态',
	'reg_time'=>'注册时间',
	'qq'=>'QQ',
	'last_time'=>'最后登录',
	'status'=>'状态',
	'operational'=>'操作',
	'id'=>'ID',
	'user_login_score'=>'每日登录送积分',
	'user_register_score'=>'注册送积分',
	'share_goods_score'=>'发布商品送积分',
	'delete_share_goods_score'=>'删除商品扣积分',
	
);
?>