<?php
return array(
    'word_cate_name' => '分类名称',
	'state'=>'审核状态',
	'word_cate_name_require'=>'分类名称不能为空',
	'word_cate_name_exist'=>'分类名称已经存在',
	'no_delete_word_cate'=>'请选择要删除的分类',
);
?>
