<?php
return array(
    'name' => '广告名称',    
    'url' => '广告链接',
	'board_id'=>'广告位',
	'type'=>'广告类型',
	'ad_text'=>'文字内容',
	'ad_code'=>'广告代码',
	'ad_image'=>'广告图片',
	'ad_flash'=>'广告动画',
	'start_time'=>'开始时间',
	'end_time'=>'结束时间',
	'status'=>'状态',
	'id'=>'ID',
	'clicks'=>'点击量',
	'ordid'=>'排序',
	'operational'=>'操作'
	
);
?>