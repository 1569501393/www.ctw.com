<?php
return array(
    'name' => '分类名称',    
    'sort' => '排序',
	'state'=>'状态',	
);
?>
