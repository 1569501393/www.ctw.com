<?php
return array(    
	'state'=>'审核状态',
	'banword_title_require'=>'关键词不能为空',
	'banword_title_exist'=>'关键词已经存在',
);
?>
