<?php
return array(
    'collect_url' => '商品地址',
    'title' => '商品名称',
    'sort' => '排序',
	'state'=>'审核状态',
	'cid'=>'所属分类',
	'img'=>'商品图片',
	'sid'=>'来源',
	'url'=>'链接地址',
	'tags'=>'标签',
	'price'=>'价格 ',
);
?>