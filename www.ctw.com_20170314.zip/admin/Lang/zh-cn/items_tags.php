<?php
return array(
    'name' => '标签名称',
);
?>