<?php
return array(
    'cate_id' => '所属分类',
    'title' => '名称',
    'url' => '链接地址',
	'img'=>'焦点图片',
	'ordid'=>'排序值',
	'abst'=>'资讯摘要',	
	'url'=>'链接地址',
	'tags'=>'标签',
	'price'=>'价格 ',
);
?>