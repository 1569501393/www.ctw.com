<?php
$array = array(	
	'data_name'=>'商品名称',
	'sn'=>'订单编号',
	'data_num'=>'数量',
	'integral'=>'兑换积分',
	'user_name'=>'会员名称',
	'status'=>'订单状态',
	'create_time'=>'下单时间',
	'update_time'=>'更新时间',
	'goods_status'=>'订单状态',
	'create_time'=>'下单时间',
	'zip'=>'邮政编码',
	'address'=>'地址',
	'email'=>'电子邮件',
	'mobile_phone'=>'手机号码',
	'fax_phone'=>'固定电话',
	'qq'=>'qq',
	'consignee'=>'收货人',	
	'order_score'=>'兑换积分',
	'remark'=>'备注信息',
    'msgtitle'=>'信息标题',
    'msgcontent'=>'信息内容',
    'ismsg'=>'是否发送信息',

);
return $array;
















?>