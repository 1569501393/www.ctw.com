<?php
return array(
    'name' => '导航名称',    
    'alias' => '导航别名',
	'url'=>'导航url',
	'type'=>'导航位置',
	'is_show'=>'是否显示',
	'in_site'=>'站内链接',
	'sort_order'=>'排序值',
	'ad_flash'=>'广告动画',
	'start_time'=>'开始时间',
	'end_time'=>'结束时间',
	'status'=>'状态',
	'id'=>'ID',
	'clicks'=>'点击量',
	'ordid'=>'排序',
	'operational'=>'操作'	,
	'category'=>'所属分类'
);
?>