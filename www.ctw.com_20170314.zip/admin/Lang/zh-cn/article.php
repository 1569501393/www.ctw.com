<?php
return array(
    'cate_id' => '资讯分类',
    'title' => '标题名称',
    'sort' => '排序',	
	'url'=>'链接地址',
	'cate_id'=>'所属分类',
	'orig'=>'内容来源',
	'img'=>'图片',
	'abst'=>'摘要简介',
	'time'=>'发布时间 ',
	'info'=>'详细内容',
	'is_hot'=>'热门推荐',
	'status'=>'状态',
	'ordid'=>'排序',
	'recommend'=>'推荐',
	'hot'=>'热门',
);
?>