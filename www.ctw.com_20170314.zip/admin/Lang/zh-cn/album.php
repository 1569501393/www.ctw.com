<?php
return array(
    'id' => 'ID',
    'title' => '名称',
    'cate_title' => '分类标题',
	'user'=>'用户',
	'last_time'=>'添加时间',
	'sort'=>'排序',
	'recommend'=>'推荐',
	'status'=>'审核',
);
?>
