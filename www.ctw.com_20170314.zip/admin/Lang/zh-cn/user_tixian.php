<?php
return array(
    'uname' => '交易用户',
    'money' => '提现金额',
    'remark' => '备注',
	'addtime'=>'提现时间',
	'ip'=>'提现人IP',	
	'status'=>'状态'
);
?>
