<?php
return array(
    'cate_id' => '链接分类',
    'name' => '链接名称',
    'url' => '链接地址',
	'img'=>'图片',
	'ordid'=>'排序值',
	'status'=>'审核状态 '
);
?>