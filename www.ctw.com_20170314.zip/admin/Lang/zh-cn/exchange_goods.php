<?php
$array = array(	
	'name'=>'名称',
	'goods_type'=>'商品类型',
	'goods_type_0'=>'实体商品',
	'goods_type_1'=>'虚拟商品',
	'img'=>'图片',
	'is_best'=>'推荐',
	'integral'=>'兑换积分',
	'stock'=>'库存',
	'begin_time'=>'开始时间',
	'end_time'=>'结束时间',
	'content'=>'描述',
	'buy_count'=>'已兑数量',
	'buy_date'=>'时间范围',
	'user_num'=>'每人限兑',
	'integral'=>'兑换积分',
	'state'=>'状态',
	'exchangegoods_title_require'=>'名称不得为空',	
);
return $array;
?>