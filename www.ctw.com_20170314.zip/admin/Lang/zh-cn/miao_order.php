<?php
$array = array(	
	'order_time'=>'下单时间',
	'seller_name'=>'商家名称',
	'username'=>'会员名称',
	'item_count'=>'数量（件）',
	'item_price'=>'单价',
	'is_best'=>'推荐',
	'commission'=>'佣金',
	'cash_back'=>'返现',
	'state'=>'状态',
	'order_code'=>'订单号'	
);
return $array;
?>