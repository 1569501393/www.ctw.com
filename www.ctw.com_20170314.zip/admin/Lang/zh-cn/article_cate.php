<?php
return array(
	'pid'=>'上级分类',
    'name' => '分类名称',
    'alias' => '分类别名',
    'sort_order' => '排序',	
	'status'=>'状态',
	'id'=>'分类ID',
	'artile_num'=>'资讯数',
	'sort'=>'排序值',
	'status'=>'审核',
	
);
?>