<?php
return array(
    'name' => '管理员组名',
    'remark' => '描述',	
	'id'=>'ID',
	'status'=>'状态',
	'operational'=>'操作'
);
?>
