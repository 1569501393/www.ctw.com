<?php
return array (
  'DB_HOST' => 'localhost',
  'DB_PWD' => 'root',
  'DB_NAME' => 'jieqiang_ctw',
  'DB_USER' => 'root',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'ctw_',
  'DEFAULT_THEME' => 'default',
  'TMPL_ACTION_SUCCESS' => 'public:success',
  'TMPL_ACTION_ERROR' => 'public:error',

 	// TODO jieqiangtest
//	'SHOW_PAGE_TRACE' => true, // 显示页面Trace信息

//	 'LOG_RECORD'            => true,   // 默认不记录日志
//    'LOG_TYPE'                 => 3, // 日志记录类型 0 系统 1 邮件 3 文件 4 SAPI 默认为文件方式
//    'LOG_LEVEL'                => 'EMERG,ALERT,CRIT,ERR',// 允许记录的日志级别
); 
?>