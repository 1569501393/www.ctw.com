<?php
return array(
  'name' => '矩形横幅',
  'option' => false,
  'allow_type' => array('text','image','code','flash'),
);