function loadjs(file){ 
	document.write("<script type='text/javascript' src='"+file+"'><\/script>");
}
loadjs(def.root+"statics/js/jquery/jquery-1.4.2.min.js");
loadjs(def.tmpl+"public/js/base64.js");
loadjs(def.root+"statics/js/jquery/plugins/jquery.cookie.js");
loadjs(def.root+"statics/js/artDialog5.0/source/artDialog.js");
loadjs(def.tmpl+"public/js/common.js");



