<?php
//000000000000a:1:{i:0;a:16:{s:2:"id";s:2:"11";s:7:"cate_id";s:1:"9";s:5:"title";s:29:"七夕到 鹊桥会 好礼送";s:4:"orig";s:0:"";s:3:"img";s:17:"502e0eec7af0a.jpg";s:3:"url";s:21:"?a=index&m=cate&cid=4";s:4:"abst";s:50:"七夕好礼，千万配饰商品等你来拿！
";s:4:"info";s:0:"";s:8:"add_time";s:19:"2012-03-17 12:16:33";s:5:"ordid";s:1:"2";s:6:"is_hot";s:1:"1";s:7:"is_best";s:1:"1";s:6:"status";s:1:"1";s:9:"seo_title";s:0:"";s:8:"seo_keys";s:0:"";s:8:"seo_desc";s:0:"";}}
?>