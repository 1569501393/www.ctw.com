<?php
//000000003600a:1:{i:0;a:7:{s:2:"id";s:1:"2";s:7:"cate_id";s:1:"1";s:3:"img";s:17:"4f8ceab7e6f6c.jpg";s:4:"name";s:12:"微购官网";s:3:"url";s:22:"http://www.wego360.com";s:6:"status";s:1:"1";s:5:"ordid";s:1:"1";}}
?>