<?php
//000000003600a:1:{i:0;a:6:{s:2:"id";s:1:"1";s:9:"click_url";s:0:"";s:4:"name";s:12:"街墙的店";s:8:"net_logo";s:0:"";s:9:"site_logo";s:36:"./data/seller_list/58a92c61aac4d.jpg";s:14:"cash_back_rate";s:2:"10";}}
?>