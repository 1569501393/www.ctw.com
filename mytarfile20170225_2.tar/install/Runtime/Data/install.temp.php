<?php
return array (
  'db_host' => 'localhost',
  'db_port' => '3306',
  'db_user' => 'root',
  'db_pass' => 'root',
  'db_name' => 'jieqiang_ctw',
  'db_prefix' => 'ctw_',
  'admin_user' => 'admin',
  'admin_pass' => 'admin',
  'admin_email' => 'jieqiang@jieqiang.com',
); 
?>